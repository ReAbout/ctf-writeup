#!/bin/sh
docker build --tag sslvpn:latest .
