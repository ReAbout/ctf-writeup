<?php

function _obf_lYqMiY2Mj4aIhouOlZOVjpI�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_k4yVh4iNjZOMk5OTiJWHiZA� = "";
$_obf_iIuTh4yVh4mShoiIiouMjIY� = array( 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 );
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keyorusername" );
if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] === FALSE || strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) < 3 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "380", "查询的信息为空或小于3个字符！" );
}
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = trim( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] );
$_obf_kIaHkJSNhpOPi5OSh4eJlIY� = array( );
$_obf_lI2HjIqUkYqTho2HiJWUk5I� = RNBR;
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['viewkey'] != 1 )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "381", "系统设置禁止查询注册卡！" );
    }
    if ( !_obf_jpOIlY_HlIaJi46IiYySiJU�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "382", "要查询的注册卡里仅能用的字符为[0..9a..zA..Z]！" );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    $_obf_jYaVkI6TlJGRipSPkIyRjYw� = strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] );
    if ( in_array( $_obf_jYaVkI6TlJGRipSPkIyRjYw�, $_obf_iIuTh4yVh4mShoiIiouMjIY� ) )
    {
        $_obf_jJOSkYeSjJSJkoaUkIaTkpI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_olddata where `oldkey`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `softcode`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softcode'] );
        if ( empty( $_obf_jJOSkYeSjJSJkoaUkIaTkpI� ) )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "383", "旧的注册卡号未找到！" );
        }
        $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = $_obf_jJOSkYeSjJSJkoaUkIaTkpI�['newkey'];
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_newkey'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'];
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "原卡是旧卡，新的卡号：VAL_newkey".RNBR;
    }
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) != 32 )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "384", "注册卡号长度错误！" );
    }
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 0, 10 )."' and `password`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 10, 10 )."' and `password2`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 20 )."'" );
    if ( !empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
    {
        if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "385", "注册卡被锁定！" );
        }
        if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['ispause'] )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "386", "注册卡被冻结！" );
        }
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "卡模式，已激活的注册卡".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "激活日期：VAL_activedate".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "到期日期：VAL_enddate".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　总天数：VAL_cday".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "剩余天数：VAL_sday".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　剩点数：VAL_points".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　通道数：VAL_linknum".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "绑定信息：VAL_bdinfo".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　标签：VAL_tag".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　附属性：VAL_extattr".RNBR;
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_activedate'] = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] );
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_enddate'] = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + 86400 * $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] );
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'];
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_sday'] = round( ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + 86400 * $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] - time( ) ) / 86400, 2 );
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_points'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'];
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_linknum'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'];
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_bdinfo'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo'];
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_tag'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['tag'];
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_extattr'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['keyextattr'];
    }
    else
    {
        $_obf_j46GkYaTj5KIkIyUh4aTjYs� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `keys`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 4, 6 )."' and `keyfix`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 0, 4 )."' and `keyspassword`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 10 )."'" );
        if ( empty( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "387", "注册卡未找到！" );
        }
        if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "385", "注册卡被锁定！" );
        }
        if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['ispause'] )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "386", "注册卡被冻结！" );
        }
        if ( 0 < $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cztime'] )
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "卡模式，注册卡已激活过，在激活表（用户表）中无记录（可能过期太久被作者删除，也可能是用户表异常需修复）".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "生成日期：VAL_adddate".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "激活日期：VAL_activedate".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　天数：VAL_cday".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　点数：VAL_points".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　通道数：VAL_linknum".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　标签：VAL_tag".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　附属性：VAL_extattr".RNBR;
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_adddate'] = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_j46GkYaTj5KIkIyUh4aTjYs�['addtime'] );
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_activedate'] = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cztime'] );
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_cday'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_points'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['points'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_linknum'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['linknum'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_tag'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['tag'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_extattr'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['keyextattr'];
        }
        else
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "卡模式，注册卡还未被使用".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "生成日期：VAL_adddate".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　天数：VAL_cday".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　点数：VAL_points".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　通道数：VAL_linknum".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　标签：VAL_tag".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　附属性：VAL_extattr".RNBR;
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_adddate'] = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_j46GkYaTj5KIkIyUh4aTjYs�['addtime'] );
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_cday'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_points'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['points'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_linknum'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['linknum'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_tag'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['tag'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_extattr'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['keyextattr'];
        }
    }
}
else
{
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    $_obf_jYaVkI6TlJGRipSPkIyRjYw� = strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] );
    if ( in_array( $_obf_jYaVkI6TlJGRipSPkIyRjYw�, $_obf_iIuTh4yVh4mShoiIiouMjIY� ) )
    {
        $_obf_jJOSkYeSjJSJkoaUkIaTkpI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_olddata where `oldkey`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `softcode`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softcode'] );
        if ( !empty( $_obf_jJOSkYeSjJSJkoaUkIaTkpI� ) )
        {
            $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = $_obf_jJOSkYeSjJSJkoaUkIaTkpI�['newkey'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_newkey'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'];
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "原卡是旧卡，新的卡号：VAL_newkey".RNBR;
        }
    }
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) == 32 )
    {
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['viewkey'] != 1 )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "381", "系统设置禁止查询注册卡！" );
        }
        if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) != 32 )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "384", "注册卡号长度错误！" );
        }
        $_obf_j46GkYaTj5KIkIyUh4aTjYs� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `keys`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 4, 6 )."' and `keyfix`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 0, 4 )."' and `keyspassword`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 10 )."'" );
        if ( empty( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "387", "注册卡未找到！" );
        }
        if ( 0 < $_obf_j46GkYaTj5KIkIyUh4aTjYs�['islock'] )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "385", "注册卡被锁定！" );
        }
        if ( 0 < $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cztime'] )
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "用户模式，注册卡已被使用过".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "生成日期：VAL_adddate".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "使用日期：VAL_activedate".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "充值帐号：VAL_czuser".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　天数：VAL_cday".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　点数：VAL_points".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　通道数：VAL_linknum".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　标签：VAL_tag".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　附属性：VAL_extattr".RNBR;
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_adddate'] = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_j46GkYaTj5KIkIyUh4aTjYs�['addtime'] );
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_activedate'] = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cztime'] );
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_czuser'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['czusername'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_cday'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_points'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['points'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_linknum'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['linknum'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_tag'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['tag'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_extattr'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['keyextattr'];
        }
        else
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "用户模式，注册卡还未被使用过".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "生成日期：VAL_adddate".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　天数：VAL_cday".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　点数：VAL_points".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　通道数：VAL_linknum".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　标签：VAL_tag".RNBR;
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　附属性：VAL_extattr".RNBR;
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_adddate'] = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_j46GkYaTj5KIkIyUh4aTjYs�['addtime'] );
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_cday'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_points'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['points'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_linknum'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['linknum'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_tag'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['tag'];
            $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_extattr'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['keyextattr'];
        }
    }
    else
    {
        $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'" );
        if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "388", "用户未找到！" );
        }
        if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "389", "用户被锁定！" );
        }
        if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['ispause'] )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "390", "用户被冻结！" );
        }
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "用户模式，查询用户成功".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "注册日期：VAL_adddate".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "激活日期：VAL_activedate".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "到期日期：VAL_enddate".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　总天数：VAL_cday".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "剩余天数：VAL_sday".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　点数：VAL_points".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　通道数：VAL_linknum".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "绑定信息：VAL_bdinfo".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　　标签：VAL_tag".RNBR;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "　附属性：VAL_extattr".RNBR;
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_adddate'] = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['addtime'] );
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_activedate'] = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] );
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_enddate'] = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + 86400 * $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] );
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'];
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_sday'] = round( ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + 86400 * $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] - time( ) ) / 86400, 2 );
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_points'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'];
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_linknum'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'];
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_bdinfo'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo'];
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_tag'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['tag'];
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_extattr'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['keyextattr'];
    }
}
_obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "391", $_obf_lI2HjIqUkYqTho2HiJWUk5I�, $_obf_kIaHkJSNhpOPi5OSh4eJlIY� );
?>
