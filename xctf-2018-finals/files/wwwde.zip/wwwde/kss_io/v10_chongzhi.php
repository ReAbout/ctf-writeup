<?php

function _obf_kouLiIaPjJWUhoqLkYaQjIg�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function zsarr_sort( $_obf_iJSNjIuPjoqSjYyUiIyIi5A�, $_obf_j4qUhoiVipWQj4iNh5CJj4w� )
{
    if ( $_obf_iJSNjIuPjoqSjYyUiIyIi5A�['num'] == $_obf_j4qUhoiVipWQj4iNh5CJj4w�['num'] )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "328", "作者在后台设置不正确：发现卡名相同充值张数相同的记录。" );
    }
    if ( $_obf_j4qUhoiVipWQj4iNh5CJj4w�['num'] < $_obf_iJSNjIuPjoqSjYyUiIyIi5A�['num'] )
    {
        return -1;
    }
    return 1;
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
if ( SVRID == 2 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "308", "备用服务器禁止对帐号充值！" );
}
$_obf_lYqUjoqMiomGlYiQio6Qi4Y� = array( );
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" );
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "czkey" );
if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] === FALSE )
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = "";
}
if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) == "" )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "309", "你好像没有输入要充值的用户名！" );
}
if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) < 3 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "310", "用户名长度小于3位。" );
}
if ( ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) + 1 ) % 33 != 0 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "311", "注册卡填写错误，长度必须32位，多张卡号请用英文逗号分隔。" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] != "USOFT" )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "312", "卡模式软件不能使用充值功能！" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 3 || $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 4 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "313", "软件已关闭用户充值功能！" );
}
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
$_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'" );
if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "314", "用户帐号未找到，无法充值。" );
}
if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "315", "用户帐号被锁定，无法充值。" );
}
if ( PETIME <= $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "316", "公用帐号不允许充值。（如果不是公用帐号可能是你的帐号有效期超出设定）" );
}
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] < PETIME )
{
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] * 86400;
}
$_obf_j42HkJGSkI6UhoaJlYuVk4k� = array(
    "username" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username'],
    "starttime" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'],
    "endtime" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'],
    "cztimes" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cztimes'],
    "cday" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'],
    "points" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'],
    "keyextattr" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['keyextattr'],
    "linknum" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'],
    "managerid" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['managerid'],
    "parentuser" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['parentuser']
);
$_obf_io6Jj4aRipKKkoiOi5SJi5U� = 1;
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] < $_obf_jomPk5WKioeLipGGi4_PhpM� )
{
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['starttime'] = $_obf_jomPk5WKioeLipGGi4_PhpM�;
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM�;
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = 0;
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] = "";
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] = 1;
    $_obf_jI6JkpSHj5SQkY2UiIeJkYc� = 9;
}
$_obf_jpSHk4yRh5CUiZKVkJSPkY8� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
$_obf_k5SGkIiQkJKPiIuUlYmHhow� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] = str_replace( ",", "|", $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] );
$_obf_kYiQkJKGlI6JlZWRioaKlYg� = explode( "|", $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] );
if ( 5 < count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "317", "每次最多可使用五张注册卡" );
}
$_obf_iJCHjZWRiJONk5OGlIqMipM� = array_unique( $_obf_kYiQkJKGlI6JlZWRioaKlYg� );
if ( count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) != count( $_obf_iJCHjZWRiJONk5OGlIqMipM� ) )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "318", "你输入的卡号有重复的。" );
}
$_obf_jIaRh4iNjpKMioaTjZWGkY4� = array( );
$_obf_ipGJkpOKioePjIaGkIuQiJA� = array( );
$_obf_jZCUjpOJiY6Iio_SiIyGk48� = array( );
$_obf_lZONjIiPhoiGk4_JkJKGlJU� = array( );
foreach ( $_obf_kYiQkJKGlI6JlZWRioaKlYg� as $_obf_io6UjZWThpOSjYeOj46Qkow� )
{
    $_obf_lIeHkoeKkpOSiomPi4mQk5E� = substr( $_obf_io6UjZWThpOSjYeOj46Qkow�, 4, 6 );
    $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = substr( $_obf_io6UjZWThpOSjYeOj46Qkow�, 0, 4 );
    $_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = substr( $_obf_io6UjZWThpOSjYeOj46Qkow�, 4, 6 );
    $_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = substr( $_obf_io6UjZWThpOSjYeOj46Qkow�, 10 );
    $_obf_jIaRh4iNjpKMioaTjZWGkY4�[] = substr( $_obf_io6UjZWThpOSjYeOj46Qkow�, 0, 4 );
}
$_obf_j46GkYaTj5KIkIyUh4aTjYs� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `keys` in ('".join( "','", $_obf_jZCUjpOJiY6Iio_SiIyGk48� )."') and isback=0" );
if ( empty( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "319", "注册卡未找到" );
}
if ( count( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) != count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) )
{
    $_obf_jY6MioyHj4iOi4aUjpOTkpQ� = array( );
    foreach ( $_obf_j46GkYaTj5KIkIyUh4aTjYs� as $_obf_lZSGkoqUio_RlZGNkY6Liok� )
    {
        $_obf_jY6MioyHj4iOi4aUjpOTkpQ�[] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['keys'];
    }
    foreach ( $_obf_jZCUjpOJiY6Iio_SiIyGk48� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
    {
        if ( !in_array( $_obf_io6UjZWThpOSjYeOj46Qkow�, $_obf_jY6MioyHj4iOi4aUjpOTkpQ� ) )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "320", "注册卡号VAL_errkey未找到。", array(
                "VAL_errkey" => $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�]
            ) );
        }
    }
}
$_obf_j5CIk4qSjZKKjImVkYmHh48� = 0;
$_obf_jpKNh4eVkY2Tio6RlZGMiI8� = 0;
$_obf_ipCMlJGQiY2ShoqQjImHlI0� = array( );
foreach ( $_obf_j46GkYaTj5KIkIyUh4aTjYs� as $_obf_lZSGkoqUio_RlZGNkY6Liok� )
{
    $_obf_lIeHkoeKkpOSiomPi4mQk5E� = $_obf_lZSGkoqUio_RlZGNkY6Liok�['keys'];
    $_obf_kJKGlYqQkoiHjYeVkIuKkYY� = $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�];
    if ( $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] != $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] || $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyspassword'] != $_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "321", "注册卡VAL_errkey错误。", array(
            "VAL_errkey" => $_obf_kJKGlYqQkoiHjYeVkIuKkYY�
        ) );
    }
    else
    {
        if ( $_obf_lZSGkoqUio_RlZGNkY6Liok�['islock'] != 0 )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "322", "注册卡VAL_errkey被锁定。", array(
                "VAL_errkey" => $_obf_kJKGlYqQkoiHjYeVkIuKkYY�
            ) );
        }
        if ( 0 < $_obf_lZSGkoqUio_RlZGNkY6Liok�['cztime'] )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "323", "注册卡VAL_errkey已使用过。", array(
                "VAL_errkey" => $_obf_kJKGlYqQkoiHjYeVkIuKkYY�
            ) );
        }
        if ( !isset( $_obf_ipCMlJGQiY2ShoqQjImHlI0�['keyextattr'] ) )
        {
            $_obf_ipCMlJGQiY2ShoqQjImHlI0�['keyextattr'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyextattr'];
            $_obf_ipCMlJGQiY2ShoqQjImHlI0�['linknum'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['linknum'];
            if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] != $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyextattr'] )
            {
                if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] == "" )
                {
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyextattr'];
                }
                else
                {
                    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "324", "你所使用的注册卡如原帐号的附属性不同，不允许使用。" );
                }
            }
            if ( $_obf_lZSGkoqUio_RlZGNkY6Liok�['linknum'] < $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "325", "你所使用的注册卡通道号小于原卡，不允许使用。" );
            }
            else
            {
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['linknum'];
            }
        }
        else
        {
            if ( $_obf_ipCMlJGQiY2ShoqQjImHlI0�['keyextattr'] != $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyextattr'] )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "326", "不同附属性的注册卡不能混在一起使用。" );
            }
            if ( $_obf_ipCMlJGQiY2ShoqQjImHlI0�['linknum'] != $_obf_lZSGkoqUio_RlZGNkY6Liok�['linknum'] )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "327", "不同通道数的注册卡不能混在一起使用。" );
            }
        }
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['onetimeskeyattrid'] == $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] )
        {
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "SELECT * from `kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `keys` like '".$_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix']."%' and cztype<2" );
            if ( !empty( $_obf_lY6RhpOJh46VkJOGkoeRiIY� ) )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "296", "VAL_errkey开头的注册卡每个帐号只能使用一张！", array(
                    "VAL_errkey" => $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix']
                ) );
            }
        }
        $_obf_j5CIk4qSjZKKjImVkYmHh48� += $_obf_lZSGkoqUio_RlZGNkY6Liok�['cday'];
        $_obf_jpKNh4eVkY2Tio6RlZGMiI8� += $_obf_lZSGkoqUio_RlZGNkY6Liok�['points'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + $_obf_lZSGkoqUio_RlZGNkY6Liok�['cday'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + $_obf_lZSGkoqUio_RlZGNkY6Liok�['points'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] + $_obf_lZSGkoqUio_RlZGNkY6Liok�['cday'] * 86400;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] + 1;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['managerid'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['managerid'];
    }
}
$_obf_ioyQkY6QhoeUjo6MjIaSkJM� = $_obf_j5CIk4qSjZKKjImVkYmHh48�;
$_obf_lI6Oh5CKh42Ri5STio2HjpE� = array( );
$_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",".$_obf_io6Jj4aRipKKkoiOi5SJi5U�.",'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_jpSHk4yRh5CUiZKVkJSPkY8�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_k5SGkIiQkJKPiIuUlYmHhow�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].",'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey']."','')";
$_obf_iZWHiZKQjpOJk5GKiJSPkpE� = 0;
$_obf_lIyIi5GQlYaNkIeIlI6LiIo� = 0;
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['zs_czset'] != "" )
{
    $_obf_lI_Jj4uGiZGPh5SUj4yNi4k� = array_unique( $_obf_jIaRh4iNjpKMioaTjZWGkY4� );
    $_obf_lJKNk5OTkYiOj4uTlI_JiYc� = json_decode( base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['zs_czset'] ), TRUE );
    foreach ( $_obf_lI_Jj4uGiZGPh5SUj4yNi4k� as $_obf_jo_SiI6SjIeSjoiMjoyTkpA� )
    {
        if ( isset( $_obf_lJKNk5OTkYiOj4uTlI_JiYc�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�] ) )
        {
            $_obf_i5OKioaRlY6TkIaGkZSGlIo� = 0;
            foreach ( $_obf_jIaRh4iNjpKMioaTjZWGkY4� as $_obf_io6UjZWThpOSjYeOj46Qkow� )
            {
                if ( $_obf_io6UjZWThpOSjYeOj46Qkow� == $_obf_jo_SiI6SjIeSjoiMjoyTkpA� )
                {
                    ++$_obf_i5OKioaRlY6TkIaGkZSGlIo�;
                }
            }
            uasort( &$_obf_lJKNk5OTkYiOj4uTlI_JiYc�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�], "zsarr_sort" );
            foreach ( $_obf_lJKNk5OTkYiOj4uTlI_JiYc�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�] as $_obf_jIyQkoaHk5OPiImPh4uUjYw� )
            {
                $_obf_jpSNkJSGhpGKiImJi4_LkJM� = floor( $_obf_i5OKioaRlY6TkIaGkZSGlIo� / $_obf_jIyQkoaHk5OPiImPh4uUjYw�['num'] );
                if ( !( $_obf_jpSNkJSGhpGKiImJi4_LkJM� == 0 ) )
                {
                    $_obf_i5OKioaRlY6TkIaGkZSGlIo� -= $_obf_jIyQkoaHk5OPiImPh4uUjYw�['num'] * $_obf_jpSNkJSGhpGKiImJi4_LkJM�;
                    $_obf_iZWHiZKQjpOJk5GKiJSPkpE� += $_obf_jIyQkoaHk5OPiImPh4uUjYw�['zsday'] * $_obf_jpSNkJSGhpGKiImJi4_LkJM�;
                    $_obf_lIyIi5GQlYaNkIeIlI6LiIo� += $_obf_jIyQkoaHk5OPiImPh4uUjYw�['zspoints'] * $_obf_jpSNkJSGhpGKiImJi4_LkJM�;
                }
            }
        }
    }
    $_obf_iJSNkomSi4qVlJOHlYuSi4k� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
    $_obf_k42Sho2GiIeHk42OjIaPipQ� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
    if ( $_obf_iZWHiZKQjpOJk5GKiJSPkpE� != 0 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + $_obf_iZWHiZKQjpOJk5GKiJSPkpE�;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] + $_obf_iZWHiZKQjpOJk5GKiJSPkpE� * 86400;
    }
    if ( $_obf_lIyIi5GQlYaNkIeIlI6LiIo� != 0 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + $_obf_lIyIi5GQlYaNkIeIlI6LiIo�;
    }
    if ( $_obf_iZWHiZKQjpOJk5GKiJSPkpE� != 0 || $_obf_lIyIi5GQlYaNkIeIlI6LiIo� != 0 )
    {
        $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values\t(".$_obf_jomPk5WKioeLipGGi4_PhpM�.",7,'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_iJSNkomSi4qVlJOHlYuSi4k�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_k42Sho2GiIeHk42OjIaPipQ�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].",'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey']."','')";
    }
}
$_obf_kIaHkJSNhpOPi5OSh4eJlIY� = array( );
$_obf_lI2HjIqUkYqTho2HiJWUk5I� = "";
$_obf_hpSOkJGOiZGNiJOPiY_ViZQ� = 0;
$_obf_kYuMjomSiYiHioePiYmQiIo� = 0;
$_obf_iJWQj5WQlY_NkYePk5OGjZM� = 0;
$_obf_iZOGi4uQkI2Uho_Lk5CPhpM� = 0;
$_obf_h4aOh4mKiZCUkoaIhouTiIg� = FALSE;
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['zs_tgset'] != "" && $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['parentuser'] != "" )
{
    $_obf_kI2Li4aJk4aMiIeSiIeUjIo� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['parentuser']."'" );
    if ( !empty( $_obf_kI2Li4aJk4aMiIeSiIeUjIo� ) )
    {
        $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['starttime'] + $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'] * 86400;
        if ( 0 < $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['islock'] || 0 < $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['ispause'] || $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] < $_obf_jomPk5WKioeLipGGi4_PhpM� )
        {
            $_obf_h4aOh4mKiZCUkoaIhouTiIg� = FALSE;
        }
        else
        {
            $_obf_h4aOh4mKiZCUkoaIhouTiIg� = TRUE;
            if ( PETIME <= $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] )
            {
                $_obf_h4aOh4mKiZCUkoaIhouTiIg� = FALSE;
            }
        }
    }
    if ( !$_obf_h4aOh4mKiZCUkoaIhouTiIg� )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['parentuser'] = "";
    }
}
if ( $_obf_h4aOh4mKiZCUkoaIhouTiIg� )
{
    $_obf_kpWRkZOIkYuNiIeTlIqPkpQ� = json_decode( base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['zs_tgset'] ), TRUE );
    foreach ( $_obf_jIaRh4iNjpKMioaTjZWGkY4� as $_obf_jo_SiI6SjIeSjoiMjoyTkpA� )
    {
        if ( !isset( $_obf_kpWRkZOIkYuNiIeTlIqPkpQ�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�] ) && !( $_obf_kpWRkZOIkYuNiIeTlIqPkpQ�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�]['cj'] == 2 ) )
        {
            $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� += $_obf_kpWRkZOIkYuNiIeTlIqPkpQ�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�]['zsday1'];
            $_obf_kYuMjomSiYiHioePiYmQiIo� += $_obf_kpWRkZOIkYuNiIeTlIqPkpQ�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�]['zspoints1'];
            $_obf_iJWQj5WQlY_NkYePk5OGjZM� += $_obf_kpWRkZOIkYuNiIeTlIqPkpQ�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�]['zsday2'];
            $_obf_iZOGi4uQkI2Uho_Lk5CPhpM� += $_obf_kpWRkZOIkYuNiIeTlIqPkpQ�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�]['zspoints2'];
        }
    }
    $_obf_iJSNkomSi4qVlJOHlYuSi4k� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
    $_obf_k42Sho2GiIeHk42OjIaPipQ� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
    if ( $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� != 0 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + $_obf_hpSOkJGOiZGNiJOPiY_ViZQ�;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] + $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� * 86400;
    }
    if ( $_obf_kYuMjomSiYiHioePiYmQiIo� != 0 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + $_obf_kYuMjomSiYiHioePiYmQiIo�;
    }
    if ( $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� != 0 || $_obf_kYuMjomSiYiHioePiYmQiIo� != 0 )
    {
        $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values \t(".$_obf_jomPk5WKioeLipGGi4_PhpM�.",4,'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_iJSNkomSi4qVlJOHlYuSi4k�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_k42Sho2GiIeHk42OjIaPipQ�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].",'','".$_obf_kI2Li4aJk4aMiIeSiIeUjIo�['username']."')";
    }
    $_obf_iI_QkZGJh4yRk4mIkYuOiYg� = array( );
    $_obf_iJSNkomSi4qVlJOHlYuSi4k� = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'];
    $_obf_k42Sho2GiIeHk42OjIaPipQ� = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'];
    if ( $_obf_iJWQj5WQlY_NkYePk5OGjZM� != 0 )
    {
        $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'] + $_obf_iJWQj5WQlY_NkYePk5OGjZM�;
        $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['endtime'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] + $_obf_iJWQj5WQlY_NkYePk5OGjZM� * 86400;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "推广帐号赠送VAL_pBday天";
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_pBday'] = $_obf_iJWQj5WQlY_NkYePk5OGjZM�;
    }
    if ( $_obf_iZOGi4uQkI2Uho_Lk5CPhpM� != 0 )
    {
        $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['points'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'] + $_obf_iZOGi4uQkI2Uho_Lk5CPhpM�;
        if ( $_obf_lI2HjIqUkYqTho2HiJWUk5I� == "" )
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "推广帐号赠送";
        }
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "VAL_pBpoints点";
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_pBpoints'] = $_obf_iZOGi4uQkI2Uho_Lk5CPhpM�;
    }
    if ( $_obf_iJWQj5WQlY_NkYePk5OGjZM� != 0 || $_obf_iZOGi4uQkI2Uho_Lk5CPhpM� != 0 )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_iI_QkZGJh4yRk4mIkYuOiYg�, "username='".$_obf_kI2Li4aJk4aMiIeSiIeUjIo�['username']."'", "sql" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
        {
            $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = $_obf_lY6RhpOJh46VkJOGkoeRiIY�;
        }
        $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",3,'".$_obf_kI2Li4aJk4aMiIeSiIeUjIo�['username']."',".$_obf_iJSNkomSi4qVlJOHlYuSi4k�.",".$_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'].",".$_obf_k42Sho2GiIeHk42OjIaPipQ�.",".$_obf_iI_QkZGJh4yRk4mIkYuOiYg�['points'].",'','".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."')";
    }
}
if ( 10001 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid'] && 0.5 < ( $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� + $_obf_iZWHiZKQjpOJk5GKiJSPkpE� ) / $_obf_ioyQkY6QhoeUjo6MjIaSkJM� )
{
    _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "329", "月付版客户的赠送天数不能超出卡面天数的50%[ VAL_zsday / VAL_kmday ]", array(
        "VAL_zsday" => $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� + $_obf_iZWHiZKQjpOJk5GKiJSPkpE�,
        "VAL_kmday" => $_obf_ioyQkY6QhoeUjo6MjIaSkJM�
    ) );
}
if ( $_obf_lI2HjIqUkYqTho2HiJWUk5I� != "" )
{
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "，";
}
$_obf_iIqGj4aSiJOUkY6HiYeGiYk� = "本帐号赠送";
if ( 0 < $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� + $_obf_iZWHiZKQjpOJk5GKiJSPkpE� )
{
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= $_obf_iIqGj4aSiJOUkY6HiYeGiYk�."VAL_Bday天";
    $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_Bday'] = $_obf_iZWHiZKQjpOJk5GKiJSPkpE� + $_obf_hpSOkJGOiZGNiJOPiY_ViZQ�;
    $_obf_iIqGj4aSiJOUkY6HiYeGiYk� = "";
}
if ( 0 < $_obf_kYuMjomSiYiHioePiYmQiIo� + $_obf_lIyIi5GQlYaNkIeIlI6LiIo� )
{
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= $_obf_iIqGj4aSiJOUkY6HiYeGiYk�."VAL_Bpoints点";
    $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_Bpoints'] = $_obf_lIyIi5GQlYaNkIeIlI6LiIo� + $_obf_kYuMjomSiYiHioePiYmQiIo�;
}
if ( $_obf_lI2HjIqUkYqTho2HiJWUk5I� != "" )
{
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "，";
}
$_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set `cztime`=".$_obf_jomPk5WKioeLipGGi4_PhpM�.",`czusername`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' where `keys` in ('".join( "','", $_obf_jZCUjpOJiY6Iio_SiIyGk48� )."')";
$_obf_kY2Qi5OGjImIh46TjZKNk48� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
if ( $_obf_kY2Qi5OGjImIh46TjZKNk48� !== TRUE )
{
    _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 309 );
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "330", "帐号充值失败！修改注册卡状态时出错VAL_sqlerr", array(
        "VAL_sqlerr" => $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )
    ) );
}
$_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sql" );
$_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
{
    if ( !empty( $_obf_lI6Oh5CKh42Ri5STio2HjpE� ) )
    {
        foreach ( $_obf_lI6Oh5CKh42Ri5STio2HjpE� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
        {
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, "sync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
            {
                _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 320 );
            }
        }
    }
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "本帐号时间VAL_Aday天";
    $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_Aday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "VAL_Apoints点。";
    $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_Apoints'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "332", "充值帐号成功，".$_obf_lI2HjIqUkYqTho2HiJWUk5I�, $_obf_kIaHkJSNhpOPi5OSh4eJlIY� );
}
else
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "331", "帐号充值失败！原因：VAL_sqlerr", array(
        "VAL_sqlerr" => $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )
    ) );
}
?>
