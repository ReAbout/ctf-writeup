<?php

function _obf_h46RkpCLhpGPiIiJioiJhog�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_iZSUk4_HkomRio2Li4iNj5A� = array( );
$_obf_iZSUk4_HkomRio2Li4iNj5A�['upset'] = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['ismustupdate'];
$_obf_iZSUk4_HkomRio2Li4iNj5A�['softver'] = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softversion'];
$_obf_iZSUk4_HkomRio2Li4iNj5A�['softdownurl'] = base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softdownurl'] );
$_obf_iZSUk4_HkomRio2Li4iNj5A�['yzpl'] = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['connectpenli'];
$_obf_iZSUk4_HkomRio2Li4iNj5A�['softgg'] = base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softnotice'] );
_obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "100", "取软件信息成功", $_obf_iZSUk4_HkomRio2Li4iNj5A� );
?>
