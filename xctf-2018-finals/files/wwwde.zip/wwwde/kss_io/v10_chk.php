<?php

function _obf_k42ThoiLh46GkIaVjIaQiIY�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_iZKGiImGiJSViYuIjpGPiYY�( &$_obf_ho6Mko_HjIeOjJKNjouNi44�, $_obf_h4ySh4aGiY6QlZKUh42Jh4g� )
{
    $_obf_jpGMh4uQipKJipKRlZSJkYk� = "__addExtData";
    if ( function_exists( "__addExtData" ) )
    {
        $_obf_jZSVhpSIj5STkJWIlJGVjos� = $_obf_jpGMh4uQipKJipKRlZSJkYk�( );
        if ( !empty( $_obf_jZSVhpSIj5STkJWIlJGVjos� ) || is_array( $_obf_jZSVhpSIj5STkJWIlJGVjos� ) )
        {
            foreach ( $_obf_jZSVhpSIj5STkJWIlJGVjos� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
            {
                if ( array_key_exists( $_obf_lIeHkoeKkpOSiomPi4mQk5E�, $_obf_ho6Mko_HjIeOjJKNjouNi44� ) )
                {
                    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "217", "__addExtData中你所附加的数据键名VAL_key已存在，不能重复添加数据键名", array(
                        "VAL_key" => $_obf_lIeHkoeKkpOSiomPi4mQk5E�
                    ) );
                }
                $_obf_ho6Mko_HjIeOjJKNjouNi44�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = $_obf_io6UjZWThpOSjYeOj46Qkow�;
            }
        }
    }
}

function _obf_j42JiI_RjZCHiIyKjZGUlYw�( $_obf_jZSVjouIlJSRk4eHkIqGjIc�, $_obf_jIaLhoqLj5GKkJSRjoaRkpA� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    global $_obf_lY_Pko2IhoyRj4qUkYqPlJU�;
    $_obf_hpKRiZSLipSLipCVlYaRioY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where id=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'] );
    $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = $_obf_hpKRiZSLipSLipCVlYaRioY�['mac_blacklist'];
    _obf_jZKTjJWKjpKUkoeJlZWGkZU�( $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    if ( $_obf_h46Mk5WRjJCTkJOKi4uUjoY� == "" )
    {
        $_obf_h42MkIiUiZWLi4aQioiHlYk� = array( );
    }
    else
    {
        $_obf_h42MkIiUiZWLi4aQioiHlYk� = explode( ",", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    }
    if ( $_obf_jZSVjouIlJSRk4eHkIqGjIc� != "InvalidSN" )
    {
        $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = $_obf_jZSVjouIlJSRk4eHkIqGjIc�.",".long2ip( $_obf_kYmJjZOIiZKJioqMkoaGiYk� );
        $_obf_iIuTk5CIjImHj5KNi4eOjZQ� = explode( ",", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    }
    else
    {
        $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = $_obf_jIaLhoqLj5GKkJSRjoaRkpA�.",".long2ip( $_obf_kYmJjZOIiZKJioqMkoaGiYk� );
        $_obf_iIuTk5CIjImHj5KNi4eOjZQ� = explode( ",", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
        $_obf_iIuTk5CIjImHj5KNi4eOjZQ� = array_diff( $_obf_iIuTk5CIjImHj5KNi4eOjZQ�, $_obf_ioiVhomLjJSHiYqRiJWOk4Y� );
    }
    $_obf_j46Vk4mIlZGUh5WPiYiSlZA� = array_merge( $_obf_h42MkIiUiZWLi4aQioiHlYk�, $_obf_iIuTk5CIjImHj5KNi4eOjZQ� );
    $_obf_j46Vk4mIlZGUh5WPiYiSlZA� = array_unique( $_obf_j46Vk4mIlZGUh5WPiYiSlZA� );
    $_obf_h5SGipOVjZORio_Lh42OlIs� = implode( ",", $_obf_j46Vk4mIlZGUh5WPiYiSlZA� );
    $_obf_h5SGipOVjZORio_Lh42OlIs� = trim( $_obf_h5SGipOVjZORio_Lh42OlIs�, "," );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_soft set `mac_blacklist`='".$_obf_h5SGipOVjZORio_Lh42OlIs�."' where id=".$_obf_hpKRiZSLipSLipCVlYaRioY�['id'], "sync" );
    $_obf_k4mMjZOVkpCRipSKlI2OiYg� = file_get_contents( $_obf_lY_Pko2IhoyRj4qUkYqPlJU� );
    $_obf_k4mMjZOVkpCRipSKlI2OiYg� = preg_replace( "/('mac_blacklist').*(\\n)/", "\$1 => '".mysql_real_escape_string( $_obf_h5SGipOVjZORio_Lh42OlIs� )."',\$2", $_obf_k4mMjZOVkpCRipSKlI2OiYg� );
    file_put_contents( $_obf_lY_Pko2IhoyRj4qUkYqPlJU�, $_obf_k4mMjZOVkpCRipSKlI2OiYg� );
}

function _rs( $_obf_kZGVkJWJkY2UipSKkJSGjYc� )
{
    global $_obf_iI2IjYyHkIyVkY_RiIqIi5U�;
    if ( isset( $_obf_iI2IjYyHkIyVkY_RiIqIi5U�[$_obf_kZGVkJWJkY2UipSKkJSGjYc�] ) )
    {
        return $_obf_iI2IjYyHkIyVkY_RiIqIi5U�[$_obf_kZGVkJWJkY2UipSKkJSGjYc�];
    }
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "268", "ADVAPI区未在资源字符串中找到_rs(VAL_i)，可能是ADVAPI字符串资源格式书写错误", array(
        "VAL_i" => $_obf_kZGVkJWJkY2UipSKkJSGjYc�
    ) );
}

function _obf_io_Mh4aMkouSiZGQiYmRjJM�( )
{
    global $_obf_jpOTkJCPjI_TipSPjoeTjYs�;
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    global $_obf_jYmJi42Gh42MhoqLkY_MlZM�;
    global $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    global $_obf_k5SIlJCMhoiIjJWMi5WLkY8�;
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    global $_obf_joeUio_LioqSh5WIiI2Pk4s�;
    $_obf_kYeVlJWTjYuNjoeSkYuPiZE� = explode( ",", _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "advapi" ) );
    $_obf_kpWTkImVh4yUiZGLlIuPiIk� = $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[0];
    if ( substr( $_obf_kpWTkImVh4yUiZGLlIuPiIk�, 0, 2 ) != "v_" )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "269", "advapi自定义接口函数只能以v_开头！" );
    }
    if ( !function_exists( $_obf_kpWTkImVh4yUiZGLlIuPiIk� ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "270", "advapi自定义接口函数未找到！" );
    }
    switch ( count( $_obf_kYeVlJWTjYuNjoeSkYuPiZE� ) )
    {
    case 1 :
        $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
        break;
    case 2 :
        $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
        break;
    case 3 :
        $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
        break;
    case 4 :
        $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
        break;
    case 5 :
        $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
        break;
    case 6 :
        $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[5], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
        break;
    case 7 :
        $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[5], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[6], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
        break;
    case 8 :
        $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[5], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[6], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[7], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
        break;
    case 9 :
        $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[5], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[6], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[7], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[8], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
        break;
    case 10 :
        $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[5], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[6], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[7], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[8], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[9], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
        break;
    default :
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "248", "advapi自定义接口最多支持9个参数！" );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 30 ), "not_sync" );
    return $_obf_kI_Gho_HjoqTk4mJiIuIh5M�;
}

function _obf_lJSVj4aKiIaUkJKUioiVjZQ�( $_obf_jJSNk5SMkY_PiouMko2LkYY� )
{
    global $_obf_jpOTkJCPjI_TipSPjoeTjYs�;
    global $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    global $_obf_kJSVj4qJlIyOi5SQiZKRiYk�;
    global $_obf_lIyRio6Kho6LiIaVkY_SiZA�;
    global $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    global $_obf_k5SIlJCMhoiIjJWMi5WLkY8�;
    if ( !isset( $_obf_lIyRio6Kho6LiIaVkY_SiZA� ) )
    {
        if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
        {
            $_obf_lIyRio6Kho6LiIaVkY_SiZA� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['lastip'];
            $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['pccode'];
        }
        else
        {
            $_obf_lIyRio6Kho6LiIaVkY_SiZA� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['lastip'];
            $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['pccode'];
        }
    }
    $_obf_j4yMjoyKj42Ti5STjo_HjIY� = "insert into kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`username`,`optype`,`clientid`,`addtime`,`ip`,`pccode`,`linecode`,`opccode`,`oip`) values ";
    $_obf_j4yMjoyKj42Ti5STjo_HjIY� .= "('"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."',".$_obf_jJSNk5SMkY_PiouMko2LkYY�.","._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" ).",".time( ).",".$_obf_kYmJjZOIiZKJioqMkoaGiYk�.",'"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" )."','"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "linecode" )."','".$_obf_kJSVj4qJlIyOi5SQiZKRiYk�."',".$_obf_lIyRio6Kho6LiIaVkY_SiZA�.")";
    return $_obf_j4yMjoyKj42Ti5STjo_HjIY�;
}

function _obf_h4_Tk4uIkIuMiYmUh42Jhoc�( $_obf_jJOSkYeSjJSJkoaUkIaTkpI�, $_obf_io2VjIiNkYqPj4iPiIuKk4k� )
{
    $_obf_kpKNjomRlYuUk4qLlI2MkJU� = "ab_".$_obf_io2VjIiNkYqPj4iPiIuKk4k�;
    if ( $_obf_jJOSkYeSjJSJkoaUkIaTkpI� == "" && function_exists( $_obf_kpKNjomRlYuUk4qLlI2MkJU� ) )
    {
        return $_obf_kpKNjomRlYuUk4qLlI2MkJU�( );
    }
    $_obf_jJOSkYeSjJSJkoaUkIaTkpI� = str_replace( "#time#", date( "Y-m-d H:i", time( ) ), $_obf_jJOSkYeSjJSJkoaUkIaTkpI� );
    return $_obf_jJOSkYeSjJSJkoaUkIaTkpI�;
}

function api_set( $_obf_h42RjJWNj5CGkYyGjpCJioo�, $_obf_iYyKk4eTjYuQlIqLiZWHkok� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    global $_obf_k5SIlJCMhoiIjJWMi5WLkY8�;
    global $_obf_kpOMjo6Mh4yUk42Uh4mNh4s�;
    global $_obf_jpOTkJCPjI_TipSPjoeTjYs�;
    $_obf_jI6OlImSkJKVjImHkIaUipA� = array( "锁" => "islock", "锁定" => "islock", "标签" => "tag", "备注" => "intro", "天数" => "cday", "点数" => "points", "开始时间" => "starttime", "到期时间" => "endtime", "附属性" => "keyextattr", "付属性" => "keyextattr", "机器码" => "pccode", "私有数据" => "updata", "绑定信息" => "bdinfo" );
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = FALSE;
    if ( !array_key_exists( $_obf_h42RjJWNj5CGkYyGjpCJioo�, $_obf_jI6OlImSkJKVjImHkIaUipA� ) )
    {
        return "par1err";
    }
    $_obf_iJGJjY2NkYqSkoqMho6Tio0� = mysql_real_escape_string( $_obf_iYyKk4eTjYuQlIqLiZWHkok� );
    switch ( $_obf_h42RjJWNj5CGkYyGjpCJioo� )
    {
    case "锁" :
    case "锁定" :
    case "标签" :
    case "备注" :
    case "天数" :
    case "开始时间" :
    case "到期时间" :
    case "点数" :
    case "附属性" :
    case "付属性" :
        $_obf_j4uUkJCTkIuMko6Vj5SSlYY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "UPDATE `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set `".$_obf_jI6OlImSkJKVjImHkIaUipA�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]."`='".$_obf_iJGJjY2NkYqSkoqMho6Tio0�."' where `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."' ", "sync" );
        if ( $_obf_j4uUkJCTkIuMko6Vj5SSlYY� !== TRUE )
        {
            $_obf_j4uUkJCTkIuMko6Vj5SSlYY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
        }
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_j4uUkJCTkIuMko6Vj5SSlYY�;
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    case "机器码" :
    case "私有数据" :
    case "绑定信息" :
        if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] == 1 )
        {
            $_obf_j4uUkJCTkIuMko6Vj5SSlYY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "UPDATE `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set `".$_obf_jI6OlImSkJKVjImHkIaUipA�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]."`='".$_obf_iJGJjY2NkYqSkoqMho6Tio0�."' where `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."'", "sync" );
        }
        else
        {
            $_obf_j4uUkJCTkIuMko6Vj5SSlYY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "UPDATE `kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set `".$_obf_jI6OlImSkJKVjImHkIaUipA�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]."`='".$_obf_iJGJjY2NkYqSkoqMho6Tio0�."' where `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."' and `clientid`=".$_obf_k5SIlJCMhoiIjJWMi5WLkY8�['clientid'], "sync" );
        }
        if ( $_obf_j4uUkJCTkIuMko6Vj5SSlYY� !== TRUE )
        {
            $_obf_j4uUkJCTkIuMko6Vj5SSlYY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
        }
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_j4uUkJCTkIuMko6Vj5SSlYY�;
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    }
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = FALSE;
    return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
}

function api_points( &$_obf_jYiMkoyVi5GOkY_NiIyKioc�, $_obf_iI_TiI_HjoiGj4eIkZSIjog�, $_obf_jYaTjpCOhpGOhoaJjpGKjpE� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    $_obf_jomPk5WKioeLipGGi4_PhpM� = time( );
    if ( $_obf_iI_TiI_HjoiGj4eIkZSIjog� < 0 )
    {
        $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "要扣的点数小于0";
        return FALSE;
    }
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'] < $_obf_iI_TiI_HjoiGj4eIkZSIjog� )
    {
        $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "用户点数不够扣";
        return FALSE;
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_sql_points where guid='".$_obf_jYaTjpCOhpGOhoaJjpGKjpE�."' and `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."' and tbname='".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']."' and svrid=1 and addtime>".( $_obf_jomPk5WKioeLipGGi4_PhpM� - 180 )." limit 0,1" );
    if ( !empty( $_obf_lY6RhpOJh46VkJOGkoeRiIY� ) )
    {
        $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "本次未扣点，可能是重复扣点操作";
        return $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'];
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']." set `points`=`points`-".$_obf_iI_TiI_HjoiGj4eIkZSIjog�." where `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."'", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === TRUE )
    {
        if ( SVRID == 2 )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_tb_sql_points (`addtime`,`tbname`,`username`,`points`,`guid`,`svrid`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",'".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']."','".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."',".$_obf_iI_TiI_HjoiGj4eIkZSIjog�.",'".$_obf_jYaTjpCOhpGOhoaJjpGKjpE�."',".SVRID.")", "notsync" );
        }
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = "扣点成功";
        return $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'] - $_obf_iI_TiI_HjoiGj4eIkZSIjog�;
    }
    $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "执行扣点SQL失败";
    return FALSE;
}

function api_get( $_obf_h42RjJWNj5CGkYyGjpCJioo� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    global $_obf_k5SIlJCMhoiIjJWMi5WLkY8�;
    global $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    $_obf_hoaLk5CMjo6RlZGTlY_GjpE� = array(
        "当前IP" => $_obf_kYmJjZOIiZKJioqMkoaGiYk�,
        "用户名" => "username",
        "锁" => "islock",
        "锁定" => "islock",
        "登陆密码" => "password",
        "用户密码" => "password",
        "安全密码" => "password2",
        "标签" => "tag",
        "登陆次数" => "activetimes",
        "备注" => "intro",
        "天数" => "cday",
        "点数" => "points",
        "附属性" => "keyextattr",
        "付属性" => "keyextattr",
        "开始时间戮" => "starttime",
        "开始时间" => "starttime",
        "机器码" => "pccode",
        "私有数据" => "updata",
        "绑定信息" => "bdinfo",
        "上一次IP" => "lastip"
    );
    if ( !array_key_exists( $_obf_h42RjJWNj5CGkYyGjpCJioo�, $_obf_hoaLk5CMjo6RlZGTlY_GjpE� ) )
    {
        return "par1err";
    }
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = "";
    switch ( $_obf_h42RjJWNj5CGkYyGjpCJioo� )
    {
    case "当前IP" :
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_hoaLk5CMjo6RlZGTlY_GjpE�[$_obf_h42RjJWNj5CGkYyGjpCJioo�];
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    case "用户名" :
    case "锁" :
    case "锁定" :
    case "登陆密码" :
    case "用户密码" :
    case "安全密码" :
    case "标签" :
    case "登陆次数" :
    case "备注" :
    case "天数" :
    case "点数" :
    case "附属性" :
    case "付属性" :
    case "开始时间戮" :
    case "开始时间" :
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�[$_obf_hoaLk5CMjo6RlZGTlY_GjpE�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]];
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    case "机器码" :
    case "私有数据" :
    case "绑定信息" :
    case "上一次IP" :
        if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
        {
            $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�[$_obf_hoaLk5CMjo6RlZGTlY_GjpE�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]];
            return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
        }
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�[$_obf_hoaLk5CMjo6RlZGTlY_GjpE�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]];
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    }
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = "par1err";
    return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
}

function _obf_k5OTiY6Kk5WJlIuOkIyJkIk�( $_obf_lImQjpCTjIqSjZCPj4aTkoo�, $_obf_iomQiY_NjIiVkJWGi4_Qj40� = 0 )
{
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    global $_obf_k5SIlJCMhoiIjJWMi5WLkY8�;
    global $_obf_kpKNkJCHjJCUioiUj4yRkpM�;
    global $_obf_jYqGjYqOlZKMkZSGj4_Gk4w�;
    global $_obf_ko2PhoaRkIeRh5GQjIuGjo4�;
    $_obf_joaQlI_PiIuVi4yMi4qIipQ� = array( );
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['state'] = "100";
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['message'] = "验证通过";
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['index'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "index" );
    if ( $_obf_lImQjpCTjIqSjZCPj4aTkoo� != "" )
    {
        $_obf_joaQlI_PiIuVi4yMi4qIipQ�['advapi'] = $_obf_lImQjpCTjIqSjZCPj4aTkoo�;
    }
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] == PETIME )
    {
        $_obf_joaQlI_PiIuVi4yMi4qIipQ�['IsPubUser'] = 1;
        $_obf_joaQlI_PiIuVi4yMi4qIipQ�['ShengYuMiaoShu'] = $_obf_iomQiY_NjIiVkJWGi4_Qj40�;
        $_obf_joaQlI_PiIuVi4yMi4qIipQ�['endtime'] = date( "Y-m-d H:i:s", time( ) + $_obf_iomQiY_NjIiVkJWGi4_Qj40� );
    }
    else
    {
        $_obf_joaQlI_PiIuVi4yMi4qIipQ�['IsPubUser'] = 0;
        $_obf_joaQlI_PiIuVi4yMi4qIipQ�['ShengYuMiaoShu'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] - time( );
        $_obf_joaQlI_PiIuVi4yMi4qIipQ�['endtime'] = date( "Y-m-d H:i:s", $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] );
    }
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['shostname'] = _obf_ko_JjomRlIiQkYiRlZKSkZI�( );
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['shosttime'] = time( );
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['unbind_changetime'] = $_obf_kpKNkJCHjJCUioiUj4yRkpM�;
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['YanZhengPinLv'] = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['connectpenli'];
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['InfoA'] = _obf_h4_Tk4uIkIuMiYmUh42Jhoc�( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['returninfo1'], "a" );
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['InfoB'] = _obf_h4_Tk4uIkIuMiYmUh42Jhoc�( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['returninfo2'], "b" );
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['username'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username'];
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['linknum'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'];
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'];
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['points'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'];
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['bdinfo'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo'];
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['tag'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['tag'];
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['keyextattr'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['keyextattr'];
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['BeiZhu'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['intro'];
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['cztimes'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cztimes'];
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['managerid'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['managerid'];
    if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "randomstr" ) !== FALSE )
    {
        $_obf_joaQlI_PiIuVi4yMi4qIipQ�['randomstr'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "randomstr" );
    }
    $_obf_joaQlI_PiIuVi4yMi4qIipQ�['pccode'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" );
    if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
    {
        $_obf_joaQlI_PiIuVi4yMi4qIipQ�['SiYouShuJu'] = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['updata'];
    }
    else
    {
        $_obf_joaQlI_PiIuVi4yMi4qIipQ�['SiYouShuJu'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['updata'];
    }
    if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ) !== FALSE )
    {
        $_obf_joaQlI_PiIuVi4yMi4qIipQ�['keystr'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" );
    }
    $_obf_kIaLi4uMi5GGipGJlIyQjo8� = _obf_i5SKlIaQlZOMkpCPk5WUiIY�( $_obf_joaQlI_PiIuVi4yMi4qIipQ� );
    $_obf_kIaLi4uMi5GGipGJlIyQjo8� = _obf_h4iTkpCKlYeHkZWPh5CIhpA�( $_obf_kIaLi4uMi5GGipGJlIyQjo8�, "utf-8", $_obf_jYqGjYqOlZKMkZSGj4_Gk4w� );
    $_obf_kIaLi4uMi5GGipGJlIyQjo8� = base64_encode( $_obf_kIaLi4uMi5GGipGJlIyQjo8� );
    $_obf_lYyUj4iRjpOHiIiTiJSLk44� = "__myEncrypt";
    if ( function_exists( $_obf_lYyUj4iRjpOHiIiTiJSLk44� ) )
    {
        $_obf_kIaLi4uMi5GGipGJlIyQjo8� = $_obf_lYyUj4iRjpOHiIiTiJSLk44�( $_obf_kIaLi4uMi5GGipGJlIyQjo8� );
    }
    $_obf_lImQjpCTjIqSjZCPj4aTkoo� = str_replace( "`", "^^^", $_obf_lImQjpCTjIqSjZCPj4aTkoo� );
    $_obf_jI2Ii5GMjJWIjIyNk4qViZU� = "_SoftConfig>>";
    $_obf_jI2Ii5GMjJWIjIyNk4qViZU� .= $_obf_jZGRipSRkIeUiIeQjoaUjJI�['chkonline']."`";
    $_obf_jI2Ii5GMjJWIjIyNk4qViZU� .= $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc']."`";
    $_obf_jI2Ii5GMjJWIjIyNk4qViZU� .= $_obf_jZGRipSRkIeUiIeQjoaUjJI�['connectpenli']."`";
    $_obf_jI2Ii5GMjJWIjIyNk4qViZU� .= $_obf_joaQlI_PiIuVi4yMi4qIipQ�['ShengYuMiaoShu']."`";
    $_obf_jI2Ii5GMjJWIjIyNk4qViZU� .= $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] == PETIME ? "1`" : "0`";
    $_obf_jI2Ii5GMjJWIjIyNk4qViZU� .= $_obf_lImQjpCTjIqSjZCPj4aTkoo�."`";
    $_obf_kIaLi4uMi5GGipGJlIyQjo8� .= $_obf_jI2Ii5GMjJWIjIyNk4qViZU�;
    $_obf_kIaLi4uMi5GGipGJlIyQjo8� = _obf_h4iTkpCKlYeHkZWPh5CIhpA�( $_obf_kIaLi4uMi5GGipGJlIyQjo8�, "utf-8", $_obf_jYqGjYqOlZKMkZSGj4_Gk4w� );
    $_obf_kZWIioyVlJKMho_KiIeJjZE� = _obf_ioaIk4uQkoqQipSLi5KJkpA�( $_obf_kIaLi4uMi5GGipGJlIyQjo8�, $_obf_ko2PhoaRkIeRh5GQjIuGjo4� );
    exit( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softhead'].$_obf_kZWIioyVlJKMho_KiIeJjZE� );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page8!" );
}
$_obf_j4yViI_OhpKQk5SPkouUj4o� = 0;
if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "changehost" ) == "1" && _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "index" ) != "0" )
{
    $_obf_j4yViI_OhpKQk5SPkouUj4o� = 1;
}
$_obf_h4_LhpSTi5WNi5COkIiViYk� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "valhost" );
if ( $_obf_h4_LhpSTi5WNi5COkIiViYk� == 2 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "218", "客户端禁止重定向域名（hosts）！" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 1 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "219", "服务端已暂停使用该软件！" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 6 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "220", "服务端已暂停使用该软件（冻结状态）。解冻后系统将自动为你帐号补上被冻结后无法使用的时间！" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 9 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "221", "因为超过60%的用户均无法解读HOSTS，服务端已被系统暂停使用（非作者操作）！" );
}
if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "softver" ) < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softversion'] && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['ismustupdate'] == 1 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "222", "有新版本发布，该版本已停止使用！新软件下载地址:VAL_url", array(
        "VAL_url" => base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softdownurl'] )
    ) );
}
$_obf_kpKNkJCHjJCUioiUj4yRkpM� = 0;
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ) === FALSE )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "223", "软件模式为卡模式，但是你没有传入注册卡参数" );
    }
    if ( strlen( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ) ) != 32 )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "224", "软件模式为卡模式，输入的卡号必须是32位" );
    }
    _obf_k5OKiY_Pj4_OlZWRjIeSjoc�( "username", substr( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ), 0, 10 ) );
    _obf_k5OKiY_Pj4_OlZWRjIeSjoc�( "password", substr( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ), 10, 10 ) );
    _obf_k5OKiY_Pj4_OlZWRjIeSjoc�( "password2", substr( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ), 20 ) );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."'" );
    if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
    {
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 2 || $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 4 )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "225", "软件模式为卡模式，服务端禁止了新卡号激活！" );
        }
        $_obf_j46GkYaTj5KIkIyUh4aTjYs� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `keys`='".substr( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ), 4, 6 )."' and `keyfix`='".substr( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ), 0, 4 )."' and `keyspassword`='".substr( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ), 10 )."' " );
        if ( empty( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "226", "软件模式为卡模式，注册卡号未找到！" );
        }
        if ( 0 < $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cztime'] )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "227", "软件模式为卡模式，注册卡号已激活，但在用户表中无记录！".RNBR."（可能过期太久被作者删除，也可能是用户表异常需修复）" );
        }
        if ( $_obf_j46GkYaTj5KIkIyUh4aTjYs�['islock'] != 0 )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "228", "软件模式为卡模式，注册卡号被锁定无法激活！" );
        }
        if ( $_obf_j46GkYaTj5KIkIyUh4aTjYs�['isback'] != 0 )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "229", "软件模式为卡模式，注册卡已执行退卡操作，无法激活！" );
        }
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['managerid'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['managerid'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['username'] = substr( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ), 0, 10 );
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['password'] = substr( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ), 10, 10 );
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['password2'] = substr( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ), 20 );
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['points'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['tag'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['tag'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['linknum'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['keyextattr'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['addtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM�;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['starttime'] = $_obf_jomPk5WKioeLipGGi4_PhpM�;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'] * 86400;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] = 1;
        if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "bdinfo" ) === FALSE )
        {
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['bdinfo'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "bdinfo" );
        }
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "sql" );
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "230", "软件模式为卡模式，注册卡激活失败，请重试！VAL_sqlerr", array(
                "VAL_sqlerr" => $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )
            ) );
        }
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update `kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set cztime=".$_obf_jomPk5WKioeLipGGi4_PhpM�.",czusername='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."' where `keys`='".$_obf_j46GkYaTj5KIkIyUh4aTjYs�['keys']."'";
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
        {
            _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 107 );
        }
        if ( SVRID == 2 )
        {
            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "insert into kss_tb_sql_active (`tbname`,`username`,`starttime`,`pccode`) values ('".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."','"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."',".$_obf_jomPk5WKioeLipGGi4_PhpM�.",'".$_obf_joeUio_LioqSh5WIiI2Pk4s�."')";
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
            {
                _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 114 );
            }
        }
        $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."'" );
    }
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['password'] != _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "password" ) || $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['password2'] != _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "password2" ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "231", "软件模式为卡模式，注册卡号错误，请检查输入（尽用复制输入卡号保证输入的准确性）！" );
    }
}
else
{
    if ( strlen( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" ) ) < 3 )
    {
        if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" ) !== FALSE )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "232", "服务端软件模式为帐号密码模式登入，但你好像是用卡号模式模板开发的软件！" );
        }
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "233", "用户帐号长度小于3位！" );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    $_obf_h4aUkomQiI6JlIaSkomSkok� = "";
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."'" );
    if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
    {
        $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
        if ( $_obf_h4aUkomQiI6JlIaSkomSkok� != "" )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "repair table kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, "notsync" );
            $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."'", 1, 1 );
            if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
            {
                $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                if ( $_obf_h4aUkomQiI6JlIaSkomSkok� != "" )
                {
                    exit( "<b>TableErr[kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."],try repair,but repair is failure！mysql errinfo:".$_obf_h4aUkomQiI6JlIaSkomSkok�."</b>" );
                }
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "234", "用户帐号未找到！" );
            }
        }
        else
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "234", "用户帐号未找到！" );
        }
    }
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['password'] !== _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "password" ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "235", "登陆密码错误！" );
    }
}
_obf_ho_Ki4_TiZCUk4yOkJCPh5M�( );
if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['ispause'] )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "236", "帐号冻结状态[VAL_pausetime]，解冻后系统将自动为你帐号补上被冻结后无法使用的时间！", array(
        "VAL_pausetime" => date( "Y-m-d H:i", $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['pausetime'] )
    ) );
}
if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "237", "帐号锁定状态，仍然在计时！" );
}
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] * 86400 < time( ) )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "238", "帐号已过期！" );
}
$_obf_ipKHkZSLjYmPk5KOjJGPiZI� = ( integer )_obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" );
if ( $_obf_ipKHkZSLjYmPk5KOjJGPiZI� < 1 )
{
    $_obf_ipKHkZSLjYmPk5KOjJGPiZI� = 1;
    _obf_k5OKiY_Pj4_OlZWRjIeSjoc�( "clientid", "1" );
}
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] < _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" ) )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "239", "通道ID号超出限制！[VAL_linknum]", array(
        "VAL_linknum" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum']
    ) );
}
$_obf_k5SIlJCMhoiIjJWMi5WLkY8� = array( );
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
{
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set id=1 where id=0", "notsync" );
    if ( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lI6Gio6PjomOj4mRjoaUjoY�( ) == 1146 )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "CREATE TABLE IF NOT EXISTS `kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` (`id` int(11) NOT NULL auto_increment,`username` varchar(32) character set utf8 collate utf8_bin NOT NULL,`clientid` int(4) unsigned NOT NULL,`linecode` varchar(10) NOT NULL,`pccode` varchar(512) NOT NULL default '', `unlockday` tinyint(3) unsigned NOT NULL default '0',  `unlocktimes` int(10) unsigned NOT NULL default '0',`isonline` int(2) unsigned NOT NULL,`lasttime` int(10) unsigned NOT NULL,`lastip` bigint(20) unsigned NOT NULL default '0',`updata` varchar(128) NOT NULL default '',PRIMARY KEY  (`id`),KEY `username` (`username`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ", "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "240", "创建通道表时出错，请重试或联系软件作者！" );
        }
    }
    if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "index" ) == 0 )
    {
        $_obf_k5SIlJCMhoiIjJWMi5WLkY8� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."' and `clientid`="._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" ) );
        if ( empty( $_obf_k5SIlJCMhoiIjJWMi5WLkY8� ) )
        {
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`username`,`clientid`,`linecode`,`unlockday`,`unlocktimes`,`pccode`,`isonline`,`lasttime`,`lastip`,`updata`) values ('"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."',"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" ).",'',0,0,'',0,0,0,'')", "notsync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "241", "通道表中加入用户数据出时出错，请重试或联系软件作者！VAL_sqlerr", array(
                    "VAL_sqlerr" => $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )
                ) );
            }
            $_obf_k5SIlJCMhoiIjJWMi5WLkY8� = array(
                "username" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" ),
                "clientid" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" ),
                "linecode" => "",
                "unlockday" => 0,
                "unlocktimes" => 0,
                "pccode" => "",
                "isonline" => 0,
                "lasttime" => 0,
                "lastip" => 0,
                "updata" => ""
            );
        }
    }
    else
    {
        $_obf_k5SIlJCMhoiIjJWMi5WLkY8� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."' and `clientid`="._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" ) );
        if ( empty( $_obf_k5SIlJCMhoiIjJWMi5WLkY8� ) )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "242", "通道表中未找到帐号通道号记录，请重试或联系软件作者！" );
        }
    }
}
$_obf_lIeKioqNiYaOlIyQjouSlY8� = "../kss_inc/advapi/".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid'].$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'].".php";
if ( !is_file( $_obf_lIeKioqNiYaOlIyQjouSlY8� ) )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "243", "高级API接口缓存文件丢失，需重建缓存。（高级管理，更新缓存）" );
}
include( $_obf_lIeKioqNiYaOlIyQjouSlY8� );
$_obf_iZKMh5WIiI2UkpGHj5SPkYk� = explode( "#", $_obf_jIaLhoqLj5GKkJSRjoaRkpA� );
$_obf_iZWVjY6HiIyQj4uUjpKHkJU� = array_intersect( $_obf_iZKMh5WIiI2UkpGHj5SPkYk�, $_obf_ioiVhomLjJSHiYqRiJWOk4Y� );
if ( !empty( $_obf_iZWVjY6HiIyQj4uUjpKHkJU� ) )
{
    _obf_j42JiI_RjZCHiIyKjZGUlYw�( $_obf_jZSVjouIlJSRk4eHkIqGjIc�, $_obf_jIaLhoqLj5GKkJSRjoaRkpA� );
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] != PETIME )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set islock=3,intro='该用户使用调试工具登陆' where username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."' and password='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "password" )."'", "sync" );
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "244", "客户端异常操作，帐号锁定，IP、机器码均已被列入黑名单！" );
    }
    else
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "245", "客户端异常操作，IP、机器码均已被列入黑名单！" );
    }
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nodebuger'] == 1 )
{
    $_obf_kJGNi4qHkI6Hjo2QkIaSlYo� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "isdebuger" );
    if ( $_obf_kJGNi4qHkI6Hjo2QkIaSlYo� !== FALSE && 0 < $_obf_kJGNi4qHkI6Hjo2QkIaSlYo� )
    {
        _obf_j42JiI_RjZCHiIyKjZGUlYw�( $_obf_jZSVjouIlJSRk4eHkIqGjIc�, $_obf_jIaLhoqLj5GKkJSRjoaRkpA� );
        if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] != PETIME )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set islock=3,intro='该用户使用调试工具登陆' where username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."' and password='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "password" )."'", "sync" );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 34 ), "notsync" );
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "246", "客户调试操作，帐号锁定，IP、机器码均已被列入黑名单！（如果你正在开发调试软件，请暂时去掉检测：后台软件参数设置->安全策略->禁止调试不要勾选）" );
        }
        else
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 34 ), "notsync" );
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "247", "客户调试操作，IP、机器码均已被列入黑名单！（如果你正在开发调试软件，请暂时去掉检测：后台软件参数设置->安全策略->禁止调试不要勾选）" );
        }
    }
}
if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "index" ) == "0" && $_obf_h4_LhpSTi5WNi5COkIiViYk� !== FALSE && 1 < $_obf_h4_LhpSTi5WNi5COkIiViYk� )
{
    $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT COUNT( * ) AS tnum FROM  kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `hstats2`>0" );
    $_obf_lYmGjomGho2UipSQi5ONj48� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
    $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT COUNT( * ) AS tnum FROM  kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `hstats`=1" );
    $_obf_koiTh5WPjIyRjZWLipSMjI0� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
    if ( 30 < $_obf_lYmGjomGho2UipSQi5ONj48� && $_obf_koiTh5WPjIyRjZWLipSMjI0� / $_obf_lYmGjomGho2UipSQi5ONj48� < 0.4 )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_soft set softstatus=9 where id='".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']."'", "sync" );
        $_obf_k4mMjZOVkpCRipSKlI2OiYg� = file_get_contents( $_obf_lY_Pko2IhoyRj4qUkYqPlJU� );
        $_obf_k4mMjZOVkpCRipSKlI2OiYg� = preg_replace( "/('softstatus').*(\\n)/", "\$1 => 9,\$2", $_obf_k4mMjZOVkpCRipSKlI2OiYg� );
        file_put_contents( $_obf_lY_Pko2IhoyRj4qUkYqPlJU�, $_obf_k4mMjZOVkpCRipSKlI2OiYg� );
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "221", "因为超过60%的用户均无法解读HOSTS，服务端已被系统暂停使用（非作者操作）！" );
    }
}
$_obf_iI2IjYyHkIyVkY_RiIqIi5U� = array( );
$_obf_jJWVlI2Kh4uIkouNkI6QkoY� = base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['resstring'] );
$_obf_jJWVlI2Kh4uIkouNkI6QkoY� = preg_replace( "/(====NEW RESSTR====).*(\\s*)/", "\$1\$2", $_obf_jJWVlI2Kh4uIkouNkI6QkoY� );
$_obf_iI2IjYyHkIyVkY_RiIqIi5U� = explode( "====NEW RESSTR====\n", $_obf_jJWVlI2Kh4uIkouNkI6QkoY� );
foreach ( $_obf_iI2IjYyHkIyVkY_RiIqIi5U� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
{
    $_obf_iI2IjYyHkIyVkY_RiIqIi5U�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = chop( $_obf_io6UjZWThpOSjYeOj46Qkow� );
}
$_obf_k5OQi5SRipSGhpKPi46UlJI� = "resstring";
$$_obf_k5OQi5SRipSGhpKPi46UlJI� = $_obf_iI2IjYyHkIyVkY_RiIqIi5U�;
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] == PETIME )
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] == "0" && _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "isrun" ) == 1 )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "249", "本机该帐号正在使用，请先关闭已登陆成功的软件！如果你确认已关闭，可能是还有残留的软件进程未被关闭，请用任务管理器结束异常的软件进程！" );
    }
    $_obf_lZCTlJCVlYmKlZGRiZCJjIY� = date( "H" );
    $_obf_h5CLhoaTko2OkIaJiYyKhoY� = explode( ",", $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_timearea'] );
    if ( $_obf_lZCTlJCVlYmKlZGRiZCJjIY� < $_obf_h5CLhoaTko2OkIaJiYyKhoY�[0] || $_obf_h5CLhoaTko2OkIaJiYyKhoY�[1] < $_obf_lZCTlJCVlYmKlZGRiZCJjIY� )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "250", "公用帐号当前时段不允许使用！" );
    }
    $_obf_iomQiY_NjIiVkJWGi4_Qj40� = 8640000;
    if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_times'] )
    {
        $_obf_iomQiY_NjIiVkJWGi4_Qj40� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_time'] * 60;
        $_obf_i4yKj4eSi4mRkIqSkY6Piok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_log_pubuser where `pccode`='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" )."' and `softid`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'] );
        if ( empty( $_obf_i4yKj4eSi4mRkIqSkY6Piok� ) )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_tb_log_pubuser (`softid`,`pccode`,`nday`,`ntimes`,`lasttime`) values (".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'].",'"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" )."',".$_obf_jomPk5WKioeLipGGi4_PhpM�.",1,".$_obf_jomPk5WKioeLipGGi4_PhpM�.")", "notsync" );
        }
        else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_time'] * 60 < $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_i4yKj4eSi4mRkIqSkY6Piok�['lasttime'] )
        {
            if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "index" ) != 0 )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "251", "本次试用时间结束！" );
            }
            if ( ( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_i4yKj4eSi4mRkIqSkY6Piok�['nday'] ) / 86400 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_day'] )
            {
                if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_times'] <= $_obf_i4yKj4eSi4mRkIqSkY6Piok�['ntimes'] )
                {
                    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "252", "今天你不能使用公用帐号！" );
                }
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_pubuser set `ntimes`=".( $_obf_i4yKj4eSi4mRkIqSkY6Piok�['ntimes'] + 1 ).",`lasttime`=".$_obf_jomPk5WKioeLipGGi4_PhpM�." where `pccode`='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" )."' and `softid`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'], "notsync" );
            }
            else
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_pubuser set nday=".$_obf_jomPk5WKioeLipGGi4_PhpM�.",`ntimes`=1,`lasttime`=".$_obf_jomPk5WKioeLipGGi4_PhpM�." where `pccode`='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" )."' and `softid`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'], "notsync" );
            }
        }
        else
        {
            $_obf_iomQiY_NjIiVkJWGi4_Qj40� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_time'] * 60 - $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_i4yKj4eSi4mRkIqSkY6Piok�['lasttime'];
        }
    }
    $_obf_lImQjpCTjIqSjZCPj4aTkoo� = "";
    if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "advapi" ) !== FALSE )
    {
        $_obf_jZGRipSRkIeUiIeQjoaUjJI�['advapi'] = "";
        $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softintro'] = "";
        $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softnotice'] = "";
        $_obf_jZGRipSRkIeUiIeQjoaUjJI�['updatelog'] = "";
        $_obf_jYmJi42Gh42MhoqLkY_MlZM� = array(
            "soft" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�,
            "member" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�,
            "ip" => long2ip( $_obf_kYmJjZOIiZKJioqMkoaGiYk� ),
            "intip" => $_obf_kYmJjZOIiZKJioqMkoaGiYk�,
            "pccode" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" ),
            "username" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" ),
            "password" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "password" ),
            "clientid" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" ),
            "linecode" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "linecode" ),
            "ischangesvr" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "ischangesvr" ),
            "apicmd" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "apicmd" )
        );
        $adv_db = $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
        $adv_table = $_obf_jpOTkJCPjI_TipSPjoeTjYs�;
        $adb_pdata = $_obf_jYmJi42Gh42MhoqLkY_MlZM�;
        $adv_user = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
        $_obf_lImQjpCTjIqSjZCPj4aTkoo� = _obf_io_Mh4aMkouSiZGQiYmRjJM�( );
    }
    _obf_k5OTiY6Kk5WJlIuOkIyJkIk�( $_obf_lImQjpCTjIqSjZCPj4aTkoo�, $_obf_iomQiY_NjIiVkJWGi4_Qj40� );
}
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] == 1 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "253", "任意登陆模式，不允许存在多通道帐号，请联系作者！" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] == "0" && _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "isrun" ) == 1 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "249", "本机该帐号正在使用，请先关闭已登陆成功的软件！如果你确认已关闭，可能是还有残留的软件进程未被关闭，请用任务管理器结束异常的软件进程！" );
}
if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "bdinfo" ) != "" && $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo'] != _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "bdinfo" ) )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "255", "绑定信息不符！" );
}
$_obf_hpGLjYmMi5CJkoqGjJSIiIY� = array( );
$_obf_lI6Oh5CKh42Ri5STio2HjpE� = array( );
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
{
    $_obf_lIyRio6Kho6LiIaVkY_SiZA� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['lastip'];
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['pccode'];
    $_obf_h5GPkpGLkYePioqSiomMlZM� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['unlockday'];
    $_obf_j5WGlIqLlYqNlYqJjo_JiJU� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['unlocktimes'];
    $_obf_j42KiZKIk5OMi4yGlYyPlI0� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['lasttime'];
    $_obf_iouLk4eQj5KOj4eQh42Vi4g� = _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" ), $_obf_kJSVj4qJlIyOi5SQiZKRiYk� );
    $_obf_lYmOk4iOkZGIkIuPiIyTioo� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['isonline'];
    $_obf_k4yQlYyNkpOJkZCIiIiMj5A� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['linecode'];
}
else
{
    $_obf_lIyRio6Kho6LiIaVkY_SiZA� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['lastip'];
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['pccode'];
    $_obf_iouLk4eQj5KOj4eQh42Vi4g� = _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" ), $_obf_kJSVj4qJlIyOi5SQiZKRiYk� );
    $_obf_k4yQlYyNkpOJkZCIiIiMj5A� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linecode'];
    $_obf_j42KiZKIk5OMi4yGlYyPlI0� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['lasttime'];
    $_obf_lYmOk4iOkZGIkIuPiIyTioo� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['isonline'];
    $_obf_h5GPkpGLkYePioqSiomMlZM� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['unlockday'];
    $_obf_j5WGlIqLlYqNlYqJjo_JiJU� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['unlocktimes'];
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time'] != 0 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_times'] != 0 )
{
    $_obf_kZKOjI2JjoaKiJCGi4qQkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(*) as tnum from kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."' and optype=1 and addtime>".( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time'] * 60 ) );
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_times'] < $_obf_kZKOjI2JjoaKiJCGi4qQkok�['tnum'] )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set islock=3,intro='短时间内登陆次数太多，锁定帐号' where username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."'", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 22 ), "notsync" );
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "256", "由于短时间内登陆次数太多，帐号被锁定！" );
    }
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time_ip'] != 0 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_ipnum'] != 0 )
{
    $_obf_kZKOjI2JjoaKiJCGi4qQkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(distinct ip) as tnum from kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."' and optype=1 and addtime>".( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time_ip'] * 60 ) );
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_ipnum'] < $_obf_kZKOjI2JjoaKiJCGi4qQkok�['tnum'] )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set islock=3,intro='IP变动太频繁，锁定帐号' where username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."'", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 32 ), "notsync" );
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "257", "由于短时间内登陆IP变动次数过多，帐号被锁定！" );
    }
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time_advapi'] != 0 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_times_advapi'] != 0 )
{
    $_obf_kZKOjI2JjoaKiJCGi4qQkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(*) as tnum from kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."' and optype=30 and addtime>".( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time_advapi'] * 60 ) );
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_times_advapi'] < $_obf_kZKOjI2JjoaKiJCGi4qQkok�['tnum'] )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set islock=3,intro='调用advapi太频繁，锁定帐号' where username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."'", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 31 ), "notsync" );
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "258", "由于短时间内调用advapi次数太多，帐号被锁定！" );
    }
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] != "1" && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] != "1" )
{
    if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "index" ) == 0 || $_obf_j4yViI_OhpKQk5SPkouUj4o� == 1 )
    {
        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['linecode'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "linecode" );
    }
    else if ( $_obf_k4yQlYyNkpOJkZCIiIiMj5A� == "" )
    {
        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['linecode'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "linecode" );
    }
    else if ( $_obf_k4yQlYyNkpOJkZCIiIiMj5A� != _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "linecode" ) )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 25 ), "notsync" );
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "259", "帐号被挤下线（在线码变动）！" );
    }
}
$_obf_kpSSj5GNj4eIh5WGkI_Gk4s� = "";
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] != "1" )
{
    if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "index" ) == 0 )
    {
        if ( $_obf_iouLk4eQj5KOj4eQh42Vi4g� === FALSE )
        {
            if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['chkonline'] == 1 )
            {
                if ( $_obf_lYmOk4iOkZGIkIuPiIyTioo� == 1 )
                {
                    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinetimes'] == 0 )
                    {
                        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 33 ), "notsync" );
                        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "260", "用户在线，禁止换机登陆！" );
                    }
                    if ( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_j42KiZKIk5OMi4yGlYyPlI0� < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinetime'] * 60 )
                    {
                        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 24 ), "notsync" );
                        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "261", "用户在线，请多等待一会再偿试重新登陆！注意：如果原程序还在运行，你换电脑偿试登陆，帐号可能会被系统锁定！" );
                    }
                    if ( $_obf_h5GPkpGLkYePioqSiomMlZM� != date( "d" ) )
                    {
                        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlockday'] = date( "d" );
                        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlocktimes'] = 1;
                    }
                    else
                    {
                        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinetimes'] < $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1 )
                        {
                            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 26 ), "notsync" );
                            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "262", "当日强登陆次数已用完，不可再强登陆！" );
                        }
                        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlocktimes'] = $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1;
                    }
                    $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 23 );
                }
                else
                {
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['isonline'] = 1;
                    $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 2 );
                }
                $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['pccode'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" );
            }
            else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_set'] == 2 )
            {
                if ( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_j42KiZKIk5OMi4yGlYyPlI0� < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_autotime'] * 60 )
                {
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 27 ), "notsync" );
                    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "263", "机器码变动，未到自动解绑时间！" );
                }
                $_obf_joiHh46HlYmMkouLlJWNk4w� = 0;
                if ( $_obf_h5GPkpGLkYePioqSiomMlZM� != date( "d" ) )
                {
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlockday'] = date( "d" );
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlocktimes'] = 1;
                    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] == 1 )
                    {
                        $_obf_joiHh46HlYmMkouLlJWNk4w� = 1;
                        $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 15 );
                    }
                    else
                    {
                        $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 16 );
                    }
                }
                else
                {
                    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] == 1 )
                    {
                        $_obf_joiHh46HlYmMkouLlJWNk4w� = 1;
                        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_times'] < $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1 )
                        {
                            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 28 ), "notsync" );
                            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "264", "当日解绑次数已用完！" );
                        }
                        $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 15 );
                    }
                    else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] == 2 )
                    {
                        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_times'] < $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1 )
                        {
                            $_obf_joiHh46HlYmMkouLlJWNk4w� = 1;
                            $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 17 );
                        }
                        else
                        {
                            $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 18 );
                        }
                    }
                    else
                    {
                        $_obf_joiHh46HlYmMkouLlJWNk4w� = 0;
                        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_times'] < $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1 )
                        {
                            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 28 );
                            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
                            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "264", "当日解绑次数已用完！" );
                        }
                        $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 16 );
                    }
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlocktimes'] = $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1;
                }
                if ( $_obf_joiHh46HlYmMkouLlJWNk4w� == 1 )
                {
                    $_obf_ioiIkIyNi4uSiY2GlY6Oko0� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'];
                    $_obf_kpKNkJCHjJCUioiUj4yRkpM� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'];
                    $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'];
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'];
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['endtime'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] * 86400 + $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'];
                    if ( $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['endtime'] < $_obf_jomPk5WKioeLipGGi4_PhpM� || $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['cday'] < 0 )
                    {
                        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 29 ), "notsync" );
                        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "265", "帐号剩余时间不足，不能自动解绑！" );
                    }
                    $_obf_kpSSj5GNj4eIh5WGkI_Gk4s� = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",6,'".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."',".$_obf_ioiIkIyNi4uSiY2GlY6Oko0�.",".$_obf_hpGLjYmMi5CJkoqGjJSIiIY�['cday'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",'','')";
                }
                $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['pccode'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" );
            }
            else
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 10 ), "notsync" );
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "266", "机器码变动，禁止登陆！" );
            }
        }
        else
        {
            if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['chkonline'] == 1 )
            {
                $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['isonline'] = 1;
            }
            if ( $_obf_kJSVj4qJlIyOi5SQiZKRiYk� != $_obf_iouLk4eQj5KOj4eQh42Vi4g� )
            {
                $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['pccode'] = $_obf_iouLk4eQj5KOj4eQh42Vi4g�;
            }
            $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 1 );
        }
        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['activetimes'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['activetimes'] + 1;
    }
    else
    {
        if ( $_obf_iouLk4eQj5KOj4eQh42Vi4g� === FALSE )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 11 ), "notsync" );
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "267", "帐号被挤下线（机器码变动）！" );
        }
        if ( $_obf_j4yViI_OhpKQk5SPkouUj4o� == 1 && $_obf_iouLk4eQj5KOj4eQh42Vi4g� != $_obf_kJSVj4qJlIyOi5SQiZKRiYk� )
        {
            $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['pccode'] = $_obf_iouLk4eQj5KOj4eQh42Vi4g�;
        }
    }
}
else if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "index" ) == 0 )
{
    $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 9 );
}
$_obf_hpGLjYmMi5CJkoqGjJSIiIY�['lasttime'] = $_obf_jomPk5WKioeLipGGi4_PhpM�;
if ( $_obf_lIyRio6Kho6LiIaVkY_SiZA� != $_obf_kYmJjZOIiZKJioqMkoaGiYk� )
{
    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['lastip'] = $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
}
if ( isset( $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['isonline'] ) && $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['isonline'] == 1 && $_obf_lYmOk4iOkZGIkIuPiIyTioo� == 1 )
{
    unset( $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['isonline'] );
}
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] == 1 )
    {
        $_obf_kpCTiIiUhouPjo6PipGMk5E� = array( "cday" => 0, "endtime" => 0, "activetimes" => 0 );
        $_obf_j4mGiJCKlI6QjJCGkpCQjo4� = array( "lastip" => 0, "pccode" => 0, "unlockday" => 0, "unlocktimes" => 0, "lasttime" => 0, "isonline" => 0 );
    }
    else
    {
        $_obf_kpCTiIiUhouPjo6PipGMk5E� = array( "cday" => 0, "endtime" => 0, "activetimes" => 0 );
        $_obf_j4mGiJCKlI6QjJCGkpCQjo4� = array( "lastip" => 0, "pccode" => 0, "unlockday" => 0, "unlocktimes" => 0, "lasttime" => 0, "isonline" => 0, "linecode" => 0 );
    }
}
else
{
    if ( $_obf_h4_LhpSTi5WNi5COkIiViYk� !== FALSE )
    {
        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['hstats'] = $_obf_h4_LhpSTi5WNi5COkIiViYk�;
    }
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] == 1 )
    {
        $_obf_kpCTiIiUhouPjo6PipGMk5E� = array( "hstats" => 0, "cday" => 0, "endtime" => 0, "lastip" => 0, "pccode" => 0, "unlockday" => 0, "unlocktimes" => 0, "lasttime" => 0, "isonline" => 0, "activetimes" => 0 );
        $_obf_j4mGiJCKlI6QjJCGkpCQjo4� = array( "no_key" => 0 );
    }
    else
    {
        $_obf_kpCTiIiUhouPjo6PipGMk5E� = array( "hstats" => 0, "cday" => 0, "endtime" => 0, "lastip" => 0, "pccode" => 0, "unlockday" => 0, "unlocktimes" => 0, "lasttime" => 0, "isonline" => 0, "activetimes" => 0, "linecode" => 0 );
        $_obf_j4mGiJCKlI6QjJCGkpCQjo4� = array( "no_key" => 0 );
    }
}
$_obf_ho6HiImLipSMlYaRhpCOkI4� = array_intersect_key( $_obf_hpGLjYmMi5CJkoqGjJSIiIY�, $_obf_kpCTiIiUhouPjo6PipGMk5E� );
$_obf_lZWLlYqJiZSQkYuVkJGKkZQ� = array_intersect_key( $_obf_hpGLjYmMi5CJkoqGjJSIiIY�, $_obf_j4mGiJCKlI6QjJCGkpCQjo4� );
if ( !empty( $_obf_lI6Oh5CKh42Ri5STio2HjpE� ) )
{
    foreach ( $_obf_lI6Oh5CKh42Ri5STio2HjpE� as $_obf_i4qNkYqQlYuOh4iLiIuOjpQ� )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qNkYqQlYuOh4iLiIuOjpQ�, "notsync" );
    }
}
$_obf_lZCSkpOUjoaNi5OUkY6Pjo4� = array( "hstats" => 0, "linecode" => 0, "lasttime" => 0, "lastip" => 0, "activetimes" => 0, "unlockday" => 0, "unlocktimes" => 0, "isonline" => 0, "pccode" => 0 );
if ( !empty( $_obf_ho6HiImLipSMlYaRhpCOkI4� ) )
{
    $_obf_kY2SiY6LkI6Sk46LipSOi44� = "sync";
    $_obf_k5SPi4eOiYyTk5SSlJCSk4c� = array_diff_key( $_obf_ho6HiImLipSMlYaRhpCOkI4�, $_obf_lZCSkpOUjoaNi5OUkY6Pjo4� );
    if ( empty( $_obf_k5SPi4eOiYyTk5SSlJCSk4c� ) )
    {
        $_obf_kY2SiY6LkI6Sk46LipSOi44� = "notsync";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_ho6HiImLipSMlYaRhpCOkI4�, "username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."'", $_obf_kY2SiY6LkI6Sk46LipSOi44� );
}
if ( !empty( $_obf_lZWLlYqJiZSQkYuVkJGKkZQ� ) )
{
    $_obf_kY2SiY6LkI6Sk46LipSOi44� = "sync";
    $_obf_k5SPi4eOiYyTk5SSlJCSk4c� = array_diff_key( $_obf_lZWLlYqJiZSQkYuVkJGKkZQ�, $_obf_lZCSkpOUjoaNi5OUkY6Pjo4� );
    if ( empty( $_obf_k5SPi4eOiYyTk5SSlJCSk4c� ) )
    {
        $_obf_kY2SiY6LkI6Sk46LipSOi44� = "notsync";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_lZWLlYqJiZSQkYuVkJGKkZQ�, "username='"._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" )."' and `clientid`="._obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" ), $_obf_kY2SiY6LkI6Sk46LipSOi44� );
}
if ( $_obf_kpSSj5GNj4eIh5WGkI_Gk4s� != "" )
{
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kpSSj5GNj4eIh5WGkI_Gk4s�, "sync" );
}
$_obf_lImQjpCTjIqSjZCPj4aTkoo� = "";
if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "advapi" ) !== FALSE )
{
    $_obf_jZGRipSRkIeUiIeQjoaUjJI�['advapi'] = "";
    $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softintro'] = "";
    $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softnotice'] = "";
    $_obf_jZGRipSRkIeUiIeQjoaUjJI�['updatelog'] = "";
    $_obf_jYmJi42Gh42MhoqLkY_MlZM� = array(
        "soft" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�,
        "member" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�,
        "client" => $_obf_k5SIlJCMhoiIjJWMi5WLkY8�,
        "ip" => long2ip( $_obf_kYmJjZOIiZKJioqMkoaGiYk� ),
        "intip" => $_obf_kYmJjZOIiZKJioqMkoaGiYk�,
        "pccode" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" ),
        "username" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" ),
        "password" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "password" ),
        "clientid" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" ),
        "linecode" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "linecode" ),
        "ischangesvr" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "ischangesvr" ),
        "apicmd" => _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "apicmd" )
    );
    $adv_db = $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $adv_table = $_obf_jpOTkJCPjI_TipSPjoeTjYs�;
    $adb_pdata = $_obf_jYmJi42Gh42MhoqLkY_MlZM�;
    $adv_user = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    $adv_user2 = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�;
    $_obf_lImQjpCTjIqSjZCPj4aTkoo� = _obf_io_Mh4aMkouSiZGQiYmRjJM�( );
}
_obf_k5OTiY6Kk5WJlIuOkIyJkIk�( $_obf_lImQjpCTjIqSjZCPj4aTkoo� );
?>
