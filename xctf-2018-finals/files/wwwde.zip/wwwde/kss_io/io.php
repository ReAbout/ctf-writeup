<?php

function _obf_jY2SkI2KioiIkZSMh5SGjZM�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_ioaIk4uQkoqQipSLi5KJkpA�( $_obf_k4iLho6Ui42Pk4iGi5SNko8�, &$_obf_lJWGkouIj4uGlIaVhpWUko4� )
{
    $_obf_jJKUjI2Gi46RiI_PiZGOhoo� = "�����������������";
    return $_obf_jJKUjI2Gi46RiI_PiZGOhoo�( $_obf_k4iLho6Ui42Pk4iGi5SNko8�, $_obf_lJWGkouIj4uGlIaVhpWUko4� );
}

function _obf_hpCPjI_OjYaVlZKGjIqKi4g�( $_obf_lIyUkIaVk46LiZCNipOIkJA�, &$_obf_lJWGkouIj4uGlIaVhpWUko4� )
{
    $_obf_lYqLh5SQjYqOlJSIiIaGlJU� = "�����������������";
    return $_obf_lYqLh5SQjYqOlJSIiIaGlJU�( $_obf_lIyUkIaVk46LiZCNipOIkJA�, &$_obf_lJWGkouIj4uGlIaVhpWUko4� );
}

function _obf_k5OKiY_Pj4_OlZWRjIeSjoc�( $_obf_h5KKkJOUkoyRipOGlY_Lj4Y�, $_obf_jJCNh42NjpGQkIaPk4qLkok� )
{
    global $_obf_joqQi4_TlZWGlI_Hh42MjYk�;
    global $_obf_kJWPkJSOjpGNjY2NioqGiZQ�;
    $GLOBALS['_POST'][$_obf_joqQi4_TlZWGlI_Hh42MjYk�[$_obf_h5KKkJOUkoyRipOGlY_Lj4Y�]] = $_obf_jJCNh42NjpGQkIaPk4qLkok�;
    $_obf_kJWPkJSOjpGNjY2NioqGiZQ�[$_obf_joqQi4_TlZWGlI_Hh42MjYk�[$_obf_h5KKkJOUkoyRipOGlY_Lj4Y�]] = $_obf_jJCNh42NjpGQkIaPk4qLkok�;
}

function _obf_jZKTjJWKjpKUkoeJlZWGkZU�( &$_obf_h46Mk5WRjJCTkJOKi4uUjoY� )
{
    $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = str_replace( "'", "", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = str_replace( YH2, "", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = str_replace( " ", "", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = str_replace( "\t", "", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = str_replace( "\r", "", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = str_replace( ",,", ",", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = str_replace( ",,", ",", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = str_replace( ",,", ",", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = str_replace( "\n", ",", $_obf_h46Mk5WRjJCTkJOKi4uUjoY� );
    $_obf_h46Mk5WRjJCTkJOKi4uUjoY� = trim( $_obf_h46Mk5WRjJCTkJOKi4uUjoY�, "," );
}

function _obf_i4yHiJWOjZKUkY_QkouIi5M�( $_obf_jo_LkZWOiY_QkoeJk4yKiZU�, $_obf_jY6MkIuIioqTk4eIiIiNj5U�, $_obf_lIqNjoyMkJSIkpKMk4iLk5Q� )
{
    if ( $_obf_jo_LkZWOiY_QkoeJk4yKiZU� == "" )
    {
        return TRUE;
    }
    _obf_jZKTjJWKjpKUkoeJlZWGkZU�( &$_obf_jo_LkZWOiY_QkoeJk4yKiZU� );
    $_obf_iJCPi4mVjoeNlYeHjpCIk5I� = explode( ",", $_obf_jo_LkZWOiY_QkoeJk4yKiZU� );
    if ( in_array( $_obf_jY6MkIuIioqTk4eIiIiNj5U�, $_obf_iJCPi4mVjoeNlYeHjpCIk5I� ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "214", "你的IP在黑名单里!" );
    }
    $_obf_j5KHk4uNj4mSjY2QlYeIj4w� = str_replace( "~", ",", $_obf_lIqNjoyMkJSIkpKMk4iLk5Q� );
    $_obf_j5KHk4uNj4mSjY2QlYeIj4w� = trim( $_obf_j5KHk4uNj4mSjY2QlYeIj4w�, "," );
    $_obf_k4yLiomGjImGiouNiIqHko0� = explode( ",", $_obf_j5KHk4uNj4mSjY2QlYeIj4w� );
    $_obf_k4qOiZCKh4mGjJORkoaNk4k� = array_intersect( $_obf_k4yLiomGjImGiouNiIqHko0�, $_obf_iJCPi4mVjoeNlYeHjpCIk5I� );
    if ( !empty( $_obf_k4qOiZCKh4mGjJORkoaNk4k� ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "215", "你的机器码在黑名单里！" );
    }
}

function _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( $_obf_jouVk5CIjYeOjJCQjY_Tkoo�, $_obf_kYaMh5WSkJGKlIiMioaUkIo� )
{
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_j4yViI_OhpKQk5SPkouUj4o�;
    if ( $_obf_kYaMh5WSkJGKlIiMioaUkIo� == "" )
    {
        return $_obf_jouVk5CIjYeOjJCQjY_Tkoo�;
    }
    $_obf_jouVk5CIjYeOjJCQjY_Tkoo� = str_replace( "!", ",", $_obf_jouVk5CIjYeOjJCQjY_Tkoo� );
    $_obf_kYaMh5WSkJGKlIiMioaUkIo� = str_replace( "!", ",", $_obf_kYaMh5WSkJGKlIiMioaUkIo� );
    if ( $_obf_j4yViI_OhpKQk5SPkouUj4o� == 1 )
    {
        return $_obf_jouVk5CIjYeOjJCQjY_Tkoo�;
    }
    $_obf_ipWRk42HhouHi5OUjYiGkIw� = $_obf_jouVk5CIjYeOjJCQjY_Tkoo�;
    $_obf_j4uSlIeLkYmKiomSiIqIj5M� = $_obf_kYaMh5WSkJGKlIiMioaUkIo�;
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = strpos( $_obf_jouVk5CIjYeOjJCQjY_Tkoo�, "~" );
    if ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� !== FALSE )
    {
        $_obf_jouVk5CIjYeOjJCQjY_Tkoo� = substr( $_obf_jouVk5CIjYeOjJCQjY_Tkoo�, 0, $_obf_jpKPlJSUiZOHkYaPlIeOiY4� );
        if ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 5 )
        {
            return FALSE;
        }
    }
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = strpos( $_obf_kYaMh5WSkJGKlIiMioaUkIo�, "~" );
    if ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� !== FALSE )
    {
        $_obf_kYaMh5WSkJGKlIiMioaUkIo� = substr( $_obf_kYaMh5WSkJGKlIiMioaUkIo�, 0, $_obf_jpKPlJSUiZOHkYaPlIeOiY4� );
    }
    $_obf_iY_KkZKTjJOQjZGLiZSUiIw� = explode( ",", $_obf_jouVk5CIjYeOjJCQjY_Tkoo� );
    $_obf_i4yLjY6PhoqJkJOUj4uTjJM� = explode( ",", $_obf_kYaMh5WSkJGKlIiMioaUkIo� );
    $_obf_k5SPi4eOiYyTk5SSlJCSk4c� = array_intersect( $_obf_iY_KkZKTjJOQjZGLiZSUiIw�, $_obf_i4yLjY6PhoqJkJOUj4uTjJM� );
    if ( empty( $_obf_k5SPi4eOiYyTk5SSlJCSk4c� ) )
    {
        return FALSE;
    }
    if ( count( $_obf_k5SPi4eOiYyTk5SSlJCSk4c� ) < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['pccodestep'] )
    {
        return FALSE;
    }
    if ( PCCODEJOIN == 0 )
    {
        return $_obf_ipWRk42HhouHi5OUjYiGkIw�;
    }
    $_obf_k5SPi4eOiYyTk5SSlJCSk4c� = array_merge( $_obf_iY_KkZKTjJOQjZGLiZSUiIw�, $_obf_i4yLjY6PhoqJkJOUj4uTjJM� );
    $_obf_k5SPi4eOiYyTk5SSlJCSk4c� = array_unique( $_obf_k5SPi4eOiYyTk5SSlJCSk4c� );
    return join( ",", $_obf_k5SPi4eOiYyTk5SSlJCSk4c� );
}

function _obf_kpSOkYmPh5SSi4mMlYePjY4�( $_obf_lJSJk4_Mi5CGh4mShoeUioo� = 0 )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    if ( defined( "NOTLOCKIP" ) && NOTLOCKIP == 1 )
    {
        $_obf_h4iLko_Lk4yKjpWViJCGlJM� = _obf_iIuRj5CUkIuHi4mPkY2Vio0�( 1 );
        if ( $_obf_lJSJk4_Mi5CGh4mShoeUioo� == 0 )
        {
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(*) as tnum from kss_tb_badip where ip=".$_obf_h4iLko_Lk4yKjpWViJCGlJM�." and addtime>".( time( ) - 600 ) );
            if ( 10 < $_obf_lY6RhpOJh46VkJOGkoeRiIY�['tnum'] )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_badip set addtime=".( time( ) + 900 )." where  ip=".$_obf_h4iLko_Lk4yKjpWViJCGlJM�." and addtime>".( time( ) - 600 ), "notsync" );
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "216", "你的IP被暂时禁止此操作！" );
            }
        }
        else
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_tb_badip (`addtime`,`ip`) values (".time( ).",".$_obf_h4iLko_Lk4yKjpWViJCGlJM�.")", "notsync" );
        }
    }
}

if ( isset( $_GET['v'] ) )
{
    switch ( $_GET['v'] )
    {
    case "10" :
    case "11" :
        define( "CLVersion", 10 );
        break;
    case "12" :
        define( "CLVersion", 12 );
        break;
    case "13" :
        define( "CLVersion", 13 );
        break;
    default :
        define( "CLVersion", 8 );
    }
}
require( "io_function.php" );
require( "../kss_inc/inc.php" );
if ( isset( $_GET['testsync'] ) && md5( $_GET['testsync'] ) == MYSQLBAKPASSWORD )
{
    $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    echo "同步测试已启动，请到系统任务日志查看";
    _obf_ho_Ki4_TiZCUk4yOkJCPh5M�( );
    exit( );
}
else
{
    set_error_handler( "error_report_fun_api" );
    _obf_kouKkIeViIqPk5KMiIiMkpE�( );
    if ( isset( $_GET['getsn'] ) )
    {
        $_obf_kJOTiIaNkY6Uh5CUho2Tho4� = _obf_jZKGhoeQk46KiJCHi5CLjpQ�( );
        exit( urlencode( $_obf_kJOTiIaNkY6Uh5CUho2Tho4� ) );
    }
    else
    {
        define( "RNBR", "\r\n<br />" );
        if ( !isset( $_GET['updatelog'] ) )
        {
            $_obf_jYqGjYqOlZKMkZSGj4_Gk4w� = "GBK";
            if ( isset( $_GET['c'] ) )
            {
                $_obf_jYqGjYqOlZKMkZSGj4_Gk4w� = $_GET['c'];
            }
            $_obf_kI6OjImLjJCRh46PjYqLhoo� = 1;
            if ( !isset( $_GET['b'] ) )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "200", "未在URL中传递返回数据格式参数b=*" );
            }
            if ( in_array( $_GET['b'], array( "0", "1", "2" ) ) )
            {
                $_obf_kI6OjImLjJCRh46PjYqLhoo� = $_GET['b'];
            }
            if ( !isset( $_GET['s'] ) )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "201", "未在URL中传递软件编号参数s=*" );
            }
            $_obf_iImHhpCJi4eSkY_VjZOUj5Q� = $_GET['s'];
            if ( !is_numeric( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) && strlen( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) != 8 )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "202", "软件编号错误[VAL_softcode]", array(
                    "VAL_softcode" => $_obf_iImHhpCJi4eSkY_VjZOUj5Q�
                ) );
            }
            if ( !isset( $_GET['v'] ) )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "203", "未在URL中传递服务端接口版本参数v=*" );
            }
            if ( !in_array( $_GET['v'], array( "10", "11", "12" ) ) )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "204", "不支持该服务端接口版本参数v=".$_GET['v'] );
            }
            $_obf_k5WPhoeNjZOTk4yQlYyQj4c� = "10";
        }
        else
        {
            $_obf_iImHhpCJi4eSkY_VjZOUj5Q� = $_GET['updatelog'];
            if ( strlen( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) == 7 )
            {
                $_obf_iImHhpCJi4eSkY_VjZOUj5Q� = substr( $_obf_iImHhpCJi4eSkY_VjZOUj5Q�, 0, 5 )."0".substr( $_obf_iImHhpCJi4eSkY_VjZOUj5Q�, 5 );
            }
        }
        $_obf_jZGRipSRkIeUiIeQjoaUjJI� = array( );
        $_obf_lY_Pko2IhoyRj4qUkYqPlJU� = "../kss_inc/cache/soft_".$_obf_iImHhpCJi4eSkY_VjZOUj5Q�.".php";
        if ( !is_file( $_obf_lY_Pko2IhoyRj4qUkYqPlJU� ) )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "205", "软件编号为VAL_softcode的缓存文件未找到！（更新缓存：后台重新保存一下软件，或高级管理->更新缓存）。", array(
                "VAL_softcode" => $_obf_iImHhpCJi4eSkY_VjZOUj5Q�
            ) );
        }
        include( $_obf_lY_Pko2IhoyRj4qUkYqPlJU� );
        if ( isset( $_GET['updatelog'] ) )
        {
            echo "<html><head><title>软件更新日志</title><meta http-equiv='Content-Type' content='text/html; charset=utf-8' /><style>body{font-family: Arial, Verdana, sans-serif;font-size: 12px;color: #222;background-color: #fff;}</style></head><body>";
            echo "<div><a href=".base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softdownurl'] )." target='_blank' style='color:#f00;font-weight:700'>如若自动更新失败，点击这里手动下载</a><br><br></div>";
            echo base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['updatelog'] );
            exit( "</body></html>" );
        }
        else
        {
            $_obf_ioiVhomLjJSHiYqRiJWOk4Y� = array( "C6E9D3ED113E", "EE3EE9D3EEA1", "A9D3E5E0813E" );
            $_obf_ko2PhoaRkIeRh5GQjIuGjo4� = 0;
            $_obf_kpWSlJGSkZKGipKVjpKVk5A� = array( "注册" => "zhuce", "充值" => "chongzhi", "修改密码和绑定信息" => "xgxx", "解绑机器码" => "unbind", "查询" => "chaxun", "check命令" => "chk", "下线" => "unline", "取软件信息" => "soft" );
            $_obf_kY6Mh5KGlZSLjJCTjIqThoo� = array( "注册" => "reg", "充值" => "cz", "修改密码和绑定信息" => "edit", "解绑机器码" => "unbind", "查询" => "search", "check命令" => "check", "下线" => "unline", "取软件信息" => "get" );
            $_obf_joqQi4_TlZWGlI_Hh42MjYk� = array( "softver" => "softver", "action" => "action", "apicmd" => "apicmd", "softcode" => "softcode", "keystr" => "keystr", "username" => "username", "index" => "index", "password" => "password", "password2" => "password2", "newpassword" => "newpassword", "pccode" => "pccode", "linecode" => "linecode", "bdinfo" => "bdinfo", "newbdinfo" => "newbdinfo", "czkey" => "czkey", "puser" => "puser", "clientid" => "clientid", "valhost" => "valhost", "isdebuger" => "isdebuger", "changehost" => "changehost", "isrun" => "isrun", "randkey" => "randkey", "advapi" => "advapi", "randomstr" => "randomstr", "keyorusername" => "keyorusername" );
            $_obf_ko2RiIiSh4qNlIqHkI_Ji4g� = FALSE;
            require( "../kss_inc/signdata/crypt95.php" );
            require( "io_ext.php" );
            $_obf_joqGjoeGlJGKk4_RioiTj4w� = FALSE;
            if ( is_file( "__mobile.php" ) && isset( $_GET['mp'] ) )
            {
                $_obf_joqGjoeGlJGKk4_RioiTj4w� = TRUE;
            }
            if ( mt_rand( 1, 5 ) == 3 )
            {
                _obf_io_MiI6UjIyKkJOVk5GSjYo�( "xio.php", 1 );
            }
            if ( $_obf_joqGjoeGlJGKk4_RioiTj4w� )
            {
                include( "__mobile.php" );
            }
            else
            {
                function _obf_hoaHlYiMh5OOjpGNiYmLk5A�( $_obf_h5KKkJOUkoyRipOGlY_Lj4Y� )
                {
                    global $_obf_joqQi4_TlZWGlI_Hh42MjYk�;
                    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
                    global $_obf_ko2PhoaRkIeRh5GQjIuGjo4�;
                    global $_obf_jYqGjYqOlZKMkZSGj4_Gk4w�;
                    global $_obf_ko2RiIiSh4qNlIqHkI_Ji4g�;
                    if ( !$_obf_ko2RiIiSh4qNlIqHkI_Ji4g� )
                    {
                        $_obf_ko2RiIiSh4qNlIqHkI_Ji4g� = TRUE;
                        if ( isset( $_GET['debug'] ) )
                        {
                            $_obf_jJGIjZGVkomQioqHiJOVjoo� = $_GET['debug'];
                        }
                        else
                        {
                            $_obf_jJGIjZGVkomQioqHiJOVjoo� = $_POST['o'];
                        }
                        if ( substr( $_obf_jJGIjZGVkomQioqHiJOVjoo�, 0, strlen( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softhead'] ) ) == $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softhead'] )
                        {
                            $_obf_jJGIjZGVkomQioqHiJOVjoo� = substr( $_obf_jJGIjZGVkomQioqHiJOVjoo�, strlen( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softhead'] ) );
                            $_obf_ko2PhoaRkIeRh5GQjIuGjo4� = 0;
                            $_obf_jJGIjZGVkomQioqHiJOVjoo� = _obf_hpCPjI_OjYaVlZKGjIqKi4g�( $_obf_jJGIjZGVkomQioqHiJOVjoo�, &$_obf_ko2PhoaRkIeRh5GQjIuGjo4� );
                            if ( CLVersion < 12 )
                            {
                                $_obf_jJGIjZGVkomQioqHiJOVjoo� = _obf_h4iTkpCKlYeHkZWPh5CIhpA�( $_obf_jJGIjZGVkomQioqHiJOVjoo�, $_obf_jYqGjYqOlZKMkZSGj4_Gk4w�, "utf-8" );
                            }
                            if ( isset( $_GET['debug'] ) )
                            {
                                print_r( unpack( "C*", $_obf_jJGIjZGVkomQioqHiJOVjoo� ) );
                            }
                            if ( isset( $_GET['debug'] ) )
                            {
                                print_r( $_obf_jJGIjZGVkomQioqHiJOVjoo� );
                            }
                            $GLOBALS['_POST'] = _obf_komQkZGUhomRk4eLipOSkJM�( $_obf_jJGIjZGVkomQioqHiJOVjoo� );
                        }
                        else
                        {
                            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "206", "客户端DLL传送过来的数据错误！VAL_data", array(
                                "VAL_data" => $_obf_jJGIjZGVkomQioqHiJOVjoo�
                            ) );
                        }
                        foreach ( $GLOBALS['_POST'] as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
                        {
                            $_obf_i4aLi4mMio2Sh4eHhpKPlYY� = TRUE;
                            if ( preg_match( "/select|>|<|script|insert|update|delete|union|into|load_file|outfile|0x[0-9a-f]{6}|\\.\\/|\\*|'/i", $_obf_io6UjZWThpOSjYeOj46Qkow�, $_obf_i4_Kj5CPh4qKkYyHj42Qkoc� ) )
                            {
                                $_obf_i4aLi4mMio2Sh4eHhpKPlYY� = $_obf_i4_Kj5CPh4qKkYyHj42Qkoc�[0];
                            }
                            if ( $_obf_i4aLi4mMio2Sh4eHhpKPlYY� !== TRUE )
                            {
                                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "207", "提交的VAL_falid字段有不允许使用的字符串VAL_value", array(
                                    "VAL_falid" => $_obf_lIeHkoeKkpOSiomPi4mQk5E�,
                                    "VAL_value" => $_obf_i4aLi4mMio2Sh4eHhpKPlYY�
                                ) );
                            }
                        }
                        if ( isset( $_GET['debug'] ) )
                        {
                            print_r( $_POST );
                        }
                        $_obf_ko2RiIiSh4qNlIqHkI_Ji4g� = TRUE;
                    }
                    if ( isset( $_obf_joqQi4_TlZWGlI_Hh42MjYk�[$_obf_h5KKkJOUkoyRipOGlY_Lj4Y�], $_POST[$_obf_joqQi4_TlZWGlI_Hh42MjYk�[$_obf_h5KKkJOUkoyRipOGlY_Lj4Y�]] ) )
                    {
                        return $_POST[$_obf_joqQi4_TlZWGlI_Hh42MjYk�[$_obf_h5KKkJOUkoyRipOGlY_Lj4Y�]];
                    }
                    return FALSE;
                }
            }
            $_obf_ioiMk5KUlY6Lk5SLkJGQjo8� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "action" );
            if ( $_obf_ioiMk5KUlY6Lk5SLkJGQjo8� === FALSE )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "208", "没有找到接口参数数据！" );
            }
            if ( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "softcode" ) != $_GET['s'] )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "209", "Get参数与Post参数里的软件编号不一致，请检查程序！" );
            }
            $_obf_jomPk5WKioeLipGGi4_PhpM� = time( );
            $_obf_jpOTkJCPjI_TipSPjoeTjYs� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'];
            if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['manager_islock'] == 1 )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "210", "作者帐号已被锁定！" );
            }
            if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['manager_endtime'] < _obf_jZGJkpOSkY_HiY2HjY2JlIg�( ) )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "211", "作者帐号已过期！" );
            }
            $_obf_ko2PhoaRkIeRh5GQjIuGjo4� = 0;
            if ( in_array( $_obf_ioiMk5KUlY6Lk5SLkJGQjo8�, $_obf_kY6Mh5KGlZSLjJCTjIqThoo� ) )
            {
                $_obf_h5GViYeRjYuMj4mUiI2JjIs� = array_flip( $_obf_kY6Mh5KGlZSLjJCTjIqThoo� );
                $_obf_lZOThomRipOIi5SRhpWRjY4� = $_obf_h5GViYeRjYuMj4mUiI2JjIs�[$_obf_ioiMk5KUlY6Lk5SLkJGQjo8�];
                if ( $_obf_lZOThomRipOIi5SRhpWRjY4� == "check命令" )
                {
                    $_obf_lIqNjoyMkJSIkpKMk4iLk5Q� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" );
                    _obf_jZKTjJWKjpKUkoeJlZWGkZU�( $_obf_lIqNjoyMkJSIkpKMk4iLk5Q� );
                    $_obf_hpSHko_LjpKMjo2UkZKTiJE� = stripos( $_obf_lIqNjoyMkJSIkpKMk4iLk5Q�, "~" );
                    if ( $_obf_hpSHko_LjpKMjo2UkZKTiJE� !== FALSE && 3 < $_obf_hpSHko_LjpKMjo2UkZKTiJE� )
                    {
                        $_obf_jZSVjouIlJSRk4eHkIqGjIc� = substr( $_obf_lIqNjoyMkJSIkpKMk4iLk5Q�, 0, $_obf_hpSHko_LjpKMjo2UkZKTiJE� );
                        $_obf_jIaLhoqLj5GKkJSRjoaRkpA� = substr( $_obf_lIqNjoyMkJSIkpKMk4iLk5Q�, $_obf_hpSHko_LjpKMjo2UkZKTiJE� + 1 );
                        $_obf_lIqNjoyMkJSIkpKMk4iLk5Q� = $_obf_jZSVjouIlJSRk4eHkIqGjIc�."~".$_obf_jIaLhoqLj5GKkJSRjoaRkpA�;
                        _obf_k5OKiY_Pj4_OlZWRjIeSjoc�( "pccode", $_obf_lIqNjoyMkJSIkpKMk4iLk5Q� );
                    }
                    else
                    {
                        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "212", "无效的机器码格式！" );
                    }
                    _obf_i4yHiJWOjZKUkY_QkouIi5M�( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['mac_blacklist'], long2ip( $_obf_kYmJjZOIiZKJioqMkoaGiYk� ), $_obf_lIqNjoyMkJSIkpKMk4iLk5Q� );
                }
                $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
                include( "v".$_obf_k5WPhoeNjZOTk4yQlYyQj4c�."_".$_obf_kpWSlJGSkZKGipKVjpKVk5A�[$_obf_lZOThomRipOIi5SRhpWRjY4�].".php" );
                exit( );
            }
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "213", "参数action=VAL_action在服务端未找到相应的处理接口！", array(
                "VAL_action" => $_obf_ioiMk5KUlY6Lk5SLkJGQjo8�
            ) );
        }
    }
}
?>
