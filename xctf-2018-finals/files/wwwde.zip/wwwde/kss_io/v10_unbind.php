<?php

function _obf_j5KUjJGLkIeIiYeJiJSTjI4�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
if ( SVRID == 2 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "360", "备用服务器，不能进行解绑操作！" );
}
$_obf_lYqUjoqMiomGlYiQio6Qi4Y� = array( );
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['isrun'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "isrun" );
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" );
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "password" );
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['pccode'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" );
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" );
if ( empty( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'] ) )
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'] = 1;
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['chkonline'] == 1 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "357", "开启了检查在线标识，无需解绑！" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_set'] != 1 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_set'] != 3 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "358", "软件没有启用自助解绑功能！" );
}
if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['isrun'] == "1" )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "359", "请先关闭已登陆成功的客户端！".RNBR."如果你确认已关闭登陆成功的软件，可能是还有残留的软件进程未被关闭，请用任务管理器结束异常的软件进程！" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['keystr'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "keystr" );
    if ( empty( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['keystr'] ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "361", "没有输入要解绑机器码的注册卡号" );
    }
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['keystr'] ) != 32 )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "362", "注册卡必须是32位！" );
    }
    if ( !_obf_joeQipOGjouJko_VlJSKiJE�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['keystr'] ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "363", "注册卡号格式错误！" );
    }
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['keystr'], 0, 10 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['keystr'], 10, 10 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['keystr'], 20 );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `password`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password']."' and `password2`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2']."'" );
    if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "364", "注册卡未找到无法解绑" );
    }
}
else
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "password" );
    if ( empty( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) || empty( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "365", "没有输入要解绑机器码的用户名或密码" );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' " );
    if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "366", "用户未找到无法解绑" );
    }
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['password'] != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "367", "用户密码错误无法解绑" );
    }
}
if ( PETIME <= $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "368", "公用帐号禁止此操作！" );
}
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] == 1 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "369", "任意登陆模式，不允许存在多通道帐号，请联系作者！" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] == "1" )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "370", "任意登陆帐号无需解绑！" );
}
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
{
    $_obf_j5CSkZSGiJKNiZSQlY_Iio0� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid']."'" );
    if ( empty( $_obf_j5CSkZSGiJKNiZSQlY_Iio0� ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "371", "该通道还未开始使用，无需解绑！" );
    }
    $_obf_h5GPkpGLkYePioqSiomMlZM� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['unlockday'];
    $_obf_j5WGlIqLlYqNlYqJjo_JiJU� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['unlocktimes'];
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['pccode'];
    $_obf_j42KiZKIk5OMi4yGlYyPlI0� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['lasttime'];
}
else
{
    $_obf_h5GPkpGLkYePioqSiomMlZM� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['unlockday'];
    $_obf_j5WGlIqLlYqNlYqJjo_JiJU� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['unlocktimes'];
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['pccode'];
    $_obf_j42KiZKIk5OMi4yGlYyPlI0� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['lasttime'];
}
if ( $_obf_kJSVj4qJlIyOi5SQiZKRiYk� == "" )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "372", "未绑定状态无需解绑！" );
}
$_obf_jYuNio2SioaQjIyOhouIiYo� = _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['pccode'], $_obf_kJSVj4qJlIyOi5SQiZKRiYk� );
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_set'] == 3 )
{
    if ( $_obf_jYuNio2SioaQjIyOhouIiYo� !== FALSE )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "373", "机器码未变动，无需解绑！" );
    }
    if ( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_j42KiZKIk5OMi4yGlYyPlI0� < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_autotime'] * 60 )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "374", "未到可解绑时间" );
    }
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_set'] == 1 && $_obf_jYuNio2SioaQjIyOhouIiYo� === FALSE )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "375", "只可在原绑定电脑上解绑！" );
}
$_obf_j42HkJGSkI6UhoaJlYuVk4k� = array( );
if ( $_obf_h5GPkpGLkYePioqSiomMlZM� == date( "d" ) )
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_times'] <= $_obf_j5WGlIqLlYqNlYqJjo_JiJU� && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] < 2 )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "376", "当日解绑次数已达上限，不可以再解绑！" );
    }
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlockday'] = $_obf_h5GPkpGLkYePioqSiomMlZM�;
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlocktimes'] = $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1;
}
else
{
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlockday'] = date( "d" );
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlocktimes'] = 1;
}
$_obf_kpSSj5GNj4eIh5WGkI_Gk4s� = "";
$_obf_kIaHkJSNhpOPi5OSh4eJlIY� = array( );
$_obf_iYaSkpCKi4iMhoaNk5OHk4o� = "";
if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] && 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'] )
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] == 1 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
        if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] < $_obf_jomPk5WKioeLipGGi4_PhpM� || $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] < 0 )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "377", "帐号剩余时间不足，改绑机器码需要扣去VAL_decday天！", array(
                "VAL_decday" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime']
            ) );
        }
        $_obf_kpSSj5GNj4eIh5WGkI_Gk4s� = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",6,'".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."',".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'].",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",'','')";
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_decday'] = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'];
        $_obf_iYaSkpCKi4iMhoaNk5OHk4o� = "并扣除了解绑机器码的费用VAL_decday天。";
    }
    else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_times'] < $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlocktimes'] )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
        if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] < $_obf_jomPk5WKioeLipGGi4_PhpM� || $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] < 0 )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "377", "帐号剩余时间不足，改绑机器码需要扣去VAL_decday天！", array(
                "VAL_decday" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime']
            ) );
        }
        $_obf_kpSSj5GNj4eIh5WGkI_Gk4s� = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",6,'".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."',".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'].",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",'','')";
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_decday'] = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'];
        $_obf_iYaSkpCKi4iMhoaNk5OHk4o� = "并扣除了改绑机器码的费用VAL_decday天。";
    }
}
$_obf_j42HkJGSkI6UhoaJlYuVk4k�['pccode'] = "";
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] == 1 )
{
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "378", "解绑失败！出错原因：VAL_sqlerr", array(
            "VAL_sqlerr" => $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )
        ) );
    }
}
else
{
    $_obf_iY2UhpKLiJKRjIiRjIyHi4k� = array(
        "unlockday" => $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlockday'],
        "unlocktimes" => $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlocktimes'],
        "pccode" => ""
    );
    unset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlockday'] );
    unset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlocktimes'] );
    if ( !empty( $_obf_j42HkJGSkI6UhoaJlYuVk4k� ) )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "378", "解绑失败！出错原因：VAL_sqlerr", array(
                "VAL_sqlerr" => $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )
            ) );
        }
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_iY2UhpKLiJKRjIiRjIyHi4k�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`=".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'], "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "378", "解绑失败！出错原因：VAL_sqlerr", array(
            "VAL_sqlerr" => $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )
        ) );
    }
}
if ( $_obf_kpSSj5GNj4eIh5WGkI_Gk4s� != "" )
{
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kpSSj5GNj4eIh5WGkI_Gk4s�, "sync" );
}
_obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "379", "解绑机器码成功！".$_obf_iYaSkpCKi4iMhoaNk5OHk4o�, $_obf_kIaHkJSNhpOPi5OSh4eJlIY� );
?>
