<?php

function _obf_k4aNj4iRh5WPipSRjYeQjoc�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function zsarr_sort( $_obf_iJSNjIuPjoqSjYyUiIyIi5A�, $_obf_j4qUhoiVipWQj4iNh5CJj4w� )
{
    if ( $_obf_iJSNjIuPjoqSjYyUiIyIi5A�['num'] == $_obf_j4qUhoiVipWQj4iNh5CJj4w�['num'] )
    {
        _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "297", "作者在后台设置不正确：发现卡名相同充值张数相同的记录" );
    }
    if ( $_obf_j4qUhoiVipWQj4iNh5CJj4w�['num'] < $_obf_iJSNjIuPjoqSjYyUiIyIi5A�['num'] )
    {
        return -1;
    }
    return 1;
}

function _obf_lJCQjZSSkpSSiI2Sh42LjYk�( $_obf_io_SlIuNkIuKjZOIkIiOlZA�, $_obf_lY6ViI_KiJWHj4aTlZKNjYw�, $_obf_jZSVhpSIj5STkJWIlJGVjos� = array( ), $_obf_kpGKjomRjY6SkIyHh4qUj5M� = "global" )
{
    global $_obf_kI6OjImLjJCRh46PjYqLhoo�;
    global $_obf_joyHlI2KjY6PkJKQhpSGkI8�;
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    if ( $_obf_kpGKjomRjY6SkIyHh4qUj5M� == "global" )
    {
        $_obf_kpGKjomRjY6SkIyHh4qUj5M� = $_obf_kI6OjImLjJCRh46PjYqLhoo�;
    }
    if ( isset( $_obf_jZSVhpSIj5STkJWIlJGVjos� ) )
    {
        $_obf_lY6ViI_KiJWHj4aTlZKNjYw� = strtr( $_obf_lY6ViI_KiJWHj4aTlZKNjYw�, $_obf_jZSVhpSIj5STkJWIlJGVjos� );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_joyHlI2KjY6PkJKQhpSGkI8� );
    switch ( $_obf_kpGKjomRjY6SkIyHh4qUj5M� )
    {
    case "0" :
        $_obf_jo6SjIuHj46LjIyTlIyQk4s� = array(
            "state" => $_obf_io_SlIuNkIuKjZOIkIiOlZA�,
            "message" => $_obf_lY6ViI_KiJWHj4aTlZKNjYw�
        );
        if ( !empty( $_obf_jZSVhpSIj5STkJWIlJGVjos� ) )
        {
            foreach ( $_obf_jZSVhpSIj5STkJWIlJGVjos� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
            {
                $_obf_jo6SjIuHj46LjIyTlIyQk4s�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = $_obf_io6UjZWThpOSjYeOj46Qkow�;
            }
        }
        exit( _obf_hpKJipCTlIePjoiMjZSOkZU�( $_obf_jo6SjIuHj46LjIyTlIyQk4s� ) );
    case "1" :
        $_obf_jo6SjIuHj46LjIyTlIyQk4s� = array(
            "state" => $_obf_io_SlIuNkIuKjZOIkIiOlZA�,
            "message" => $_obf_lY6ViI_KiJWHj4aTlZKNjYw�
        );
        if ( !empty( $_obf_jZSVhpSIj5STkJWIlJGVjos� ) )
        {
            foreach ( $_obf_jZSVhpSIj5STkJWIlJGVjos� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
            {
                $_obf_jo6SjIuHj46LjIyTlIyQk4s�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = $_obf_io6UjZWThpOSjYeOj46Qkow�;
            }
        }
        exit( _obf_i5SKlIaQlZOMkpCPk5WUiIY�( $_obf_jo6SjIuHj46LjIyTlIyQk4s� ) );
    case "2" :
        exit( $_obf_io_SlIuNkIuKjZOIkIiOlZA�."  :  ".$_obf_lY6ViI_KiJWHj4aTlZKNjYw� );
    }
    $_obf_jo6SjIuHj46LjIyTlIyQk4s� = array(
        "state" => $_obf_io_SlIuNkIuKjZOIkIiOlZA�,
        "message" => $_obf_lY6ViI_KiJWHj4aTlZKNjYw�
    );
    if ( !empty( $_obf_jZSVhpSIj5STkJWIlJGVjos� ) )
    {
        foreach ( $_obf_jZSVhpSIj5STkJWIlJGVjos� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
        {
            $_obf_jo6SjIuHj46LjIyTlIyQk4s�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = $_obf_io6UjZWThpOSjYeOj46Qkow�;
        }
    }
    exit( _obf_i5SKlIaQlZOMkpCPk5WUiIY�( $_obf_jo6SjIuHj46LjIyTlIyQk4s� ) );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
if ( SVRID == 2 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "271", "禁止在备用服务器上注册帐号！" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "272", "卡模式软件是自动激活帐号，无需注册！" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 4 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "273", "软件已关闭新用户注册！" );
}
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['manager_maxusernum'] )
{
    $_obf_iZWGh5SKipCTk4mUkI_Kk48� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(*) as tnum,sum(`linknum`) from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs� );
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['manager_maxusernum'] <= $_obf_iZWGh5SKipCTk4mUkI_Kk48�['tnum'] + ( $_obf_iZWGh5SKipCTk4mUkI_Kk48�['tnum'] - $_obf_iZWGh5SKipCTk4mUkI_Kk48�['tnum'] ) / 2 )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "274", "作者可管理用户数已达上限！" );
    }
}
$_obf_lJKIh46Pho6OiZWUi4aJhpU� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "bdinfo" );
$_obf_lI2KiouPkIaOj5OJiJSTiI4� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" );
$_obf_k5CUiZCKjI6Mk5OGlZCJlIY� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "password" );
$_obf_jpWHioeQiJWMh42MjoyQkI8� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "password2" );
$_obf_k5WIi4mIlIaGkY2GlJGOj4w� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "puser" );
$_obf_joyMko_HhpCVlJOMlJGPkIo� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "czkey" );
if ( $_obf_lJKIh46Pho6OiZWUi4aJhpU� === FALSE )
{
    $_obf_lJKIh46Pho6OiZWUi4aJhpU� = "";
}
if ( $_obf_lI2KiouPkIaOj5OJiJSTiI4� === FALSE )
{
    $_obf_lI2KiouPkIaOj5OJiJSTiI4� = "";
}
if ( $_obf_k5CUiZCKjI6Mk5OGlZCJlIY� === FALSE )
{
    $_obf_k5CUiZCKjI6Mk5OGlZCJlIY� = "";
}
if ( $_obf_jpWHioeQiJWMh42MjoyQkI8� === FALSE )
{
    $_obf_jpWHioeQiJWMh42MjoyQkI8� = "";
}
if ( $_obf_k5WIi4mIlIaGkY2GlJGOj4w� === FALSE )
{
    $_obf_k5WIi4mIlIaGkY2GlJGOj4w� = "";
}
if ( $_obf_joyMko_HhpCVlJOMlJGPkIo� === FALSE )
{
    $_obf_joyMko_HhpCVlJOMlJGPkIo� = "";
}
$_obf_lI2KiouPkIaOj5OJiJSTiI4� = trim( $_obf_lI2KiouPkIaOj5OJiJSTiI4� );
$_obf_joyMko_HhpCVlJOMlJGPkIo� = trim( $_obf_joyMko_HhpCVlJOMlJGPkIo� );
if ( strlen( $_obf_lI2KiouPkIaOj5OJiJSTiI4� ) < 3 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "275", "用户名长度最少为3！" );
}
if ( strlen( $_obf_k5CUiZCKjI6Mk5OGlZCJlIY� ) < 5 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "276", "用户名密码长度最少为5！" );
}
if ( strlen( $_obf_jpWHioeQiJWMh42MjoyQkI8� ) < 8 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "277", "安全密码长度最少为8！" );
}
$_obf_iImHk5CLiY2Gk5OTlZONk4k� = array( );
$_obf_iYuKhpCNhoaJlYmThpOTiIY� = FALSE;
if ( strlen( $_obf_joyMko_HhpCVlJOMlJGPkIo� == "" ) )
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg'] == "0.00" )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "278", "注册本软件帐号必须输入注册卡号！" );
    }
    else
    {
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['freeregs'] == "0" )
        {
            $_obf_k4yGjoyTjJGKjJWUkZSNlIc� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" );
            if ( !$_obf_k4yGjoyTjJGKjJWUkZSNlIc� )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "254", "你运行的客户端版本DLL有BUG，未找到机器码参数。" );
            }
            $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = strpos( $_obf_k4yGjoyTjJGKjJWUkZSNlIc�, "~" );
            if ( 5 < $_obf_jpKPlJSUiZOHkYaPlIeOiY4� )
            {
                $_obf_k4yGjoyTjJGKjJWUkZSNlIc� = substr( $_obf_k4yGjoyTjJGKjJWUkZSNlIc�, 0, $_obf_jpKPlJSUiZOHkYaPlIeOiY4� );
            }
            $_obf_io_UkouIkIyHj42UlI_GiZA� = explode( ",", $_obf_k4yGjoyTjJGKjJWUkZSNlIc� );
            $_obf_h46JiZOTlZSPhpGIj4yHi5I� = "('".join( "','", $_obf_io_UkouIkIyHj42UlI_GiZA� )."')";
            $_obf_jI6LkY2TlJSJjJCHlImHj4Y� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_log_havereg where `pccode` in ".$_obf_h46JiZOTlZSPhpGIj4yHi5I�." and `softid`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'] );
            if ( !empty( $_obf_jI6LkY2TlJSJjJCHlImHj4Y� ) )
            {
                _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "279", "你所使用的电脑已免费注册过帐号，如果想继续注册新帐号请输入注册卡号！" );
            }
            foreach ( $_obf_io_UkouIkIyHj42UlI_GiZA� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
            {
                $_obf_iImHk5CLiY2Gk5OTlZONk4k�[] = "insert into kss_tb_log_havereg (`softid`,`addtime`,`pccode`) values (".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'].",".time( ).",'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�."')";
            }
        }
        $_obf_iYuKhpCNhoaJlYmThpOTiIY� = TRUE;
    }
}
else if ( ( strlen( $_obf_joyMko_HhpCVlJOMlJGPkIo� ) + 1 ) % 33 != 0 )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "280", "注册卡填写错误，长度必须32位，多张卡号请用英文逗号分隔。" );
}
if ( 100 < _obf_ioqHi5WHiJKIkoeIhouHjYw�( $_obf_lJKIh46Pho6OiZWUi4aJhpU� ) )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "281", "绑定信息最多只允许100个字符" );
}
$_obf_jZCGhpKRipWQjY_UjZWMj5M� = crc32( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softcode'].$_obf_lI2KiouPkIaOj5OJiJSTiI4� );
$_obf_joyHlI2KjY6PkJKQhpSGkI8� = "regu".sprintf( "%u", $_obf_jZCGhpKRipWQjY_UjZWMj5M� );
$_obf_k4eUjoiPkomNjIaPi4aLlYo� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "SELECT `nonononono` FROM `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."`", "notsync" );
if ( 1054 != $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lI6Gio6PjomOj4mRjoaUjoY�( ) )
{
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "repair table kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, "notsync" );
    $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
    if ( $_obf_h4aUkomQiI6JlIaSkomSkok� != "" )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "254", "用户表[kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."]出错，偿试修复但修复失败。修复时产生的错误信息：VAL_sqlerr", array(
            "VAL_sqlerr" => $_obf_h4aUkomQiI6JlIaSkomSkok�
        ) );
    }
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['onlyonebdinfo'] == "1" && !empty( $_obf_lJKIh46Pho6OiZWUi4aJhpU� ) )
{
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `bdinfo`='".mysql_real_escape_string( $_obf_lJKIh46Pho6OiZWUi4aJhpU� )."'" );
    if ( !empty( $_obf_lY6RhpOJh46VkJOGkoeRiIY� ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "282", "绑定信息已被其他用户使用！" );
    }
}
$_obf_jpOPko_LjYiHkoqPjZWLiog� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_ho_Ljo6NjpOOhpGHj5KHiYs�( $_obf_joyHlI2KjY6PkJKQhpSGkI8� );
if ( $_obf_jpOPko_LjYiHkoqPjZWLiog� !== TRUE )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "283", "注册帐号时未能取得数据锁，请一分钟后重试！" );
}
$_obf_h42NjZKIkoqSkouPh5WIiYw� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lI2KiouPkIaOj5OJiJSTiI4�."'", 1, 1 );
if ( !empty( $_obf_h42NjZKIkoqSkouPh5WIiYw� ) )
{
    _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "284", "用户帐号已存在，不需要再注册。" );
}
else
{
    $_obf_ko_OkJOPkIqLjY_Mj4_SjoY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."_recycle` where `username`='".$_obf_lI2KiouPkIaOj5OJiJSTiI4�."'" );
    if ( !empty( $_obf_ko_OkJOPkIqLjY_Mj4_SjoY� ) )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."_recycle` set `username`=concat('delete_',`username`) where `username`='".$_obf_lI2KiouPkIaOj5OJiJSTiI4�."'" );
    }
}
if ( $_obf_iYuKhpCNhoaJlYmThpOTiIY� === TRUE )
{
    $_obf_iouSi4_PlIuKhoeUlI_LkpE� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['manager_id'];
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['fregmanagerid'] != 0 )
    {
        $_obf_iouSi4_PlIuKhoeUlI_LkpE� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['fregmanagerid'];
    }
    $_obf_j42HkJGSkI6UhoaJlYuVk4k� = array(
        "managerid" => $_obf_iouSi4_PlIuKhoeUlI_LkpE�,
        "username" => $_obf_lI2KiouPkIaOj5OJiJSTiI4�,
        "password" => $_obf_k5CUiZCKjI6Mk5OGlZCJlIY�,
        "password2" => $_obf_jpWHioeQiJWMh42MjoyQkI8�,
        "cday" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg'],
        "points" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg_points'],
        "tag" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['fregtag'],
        "keyextattr" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['fregattr'],
        "bdinfo" => $_obf_lJKIh46Pho6OiZWUi4aJhpU�,
        "addtime" => $_obf_jomPk5WKioeLipGGi4_PhpM�,
        "starttime" => $_obf_jomPk5WKioeLipGGi4_PhpM�,
        "endtime" => $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg'] * 86400,
        "isusetestkey" => 1,
        "intro" => "无卡注册"
    );
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        if ( !empty( $_obf_iImHk5CLiY2Gk5OTlZONk4k� ) )
        {
            foreach ( $_obf_iImHk5CLiY2Gk5OTlZONk4k� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, "sync" );
            }
        }
        _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "285", "无卡注册帐号成功，帐号时间VAL_Aday天VAL_Apoints点。", array(
            "VAL_Aday" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg'],
            "VAL_Apoints" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg_points']
        ) );
    }
    else
    {
        _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "286", "注册帐号失败！原因：VAL_sqlerr", array(
            "VAL_sqlerr" => $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )
        ) );
    }
}
$_obf_j42HkJGSkI6UhoaJlYuVk4k� = array(
    "username" => $_obf_lI2KiouPkIaOj5OJiJSTiI4�,
    "password" => $_obf_k5CUiZCKjI6Mk5OGlZCJlIY�,
    "password2" => $_obf_jpWHioeQiJWMh42MjoyQkI8�,
    "bdinfo" => $_obf_lJKIh46Pho6OiZWUi4aJhpU�,
    "addtime" => $_obf_jomPk5WKioeLipGGi4_PhpM�,
    "starttime" => $_obf_jomPk5WKioeLipGGi4_PhpM�
);
$_obf_joyMko_HhpCVlJOMlJGPkIo� = str_replace( ",", "|", $_obf_joyMko_HhpCVlJOMlJGPkIo� );
$_obf_kYiQkJKGlI6JlZWRioaKlYg� = explode( "|", $_obf_joyMko_HhpCVlJOMlJGPkIo� );
if ( 5 < count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) )
{
    _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "287", "每次最多可使用五张注册卡" );
}
$_obf_iJCHjZWRiJONk5OGlIqMipM� = array_unique( $_obf_kYiQkJKGlI6JlZWRioaKlYg� );
if ( count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) != count( $_obf_iJCHjZWRiJONk5OGlIqMipM� ) )
{
    _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "288", "你输入的多张注册有相同的卡号" );
}
$_obf_jIaRh4iNjpKMioaTjZWGkY4� = array( );
$_obf_ipGJkpOKioePjIaGkIuQiJA� = array( );
$_obf_jZCUjpOJiY6Iio_SiIyGk48� = array( );
$_obf_lZONjIiPhoiGk4_JkJKGlJU� = array( );
foreach ( $_obf_kYiQkJKGlI6JlZWRioaKlYg� as $_obf_io6UjZWThpOSjYeOj46Qkow� )
{
    $_obf_lIeHkoeKkpOSiomPi4mQk5E� = substr( $_obf_io6UjZWThpOSjYeOj46Qkow�, 4, 6 );
    $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = substr( $_obf_io6UjZWThpOSjYeOj46Qkow�, 0, 4 );
    $_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = substr( $_obf_io6UjZWThpOSjYeOj46Qkow�, 4, 6 );
    $_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = substr( $_obf_io6UjZWThpOSjYeOj46Qkow�, 10 );
    $_obf_jIaRh4iNjpKMioaTjZWGkY4�[] = substr( $_obf_io6UjZWThpOSjYeOj46Qkow�, 0, 4 );
}
$_obf_j46GkYaTj5KIkIyUh4aTjYs� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `keys` in ('".join( "','", $_obf_jZCUjpOJiY6Iio_SiIyGk48� )."') and isback=0" );
if ( empty( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) )
{
    _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "289", "注册卡未找到" );
}
if ( count( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) != count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) )
{
    $_obf_jY6MioyHj4iOi4aUjpOTkpQ� = array( );
    foreach ( $_obf_j46GkYaTj5KIkIyUh4aTjYs� as $_obf_lZSGkoqUio_RlZGNkY6Liok� )
    {
        $_obf_jY6MioyHj4iOi4aUjpOTkpQ�[] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['keys'];
    }
    foreach ( $_obf_jZCUjpOJiY6Iio_SiIyGk48� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
    {
        if ( !in_array( $_obf_io6UjZWThpOSjYeOj46Qkow�, $_obf_jY6MioyHj4iOi4aUjpOTkpQ� ) )
        {
            _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "290", "注册卡号VAL_errkey未找到。", array(
                "VAL_errkey" => $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�]
            ) );
        }
    }
}
$_obf_ioyQkY6QhoeUjo6MjIaSkJM� = 0;
foreach ( $_obf_j46GkYaTj5KIkIyUh4aTjYs� as $_obf_lZSGkoqUio_RlZGNkY6Liok� )
{
    $_obf_lIeHkoeKkpOSiomPi4mQk5E� = $_obf_lZSGkoqUio_RlZGNkY6Liok�['keys'];
    $_obf_kJKGlYqQkoiHjYeVkIuKkYY� = $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�];
    if ( $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] != $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] || $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyspassword'] != $_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] )
    {
        _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "291", "注册卡VAL_errkey错误。", array(
            "VAL_errkey" => $_obf_kJKGlYqQkoiHjYeVkIuKkYY�
        ) );
    }
    else
    {
        if ( $_obf_lZSGkoqUio_RlZGNkY6Liok�['islock'] != 0 )
        {
            _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "292", "注册卡VAL_errkey被锁定。", array(
                "VAL_errkey" => $_obf_kJKGlYqQkoiHjYeVkIuKkYY�
            ) );
        }
        if ( 0 < $_obf_lZSGkoqUio_RlZGNkY6Liok�['cztime'] )
        {
            _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "293", "注册卡VAL_errkey已使用过。", array(
                "VAL_errkey" => $_obf_kJKGlYqQkoiHjYeVkIuKkYY�
            ) );
        }
        $_obf_ioyQkY6QhoeUjo6MjIaSkJM� += $_obf_lZSGkoqUio_RlZGNkY6Liok�['cday'];
        if ( !isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] ) )
        {
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['managerid'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['managerid'];
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['tag'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['tag'];
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['cday'];
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['points'];
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] = 1;
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyextattr'];
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['linknum'];
            if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['onetimeskeyattrid'] == $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] )
            {
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['isusetestkey'] = 1;
            }
            else
            {
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['isusetestkey'] = 0;
            }
        }
        else
        {
            if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] != $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyextattr'] )
            {
                _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "294", "不同附属性的注册卡不能混在一起使用！" );
            }
            if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] != $_obf_lZSGkoqUio_RlZGNkY6Liok�['linknum'] )
            {
                _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "295", "不同通道数的注册卡不能混在一起使用！" );
            }
            if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['onetimeskeyattrid'] == $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] )
            {
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['isusetestkey'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['isusetestkey'] + 1;
                if ( 1 < $_obf_j42HkJGSkI6UhoaJlYuVk4k�['isusetestkey'] )
                {
                    _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "296", "VAL_errkey开头的注册卡每个帐号只能使用一张！", array(
                        "VAL_errkey" => $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix']
                    ) );
                }
            }
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + $_obf_lZSGkoqUio_RlZGNkY6Liok�['cday'];
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + $_obf_lZSGkoqUio_RlZGNkY6Liok�['points'];
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] + 1;
        }
    }
}
$_obf_lI6Oh5CKh42Ri5STio2HjpE� = array( );
$_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",0,'".$_obf_lI2KiouPkIaOj5OJiJSTiI4�."',0,".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",0,".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].",'".$_obf_joyMko_HhpCVlJOMlJGPkIo�."','')";
$_obf_iZWHiZKQjpOJk5GKiJSPkpE� = 0;
$_obf_lIyIi5GQlYaNkIeIlI6LiIo� = 0;
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['zs_czset'] != "" )
{
    $_obf_lI_Jj4uGiZGPh5SUj4yNi4k� = array_unique( $_obf_jIaRh4iNjpKMioaTjZWGkY4� );
    $_obf_lJKNk5OTkYiOj4uTlI_JiYc� = json_decode( base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['zs_czset'] ), TRUE );
    foreach ( $_obf_lI_Jj4uGiZGPh5SUj4yNi4k� as $_obf_jo_SiI6SjIeSjoiMjoyTkpA� )
    {
        if ( isset( $_obf_lJKNk5OTkYiOj4uTlI_JiYc�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�] ) )
        {
            $_obf_i5OKioaRlY6TkIaGkZSGlIo� = 0;
            foreach ( $_obf_jIaRh4iNjpKMioaTjZWGkY4� as $_obf_io6UjZWThpOSjYeOj46Qkow� )
            {
                if ( $_obf_io6UjZWThpOSjYeOj46Qkow� == $_obf_jo_SiI6SjIeSjoiMjoyTkpA� )
                {
                    ++$_obf_i5OKioaRlY6TkIaGkZSGlIo�;
                }
            }
            uasort( &$_obf_lJKNk5OTkYiOj4uTlI_JiYc�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�], "zsarr_sort" );
            foreach ( $_obf_lJKNk5OTkYiOj4uTlI_JiYc�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�] as $_obf_jIyQkoaHk5OPiImPh4uUjYw� )
            {
                $_obf_jpSNkJSGhpGKiImJi4_LkJM� = floor( $_obf_i5OKioaRlY6TkIaGkZSGlIo� / $_obf_jIyQkoaHk5OPiImPh4uUjYw�['num'] );
                if ( !( $_obf_jpSNkJSGhpGKiImJi4_LkJM� == 0 ) )
                {
                    $_obf_i5OKioaRlY6TkIaGkZSGlIo� -= $_obf_jIyQkoaHk5OPiImPh4uUjYw�['num'] * $_obf_jpSNkJSGhpGKiImJi4_LkJM�;
                    $_obf_iZWHiZKQjpOJk5GKiJSPkpE� += $_obf_jIyQkoaHk5OPiImPh4uUjYw�['zsday'] * $_obf_jpSNkJSGhpGKiImJi4_LkJM�;
                    $_obf_lIyIi5GQlYaNkIeIlI6LiIo� += $_obf_jIyQkoaHk5OPiImPh4uUjYw�['zspoints'] * $_obf_jpSNkJSGhpGKiImJi4_LkJM�;
                }
            }
        }
    }
    $_obf_iJSNkomSi4qVlJOHlYuSi4k� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
    $_obf_k42Sho2GiIeHk42OjIaPipQ� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
    if ( $_obf_iZWHiZKQjpOJk5GKiJSPkpE� != 0 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + $_obf_iZWHiZKQjpOJk5GKiJSPkpE�;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
    }
    if ( $_obf_lIyIi5GQlYaNkIeIlI6LiIo� != 0 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + $_obf_lIyIi5GQlYaNkIeIlI6LiIo�;
    }
    if ( $_obf_iZWHiZKQjpOJk5GKiJSPkpE� != 0 || $_obf_lIyIi5GQlYaNkIeIlI6LiIo� != 0 )
    {
        $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values\t(".$_obf_jomPk5WKioeLipGGi4_PhpM�.",7,'".$_obf_lI2KiouPkIaOj5OJiJSTiI4�."',".$_obf_iJSNkomSi4qVlJOHlYuSi4k�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_k42Sho2GiIeHk42OjIaPipQ�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].",'".$_obf_joyMko_HhpCVlJOMlJGPkIo�."','')";
    }
}
$_obf_kIaHkJSNhpOPi5OSh4eJlIY� = array( );
$_obf_lI2HjIqUkYqTho2HiJWUk5I� = "";
$_obf_hpSOkJGOiZGNiJOPiY_ViZQ� = 0;
$_obf_kYuMjomSiYiHioePiYmQiIo� = 0;
$_obf_iJWQj5WQlY_NkYePk5OGjZM� = 0;
$_obf_iZOGi4uQkI2Uho_Lk5CPhpM� = 0;
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['zs_tgset'] != "" && $_obf_k5WIi4mIlIaGkY2GlJGOj4w� != "" )
{
    if ( _obf_ioqHi5WHiJKIkoeIhouHjYw�( $_obf_k5WIi4mIlIaGkY2GlJGOj4w� ) < 3 )
    {
        _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "298", "推广帐号长度少于3个字符，如不知道推广帐号请留空。" );
    }
    $_obf_kI2Li4aJk4aMiIeSiIeUjIo� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_k5WIi4mIlIaGkY2GlJGOj4w�."'" );
    if ( empty( $_obf_kI2Li4aJk4aMiIeSiIeUjIo� ) )
    {
        _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "299", "所填的推广帐号不存在，如果你不清楚推广帐号请留空。" );
    }
    if ( PETIME <= $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] )
    {
        _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "300", "不能用公用帐号做为推广帐号。" );
    }
    if ( intval( $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['islock'] ) != 0 )
    {
        _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "301", "注册失败：所填的推广帐号被锁定，请填写一个有效的推广帐号或不填。" );
    }
    if ( intval( $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['ispause'] ) != 0 )
    {
        _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "302", "注册失败：所填的推广帐号被冻结，请填写一个有效的推广帐号或不填。" );
    }
    if ( intval( $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] ) < time( ) )
    {
        _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "303", "注册失败：所填的推广帐号已过期，请填写一个有效的推广帐号或不填。" );
    }
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['parentuser'] = $_obf_k5WIi4mIlIaGkY2GlJGOj4w�;
    $_obf_kpWRkZOIkYuNiIeTlIqPkpQ� = json_decode( base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['zs_tgset'] ), TRUE );
    foreach ( $_obf_jIaRh4iNjpKMioaTjZWGkY4� as $_obf_jo_SiI6SjIeSjoiMjoyTkpA� )
    {
        if ( isset( $_obf_kpWRkZOIkYuNiIeTlIqPkpQ�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�] ) )
        {
            $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� += $_obf_kpWRkZOIkYuNiIeTlIqPkpQ�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�]['zsday1'];
            $_obf_kYuMjomSiYiHioePiYmQiIo� += $_obf_kpWRkZOIkYuNiIeTlIqPkpQ�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�]['zspoints1'];
            $_obf_iJWQj5WQlY_NkYePk5OGjZM� += $_obf_kpWRkZOIkYuNiIeTlIqPkpQ�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�]['zsday2'];
            $_obf_iZOGi4uQkI2Uho_Lk5CPhpM� += $_obf_kpWRkZOIkYuNiIeTlIqPkpQ�[$_obf_jo_SiI6SjIeSjoiMjoyTkpA�]['zspoints2'];
        }
    }
    $_obf_iJSNkomSi4qVlJOHlYuSi4k� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
    $_obf_k42Sho2GiIeHk42OjIaPipQ� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
    if ( $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� != 0 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + $_obf_hpSOkJGOiZGNiJOPiY_ViZQ�;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
    }
    if ( $_obf_kYuMjomSiYiHioePiYmQiIo� != 0 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + $_obf_kYuMjomSiYiHioePiYmQiIo�;
    }
    if ( $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� != 0 || $_obf_kYuMjomSiYiHioePiYmQiIo� != 0 )
    {
        $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values \t(".$_obf_jomPk5WKioeLipGGi4_PhpM�.",4,'".$_obf_lI2KiouPkIaOj5OJiJSTiI4�."',".$_obf_iJSNkomSi4qVlJOHlYuSi4k�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_k42Sho2GiIeHk42OjIaPipQ�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].",'','".$_obf_kI2Li4aJk4aMiIeSiIeUjIo�['username']."')";
    }
    $_obf_iI_QkZGJh4yRk4mIkYuOiYg� = array( );
    $_obf_iJSNkomSi4qVlJOHlYuSi4k� = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'];
    $_obf_k42Sho2GiIeHk42OjIaPipQ� = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'];
    if ( $_obf_iJWQj5WQlY_NkYePk5OGjZM� != 0 )
    {
        $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'] + $_obf_iJWQj5WQlY_NkYePk5OGjZM�;
        $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['endtime'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['starttime'] + $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'] * 86400;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "推广帐号赠送VAL_pBday天";
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_pBday'] = $_obf_iJWQj5WQlY_NkYePk5OGjZM�;
    }
    if ( $_obf_iZOGi4uQkI2Uho_Lk5CPhpM� != 0 )
    {
        $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['points'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'] + $_obf_iZOGi4uQkI2Uho_Lk5CPhpM�;
        if ( $_obf_lI2HjIqUkYqTho2HiJWUk5I� == "" )
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "推广帐号赠送";
        }
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "VAL_pBpoints点";
        $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_pBpoints'] = $_obf_iZOGi4uQkI2Uho_Lk5CPhpM�;
    }
    if ( $_obf_iJWQj5WQlY_NkYePk5OGjZM� != 0 || $_obf_iZOGi4uQkI2Uho_Lk5CPhpM� != 0 )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_iI_QkZGJh4yRk4mIkYuOiYg�, "username='".$_obf_k5WIi4mIlIaGkY2GlJGOj4w�."'", "sql" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
        {
            $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = $_obf_lY6RhpOJh46VkJOGkoeRiIY�;
        }
        if ( !isset( $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'] ) )
        {
            $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'];
        }
        if ( !isset( $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['points'] ) )
        {
            $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['points'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'];
        }
        $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",3,'".$_obf_kI2Li4aJk4aMiIeSiIeUjIo�['username']."',".$_obf_iJSNkomSi4qVlJOHlYuSi4k�.",".$_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'].",".$_obf_k42Sho2GiIeHk42OjIaPipQ�.",".$_obf_iI_QkZGJh4yRk4mIkYuOiYg�['points'].",'','".$_obf_lI2KiouPkIaOj5OJiJSTiI4�."')";
    }
}
if ( 10001 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid'] && 0.5 < ( $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� + $_obf_iZWHiZKQjpOJk5GKiJSPkpE� ) / $_obf_ioyQkY6QhoeUjo6MjIaSkJM� )
{
    _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "304", "月付版客户总的赠送天数不能超出卡面天数的50%[ VAL_zsday / VAL_kmday ]", array(
        "VAL_zsday" => $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� + $_obf_iZWHiZKQjpOJk5GKiJSPkpE�,
        "VAL_kmday" => $_obf_ioyQkY6QhoeUjo6MjIaSkJM�
    ) );
}
if ( $_obf_lI2HjIqUkYqTho2HiJWUk5I� != "" )
{
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "，";
}
$_obf_iIqGj4aSiJOUkY6HiYeGiYk� = "本帐号赠送";
if ( 0 < $_obf_hpSOkJGOiZGNiJOPiY_ViZQ� + $_obf_iZWHiZKQjpOJk5GKiJSPkpE� )
{
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= $_obf_iIqGj4aSiJOUkY6HiYeGiYk�."VAL_Bday天";
    $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_Bday'] = $_obf_iZWHiZKQjpOJk5GKiJSPkpE� + $_obf_hpSOkJGOiZGNiJOPiY_ViZQ�;
    $_obf_iIqGj4aSiJOUkY6HiYeGiYk� = "";
}
if ( 0 < $_obf_kYuMjomSiYiHioePiYmQiIo� + $_obf_lIyIi5GQlYaNkIeIlI6LiIo� )
{
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= $_obf_iIqGj4aSiJOUkY6HiYeGiYk�."VAL_Bpoints点";
    $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_Bpoints'] = $_obf_lIyIi5GQlYaNkIeIlI6LiIo� + $_obf_kYuMjomSiYiHioePiYmQiIo�;
}
if ( $_obf_lI2HjIqUkYqTho2HiJWUk5I� != "" )
{
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "，";
}
$_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set `cztime`=".$_obf_jomPk5WKioeLipGGi4_PhpM�.",`czusername`='".$_obf_lI2KiouPkIaOj5OJiJSTiI4�."' where `keys` in ('".join( "','", $_obf_jZCUjpOJiY6Iio_SiIyGk48� )."')";
$_obf_kY2Qi5OGjImIh46TjZKNk48� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
if ( $_obf_kY2Qi5OGjImIh46TjZKNk48� !== TRUE )
{
    _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 402 );
    _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "305", "注册帐号失败：修改注册卡状态时出错VAL_sqlerr", array(
        "VAL_sqlerr" => $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )
    ) );
}
$_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "sync" );
if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
{
    if ( !empty( $_obf_lI6Oh5CKh42Ri5STio2HjpE� ) )
    {
        foreach ( $_obf_lI6Oh5CKh42Ri5STio2HjpE� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
        {
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, "sync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
            {
                _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 412 );
            }
        }
    }
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "本帐号时间VAL_Aday天";
    $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_Aday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "VAL_Apoints点。";
    $_obf_kIaHkJSNhpOPi5OSh4eJlIY�['VAL_Apoints'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
    _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "307", "注册帐号成功，".$_obf_lI2HjIqUkYqTho2HiJWUk5I�, $_obf_kIaHkJSNhpOPi5OSh4eJlIY� );
}
else
{
    _obf_lJCQjZSSkpSSiI2Sh42LjYk�( "306", "注册帐号失败！原因：VAL_sqlerr", array(
        "VAL_sqlerr" => $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )
    ) );
}
?>
