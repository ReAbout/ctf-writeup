<?php

function _obf_jpSOlYyLk5OVj4eQj5KHiIo�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_kZOVhpCShoiIlZCJhoqVlI0�( $_obf_j4qRlY6KjYeVhpSPi4yGkIg� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['unlineday'] != date( "d" ) )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_user_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']."` set `unlineday`=".date( "d" ).",`unlinetimes`=1 where `id`=".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['id'], "notsync" );
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( $_obf_j4qRlY6KjYeVhpSPi4yGkIg� );
        echo "update `kss_z_user_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']."` set `unlineday`=".date( "d" ).",`unlinetimes`=1 where `id`=".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['id'];
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
    }
    else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinelock'] <= $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['unlinetimes'] )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_user_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']."` set `islock`=3,`intro`='非法下线次数超限' where `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."' ", "sync" );
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 3 );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
    }
    else
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_user_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']."` set `unlinetimes`=`unlinetimes`+1 where `id`=".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['id'], "notsync" );
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( $_obf_j4qRlY6KjYeVhpSPi4yGkIg� );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
    }
}

function _obf_lJSVj4aKiIaUkJKUioiVjZQ�( $_obf_jJSNk5SMkY_PiouMko2LkYY� )
{
    global $_obf_jpOTkJCPjI_TipSPjoeTjYs�;
    global $_obf_lYqUjoqMiomGlYiQio6Qi4Y�;
    global $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    global $_obf_kJSVj4qJlIyOi5SQiZKRiYk�;
    global $_obf_lIyRio6Kho6LiIaVkY_SiZA�;
    global $_obf_joeUio_LioqSh5WIiI2Pk4s�;
    $_obf_j4yMjoyKj42Ti5STjo_HjIY� = "insert into kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`username`,`optype`,`clientid`,`addtime`,`ip`,`pccode`,`linecode`,`opccode`,`oip`) values ";
    $_obf_j4yMjoyKj42Ti5STjo_HjIY� .= "('".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_jJSNk5SMkY_PiouMko2LkYY�.",".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'].",".time( ).",".$_obf_kYmJjZOIiZKJioqMkoaGiYk�.",'".$_obf_joeUio_LioqSh5WIiI2Pk4s�."','".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode']."','".$_obf_kJSVj4qJlIyOi5SQiZKRiYk�."',".$_obf_lIyRio6Kho6LiIaVkY_SiZA�.")";
    return $_obf_j4yMjoyKj42Ti5STjo_HjIY�;
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = substr( _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" ), 0, 10 );
}
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "username" );
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "clientid" );
$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'] = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "linecode" );
$_obf_joeUio_LioqSh5WIiI2Pk4s� = _obf_hoaHlYiMh5OOjpGNiYmLk5A�( "pccode" );
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
$_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' " );
if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "393", "用户未找到，下线失败！" );
}
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] == PETIME )
{
    _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "394", "公用帐号，无需执行此操作！" );
}
$_obf_k5SIlJCMhoiIjJWMi5WLkY8� = array( );
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] == 1 )
{
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['pccode'];
    $_obf_lIyRio6Kho6LiIaVkY_SiZA� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['lastip'];
    if ( SVRID == 1 && _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( $_obf_joeUio_LioqSh5WIiI2Pk4s�, $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['pccode'] ) === FALSE )
    {
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinelock'] )
        {
            _obf_kZOVhpCShoiIlZCJhoqVlI0�( 5 );
        }
        else
        {
            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 5 );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        }
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "396", "下线失败，机器码不符" );
    }
    if ( SVRID == 1 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] != "1" && $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linecode'] != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'] )
    {
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinelock'] )
        {
            _obf_kZOVhpCShoiIlZCJhoqVlI0�( 7 );
        }
        else
        {
            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 7 );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        }
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "397", "下线失败，在线码不符" );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set `isonline`=0,`lasttime`=".( time( ) - ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['connectpenli'] + 6 ) * 60 )." where  `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "notsync" );
}
else
{
    $_obf_k5SIlJCMhoiIjJWMi5WLkY8� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from `kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`=".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'] );
    if ( empty( $_obf_k5SIlJCMhoiIjJWMi5WLkY8� ) )
    {
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "393", "用户未找到，下线失败！" );
    }
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['pccode'];
    $_obf_lIyRio6Kho6LiIaVkY_SiZA� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['lastip'];
    if ( SVRID == 1 && _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( $_obf_joeUio_LioqSh5WIiI2Pk4s�, $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['pccode'] ) === FALSE )
    {
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinelock'] )
        {
            _obf_kZOVhpCShoiIlZCJhoqVlI0�( 5 );
        }
        else
        {
            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 5 );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        }
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "396", "下线失败，机器码不符" );
    }
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] != "1" && $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['linecode'] != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'] )
    {
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinelock'] )
        {
            _obf_kZOVhpCShoiIlZCJhoqVlI0�( 7 );
        }
        else
        {
            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 7 );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        }
        _obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "397", "下线失败，在线码不符" );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set `isonline`=0,`lasttime`=".( time( ) - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['connectpenl'] * 60 )." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`=".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'], "notsync" );
}
$_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 4 );
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
_obf_j5CLlY6TlYqUiI_VlI6Vk5Q�( "398", "下线成功" );
?>
