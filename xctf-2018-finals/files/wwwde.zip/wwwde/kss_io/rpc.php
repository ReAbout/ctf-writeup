<?php

function _obf_lJCGi5CSkIyRkYiVlY2Gjoc�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

require( "../kss_inc/inc.php" );
if ( isset( $_GET['getgenkey'] ) )
{
    $_obf_kJOTiIaNkY6Uh5CUho2Tho4� = _obf_jZKGhoeQk46KiJCHi5CLjpQ�( );
    exit( urlencode( $_obf_kJOTiIaNkY6Uh5CUho2Tho4� ) );
}
?>
