<?php

function _obf_j4_IiouMj4qMkYqNhoyIjoo�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function api_set( $_obf_h42RjJWNj5CGkYyGjpCJioo�, $_obf_iYyKk4eTjYuQlIqLiZWHkok� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    global $_obf_k5SIlJCMhoiIjJWMi5WLkY8�;
    global $_obf_kpOMjo6Mh4yUk42Uh4mNh4s�;
    global $_obf_jpOTkJCPjI_TipSPjoeTjYs�;
    $_obf_jI6OlImSkJKVjImHkIaUipA� = array( "锁" => "islock", "锁定" => "islock", "标签" => "tag", "备注" => "intro", "天数" => "cday", "点数" => "points", "开始时间" => "starttime", "到期时间" => "endtime", "附属性" => "keyextattr", "付属性" => "keyextattr", "机器码" => "pccode", "私有数据" => "updata", "绑定信息" => "bdinfo" );
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = FALSE;
    if ( !array_key_exists( $_obf_h42RjJWNj5CGkYyGjpCJioo�, $_obf_jI6OlImSkJKVjImHkIaUipA� ) )
    {
        return "par1err";
    }
    $_obf_iJGJjY2NkYqSkoqMho6Tio0� = mysql_real_escape_string( $_obf_iYyKk4eTjYuQlIqLiZWHkok� );
    switch ( $_obf_h42RjJWNj5CGkYyGjpCJioo� )
    {
    case "锁" :
    case "锁定" :
    case "标签" :
    case "备注" :
    case "天数" :
    case "开始时间" :
    case "到期时间" :
    case "点数" :
    case "附属性" :
    case "付属性" :
        $_obf_j4uUkJCTkIuMko6Vj5SSlYY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "UPDATE `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set `".$_obf_jI6OlImSkJKVjImHkIaUipA�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]."`='".$_obf_iJGJjY2NkYqSkoqMho6Tio0�."' where `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."' ", "sync" );
        if ( $_obf_j4uUkJCTkIuMko6Vj5SSlYY� !== TRUE )
        {
            $_obf_j4uUkJCTkIuMko6Vj5SSlYY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
        }
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_j4uUkJCTkIuMko6Vj5SSlYY�;
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    case "机器码" :
    case "私有数据" :
    case "绑定信息" :
        if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] == 1 )
        {
            $_obf_j4uUkJCTkIuMko6Vj5SSlYY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "UPDATE `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set `".$_obf_jI6OlImSkJKVjImHkIaUipA�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]."`='".$_obf_iJGJjY2NkYqSkoqMho6Tio0�."' where `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."'", "sync" );
        }
        else
        {
            $_obf_j4uUkJCTkIuMko6Vj5SSlYY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "UPDATE `kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set `".$_obf_jI6OlImSkJKVjImHkIaUipA�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]."`='".$_obf_iJGJjY2NkYqSkoqMho6Tio0�."' where `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."' and `clientid`=".$_obf_k5SIlJCMhoiIjJWMi5WLkY8�['clientid'], "sync" );
        }
        if ( $_obf_j4uUkJCTkIuMko6Vj5SSlYY� !== TRUE )
        {
            $_obf_j4uUkJCTkIuMko6Vj5SSlYY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
        }
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_j4uUkJCTkIuMko6Vj5SSlYY�;
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    }
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = FALSE;
    return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
}

function api_get( $_obf_h42RjJWNj5CGkYyGjpCJioo� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    global $_obf_k5SIlJCMhoiIjJWMi5WLkY8�;
    global $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    $_obf_hoaLk5CMjo6RlZGTlY_GjpE� = array(
        "当前IP" => $_obf_kYmJjZOIiZKJioqMkoaGiYk�,
        "用户名" => "username",
        "锁" => "islock",
        "锁定" => "islock",
        "登陆密码" => "password",
        "用户密码" => "password",
        "安全密码" => "password2",
        "标签" => "tag",
        "登陆次数" => "activetimes",
        "备注" => "intro",
        "天数" => "cday",
        "点数" => "points",
        "附属性" => "keyextattr",
        "付属性" => "keyextattr",
        "开始时间戮" => "starttime",
        "开始时间" => "starttime",
        "机器码" => "pccode",
        "私有数据" => "updata",
        "绑定信息" => "bdinfo",
        "上一次IP" => "lastip"
    );
    if ( !array_key_exists( $_obf_h42RjJWNj5CGkYyGjpCJioo�, $_obf_hoaLk5CMjo6RlZGTlY_GjpE� ) )
    {
        return "par1err";
    }
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = "";
    switch ( $_obf_h42RjJWNj5CGkYyGjpCJioo� )
    {
    case "当前IP" :
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_hoaLk5CMjo6RlZGTlY_GjpE�[$_obf_h42RjJWNj5CGkYyGjpCJioo�];
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    case "用户名" :
    case "锁" :
    case "锁定" :
    case "登陆密码" :
    case "用户密码" :
    case "安全密码" :
    case "标签" :
    case "登陆次数" :
    case "备注" :
    case "天数" :
    case "点数" :
    case "附属性" :
    case "付属性" :
    case "开始时间戮" :
    case "开始时间" :
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�[$_obf_hoaLk5CMjo6RlZGTlY_GjpE�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]];
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    case "机器码" :
    case "私有数据" :
    case "绑定信息" :
    case "上一次IP" :
        if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
        {
            $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�[$_obf_hoaLk5CMjo6RlZGTlY_GjpE�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]];
            return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
        }
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�[$_obf_hoaLk5CMjo6RlZGTlY_GjpE�[$_obf_h42RjJWNj5CGkYyGjpCJioo�]];
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    }
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = "par1err";
    return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
}

function api_points( &$_obf_jYiMkoyVi5GOkY_NiIyKioc�, $_obf_iI_TiI_HjoiGj4eIkZSIjog�, $_obf_jYaTjpCOhpGOhoaJjpGKjpE� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    $_obf_jomPk5WKioeLipGGi4_PhpM� = time( );
    if ( $_obf_iI_TiI_HjoiGj4eIkZSIjog� < 0 )
    {
        $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "要扣的点数小于0";
        return FALSE;
    }
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'] < $_obf_iI_TiI_HjoiGj4eIkZSIjog� )
    {
        $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "用户点数不够扣";
        return FALSE;
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_sql_points where guid='".$_obf_jYaTjpCOhpGOhoaJjpGKjpE�."' and `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."' and tbname='".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']."' and svrid=1 and addtime>".( $_obf_jomPk5WKioeLipGGi4_PhpM� - 180 )." limit 0,1" );
    if ( !empty( $_obf_lY6RhpOJh46VkJOGkoeRiIY� ) )
    {
        $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "本次未扣点，可能是重复扣点操作";
        return $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'];
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']." set `points`=`points`-".$_obf_iI_TiI_HjoiGj4eIkZSIjog�." where `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."'", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === TRUE )
    {
        if ( SVRID == 2 )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_tb_sql_points (`addtime`,`tbname`,`username`,`points`,`guid`,`svrid`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",'".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']."','".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."',".$_obf_iI_TiI_HjoiGj4eIkZSIjog�.",'".$_obf_jYaTjpCOhpGOhoaJjpGKjpE�."',".SVRID.")", "notsync" );
        }
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = "扣点成功";
        return $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'] - $_obf_iI_TiI_HjoiGj4eIkZSIjog�;
    }
    $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "执行扣点SQL失败";
    return FALSE;
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'];
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 10, 10 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 0, 10 );
}
$_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `password`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password']."' " );
if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
{
    exit( "crypteno300" );
}
if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
{
    exit( "crypteno301" );
}
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] < $_obf_jomPk5WKioeLipGGi4_PhpM� )
{
    exit( "crypteno302" );
}
$_obf_k5SIlJCMhoiIjJWMi5WLkY8� = array( );
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] != "1" && $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['ischangesvr'] != 1 && $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] != PETIME )
{
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] == 1 )
    {
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] != "1" && $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linecode'] != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'] )
        {
            exit( "crypteno305" );
        }
    }
    else
    {
        $_obf_k5SIlJCMhoiIjJWMi5WLkY8� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from `kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`=".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'] );
        if ( empty( $_obf_k5SIlJCMhoiIjJWMi5WLkY8� ) )
        {
            exit( "crypteno304" );
        }
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] != "1" && $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['linecode'] != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'] )
        {
            exit( "crypteno305" );
        }
    }
}
$_obf_lIeKioqNiYaOlIyQjouSlY8� = KSSINCDIR."advapi".DIRECTORY_SEPARATOR.$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid'].$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'].".php";
if ( is_file( $_obf_lIeKioqNiYaOlIyQjouSlY8� ) )
{
    include( $_obf_lIeKioqNiYaOlIyQjouSlY8� );
}
else
{
    exit( "crypteno306" );
}
$_obf_kYeVlJWTjYuNjoeSkYuPiZE� = explode( ",", $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['cmd'] );
$_obf_kpWTkImVh4yUiZGLlIuPiIk� = $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[0];
if ( substr( $_obf_kpWTkImVh4yUiZGLlIuPiIk�, 0, 2 ) != "v_" )
{
    exit( "crypteno307" );
}
if ( !function_exists( $_obf_kpWTkImVh4yUiZGLlIuPiIk� ) )
{
    exit( "crypteno308" );
}
$_obf_jZGRipSRkIeUiIeQjoaUjJI�['advapi'] = "";
$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softintro'] = "";
$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softnotice'] = "";
$_obf_jZGRipSRkIeUiIeQjoaUjJI�['updatelog'] = "";
$_obf_jYmJi42Gh42MhoqLkY_MlZM� = array(
    "soft" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�,
    "member" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�,
    "client" => $_obf_k5SIlJCMhoiIjJWMi5WLkY8�,
    "ip" => long2ip( $_obf_kYmJjZOIiZKJioqMkoaGiYk� ),
    "intip" => $_obf_kYmJjZOIiZKJioqMkoaGiYk�,
    "pccode" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[4],
    "username" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'],
    "password" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'],
    "clientid" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'],
    "linecode" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[8],
    "ischangesvr" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[9],
    "cmd" => $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[10]
);
$adv_db = $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
$adv_table = $_obf_jpOTkJCPjI_TipSPjoeTjYs�;
$adb_pdata = $_obf_jYmJi42Gh42MhoqLkY_MlZM�;
$adv_user = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
$adv_user2 = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�;
switch ( count( $_obf_kYeVlJWTjYuNjoeSkYuPiZE� ) )
{
case 1 :
    $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
    break;
case 2 :
    $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
    break;
case 3 :
    $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
    break;
case 4 :
    $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
    break;
case 5 :
    $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
    break;
case 6 :
    $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[5], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
    break;
case 7 :
    $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[5], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[6], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
    break;
case 8 :
    $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[5], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[6], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[7], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
    break;
case 9 :
    $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[5], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[6], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[7], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[8], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
    break;
case 10 :
    $_obf_kI_Gho_HjoqTk4mJiIuIh5M� = $_obf_kpWTkImVh4yUiZGLlIuPiIk�( $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[1], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[2], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[3], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[4], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[5], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[6], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[7], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[8], $_obf_kYeVlJWTjYuNjoeSkYuPiZE�[9], $_obf_jYmJi42Gh42MhoqLkY_MlZM�, $_obf_jIaUiIeSjZWKlIqLkIqOioc� );
    break;
default :
    exit( "crypteno309" );
}
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set lasttime=".$_obf_jomPk5WKioeLipGGi4_PhpM�." where `username`='".$_obf_jYmJi42Gh42MhoqLkY_MlZM�['username']."'", "notsync" );
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time_advapi'] != 0 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_times_advapi'] != 0 )
{
    $_obf_kZKOjI2JjoaKiJCGi4qQkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(*) as tnum from kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and optype=30 and addtime>".( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time_advapi'] * 60 ) );
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_times_advapi'] < $_obf_kZKOjI2JjoaKiJCGi4qQkok�['tnum'] )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set islock=3,intro='调用advapi太频繁，锁定帐号' where username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sync" );
        $_obf_j4yMjoyKj42Ti5STjo_HjIY� = "insert into kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`username`,`optype`,`clientid`,`addtime`,`ip`,`pccode`,`linecode`,`opccode`,`oip`) values ";
        $_obf_j4yMjoyKj42Ti5STjo_HjIY� .= "('".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',31,".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'].",".time( ).",".$_obf_kYmJjZOIiZKJioqMkoaGiYk�.",'".$_obf_joeUio_LioqSh5WIiI2Pk4s�."','".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode']."','',".$_obf_kYmJjZOIiZKJioqMkoaGiYk�.")";
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_j4yMjoyKj42Ti5STjo_HjIY�, "notsync" );
        exit( "crypteno129" );
    }
}
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`username`,`optype`,`clientid`,`addtime`,`ip`,`pccode`,`linecode`,`opccode`,`oip`) values  ('".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',30,".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'].",".time( ).",".$_obf_kYmJjZOIiZKJioqMkoaGiYk�.",'".$_obf_joeUio_LioqSh5WIiI2Pk4s�."','".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode']."','".$_obf_joeUio_LioqSh5WIiI2Pk4s�."',".$_obf_kYmJjZOIiZKJioqMkoaGiYk�.")", "notsync" );
$_obf_kZWIioyVlJKMho_KiIeJjZE� = _obf_koiSlI6IlZSMkY_IiZSSkIw�( $_obf_kI_Gho_HjoqTk4mJiIuIh5M�, $_obf_ko2PhoaRkIeRh5GQjIuGjo4�, Client_Language );
if ( $_obf_kpWTkImVh4yUiZGLlIuPiIk� != "v_points" )
{
    if ( !defined( "SOFTRSAMODE" ) )
    {
        $_obf_hpKMkImIjJSUh4aVkYuIlZE� = KSSINCDIR."advapi".DIRECTORY_SEPARATOR."rsa".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softcode'].".php";
        if ( is_file( $_obf_hpKMkImIjJSUh4aVkYuIlZE� ) )
        {
            include( $_obf_hpKMkImIjJSUh4aVkYuIlZE� );
        }
        else
        {
            exit( "crypteno171" );
        }
    }
    if ( SOFTRSAMODE == 0 )
    {
        if ( RSACRYPT == 1 )
        {
            if ( strlen( RSA_PRVKEY ) < 70 || strlen( RSA_MODULES ) < 70 )
            {
                exit( "crypteno151" );
            }
            $_obf_hoaVjJGTj4uNioeOjpSVh4Y� = rsa_encrypt( substr( $_obf_kZWIioyVlJKMho_KiIeJjZE�, 0, 20 ), RSA_PRVKEY, RSA_MODULES, 256 );
            exit( "cryptrsadata".$_obf_hoaVjJGTj4uNioeOjpSVh4Y�."`".substr( $_obf_kZWIioyVlJKMho_KiIeJjZE�, 20 ) );
        }
        exit( "crypt".$_obf_kZWIioyVlJKMho_KiIeJjZE� );
    }
    if ( SOFTRSAMODE == 1 )
    {
        if ( strlen( SOFTRSAEKEY ) < 70 || strlen( SOFTRSANKEY ) < 70 )
        {
            exit( "crypteno151" );
        }
        $_obf_hoaVjJGTj4uNioeOjpSVh4Y� = rsa_encrypt( substr( $_obf_kZWIioyVlJKMho_KiIeJjZE�, 0, 20 ), SOFTRSAEKEY, SOFTRSANKEY, 256 );
        exit( "cryptrsadata".$_obf_hoaVjJGTj4uNioeOjpSVh4Y�."`".substr( $_obf_kZWIioyVlJKMho_KiIeJjZE�, 20 ) );
    }
    exit( "crypt".$_obf_kZWIioyVlJKMho_KiIeJjZE� );
}
exit( "crypt".$_obf_kZWIioyVlJKMho_KiIeJjZE� );
?>
