<?php

function _obf_jpSOlYyLk5OVj4eQj5KHiIo�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_kZOVhpCShoiIlZCJhoqVlI0�( $_obf_h4eSk4uGiZCKhoyNkIiTlI8�, $_obf_jZGRipSRkIeUiIeQjoaUjJI� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_i4aTkI_IjoaJlIyTiIuNkZA� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(*) as tnum from kss_z_log_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']." where `username`='".$_obf_h4eSk4uGiZCKhoyNkIiTlI8�."' and `optype` in (5,7)" );
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinelock'] <= $_obf_i4aTkI_IjoaJlIyTiIuNkZA�['tnum'] )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_user_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid']."_".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id']."` set `islock`=3,`intro`='非法下线次数超限' where `username`='".$_obf_h4eSk4uGiZCKhoyNkIiTlI8�."' ", "sync" );
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 3 );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
    }
}

function _obf_lJSVj4aKiIaUkJKUioiVjZQ�( $_obf_jJSNk5SMkY_PiouMko2LkYY� )
{
    global $_obf_jpOTkJCPjI_TipSPjoeTjYs�;
    global $_obf_lYqUjoqMiomGlYiQio6Qi4Y�;
    global $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    global $_obf_joeUio_LioqSh5WIiI2Pk4s�;
    global $_obf_kJSVj4qJlIyOi5SQiZKRiYk�;
    global $_obf_lIyRio6Kho6LiIaVkY_SiZA�;
    $_obf_j4yMjoyKj42Ti5STjo_HjIY� = "insert into kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`username`,`optype`,`clientid`,`addtime`,`ip`,`pccode`,`linecode`,`opccode`,`oip`) values ";
    $_obf_j4yMjoyKj42Ti5STjo_HjIY� .= "('".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_jJSNk5SMkY_PiouMko2LkYY�.",".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'].",".time( ).",".$_obf_kYmJjZOIiZKJioqMkoaGiYk�.",'".$_obf_joeUio_LioqSh5WIiI2Pk4s�."','".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode']."','".$_obf_kJSVj4qJlIyOi5SQiZKRiYk�."',".$_obf_lIyRio6Kho6LiIaVkY_SiZA�.")";
    return $_obf_j4yMjoyKj42Ti5STjo_HjIY�;
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 0, 10 );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['chkonline'] != "1" )
{
    exit( "crypteno198" );
}
$_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' " );
if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
{
    exit( "crypteno193" );
}
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] == PETIME )
{
    exit( "crypteno199" );
}
$_obf_k5SIlJCMhoiIjJWMi5WLkY8� = array( );
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] == 1 )
{
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['pccode'];
    $_obf_lIyRio6Kho6LiIaVkY_SiZA� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['lastip'];
    if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['isrun'] == "1" )
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 8 );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        exit( "crypteno192" );
    }
    if ( SVRID == 1 && _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( $_obf_joeUio_LioqSh5WIiI2Pk4s�, $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['pccode'] ) === FALSE )
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 5 );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinelock'] )
        {
            _obf_kZOVhpCShoiIlZCJhoqVlI0�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], $_obf_jZGRipSRkIeUiIeQjoaUjJI� );
        }
        exit( "crypteno197" );
    }
    if ( SVRID == 1 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] != "1" && $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linecode'] != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'] )
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 7 );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinelock'] )
        {
            _obf_kZOVhpCShoiIlZCJhoqVlI0�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], $_obf_jZGRipSRkIeUiIeQjoaUjJI� );
        }
        exit( "crypteno196" );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set `isonline`=0,`lasttime`=".time( )." where  `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "notsync" );
}
else
{
    $_obf_k5SIlJCMhoiIjJWMi5WLkY8� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from `kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`=".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'] );
    if ( empty( $_obf_k5SIlJCMhoiIjJWMi5WLkY8� ) )
    {
        exit( "crypteno194" );
    }
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['pccode'];
    $_obf_lIyRio6Kho6LiIaVkY_SiZA� = $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['lastip'];
    if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['isrun'] == "1" )
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 8 );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        exit( "crypteno192" );
    }
    if ( SVRID == 1 && _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( $_obf_joeUio_LioqSh5WIiI2Pk4s�, $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['pccode'] ) === FALSE )
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 5 );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinelock'] )
        {
            _obf_kZOVhpCShoiIlZCJhoqVlI0�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], $_obf_jZGRipSRkIeUiIeQjoaUjJI� );
        }
        exit( "crypteno197" );
    }
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] != "1" && $_obf_k5SIlJCMhoiIjJWMi5WLkY8�['linecode'] != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'] )
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 7 );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinelock'] )
        {
            _obf_kZOVhpCShoiIlZCJhoqVlI0�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], $_obf_jZGRipSRkIeUiIeQjoaUjJI� );
        }
        exit( "crypteno196" );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set `isonline`=0,`lasttime`=".time( )." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`=".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'], "notsync" );
}
$_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 4 );
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
exit( "crypteno199" );
?>
