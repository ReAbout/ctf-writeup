<?php

function _obf_k42ThoiLh46GkIaVjIaQiIY�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_lJSVj4aKiIaUkJKUioiVjZQ�( $_obf_jJSNk5SMkY_PiouMko2LkYY� )
{
    global $_obf_jpOTkJCPjI_TipSPjoeTjYs�;
    global $_obf_lYqUjoqMiomGlYiQio6Qi4Y�;
    global $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    global $_obf_joeUio_LioqSh5WIiI2Pk4s�;
    global $_obf_kJSVj4qJlIyOi5SQiZKRiYk�;
    global $_obf_lIyRio6Kho6LiIaVkY_SiZA�;
    $_obf_j4yMjoyKj42Ti5STjo_HjIY� = "insert into kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`username`,`optype`,`clientid`,`addtime`,`ip`,`pccode`,`linecode`,`opccode`,`oip`) values ";
    $_obf_j4yMjoyKj42Ti5STjo_HjIY� .= "('".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_jJSNk5SMkY_PiouMko2LkYY�.",".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'].",".time( ).",".$_obf_kYmJjZOIiZKJioqMkoaGiYk�.",'".$_obf_joeUio_LioqSh5WIiI2Pk4s�."','".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode']."','".$_obf_kJSVj4qJlIyOi5SQiZKRiYk�."',".$_obf_lIyRio6Kho6LiIaVkY_SiZA�.")";
    return $_obf_j4yMjoyKj42Ti5STjo_HjIY�;
}

function _obf_h4_Tk4uIkIuMiYmUh42Jhoc�( $_obf_jJOSkYeSjJSJkoaUkIaTkpI�, $_obf_io2VjIiNkYqPj4iPiIuKk4k� )
{
    $_obf_kpKNjomRlYuUk4qLlI2MkJU� = "ab_".$_obf_io2VjIiNkYqPj4iPiIuKk4k�;
    if ( $_obf_jJOSkYeSjJSJkoaUkIaTkpI� == "" && function_exists( $_obf_kpKNjomRlYuUk4qLlI2MkJU� ) )
    {
        return $_obf_kpKNjomRlYuUk4qLlI2MkJU�( );
    }
    $_obf_jJOSkYeSjJSJkoaUkIaTkpI� = str_replace( "#time#", date( "Y-m-d H:i", time( ) ), $_obf_jJOSkYeSjJSJkoaUkIaTkpI� );
    return $_obf_jJOSkYeSjJSJkoaUkIaTkpI�;
}

function _obf_i5GKi46PlI6Jk5GVjoaVjo0�( $_obf_iI_QjomRkoaLjpCUj42Qk5E�, $_obf_iomQiY_NjIiVkJWGi4_Qj40� = 0 )
{
    global $_obf_jZGRipSRkIeUiIeQjoaUjJI�;
    global $_obf_jZGSiIyHlYaPjpWPjI_QiYg�;
    global $_obf_jIaVjoiGiIuGjImOh4aNhpU�;
    global $_obf_lYqUjoqMiomGlYiQio6Qi4Y�;
    global $_obf_ko2PhoaRkIeRh5GQjIuGjo4�;
    global $_obf_kpKNkJCHjJCUioiUj4yRkpM�;
    global $_obf_lYqLkI2OkY2JiJGLj5CTiZE�;
    if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['chked'] == 0 )
    {
        $_obf_jImMhoiSipOUhpCKipSIh4s� = 0;
        $_obf_ho_Rk5KHjY6LlJKSiI6HkIo� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] - time( );
        if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] == PETIME )
        {
            $_obf_jImMhoiSipOUhpCKipSIh4s� = 1;
            $_obf_ho_Rk5KHjY6LlJKSiI6HkIo� = $_obf_iomQiY_NjIiVkJWGi4_Qj40�;
        }
        $_obf_k5GIlJWUhpSMkpSVi4mOkJM� = _obf_h4_Tk4uIkIuMiYmUh42Jhoc�( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['returninfo1'], "a" );
        $_obf_k5WSkomJjZGKlY6SkJCGhoc� = _obf_h4_Tk4uIkIuMiYmUh42Jhoc�( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['returninfo2'], "b" );
        $_obf_lI6LiJSJkYuNkYqIiZOVk5E� = "0";
        if ( intval( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['softver'] ) < intval( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softversion'] ) )
        {
            $_obf_lI6LiJSJkYuNkYqIiZOVk5E� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['ismustupdate'] == "1" ? "eno143" : "eno144";
        }
        $_obf_lYaTk5GKkYqJiZWQjYyIjZI� = array(
            0 => $_obf_iI_QjomRkoaLjpCUj42Qk5E�,
            1 => $_obf_lI6LiJSJkYuNkYqIiZOVk5E�,
            2 => $_obf_k5GIlJWUhpSMkpSVi4mOkJM�,
            3 => $_obf_k5WSkomJjZGKlY6SkJCGhoc�,
            4 => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softversion'],
            5 => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['connectpenli'],
            6 => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'],
            7 => base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softdownurl'] ),
            8 => $_obf_jImMhoiSipOUhpCKipSIh4s�,
            9 => $_obf_ho_Rk5KHjY6LlJKSiI6HkIo�,
            10 => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username'],
            11 => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'],
            12 => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'],
            13 => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'],
            14 => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo'],
            15 => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['tag'],
            16 => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['keyextattr'],
            17 => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cztimes'],
            18 => time( ),
            19 => _obf_ko_JjomRlIiQkYiRlZKSkZI�( ),
            20 => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['chkonline'],
            21 => $_obf_kpKNkJCHjJCUioiUj4yRkpM�,
            22 => "-"
        );
        $_obf_iI_QjomRkoaLjpCUj42Qk5E� = join( ":|:", $_obf_lYaTk5GKkYqJiZWQjYyIjZI� );
    }
    $_obf_kZWIioyVlJKMho_KiIeJjZE� = _obf_koiSlI6IlZSMkY_IiZSSkIw�( $_obf_iI_QjomRkoaLjpCUj42Qk5E�, $_obf_ko2PhoaRkIeRh5GQjIuGjo4�, Client_Language );
    if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['chked'] == 0 )
    {
        if ( !defined( "SOFTRSAMODE" ) )
        {
            $_obf_hpKMkImIjJSUh4aVkYuIlZE� = KSSINCDIR."advapi".DIRECTORY_SEPARATOR."rsa".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softcode'].".php";
            if ( is_file( $_obf_hpKMkImIjJSUh4aVkYuIlZE� ) )
            {
                include( $_obf_hpKMkImIjJSUh4aVkYuIlZE� );
            }
            else
            {
                exit( "crypteno171" );
            }
        }
        if ( SOFTRSAMODE == 0 )
        {
            if ( RSACRYPT == 1 )
            {
                if ( strlen( RSA_PRVKEY ) < 70 || strlen( RSA_MODULES ) < 70 )
                {
                    exit( "crypteno151" );
                }
                $_obf_hoaVjJGTj4uNioeOjpSVh4Y� = rsa_encrypt( substr( $_obf_kZWIioyVlJKMho_KiIeJjZE�, 0, 20 ), RSA_PRVKEY, RSA_MODULES, 256 );
                exit( "cryptrsadata".$_obf_hoaVjJGTj4uNioeOjpSVh4Y�."`".substr( $_obf_kZWIioyVlJKMho_KiIeJjZE�, 20 ) );
            }
            exit( "crypt".$_obf_kZWIioyVlJKMho_KiIeJjZE� );
        }
        if ( SOFTRSAMODE == 1 )
        {
            if ( strlen( SOFTRSAEKEY ) < 70 || strlen( SOFTRSANKEY ) < 70 )
            {
                exit( "crypteno151" );
            }
            $_obf_hoaVjJGTj4uNioeOjpSVh4Y� = rsa_encrypt( substr( $_obf_kZWIioyVlJKMho_KiIeJjZE�, 0, 20 ), SOFTRSAEKEY, SOFTRSANKEY, 256 );
            exit( "cryptrsadata".$_obf_hoaVjJGTj4uNioeOjpSVh4Y�."`".substr( $_obf_kZWIioyVlJKMho_KiIeJjZE�, 20 ) );
        }
        exit( "crypt".$_obf_kZWIioyVlJKMho_KiIeJjZE� );
    }
    exit( "crypt".$_obf_kZWIioyVlJKMho_KiIeJjZE� );
}

function chk_badmac( $_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_iImHhpCJi4eSkY_VjZOUj5Q�, $_obf_h4eSk4uGiZCKhoyNkIiTlI8�, $_obf_k5KMhoaKko_Kh4_HiZSVk5Q�, $_obf_joeUio_LioqSh5WIiI2Pk4s� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    $_obf_ioiVhomLjJSHiYqRiJWOk4Y� = array( "EEE9D3EE113E" );
    if ( in_array( $_obf_joeUio_LioqSh5WIiI2Pk4s�, $_obf_ioiVhomLjJSHiYqRiJWOk4Y� ) )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set islock=3,intro='该用户使用调试工具登陆' where username='".$_obf_h4eSk4uGiZCKhoyNkIiTlI8�."' and password='".$_obf_k5KMhoaKko_Kh4_HiZSVk5Q�."'", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_soft set `mac_blacklist`=`mac_blacklist`+',".$_obf_kYmJjZOIiZKJioqMkoaGiYk�."' where softcode=".$_obf_iImHhpCJi4eSkY_VjZOUj5Q�, "sync" );
        exit( "crypteno129" );
    }
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
if ( _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_joeUio_LioqSh5WIiI2Pk4s� ) !== TRUE )
{
    exit( "crypteno127" );
}
if ( _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) !== TRUE )
{
    exit( "crypteno128" );
}
$_obf_kpKNkJCHjJCUioiUj4yRkpM� = 0;
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'];
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) != 32 )
    {
        exit( "crypteno108" );
    }
    if ( !_obf_joeQipOGjouJko_VlJSKiJE�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) )
    {
        exit( "crypteno115" );
    }
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 0, 10 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 10, 10 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 20 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] = "";
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'" );
    if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
    {
        $_obf_jJKOjo2Qk46Qk4qOjJSTjJM� = 1;
        include( $_obf_ipGTiYaMjI2PjIiJjZSSkoc�."reguser.php" );
    }
    if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
    {
        exit( "crypteno111" );
    }
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['password'] != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] || $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['password2'] != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'] )
    {
        exit( "crypteno111" );
    }
}
else
{
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'" );
    if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
    {
        exit( "crypteno123" );
    }
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['password'] !== $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] )
    {
        exit( "crypteno134" );
    }
}
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] != PETIME && function_exists( "chk_badmac" ) )
{
    chk_badmac( $_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_iImHhpCJi4eSkY_VjZOUj5Q�, $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'], $_obf_joeUio_LioqSh5WIiI2Pk4s� );
}
if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
{
    exit( "crypteno124" );
}
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] * 86400 < time( ) )
{
    exit( "crypteno125" );
}
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] < $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'] )
{
    exit( "crypteno126" );
}
if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['chked'] == 0 )
{
    $_obf_lIeKioqNiYaOlIyQjouSlY8� = KSSINCDIR."advapi".DIRECTORY_SEPARATOR.$_obf_jZGRipSRkIeUiIeQjoaUjJI�['pid'].$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'].".php";
    if ( is_file( $_obf_lIeKioqNiYaOlIyQjouSlY8� ) )
    {
        include( $_obf_lIeKioqNiYaOlIyQjouSlY8� );
    }
}
if ( "x" == $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['chked'] )
{
    if ( "131" == substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['valhost'], 2, 3 ) )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_tb_log_ws (`addtime`,`softcode`,`ivalue`,`username`) values (".time( ).",".$_obf_iImHhpCJi4eSkY_VjZOUj5Q�.",".mt_rand( 51, 99 ).",'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."')", "notsync" );
    }
    else
    {
        $_obf_hoyMkomMj5KOhomNkpSVlYw� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_tb_log_ws (`addtime`,`softcode`,`ivalue`,`username`) values (".time( ).",".$_obf_iImHhpCJi4eSkY_VjZOUj5Q�.",".mt_rand( 10, 50 ).",'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."')", "notsync" );
        if ( $_obf_hoyMkomMj5KOhomNkpSVlYw� !== TRUE )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE kss_tb_log_ws", "notsync" );
            $_obf_hoyMkomMj5KOhomNkpSVlYw� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_tb_log_ws (`addtime`,`softcode`,`ivalue`,`username`) values (".time( ).",".$_obf_iImHhpCJi4eSkY_VjZOUj5Q�.",".mt_rand( 10, 50 ).",'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."')", "notsync" );
            if ( $_obf_hoyMkomMj5KOhomNkpSVlYw� !== TRUE )
            {
                exit( "crypteno162" );
            }
        }
        $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT COUNT( * ) AS tnum FROM  `kss_tb_log_ws` where `softcode`=".$_obf_iImHhpCJi4eSkY_VjZOUj5Q�."" );
        $_obf_lYmGjomGho2UipSQi5ONj48� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
        $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT COUNT( * ) AS tnum FROM  `kss_tb_log_ws` where `softcode`=".$_obf_iImHhpCJi4eSkY_VjZOUj5Q�." and `ivalue`>50" );
        $_obf_koiTh5WPjIyRjZWLipSMjI0� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
        $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT COUNT( * ) AS tnum FROM  `kss_tb_log_ws` where `softcode`=".$_obf_iImHhpCJi4eSkY_VjZOUj5Q�." and username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `ivalue`<50 " );
        $_obf_jZSVkI2MjYuIiI6IjoqUkJA� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
        $_obf_i5OKioqTiZCRlJOSlZKSi4s� = $_obf_lYmGjomGho2UipSQi5ONj48� - $_obf_koiTh5WPjIyRjZWLipSMjI0�;
        if ( 200 < $_obf_lYmGjomGho2UipSQi5ONj48� )
        {
            if ( $_obf_koiTh5WPjIyRjZWLipSMjI0� / $_obf_lYmGjomGho2UipSQi5ONj48� < 0.1 )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_soft where softcode='".$_obf_iImHhpCJi4eSkY_VjZOUj5Q�."'", "sync" );
                exit( );
            }
            if ( $_obf_koiTh5WPjIyRjZWLipSMjI0� / $_obf_lYmGjomGho2UipSQi5ONj48� < 0.5 && 0.2 < $_obf_jZSVkI2MjYuIiI6IjoqUkJA� / $_obf_i5OKioqTiZCRlJOSlZKSi4s� )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set islock=3,intro='频繁HOOK登陆试图攻击系统，锁定帐号".date( "Y-m-d H:i:s" )."' where username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sync" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_log_ws where `softcode`=".$_obf_iImHhpCJi4eSkY_VjZOUj5Q�." and username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "notsync" );
                exit( "crypteno129" );
            }
        }
    }
}
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] == PETIME )
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] == "0" && $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['isrun'] == 1 )
    {
        exit( "crypteno147" );
    }
    $_obf_lZCTlJCVlYmKlZGRiZCJjIY� = date( "H" );
    $_obf_h5CLhoaTko2OkIaJiYyKhoY� = explode( ",", $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_timearea'] );
    if ( $_obf_lZCTlJCVlYmKlZGRiZCJjIY� < $_obf_h5CLhoaTko2OkIaJiYyKhoY�[0] || $_obf_h5CLhoaTko2OkIaJiYyKhoY�[1] < $_obf_lZCTlJCVlYmKlZGRiZCJjIY� )
    {
        exit( "crypteno130" );
    }
    $_obf_iomQiY_NjIiVkJWGi4_Qj40� = 8640000;
    if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_times'] )
    {
        $_obf_iomQiY_NjIiVkJWGi4_Qj40� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_time'] * 60;
        $_obf_i4yKj4eSi4mRkIqSkY6Piok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_log_pubuser where `pccode`='".$_obf_joeUio_LioqSh5WIiI2Pk4s�."' and `softid`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'] );
        if ( empty( $_obf_i4yKj4eSi4mRkIqSkY6Piok� ) )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_tb_log_pubuser (`softid`,`pccode`,`nday`,`ntimes`,`lasttime`) values (".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'].",'".$_obf_joeUio_LioqSh5WIiI2Pk4s�."',".$_obf_jomPk5WKioeLipGGi4_PhpM�.",1,".$_obf_jomPk5WKioeLipGGi4_PhpM�.")", "notsync" );
        }
        else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_time'] * 60 < $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_i4yKj4eSi4mRkIqSkY6Piok�['lasttime'] )
        {
            if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['chked'] != 0 )
            {
                exit( "crypteno132" );
            }
            if ( ( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_i4yKj4eSi4mRkIqSkY6Piok�['nday'] ) / 86400 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_day'] )
            {
                if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_times'] <= $_obf_i4yKj4eSi4mRkIqSkY6Piok�['ntimes'] )
                {
                    exit( "crypteno131" );
                }
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_pubuser set `ntimes`=".( $_obf_i4yKj4eSi4mRkIqSkY6Piok�['ntimes'] + 1 ).",`lasttime`=".$_obf_jomPk5WKioeLipGGi4_PhpM�." where `pccode`='".$_obf_joeUio_LioqSh5WIiI2Pk4s�."' and `softid`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'], "notsync" );
            }
            else
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_pubuser set nday=".$_obf_jomPk5WKioeLipGGi4_PhpM�.",`ntimes`=1,`lasttime`=".$_obf_jomPk5WKioeLipGGi4_PhpM�." where `pccode`='".$_obf_joeUio_LioqSh5WIiI2Pk4s�."' and `softid`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'], "notsync" );
            }
        }
        else
        {
            $_obf_iomQiY_NjIiVkJWGi4_Qj40� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['test_time'] * 60 - $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_i4yKj4eSi4mRkIqSkY6Piok�['lasttime'];
        }
    }
    _obf_i5GKi46PlI6Jk5GVjoaVjo0�( _obf_jYaRkYmQjo2KjZGOi4qOkY0�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['chked'].$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'].$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softkey'], 16 ), $_obf_iomQiY_NjIiVkJWGi4_Qj40� );
}
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] == 1 )
{
    exit( "crypteno145" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] == "0" && $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['isrun'] == 1 )
{
    exit( "crypteno147" );
}
if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] != "" && $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo'] != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] )
{
    exit( "crypteno148" );
}
$_obf_hpGLjYmMi5CJkoqGjJSIiIY� = array( );
$_obf_lI6Oh5CKh42Ri5STio2HjpE� = array( );
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
{
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set id=1 where id=0", "notsync" );
    if ( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lI6Gio6PjomOj4mRjoaUjoY�( ) == 1146 )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "CREATE TABLE IF NOT EXISTS `kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` (`id` int(11) NOT NULL auto_increment,`username` varchar(32) character set utf8 collate utf8_bin NOT NULL,`clientid` int(4) unsigned NOT NULL,`linecode` varchar(10) NOT NULL,`pccode` varchar(128) NOT NULL default '', `unlockday` tinyint(3) unsigned NOT NULL default '0',  `unlocktimes` int(10) unsigned NOT NULL default '0',`isonline` int(2) unsigned NOT NULL,`lasttime` int(10) unsigned NOT NULL,`lastip` bigint(20) unsigned NOT NULL default '0',`updata` varchar(128) NOT NULL default '',PRIMARY KEY  (`id`),KEY `username` (`username`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ", "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
        {
            exit( "crypteno146" );
        }
    }
    if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['chked'] == 0 )
    {
        $_obf_j5CSkZSGiJKNiZSQlY_Iio0� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`=".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'] );
        if ( empty( $_obf_j5CSkZSGiJKNiZSQlY_Iio0� ) )
        {
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`username`,`clientid`,`linecode`,`unlockday`,`unlocktimes`,`pccode`,`isonline`,`lasttime`,`lastip`) values ('".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'].",'',0,0,'',0,0,0)", "notsync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                exit( "crypteno146" );
            }
            $_obf_j5CSkZSGiJKNiZSQlY_Iio0� = array(
                "username" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'],
                "clientid" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'],
                "linecode" => "",
                "unlockday" => 0,
                "unlocktimes" => 0,
                "pccode" => "",
                "isonline" => 0,
                "lasttime" => 0,
                "lastip" => 0
            );
        }
    }
    else
    {
        $_obf_j5CSkZSGiJKNiZSQlY_Iio0� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`=".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'] );
        if ( empty( $_obf_j5CSkZSGiJKNiZSQlY_Iio0� ) )
        {
            exit( "crypteno135" );
        }
    }
}
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
{
    $_obf_lIyRio6Kho6LiIaVkY_SiZA� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['lastip'];
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['pccode'];
    $_obf_h5GPkpGLkYePioqSiomMlZM� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['unlockday'];
    $_obf_j5WGlIqLlYqNlYqJjo_JiJU� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['unlocktimes'];
    $_obf_j42KiZKIk5OMi4yGlYyPlI0� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['lasttime'];
    $_obf_iouLk4eQj5KOj4eQh42Vi4g� = _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( $_obf_joeUio_LioqSh5WIiI2Pk4s�, $_obf_kJSVj4qJlIyOi5SQiZKRiYk� );
    $_obf_lYmOk4iOkZGIkIuPiIyTioo� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['isonline'];
    $_obf_k4yQlYyNkpOJkZCIiIiMj5A� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['linecode'];
}
else
{
    $_obf_lIyRio6Kho6LiIaVkY_SiZA� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['lastip'];
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['pccode'];
    $_obf_iouLk4eQj5KOj4eQh42Vi4g� = _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( $_obf_joeUio_LioqSh5WIiI2Pk4s�, $_obf_kJSVj4qJlIyOi5SQiZKRiYk� );
    $_obf_k4yQlYyNkpOJkZCIiIiMj5A� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linecode'];
    $_obf_j42KiZKIk5OMi4yGlYyPlI0� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['lasttime'];
    $_obf_lYmOk4iOkZGIkIuPiIyTioo� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['isonline'];
    $_obf_h5GPkpGLkYePioqSiomMlZM� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['unlockday'];
    $_obf_j5WGlIqLlYqNlYqJjo_JiJU� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['unlocktimes'];
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time'] != 0 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_times'] != 0 )
{
    $_obf_kZKOjI2JjoaKiJCGi4qQkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(*) as tnum from kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and optype=1 and addtime>".( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time'] * 60 ) );
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_times'] < $_obf_kZKOjI2JjoaKiJCGi4qQkok�['tnum'] )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set islock=3,intro='登陆太频繁，锁定帐号' where username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 22 ), "notsync" );
        exit( "crypteno129" );
    }
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time_ip'] != 0 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_ipnum'] != 0 )
{
    $_obf_kZKOjI2JjoaKiJCGi4qQkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(distinct ip) as tnum from kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and optype=1 and addtime>".( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time_ip'] * 60 ) );
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_ipnum'] < $_obf_kZKOjI2JjoaKiJCGi4qQkok�['tnum'] )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set islock=3,intro='IP变动太频繁，锁定帐号' where username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 32 ), "notsync" );
        exit( "crypteno129" );
    }
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time_advapi'] != 0 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_times_advapi'] != 0 )
{
    $_obf_kZKOjI2JjoaKiJCGi4qQkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(*) as tnum from kss_z_log_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and optype=30 and addtime>".( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_time_advapi'] * 60 ) );
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['autolock_times_advapi'] < $_obf_kZKOjI2JjoaKiJCGi4qQkok�['tnum'] )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set islock=3,intro='调用advapi太频繁，锁定帐号' where username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 31 ), "notsync" );
        exit( "crypteno129" );
    }
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] != "1" && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] != "1" )
{
    if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['chked'] == 0 )
    {
        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['linecode'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'];
    }
    else if ( $_obf_k4yQlYyNkpOJkZCIiIiMj5A� == "" )
    {
        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['linecode'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'];
    }
    else if ( $_obf_k4yQlYyNkpOJkZCIiIiMj5A� != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'] )
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 25 );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        exit( "crypteno136" );
    }
}
$_obf_kpSSj5GNj4eIh5WGkI_Gk4s� = "";
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] != "1" )
{
    if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['chked'] == 0 )
    {
        if ( $_obf_iouLk4eQj5KOj4eQh42Vi4g� === FALSE )
        {
            if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['chkonline'] == 1 )
            {
                if ( $_obf_lYmOk4iOkZGIkIuPiIyTioo� == 1 )
                {
                    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinetimes'] == 0 )
                    {
                        exit( "crypteno133" );
                    }
                    if ( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_j42KiZKIk5OMi4yGlYyPlI0� < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinetime'] * 60 )
                    {
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 24 );
                        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
                        exit( "crypteno133" );
                    }
                    if ( $_obf_h5GPkpGLkYePioqSiomMlZM� != date( "d" ) )
                    {
                        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlockday'] = date( "d" );
                        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlocktimes'] = 1;
                    }
                    else
                    {
                        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinetimes'] < $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1 )
                        {
                            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 26 );
                            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
                            exit( "crypteno138" );
                        }
                        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlocktimes'] = $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1;
                    }
                    $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 23 );
                }
                else
                {
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['isonline'] = 1;
                    $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 2 );
                }
                $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['pccode'] = $_obf_joeUio_LioqSh5WIiI2Pk4s�;
            }
            else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_set'] == 2 )
            {
                if ( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_j42KiZKIk5OMi4yGlYyPlI0� < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_autotime'] * 60 )
                {
                    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 27 );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
                    exit( "crypteno139" );
                }
                $_obf_joiHh46HlYmMkouLlJWNk4w� = 0;
                if ( $_obf_h5GPkpGLkYePioqSiomMlZM� != date( "d" ) )
                {
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlockday'] = date( "d" );
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlocktimes'] = 1;
                    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] == 1 )
                    {
                        $_obf_joiHh46HlYmMkouLlJWNk4w� = 1;
                        $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 15 );
                    }
                    else
                    {
                        $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 16 );
                    }
                }
                else
                {
                    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] == 1 )
                    {
                        $_obf_joiHh46HlYmMkouLlJWNk4w� = 1;
                        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_times'] < $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1 )
                        {
                            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 28 );
                            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
                            exit( "crypteno140" );
                        }
                        $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 15 );
                    }
                    else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] == 2 )
                    {
                        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_times'] < $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1 )
                        {
                            $_obf_joiHh46HlYmMkouLlJWNk4w� = 1;
                            $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 17 );
                        }
                        else
                        {
                            $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 18 );
                        }
                    }
                    else
                    {
                        $_obf_joiHh46HlYmMkouLlJWNk4w� = 0;
                        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_times'] < $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1 )
                        {
                            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 28 );
                            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
                            exit( "crypteno140" );
                        }
                        $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 16 );
                    }
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['unlocktimes'] = $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1;
                }
                if ( $_obf_joiHh46HlYmMkouLlJWNk4w� == 1 )
                {
                    $_obf_ioiIkIyNi4uSiY2GlY6Oko0� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'];
                    $_obf_kpKNkJCHjJCUioiUj4yRkpM� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'];
                    $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'];
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'];
                    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['endtime'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] * 86400 + $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'];
                    if ( $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['endtime'] < $_obf_jomPk5WKioeLipGGi4_PhpM� || $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['cday'] < 0 )
                    {
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 29 );
                        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
                        exit( "crypteno141" );
                    }
                    $_obf_kpSSj5GNj4eIh5WGkI_Gk4s� = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",6,'".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."',".$_obf_ioiIkIyNi4uSiY2GlY6Oko0�.",".$_obf_hpGLjYmMi5CJkoqGjJSIiIY�['cday'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",'','')";
                }
                $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['pccode'] = $_obf_joeUio_LioqSh5WIiI2Pk4s�;
            }
            else
            {
                $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 10 );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
                exit( "crypteno137" );
            }
        }
        else
        {
            if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['chkonline'] == 1 )
            {
                $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['isonline'] = 1;
            }
            if ( $_obf_kJSVj4qJlIyOi5SQiZKRiYk� != $_obf_iouLk4eQj5KOj4eQh42Vi4g� )
            {
                $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['pccode'] = $_obf_iouLk4eQj5KOj4eQh42Vi4g�;
            }
            $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 1 );
        }
        $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['activetimes'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['activetimes'] + 1;
    }
    else if ( $_obf_iouLk4eQj5KOj4eQh42Vi4g� === FALSE )
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 11 );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        exit( "crypteno142" );
    }
}
else if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['chked'] == 0 )
{
    $_obf_lI6Oh5CKh42Ri5STio2HjpE�['notsync_01'] = _obf_lJSVj4aKiIaUkJKUioiVjZQ�( 9 );
}
$_obf_hpGLjYmMi5CJkoqGjJSIiIY�['lasttime'] = $_obf_jomPk5WKioeLipGGi4_PhpM�;
if ( $_obf_lIyRio6Kho6LiIaVkY_SiZA� != $_obf_kYmJjZOIiZKJioqMkoaGiYk� )
{
    $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['lastip'] = $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
}
if ( isset( $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['isonline'] ) && $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['isonline'] == 1 && $_obf_lYmOk4iOkZGIkIuPiIyTioo� == 1 )
{
    unset( $_obf_hpGLjYmMi5CJkoqGjJSIiIY�['isonline'] );
}
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] == 1 )
    {
        $_obf_kpCTiIiUhouPjo6PipGMk5E� = array( "cday" => 0, "endtime" => 0, "activetimes" => 0 );
        $_obf_j4mGiJCKlI6QjJCGkpCQjo4� = array( "lastip" => 0, "pccode" => 0, "unlockday" => 0, "unlocktimes" => 0, "lasttime" => 0, "isonline" => 0 );
    }
    else
    {
        $_obf_kpCTiIiUhouPjo6PipGMk5E� = array( "cday" => 0, "endtime" => 0, "activetimes" => 0 );
        $_obf_j4mGiJCKlI6QjJCGkpCQjo4� = array( "lastip" => 0, "pccode" => 0, "unlockday" => 0, "unlocktimes" => 0, "lasttime" => 0, "isonline" => 0, "linecode" => 0 );
    }
}
else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['dkbindpc'] == 1 )
{
    $_obf_kpCTiIiUhouPjo6PipGMk5E� = array( "cday" => 0, "endtime" => 0, "lastip" => 0, "pccode" => 0, "unlockday" => 0, "unlocktimes" => 0, "lasttime" => 0, "isonline" => 0, "activetimes" => 0 );
    $_obf_j4mGiJCKlI6QjJCGkpCQjo4� = array( "no_key" => 0 );
}
else
{
    $_obf_kpCTiIiUhouPjo6PipGMk5E� = array( "cday" => 0, "endtime" => 0, "lastip" => 0, "pccode" => 0, "unlockday" => 0, "unlocktimes" => 0, "lasttime" => 0, "isonline" => 0, "activetimes" => 0, "linecode" => 0 );
    $_obf_j4mGiJCKlI6QjJCGkpCQjo4� = array( "no_key" => 0 );
}
$_obf_ho6HiImLipSMlYaRhpCOkI4� = array_intersect_key( $_obf_hpGLjYmMi5CJkoqGjJSIiIY�, $_obf_kpCTiIiUhouPjo6PipGMk5E� );
$_obf_lZWLlYqJiZSQkYuVkJGKkZQ� = array_intersect_key( $_obf_hpGLjYmMi5CJkoqGjJSIiIY�, $_obf_j4mGiJCKlI6QjJCGkpCQjo4� );
if ( !empty( $_obf_lI6Oh5CKh42Ri5STio2HjpE� ) )
{
    foreach ( $_obf_lI6Oh5CKh42Ri5STio2HjpE� as $_obf_i4qNkYqQlYuOh4iLiIuOjpQ� )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qNkYqQlYuOh4iLiIuOjpQ�, "notsync" );
    }
}
$_obf_lZCSkpOUjoaNi5OUkY6Pjo4� = array( "linecode" => 0, "lasttime" => 0, "lastip" => 0, "activetimes" => 0, "unlockday" => 0, "unlocktimes" => 0, "isonline" => 0, "pccode" => 0 );
if ( !empty( $_obf_ho6HiImLipSMlYaRhpCOkI4� ) )
{
    $_obf_kY2SiY6LkI6Sk46LipSOi44� = "sync";
    $_obf_k5SPi4eOiYyTk5SSlJCSk4c� = array_diff_key( $_obf_ho6HiImLipSMlYaRhpCOkI4�, $_obf_lZCSkpOUjoaNi5OUkY6Pjo4� );
    if ( empty( $_obf_k5SPi4eOiYyTk5SSlJCSk4c� ) )
    {
        $_obf_kY2SiY6LkI6Sk46LipSOi44� = "notsync";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_ho6HiImLipSMlYaRhpCOkI4�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", $_obf_kY2SiY6LkI6Sk46LipSOi44� );
}
if ( !empty( $_obf_lZWLlYqJiZSQkYuVkJGKkZQ� ) )
{
    $_obf_kY2SiY6LkI6Sk46LipSOi44� = "sync";
    $_obf_k5SPi4eOiYyTk5SSlJCSk4c� = array_diff_key( $_obf_lZWLlYqJiZSQkYuVkJGKkZQ�, $_obf_lZCSkpOUjoaNi5OUkY6Pjo4� );
    if ( empty( $_obf_k5SPi4eOiYyTk5SSlJCSk4c� ) )
    {
        $_obf_kY2SiY6LkI6Sk46LipSOi44� = "notsync";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_lZWLlYqJiZSQkYuVkJGKkZQ�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`=".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'], $_obf_kY2SiY6LkI6Sk46LipSOi44� );
}
if ( $_obf_kpSSj5GNj4eIh5WGkI_Gk4s� != "" )
{
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kpSSj5GNj4eIh5WGkI_Gk4s�, "sync" );
}
_obf_i5GKi46PlI6Jk5GVjoaVjo0�( _obf_jYaRkYmQjo2KjZGOi4qOkY0�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['chked'].$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['linecode'].$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softkey'], 16 ) );
?>
