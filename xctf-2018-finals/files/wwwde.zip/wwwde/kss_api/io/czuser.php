<?php

function _obf_kouLiIaPjJWUhoqLkYaQjIg�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
if ( SVRID == 2 )
{
    exit( "kssdata".QQ120 );
}
_obf_kpSOkYmPh5SSi4mMlYePjY4�( 0 );
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] != "USOFT" )
{
    exit( "kssdata".QQ121 );
}
if ( 2 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] )
{
    exit( "kssdata".QQ122 );
}
if ( ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) + 1 ) % 33 != 0 )
{
    exit( "kssdata".QQ123 );
}
$_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] );
if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
{
    exit( "kssdata".QQ124.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
}
$_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] );
if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
{
    exit( "kssdata".QQ125.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
}
$_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'" );
if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
{
    exit( "kssdata".QQ126 );
}
if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
{
    exit( "kssdata".QQ127 );
}
if ( PETIME <= $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] )
{
    exit( "kssdata".QQ128 );
}
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] < PETIME )
{
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] * 86400;
}
$_obf_j42HkJGSkI6UhoaJlYuVk4k� = array(
    "username" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username'],
    "starttime" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'],
    "endtime" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'],
    "cztimes" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cztimes'],
    "cday" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'],
    "points" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'],
    "managerid" => $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['managerid']
);
$_obf_jI6JkpSHj5SQkY2UiIeJkYc� = 0;
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] < $_obf_jomPk5WKioeLipGGi4_PhpM� )
{
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['starttime'] = $_obf_jomPk5WKioeLipGGi4_PhpM�;
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM�;
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = 0;
    $_obf_jI6JkpSHj5SQkY2UiIeJkYc� = 8;
}
$_obf_jpSHk4yRh5CUiZKVkJSPkY8� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
$_obf_k5SGkIiQkJKPiIuUlYmHhow� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
$_obf_kYiQkJKGlI6JlZWRioaKlYg� = explode( "|", $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] );
if ( 5 < count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) )
{
    exit( "kssdata".QQ128 );
}
$_obf_iJCHjZWRiJONk5OGlIqMipM� = array_unique( $_obf_kYiQkJKGlI6JlZWRioaKlYg� );
if ( count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) != count( $_obf_iJCHjZWRiJONk5OGlIqMipM� ) )
{
    exit( "kssdata".QQ129 );
}
$_obf_ipGJkpOKioePjIaGkIuQiJA� = array( );
$_obf_jZCUjpOJiY6Iio_SiIyGk48� = array( );
$_obf_lZONjIiPhoiGk4_JkJKGlJU� = array( );
foreach ( $_obf_kYiQkJKGlI6JlZWRioaKlYg� as $_obf_lZSGkoqUio_RlZGNkY6Liok� )
{
    $_obf_lIqUjpSPk4uMjZKMhoyTlZU� = substr( $_obf_lZSGkoqUio_RlZGNkY6Liok�, 4, 6 );
    $_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lIqUjpSPk4uMjZKMhoyTlZU�] = substr( $_obf_lZSGkoqUio_RlZGNkY6Liok�, 4, 6 );
    $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lIqUjpSPk4uMjZKMhoyTlZU�] = substr( $_obf_lZSGkoqUio_RlZGNkY6Liok�, 0, 4 );
    $_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lIqUjpSPk4uMjZKMhoyTlZU�] = substr( $_obf_lZSGkoqUio_RlZGNkY6Liok�, 10 );
}
$_obf_j46GkYaTj5KIkIyUh4aTjYs� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `keys` in ('".join( "','", $_obf_jZCUjpOJiY6Iio_SiIyGk48� )."') and isback=0" );
if ( empty( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) )
{
    _obf_kpSOkYmPh5SSi4mMlYePjY4�( 1 );
    exit( "kssdata".QQ130 );
}
if ( count( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) != count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) )
{
    $_obf_jpCKlY6RkYuPkoyHlJKMios� = "";
    _obf_kpSOkYmPh5SSi4mMlYePjY4�( 1 );
    foreach ( $_obf_j46GkYaTj5KIkIyUh4aTjYs� as $_obf_lZSGkoqUio_RlZGNkY6Liok� )
    {
        if ( !in_array( $_obf_lZSGkoqUio_RlZGNkY6Liok�['keys'], $_obf_jZCUjpOJiY6Iio_SiIyGk48� ) )
        {
            $_obf_jpCKlY6RkYuPkoyHlJKMios� .= QQ131.$_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].QQ132."\r\n";
        }
    }
    exit( "kssdata".$_obf_jpCKlY6RkYuPkoyHlJKMios� );
}
$_obf_jpCKlY6RkYuPkoyHlJKMios� = "";
$_obf_homPkY_KioeUiIeMipSQjZU� = 0;
$_obf_jImSiIyUiouIiZWUlIeHh5E� = 0;
$_obf_jYmSi4iRi4mJjZWUjI2PjIs� = 0;
foreach ( $_obf_j46GkYaTj5KIkIyUh4aTjYs� as $_obf_lZSGkoqUio_RlZGNkY6Liok� )
{
    if ( $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] != $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']] || $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyspassword'] != $_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']] )
    {
        $_obf_jpCKlY6RkYuPkoyHlJKMios� = QQ131.$_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].QQ133."，\r\n";
    }
    else if ( $_obf_lZSGkoqUio_RlZGNkY6Liok�['islock'] != 0 )
    {
        $_obf_jpCKlY6RkYuPkoyHlJKMios� = QQ131.$_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].QQ134."\r\n";
    }
    else
    {
        if ( 0 < $_obf_lZSGkoqUio_RlZGNkY6Liok�['cztime'] )
        {
            $_obf_jpCKlY6RkYuPkoyHlJKMios� = QQ131.$_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].QQ135."\r\n";
        }
        else
        {
            if ( $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] == $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_keytypeid'] )
            {
                $_obf_homPkY_KioeUiIeMipSQjZU� += 1;
            }
            $_obf_jImSiIyUiouIiZWUlIeHh5E� += $_obf_lZSGkoqUio_RlZGNkY6Liok�['cday'];
            $_obf_jYmSi4iRi4mJjZWUjI2PjIs� += $_obf_lZSGkoqUio_RlZGNkY6Liok�['points'];
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + $_obf_lZSGkoqUio_RlZGNkY6Liok�['cday'];
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + $_obf_lZSGkoqUio_RlZGNkY6Liok�['points'];
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] + $_obf_lZSGkoqUio_RlZGNkY6Liok�['cday'] * 86400;
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] + 1;
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['managerid'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['managerid'];
            if ( !isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] ) )
            {
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyextattr'];
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['linknum'];
            }
            else
            {
                if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] != $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyextattr'] )
                {
                    exit( "kssdata".QQ136 );
                }
                if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] != $_obf_lZSGkoqUio_RlZGNkY6Liok�['linknum'] )
                {
                    exit( "kssdata".QQ137 );
                }
            }
            if ( !( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['onetimeskeyattrid'] == $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] ) )
            {
                continue;
            }
            $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['isusetestkey'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['isusetestkey'] + 1;
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['isusetestkey'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['isusetestkey'];
            if ( !( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['isusetestkey'] ) )
            {
                continue;
            }
            exit( "kssdata".$_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'].QQ138 );
        }
    }
}
if ( $_obf_jpCKlY6RkYuPkoyHlJKMios� != "" )
{
    exit( "kssdata".$_obf_jpCKlY6RkYuPkoyHlJKMios� );
}
$_obf_lI6Oh5CKh42Ri5STio2HjpE� = array( );
if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cztimes'] )
{
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['keyextattr'] != $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] && time( ) + 86400 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] * 86400 )
    {
        exit( "kssdata".QQ139 );
    }
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] != $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] && time( ) + 86400 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] * 86400 )
    {
        exit( "kssdata".QQ140 );
    }
}
$_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",".( 1 + $_obf_jI6JkpSHj5SQkY2UiIeJkYc� ).",'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_jpSHk4yRh5CUiZKVkJSPkY8�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_k5SGkIiQkJKPiIuUlYmHhow�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].",'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey']."','')";
$_obf_komOhpCIlI6SkYqSkYqHhoY� = 0;
$_obf_jomKiJWJhoyUlY_JjJKJiI8� = 0;
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_keytypeid'] != "" && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_number'] != 0 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_cday'] != 0 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_number'] <= $_obf_homPkY_KioeUiIeMipSQjZU� )
{
    $_obf_komOhpCIlI6SkYqSkYqHhoY� = floor( $_obf_homPkY_KioeUiIeMipSQjZU� / $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_number'] ) * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_cday'];
    $_obf_jomKiJWJhoyUlY_JjJKJiI8� = floor( $_obf_homPkY_KioeUiIeMipSQjZU� / $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_number'] ) * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_points'];
    if ( $_obf_komOhpCIlI6SkYqSkYqHhoY� != 0 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + $_obf_komOhpCIlI6SkYqSkYqHhoY�;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] + $_obf_komOhpCIlI6SkYqSkYqHhoY� * 86400;
    }
    if ( $_obf_jomKiJWJhoyUlY_JjJKJiI8� != 0 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + $_obf_jomKiJWJhoyUlY_JjJKJiI8�;
    }
    $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values\t(".$_obf_jomPk5WKioeLipGGi4_PhpM�.",7,'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".( $_obf_jpSHk4yRh5CUiZKVkJSPkY8� + $_obf_jImSiIyUiouIiZWUlIeHh5E� ).",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".( $_obf_k5SGkIiQkJKPiIuUlYmHhow� + $_obf_jYmSi4iRi4mJjZWUjI2PjIs� ).",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].",'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey']."','')";
}
$_obf_k42Nk5GRj42Ii4iKjo2Sk40� = "";
$_obf_i5KQiouLlYiLjJCLkomJjZQ� = 0;
$_obf_iIaKj4eHh46NkYeHiJWUjpI� = 0;
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_addtimetype'] == 2 && $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['parentuser'] != "" )
{
    $_obf_h4aOh4mKiZCUkoaIhouTiIg� = 1;
    $_obf_kI2Li4aJk4aMiIeSiIeUjIo� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['parentuser']."'" );
    if ( empty( $_obf_kI2Li4aJk4aMiIeSiIeUjIo� ) )
    {
        $_obf_h4aOh4mKiZCUkoaIhouTiIg� = 0;
    }
    else
    {
        if ( PETIME <= $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] )
        {
            $_obf_h4aOh4mKiZCUkoaIhouTiIg� = 0;
        }
        $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['starttime'] + $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'] * 86400;
        if ( intval( $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['islock'] ) != 0 || intval( $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] ) < $_obf_jomPk5WKioeLipGGi4_PhpM� )
        {
            $_obf_h4aOh4mKiZCUkoaIhouTiIg� = 0;
        }
    }
    if ( $_obf_h4aOh4mKiZCUkoaIhouTiIg� == 0 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['parentuser'] = "";
    }
    else
    {
        $_obf_k4uUiZCSkI2PhpWQjZWHjJU� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
        $_obf_iIuSjomOk4eRioaPlJWIiJQ� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_newuseraddtime'] || 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points1'] )
        {
            if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_newuseraddtime'] )
            {
                $_obf_i5KQiouLlYiLjJCLkomJjZQ� = round( $_obf_jImSiIyUiouIiZWUlIeHh5E� * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_newuseraddtime'] / 100, 2 );
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + $_obf_i5KQiouLlYiLjJCLkomJjZQ�;
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] + $_obf_i5KQiouLlYiLjJCLkomJjZQ� * 86400;
            }
            if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points1'] )
            {
                $_obf_iIaKj4eHh46NkYeHiJWUjpI� = floor( $_obf_jYmSi4iRi4mJjZWUjI2PjIs� * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points1'] / 100 );
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + $_obf_iIaKj4eHh46NkYeHiJWUjpI�;
            }
            $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",4,'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".( $_obf_jpSHk4yRh5CUiZKVkJSPkY8� + $_obf_jImSiIyUiouIiZWUlIeHh5E� + $_obf_komOhpCIlI6SkYqSkYqHhoY� ).",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".( $_obf_k5SGkIiQkJKPiIuUlYmHhow� + $_obf_jYmSi4iRi4mJjZWUjI2PjIs� + $_obf_jomKiJWJhoyUlY_JjJKJiI8� ).",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].",'','".$_obf_kI2Li4aJk4aMiIeSiIeUjIo�['username']."')";
        }
        $_obf_iI_QkZGJh4yRk4mIkYuOiYg� = array( );
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_parentuseraddtime'] || 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points2'] )
        {
            $_obf_iJSNkomSi4qVlJOHlYuSi4k� = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'];
            $_obf_k42Sho2GiIeHk42OjIaPipQ� = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'];
            $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'];
            $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['points'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'];
            if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_parentuseraddtime'] && 0 < $_obf_jImSiIyUiouIiZWUlIeHh5E� )
            {
                $_obf_kIeSj42MiJSPjpCRjo2MlZE� = round( $_obf_jImSiIyUiouIiZWUlIeHh5E� * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_parentuseraddtime'] / 100, 2 );
                $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'] + $_obf_kIeSj42MiJSPjpCRjo2MlZE�;
                $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['endtime'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] + $_obf_kIeSj42MiJSPjpCRjo2MlZE� * 86400;
                $_obf_k42Nk5GRj42Ii4iKjo2Sk40� = QQ141.$_obf_kIeSj42MiJSPjpCRjo2MlZE�."天";
            }
            if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points2'] && 0 < $_obf_jYmSi4iRi4mJjZWUjI2PjIs� )
            {
                $_obf_j4eQiIyUjoeRiY6UjJSQjpI� = floor( $_obf_jYmSi4iRi4mJjZWUjI2PjIs� * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points2'] / 100 );
                $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['points'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'] + $_obf_j4eQiIyUjoeRiY6UjJSQjpI�;
                $_obf_k42Nk5GRj42Ii4iKjo2Sk40� .= $_obf_j4eQiIyUjoeRiY6UjJSQjpI�.QQ142;
            }
            if ( $_obf_k42Nk5GRj42Ii4iKjo2Sk40� != "" )
            {
                $_obf_k42Nk5GRj42Ii4iKjo2Sk40� .= "，";
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_iI_QkZGJh4yRk4mIkYuOiYg�, "username='".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['parentuser']."'", "sql" );
                if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
                {
                    $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = $_obf_lY6RhpOJh46VkJOGkoeRiIY�;
                }
                $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",3,'".$_obf_kI2Li4aJk4aMiIeSiIeUjIo�['username']."',".$_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'].",".$_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'].",".$_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'].",".$_obf_iI_QkZGJh4yRk4mIkYuOiYg�['points'].",'','".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."')";
            }
        }
    }
}
$_obf_kZOKjJCNkZGVh4yPkoyQk4c� = $_obf_jImSiIyUiouIiZWUlIeHh5E� + $_obf_komOhpCIlI6SkYqSkYqHhoY� + $_obf_i5KQiouLlYiLjJCLkomJjZQ�;
$_obf_jouOjpWUiIqRi4eNiIiRjYw� = $_obf_jYmSi4iRi4mJjZWUjI2PjIs� + $_obf_jomKiJWJhoyUlY_JjJKJiI8� + $_obf_iIaKj4eHh46NkYeHiJWUjpI�;
$_obf_lI2HjIqUkYqTho2HiJWUk5I� = $_obf_k42Nk5GRj42Ii4iKjo2Sk40�;
$_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set `cztime`=".$_obf_jomPk5WKioeLipGGi4_PhpM�.",`czusername`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' where `keys` in ('".join( "','", $_obf_jZCUjpOJiY6Iio_SiIyGk48� )."')";
$_obf_kY2Qi5OGjImIh46TjZKNk48� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
if ( $_obf_kY2Qi5OGjImIh46TjZKNk48� !== TRUE )
{
    _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 251 );
    exit( "kssdata".QQ143.$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
}
$_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['starttime'] + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
$_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sql" );
$_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
{
    _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 258 );
    exit( "kssdata".QQ144.$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
}
if ( !empty( $_obf_lI6Oh5CKh42Ri5STio2HjpE� ) )
{
    foreach ( $_obf_lI6Oh5CKh42Ri5STio2HjpE� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
        {
            _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 266 );
        }
    }
}
exit( "kssdata".$_obf_lI2HjIqUkYqTho2HiJWUk5I�.QQ145.$_obf_kZOKjJCNkZGVh4yPkoyQk4c�."天".$_obf_jouOjpWUiIqRi4eNiIiRjYw�.QQ142 );
?>
