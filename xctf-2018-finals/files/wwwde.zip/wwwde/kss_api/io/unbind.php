<?php

function _obf_j5KUjJGLkIeIiYeJiJSTjI4�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['chkonline'] == 1 )
{
    exit( "kssdata".QQ199 );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_set'] != 1 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_set'] != 3 )
{
    exit( "kssdata".QQ200 );
}
if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['isrun'] == "1" )
{
    exit( "kssdata".QQ201 );
}
if ( SVRID == 2 )
{
    exit( "kssdata".QQ202 );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'];
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) != 32 )
    {
        exit( "kssdata".QQ203 );
    }
    if ( !_obf_joeQipOGjouJko_VlJSKiJE�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) )
    {
        exit( "kssdata".QQ204 );
    }
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 0, 10 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 10, 10 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 20 );
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `password`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password']."' and `password2`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2']."'" );
}
else
{
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `password`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password']."'" );
}
if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
{
    exit( "kssdata".QQ205 );
}
if ( PETIME <= $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] )
{
    exit( "kssdata".QQ206 );
}
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] == 1 )
{
    exit( "kssdata".QQ207 );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] == "1" )
{
    exit( "kssdata".QQ208 );
}
if ( 1 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] )
{
    $_obf_j5CSkZSGiJKNiZSQlY_Iio0� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid']."'" );
    if ( empty( $_obf_j5CSkZSGiJKNiZSQlY_Iio0� ) )
    {
        exit( "kssdata".QQ209 );
    }
    $_obf_h5GPkpGLkYePioqSiomMlZM� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['unlockday'];
    $_obf_j5WGlIqLlYqNlYqJjo_JiJU� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['unlocktimes'];
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['pccode'];
    $_obf_j42KiZKIk5OMi4yGlYyPlI0� = $_obf_j5CSkZSGiJKNiZSQlY_Iio0�['lasttime'];
}
else
{
    $_obf_h5GPkpGLkYePioqSiomMlZM� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['unlockday'];
    $_obf_j5WGlIqLlYqNlYqJjo_JiJU� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['unlocktimes'];
    $_obf_kJSVj4qJlIyOi5SQiZKRiYk� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['pccode'];
    $_obf_j42KiZKIk5OMi4yGlYyPlI0� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['lasttime'];
}
if ( $_obf_kJSVj4qJlIyOi5SQiZKRiYk� == "" )
{
    exit( "kssdata".QQ210 );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_set'] == 3 )
{
    if ( _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( $_obf_joeUio_LioqSh5WIiI2Pk4s�, $_obf_kJSVj4qJlIyOi5SQiZKRiYk� ) !== FALSE )
    {
        exit( "kssdata".QQ232 );
    }
    if ( $_obf_jomPk5WKioeLipGGi4_PhpM� - $_obf_j42KiZKIk5OMi4yGlYyPlI0� < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_autotime'] * 60 )
    {
        exit( "kssdata".QQ233 );
    }
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_set'] == 1 && _obf_h4_HlI6KlZKKlZCKkY_Jjo4�( $_obf_joeUio_LioqSh5WIiI2Pk4s�, $_obf_kJSVj4qJlIyOi5SQiZKRiYk� ) === FALSE )
{
    exit( "kssdata".QQ211 );
}
$_obf_j42HkJGSkI6UhoaJlYuVk4k� = array( );
$_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlockday'] = $_obf_h5GPkpGLkYePioqSiomMlZM�;
$_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlocktimes'] = $_obf_j5WGlIqLlYqNlYqJjo_JiJU�;
if ( $_obf_h5GPkpGLkYePioqSiomMlZM� == date( "d" ) )
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_times'] <= $_obf_j5WGlIqLlYqNlYqJjo_JiJU� && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] < 2 )
    {
        exit( "kssdata".QQ212 );
    }
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlocktimes'] = $_obf_j5WGlIqLlYqNlYqJjo_JiJU� + 1;
}
else
{
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlockday'] = date( "d" );
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlocktimes'] = 1;
}
$_obf_kpSSj5GNj4eIh5WGkI_Gk4s� = "";
if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] && 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'] )
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_ctset'] == 1 )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
        if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] < $_obf_jomPk5WKioeLipGGi4_PhpM� || $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] < 0 )
        {
            exit( "kssdata".QQ237 );
        }
        $_obf_kpSSj5GNj4eIh5WGkI_Gk4s� = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",6,'".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."',".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'].",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",'','')";
    }
    else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_times'] < $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlocktimes'] )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['unbindpc_changetime'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
        if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] < $_obf_jomPk5WKioeLipGGi4_PhpM� || $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] < 0 )
        {
            exit( "kssdata".QQ237 );
        }
        $_obf_kpSSj5GNj4eIh5WGkI_Gk4s� = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",6,'".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."',".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'].",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",'','')";
    }
}
$_obf_j42HkJGSkI6UhoaJlYuVk4k�['pccode'] = "";
if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'] == 1 )
{
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
    {
        exit( "kssdata".QQ213.$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
    }
}
else
{
    $_obf_iY2UhpKLiJKRjIiRjIyHi4k� = array(
        "unlockday" => $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlockday'],
        "unlocktimes" => $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlocktimes'],
        "pccode" => ""
    );
    unset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlockday'] );
    unset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['unlocktimes'] );
    if ( !empty( $_obf_j42HkJGSkI6UhoaJlYuVk4k� ) )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
        {
            exit( "kssdata".QQ213."1!".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
        }
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_client_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_iY2UhpKLiJKRjIiRjIyHi4k�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `clientid`=".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['clientid'], "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
    {
        exit( "kssdata".QQ213."2!".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
    }
}
if ( $_obf_kpSSj5GNj4eIh5WGkI_Gk4s� != "" )
{
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kpSSj5GNj4eIh5WGkI_Gk4s�, "sync" );
}
exit( "kssdata".QQ214 );
?>
