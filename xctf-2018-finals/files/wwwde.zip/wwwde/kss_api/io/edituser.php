<?php

function _obf_iIuSi4iHkIaKiouRj5WTk4k�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
if ( SVRID == 2 )
{
    exit( "kssdata".QQ146 );
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'];
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) != 32 )
    {
        exit( "kssdata".QQ123 );
    }
    if ( !_obf_joeQipOGjouJko_VlJSKiJE�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) )
    {
        exit( "kssdata".QQ147 );
    }
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 0, 10 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 10, 10 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 20 );
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `password`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password']."' and `password2`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2']."'" );
    if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
    {
        exit( "kssdata".QQ148 );
    }
    if ( PETIME <= $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] )
    {
        exit( "kssdata".QQ149 );
    }
    if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
    {
        exit( "kssdata".QQ150 );
    }
}
else
{
    $_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] );
    if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
    {
        exit( "kssdata".QQ151.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
    }
    $_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] );
    if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
    {
        exit( "kssdata".QQ152.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
    }
    $_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'] );
    if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
    {
        exit( "kssdata".QQ153.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
    }
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'" );
    if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
    {
        exit( "kssdata".QQ154 );
    }
    if ( PETIME <= $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] )
    {
        exit( "kssdata".QQ155 );
    }
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['password2'] != $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'] )
    {
        exit( "kssdata".QQ156 );
    }
    if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
    {
        exit( "kssdata".QQ157 );
    }
}
$_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] );
if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
{
    exit( "kssdata".QQ158.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
}
$_obf_jJCMkpKRj4mNh4eNjpKGi4g� = array( );
$_obf_lI6Oh5CKh42Ri5STio2HjpE� = "";
if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] != "" )
{
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] ) < 3 )
    {
        exit( "kssdata".QQ159 );
    }
    if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] == $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo'] )
    {
        exit( "kssdata".QQ160 );
    }
    $_obf_jJCMkpKRj4mNh4eNjpKGi4g�['bdinfo'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'];
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['onlyonebdinfo'] == "1" )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `bdinfo`='".mysql_real_escape_string( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] )."'" );
        if ( !empty( $_obf_lY6RhpOJh46VkJOGkoeRiIY� ) )
        {
            exit( "kssdata".QQ260 );
        }
    }
    if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['editbdinfo_changetime'] )
    {
        if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] - $_obf_jomPk5WKioeLipGGi4_PhpM� < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['editbdinfo_changetime'] * 86400 )
        {
            exit( "kssdata".QQ161.$_obf_jZGRipSRkIeUiIeQjoaUjJI�['editbdinfo_changetime']."天！" );
        }
        $_obf_jJCMkpKRj4mNh4eNjpKGi4g�['cday'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] - $_obf_jZGRipSRkIeUiIeQjoaUjJI�['editbdinfo_changetime'];
        $_obf_jJCMkpKRj4mNh4eNjpKGi4g�['endtime'] = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_jJCMkpKRj4mNh4eNjpKGi4g�['cday'] * 86400;
        $_obf_lI6Oh5CKh42Ri5STio2HjpE� = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",5,'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'].",".$_obf_jJCMkpKRj4mNh4eNjpKGi4g�['cday'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'].",'".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo']." - ".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo']."','')";
    }
    else
    {
        exit( "kssdata".QQ162 );
    }
}
else
{
    if ( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo'] != "" && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
    {
        exit( "kssdata".QQ163 );
    }
}
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "USOFT" && $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] != $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['password'] )
{
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] ) < 5 )
    {
        exit( "kssdata".QQ164 );
    }
    $_obf_jJCMkpKRj4mNh4eNjpKGi4g�['password'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'];
}
if ( empty( $_obf_jJCMkpKRj4mNh4eNjpKGi4g� ) )
{
    exit( "kssdata".QQ165 );
}
$_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_jJCMkpKRj4mNh4eNjpKGi4g�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", "sql" );
$_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
{
    exit( "kssdata".QQ166.$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
}
if ( $_obf_lI6Oh5CKh42Ri5STio2HjpE� != "" )
{
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_lI6Oh5CKh42Ri5STio2HjpE�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
    {
        _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_lI6Oh5CKh42Ri5STio2HjpE�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 111 );
    }
}
exit( "kssdata".QQ167 );
?>
