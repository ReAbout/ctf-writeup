<?php

function _obf_k4aNj4iRh5WPipSRjYeQjoc�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_jI2LjJOIhoeUi4iVjYmKh5U�( $_obf_i5SGi4qQhoqUko2HhoeTlZM� )
{
    global $_obf_joyHlI2KjY6PkJKQhpSGkI8�;
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_joyHlI2KjY6PkJKQhpSGkI8� );
    exit( $_obf_i5SGi4qQhoqUko2HhoeTlZM� );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
_obf_kpSOkYmPh5SSi4mMlYePjY4�( 0, $_obf_jJKOjo2Qk46Qk4qOjJSTjJM� );
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "USOFT" )
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 2 || $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 4 )
    {
        exit( "kssdata".QQ168 );
    }
    if ( SVRID == 2 )
    {
        exit( "kssdata".QQ169 );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_joeUio_LioqSh5WIiI2Pk4s� );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
    {
        exit( "kssdata".QQ170.$_obf_lY6RhpOJh46VkJOGkoeRiIY� );
    }
}
else
{
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 2 )
    {
        exit( "crypteno114" );
    }
    if ( _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_joeUio_LioqSh5WIiI2Pk4s� ) !== TRUE )
    {
        exit( "crypteno123" );
    }
}
if ( 0 < $_obf_iJSOjpOVh4qLjI6TkY2Rj44�['maxusernum'] )
{
    $_obf_iZWGh5SKipCTk4mUkI_Kk48� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(*) as tnum,sum(`linknum`) from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs� );
    if ( $_obf_iJSOjpOVh4qLjI6TkY2Rj44�['maxusernum'] <= $_obf_iZWGh5SKipCTk4mUkI_Kk48�['tnum'] + ( $_obf_iZWGh5SKipCTk4mUkI_Kk48�['tnum'] - $_obf_iZWGh5SKipCTk4mUkI_Kk48�['tnum'] ) / 2 )
    {
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
        {
            exit( "crypteno109" );
        }
        exit( "kssdata".QQ171 );
    }
}
$_obf_iImHk5CLiY2Gk5OTlZONk4k� = array( );
$_obf_iYuKhpCNhoaJlYmThpOTiIY� = FALSE;
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "USOFT" )
{
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] == "" ) )
    {
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg'] == "0.00" )
        {
            exit( "kssdata".QQ172 );
        }
        if ( SVRID == 2 )
        {
            exit( "kssdata".QQ173 );
        }
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['freeregs'] == "0" )
        {
            $_obf_h46JiZOTlZSPhpGIj4yHi5I� = "('".join( "','", $_obf_io_UkouIkIyHj42UlI_GiZA� )."')";
            $_obf_jI6LkY2TlJSJjJCHlImHj4Y� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_log_havereg where `pccode` in ".$_obf_h46JiZOTlZSPhpGIj4yHi5I�." and `softid`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'] );
            if ( !empty( $_obf_jI6LkY2TlJSJjJCHlImHj4Y� ) )
            {
                exit( "kssdata".QQ174 );
            }
            foreach ( $_obf_io_UkouIkIyHj42UlI_GiZA� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
            {
                $_obf_iImHk5CLiY2Gk5OTlZONk4k�[] = "insert into kss_tb_log_havereg (`softid`,`addtime`,`pccode`) values (".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['id'].",".time( ).",'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�."')";
            }
        }
        $_obf_iYuKhpCNhoaJlYmThpOTiIY� = TRUE;
    }
    else
    {
        if ( ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) + 1 ) % 33 != 0 )
        {
            exit( "kssdata".QQ175 );
        }
    }
}
if ( 100 < _obf_ioqHi5WHiJKIkoeIhouHjYw�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] ) )
{
    exit( "kssdata".QQ176 );
}
$_obf_jZCGhpKRipWQjY_UjZWMj5M� = crc32( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softcode'].$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] );
$_obf_joyHlI2KjY6PkJKQhpSGkI8� = "regu".sprintf( "%u", $_obf_jZCGhpKRipWQjY_UjZWMj5M� );
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['onlyonebdinfo'] == "1" && !empty( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] ) )
{
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `bdinfo`='".mysql_real_escape_string( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] )."'" );
    if ( !empty( $_obf_lY6RhpOJh46VkJOGkoeRiIY� ) )
    {
        exit( "kssdata".QQ260 );
    }
}
if ( $_obf_jJKOjo2Qk46Qk4qOjJSTjJM� == 0 )
{
    $_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] );
    if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
    {
        exit( "kssdata".QQ177.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
    }
    $_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] );
    if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
    {
        exit( "kssdata".QQ178.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
    }
    $_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] );
    if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
    {
        exit( "kssdata".QQ179.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
    }
    $_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'] );
    if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
    {
        exit( "kssdata".QQ180.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
    }
    $_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'] );
    if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
    {
        exit( "kssdata".QQ181.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
    }
    $_obf_jpOPko_LjYiHkoqPjZWLiog� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_ho_Ljo6NjpOOhpGHj5KHiYs�( $_obf_joyHlI2KjY6PkJKQhpSGkI8� );
    if ( $_obf_jpOPko_LjYiHkoqPjZWLiog� !== TRUE )
    {
        exit( "kssdata".QQ234 );
    }
    $_obf_h42NjZKIkoqSkouPh5WIiYw� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", 1, 1 );
    if ( !empty( $_obf_h42NjZKIkoqSkouPh5WIiYw� ) )
    {
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ182 );
    }
    else
    {
        $_obf_ko_OkJOPkIqLjY_Mj4_SjoY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."_recycle` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'" );
        if ( !empty( $_obf_ko_OkJOPkIqLjY_Mj4_SjoY� ) )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."_recycle` set `username`=concat('delete_',`username`) where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'" );
        }
    }
    if ( $_obf_iYuKhpCNhoaJlYmThpOTiIY� === TRUE )
    {
        $_obf_iouSi4_PlIuKhoeUlI_LkpE� = $_obf_iJSOjpOVh4qLjI6TkY2Rj44�['id'];
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['fregmanagerid'] != 0 )
        {
            $_obf_iouSi4_PlIuKhoeUlI_LkpE� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['fregmanagerid'];
        }
        $_obf_j42HkJGSkI6UhoaJlYuVk4k� = array(
            "managerid" => $_obf_iouSi4_PlIuKhoeUlI_LkpE�,
            "username" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'],
            "password" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'],
            "password2" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'],
            "cday" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg'],
            "points" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg_points'],
            "tag" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['fregtag'],
            "keyextattr" => $_obf_jZGRipSRkIeUiIeQjoaUjJI�['fregattr'],
            "bdinfo" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'],
            "addtime" => $_obf_jomPk5WKioeLipGGi4_PhpM�,
            "starttime" => $_obf_jomPk5WKioeLipGGi4_PhpM�,
            "endtime" => $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg'] * 86400,
            "isusetestkey" => 1,
            "intro" => "无卡注册"
        );
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
        {
            if ( !empty( $_obf_iImHk5CLiY2Gk5OTlZONk4k� ) )
            {
                foreach ( $_obf_iImHk5CLiY2Gk5OTlZONk4k� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
                {
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, "sync" );
                }
            }
            _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ183.$_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg']."天".( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg_points'] != 0 ? $_obf_jZGRipSRkIeUiIeQjoaUjJI�['nokeyreg_points'].QQ142 : "" )."。" );
        }
        else
        {
            _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ184.$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
        }
    }
}
else
{
    $_obf_jpOPko_LjYiHkoqPjZWLiog� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_ho_Ljo6NjpOOhpGHj5KHiYs�( $_obf_joyHlI2KjY6PkJKQhpSGkI8� );
    if ( $_obf_jpOPko_LjYiHkoqPjZWLiog� !== TRUE )
    {
        exit( "crypteno116" );
    }
    $_obf_ko2Uh4eRkoqRjYqHiIaPjIk� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'", 1, 1 );
    if ( !empty( $_obf_ko2Uh4eRkoqRjYqHiIaPjIk� ) )
    {
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "crypteno117" );
    }
}
$_obf_j42HkJGSkI6UhoaJlYuVk4k� = array(
    "username" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'],
    "password" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'],
    "password2" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'],
    "bdinfo" => $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['bdinfo'],
    "addtime" => $_obf_jomPk5WKioeLipGGi4_PhpM�,
    "starttime" => $_obf_jomPk5WKioeLipGGi4_PhpM�
);
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['pccode'] = $_obf_joeUio_LioqSh5WIiI2Pk4s�;
}
if ( SVRID == 2 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "USOFT" )
{
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['istempuser'] = 1;
}
if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_addtimetype'] && $_obf_jJKOjo2Qk46Qk4qOjJSTjJM� == 0 )
{
    $_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['puser'] );
    if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
    {
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ185.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
    }
    if ( _obf_ioqHi5WHiJKIkoeIhouHjYw�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['puser'] ) != 0 && _obf_ioqHi5WHiJKIkoeIhouHjYw�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['puser'] ) < 3 )
    {
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ186 );
    }
    if ( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['puser'] != "" )
    {
        $_obf_kI2Li4aJk4aMiIeSiIeUjIo� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT * from `kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['puser']."'" );
        if ( empty( $_obf_kI2Li4aJk4aMiIeSiIeUjIo� ) )
        {
            _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ187 );
        }
        if ( PETIME <= $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] )
        {
            _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ188 );
        }
        if ( intval( $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['islock'] ) != 0 )
        {
            _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ189 );
        }
        if ( intval( $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] ) < time( ) )
        {
            _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ190 );
        }
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['parentuser'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['puser'];
    }
}
else
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['puser'] = "";
}
if ( $_obf_jJKOjo2Qk46Qk4qOjJSTjJM� == 0 )
{
    $_obf_kYiQkJKGlI6JlZWRioaKlYg� = explode( "|", $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] );
    if ( 5 < count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) )
    {
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ128 );
    }
    $_obf_iJCHjZWRiJONk5OGlIqMipM� = array_unique( $_obf_kYiQkJKGlI6JlZWRioaKlYg� );
    if ( count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) != count( $_obf_iJCHjZWRiJONk5OGlIqMipM� ) )
    {
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ129 );
    }
}
$_obf_lI6Oh5CKh42Ri5STio2HjpE� = array( );
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    $_obf_j46GkYaTj5KIkIyUh4aTjYs� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `keys`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 4, 6 )."' and `keyfix`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 0, 4 )."' and `keyspassword`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 10 )."' and cztime=0 " );
    if ( empty( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) )
    {
        _obf_kpSOkYmPh5SSi4mMlYePjY4�( 1 );
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "crypteno111" );
    }
    if ( $_obf_j46GkYaTj5KIkIyUh4aTjYs�['islock'] != 0 )
    {
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "crypteno112" );
    }
    if ( $_obf_j46GkYaTj5KIkIyUh4aTjYs�['isback'] != 0 )
    {
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "crypteno113" );
    }
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['managerid'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['managerid'];
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'];
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['points'];
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['tag'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['tag'];
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['linknum'];
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] = $_obf_j46GkYaTj5KIkIyUh4aTjYs�['keyextattr'];
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'] * 86400;
    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] = 1;
    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "sql" );
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
    {
        _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 232 );
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "crypteno116" );
    }
    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update `kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."` set cztime=".$_obf_jomPk5WKioeLipGGi4_PhpM�.",czusername='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' where `keys`='".$_obf_j46GkYaTj5KIkIyUh4aTjYs�['keys']."'";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
    {
        _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 239 );
    }
    if ( SVRID == 2 )
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "insert into kss_tb_sql_active (`tbname`,`username`,`starttime`,`pccode`) values ('".$_obf_jpOTkJCPjI_TipSPjoeTjYs�."','".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_jomPk5WKioeLipGGi4_PhpM�.",'".$_obf_joeUio_LioqSh5WIiI2Pk4s�."')";
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
        {
            _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 245 );
        }
    }
    $_obf_jJKOjo2Qk46Qk4qOjJSTjJM� = 2;
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'" );
}
else
{
    $_obf_ipGJkpOKioePjIaGkIuQiJA� = array( );
    $_obf_jZCUjpOJiY6Iio_SiIyGk48� = array( );
    $_obf_lZONjIiPhoiGk4_JkJKGlJU� = array( );
    foreach ( $_obf_kYiQkJKGlI6JlZWRioaKlYg� as $_obf_lZSGkoqUio_RlZGNkY6Liok� )
    {
        $_obf_lIqUjpSPk4uMjZKMhoyTlZU� = substr( $_obf_lZSGkoqUio_RlZGNkY6Liok�, 4, 6 );
        $_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lIqUjpSPk4uMjZKMhoyTlZU�] = substr( $_obf_lZSGkoqUio_RlZGNkY6Liok�, 4, 6 );
        $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lIqUjpSPk4uMjZKMhoyTlZU�] = substr( $_obf_lZSGkoqUio_RlZGNkY6Liok�, 0, 4 );
        $_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lIqUjpSPk4uMjZKMhoyTlZU�] = substr( $_obf_lZSGkoqUio_RlZGNkY6Liok�, 10 );
    }
    $_obf_j46GkYaTj5KIkIyUh4aTjYs� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `keys` in ('".join( "','", $_obf_jZCUjpOJiY6Iio_SiIyGk48� )."') and isback=0" );
    if ( empty( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) )
    {
        _obf_kpSOkYmPh5SSi4mMlYePjY4�( 1 );
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ130 );
    }
    if ( count( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) != count( $_obf_kYiQkJKGlI6JlZWRioaKlYg� ) )
    {
        _obf_kpSOkYmPh5SSi4mMlYePjY4�( 1 );
        $_obf_jpCKlY6RkYuPkoyHlJKMios� = "";
        foreach ( $_obf_j46GkYaTj5KIkIyUh4aTjYs� as $_obf_lZSGkoqUio_RlZGNkY6Liok� )
        {
            if ( !in_array( $_obf_lZSGkoqUio_RlZGNkY6Liok�['keys'], $_obf_jZCUjpOJiY6Iio_SiIyGk48� ) )
            {
                $_obf_jpCKlY6RkYuPkoyHlJKMios� .= QQ131.$_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].QQ132."\r\n";
            }
        }
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".$_obf_jpCKlY6RkYuPkoyHlJKMios� );
    }
    $_obf_jpCKlY6RkYuPkoyHlJKMios� = "";
    $_obf_homPkY_KioeUiIeMipSQjZU� = 0;
    foreach ( $_obf_j46GkYaTj5KIkIyUh4aTjYs� as $_obf_lZSGkoqUio_RlZGNkY6Liok� )
    {
        if ( $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] != $_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']] || $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyspassword'] != $_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']] )
        {
            $_obf_jpCKlY6RkYuPkoyHlJKMios� = QQ132.$_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].QQ133."\r\n";
        }
        else if ( $_obf_lZSGkoqUio_RlZGNkY6Liok�['islock'] != 0 )
        {
            $_obf_jpCKlY6RkYuPkoyHlJKMios� = QQ132.$_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].QQ134."\r\n";
        }
        else
        {
            if ( 0 < $_obf_lZSGkoqUio_RlZGNkY6Liok�['cztime'] )
            {
                $_obf_jpCKlY6RkYuPkoyHlJKMios� = QQ132.$_obf_ipGJkpOKioePjIaGkIuQiJA�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_jZCUjpOJiY6Iio_SiIyGk48�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].$_obf_lZONjIiPhoiGk4_JkJKGlJU�[$_obf_lZSGkoqUio_RlZGNkY6Liok�['keys']].QQ191."\r\n";
            }
            else
            {
                if ( $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] == $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_keytypeid'] )
                {
                    $_obf_homPkY_KioeUiIeMipSQjZU� += 1;
                }
                if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] ) )
                {
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + $_obf_lZSGkoqUio_RlZGNkY6Liok�['cday'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + $_obf_lZSGkoqUio_RlZGNkY6Liok�['points'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] + 1;
                    if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] != $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyextattr'] )
                    {
                        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ136 );
                    }
                    if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] != $_obf_lZSGkoqUio_RlZGNkY6Liok�['linknum'] )
                    {
                        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ137 );
                    }
                    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['onetimeskeyattrid'] == $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] )
                    {
                        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['isusetestkey'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['isusetestkey'] + 1;
                        if ( 1 < $_obf_j42HkJGSkI6UhoaJlYuVk4k�['isusetestkey'] )
                        {
                            _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".$_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'].QQ138 );
                        }
                    }
                }
                else
                {
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['managerid'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['managerid'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['tag'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['tag'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['cday'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['points'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] = 1;
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyextattr'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] = $_obf_lZSGkoqUio_RlZGNkY6Liok�['linknum'];
                    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['onetimeskeyattrid'] == $_obf_lZSGkoqUio_RlZGNkY6Liok�['keyfix'] )
                    {
                        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['isusetestkey'] = 1;
                    }
                    else
                    {
                        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['isusetestkey'] = 0;
                    }
                }
            }
        }
    }
    if ( $_obf_jpCKlY6RkYuPkoyHlJKMios� != "" )
    {
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".$_obf_jpCKlY6RkYuPkoyHlJKMios� );
    }
    $_obf_iYaHkYiJk5WVk4qPkIiRiYo� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
    $_obf_iZSKjI_SipKTioySj4iSjJQ� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� = "";
    $_obf_k42Nk5GRj42Ii4iKjo2Sk40� = "";
    $_obf_iImPiZWTko6HlI_TiZCSk4g� = 0;
    $_obf_ioyRlYaGjIuMh4mJk5GIkpM� = 0;
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_keytypeid'] != "" && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_number'] != 0 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_cday'] != 0 && $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_number'] <= $_obf_homPkY_KioeUiIeMipSQjZU� )
    {
        $_obf_iJSNkomSi4qVlJOHlYuSi4k� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
        $_obf_k42Sho2GiIeHk42OjIaPipQ� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
        $_obf_iImPiZWTko6HlI_TiZCSk4g� = floor( $_obf_homPkY_KioeUiIeMipSQjZU� / $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_number'] ) * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_cday'];
        $_obf_ioyRlYaGjIuMh4mJk5GIkpM� = floor( $_obf_homPkY_KioeUiIeMipSQjZU� / $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_number'] ) * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['czzs_points'];
        if ( $_obf_iImPiZWTko6HlI_TiZCSk4g� != 0 )
        {
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + $_obf_iImPiZWTko6HlI_TiZCSk4g�;
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
        }
        if ( $_obf_ioyRlYaGjIuMh4mJk5GIkpM� != 0 )
        {
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + $_obf_ioyRlYaGjIuMh4mJk5GIkpM�;
        }
        $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values\t(".$_obf_jomPk5WKioeLipGGi4_PhpM�.",7,'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_iJSNkomSi4qVlJOHlYuSi4k�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_k42Sho2GiIeHk42OjIaPipQ�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].",'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey']."','')";
    }
    if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_addtimetype'] && $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['puser'] != "" )
    {
        $_obf_k4uUiZCSkI2PhpWQjZWHjJU� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
        $_obf_iIuSjomOk4eRioaPlJWIiJQ� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_newuseraddtime'] || 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points1'] )
        {
            $_obf_iJSNkomSi4qVlJOHlYuSi4k� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'];
            $_obf_k42Sho2GiIeHk42OjIaPipQ� = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'];
            if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_newuseraddtime'] )
            {
                $_obf_iImPiZWTko6HlI_TiZCSk4g� += round( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_newuseraddtime'] / 100, 2 );
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] + round( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_newuseraddtime'] / 100, 2 );
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_jomPk5WKioeLipGGi4_PhpM� + $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] * 86400;
            }
            if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points1'] )
            {
                $_obf_ioyRlYaGjIuMh4mJk5GIkpM� += floor( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points1'] / 100 );
                $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] + floor( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points1'] / 100 );
            }
            $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",4,'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',".$_obf_iJSNkomSi4qVlJOHlYuSi4k�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'].",".$_obf_k42Sho2GiIeHk42OjIaPipQ�.",".$_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].",'','".$_obf_kI2Li4aJk4aMiIeSiIeUjIo�['username']."')";
        }
        $_obf_iI_QkZGJh4yRk4mIkYuOiYg� = array( );
        if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_parentuseraddtime'] || 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points2'] )
        {
            $_obf_iJSNkomSi4qVlJOHlYuSi4k� = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'];
            $_obf_kJWKkYuPko2SkZORiI6UiZM� = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'];
            $_obf_k42Sho2GiIeHk42OjIaPipQ� = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'];
            $_obf_iYqRkpWJiY2Nj4_IkYuJkJU� = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'];
            if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_parentuseraddtime'] )
            {
                $_obf_kIeSj42MiJSPjpCRjo2MlZE� = round( $_obf_k4uUiZCSkI2PhpWQjZWHjJU� * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_parentuseraddtime'] / 100, 2 );
                $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['cday'] + $_obf_kIeSj42MiJSPjpCRjo2MlZE�;
                $_obf_kJWKkYuPko2SkZORiI6UiZM� = $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'];
                $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['endtime'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['endtime'] + $_obf_kIeSj42MiJSPjpCRjo2MlZE� * 86400;
                $_obf_k42Nk5GRj42Ii4iKjo2Sk40� = QQ192.$_obf_kIeSj42MiJSPjpCRjo2MlZE�."天";
                $_obf_kJWKkYuPko2SkZORiI6UiZM� = $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['cday'];
            }
            if ( 0 < $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points2'] && 0 < $_obf_ioyRlYaGjIuMh4mJk5GIkpM� )
            {
                $_obf_j4eQiIyUjoeRiY6UjJSQjpI� = floor( $_obf_iIuSjomOk4eRioaPlJWIiJQ� * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['tg_points2'] / 100 );
                $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['points'] = $_obf_kI2Li4aJk4aMiIeSiIeUjIo�['points'] + $_obf_j4eQiIyUjoeRiY6UjJSQjpI�;
                $_obf_iYqRkpWJiY2Nj4_IkYuJkJU� = $_obf_iI_QkZGJh4yRk4mIkYuOiYg�['points'];
                $_obf_k42Nk5GRj42Ii4iKjo2Sk40� .= $_obf_j4eQiIyUjoeRiY6UjJSQjpI�.QQ142;
            }
            if ( $_obf_k42Nk5GRj42Ii4iKjo2Sk40� != "" )
            {
                $_obf_k42Nk5GRj42Ii4iKjo2Sk40� .= "，";
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_iI_QkZGJh4yRk4mIkYuOiYg�, "username='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['puser']."'", "sql" );
                if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
                {
                    $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = $_obf_lY6RhpOJh46VkJOGkoeRiIY�;
                }
                $_obf_lI6Oh5CKh42Ri5STio2HjpE�[] = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",3,'".$_obf_kI2Li4aJk4aMiIeSiIeUjIo�['username']."',".$_obf_iJSNkomSi4qVlJOHlYuSi4k�.",".$_obf_kJWKkYuPko2SkZORiI6UiZM�.",".$_obf_k42Sho2GiIeHk42OjIaPipQ�.",".$_obf_iYqRkpWJiY2Nj4_IkYuJkJU�.",'','".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."')";
            }
        }
    }
    $_obf_lI2HjIqUkYqTho2HiJWUk5I� = $_obf_k42Nk5GRj42Ii4iKjo2Sk40�;
    if ( 0 < $_obf_iImPiZWTko6HlI_TiZCSk4g� )
    {
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= QQ193.$_obf_iImPiZWTko6HlI_TiZCSk4g�."天";
    }
    if ( 0 < $_obf_ioyRlYaGjIuMh4mJk5GIkpM� )
    {
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= $_obf_ioyRlYaGjIuMh4mJk5GIkpM�.QQ142;
    }
    if ( $_obf_lI2HjIqUkYqTho2HiJWUk5I� != "" )
    {
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "，";
    }
    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." set `cztime`=".$_obf_jomPk5WKioeLipGGi4_PhpM�.",`czusername`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' where `keys` in ('".join( "','", $_obf_jZCUjpOJiY6Iio_SiIyGk48� )."')";
    $_obf_kY2Qi5OGjImIh46TjZKNk48� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
    if ( $_obf_kY2Qi5OGjImIh46TjZKNk48� !== TRUE )
    {
        _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 416 );
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ194.$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( "kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "insert into kss_z_cz_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." (`addtime`,`cztype`,`username`,`oldcday`,`newcday`,`oldtimes`,`newtimes`,`keys`,`tzxguser`) values (".$_obf_jomPk5WKioeLipGGi4_PhpM�.",0,'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."',0,".$_obf_iYaHkYiJk5WVk4qPkIiRiYo�.",0,".$_obf_iZSKjI_SipKTioySj4iSjJQ�.",'".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey']."','')";
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
        {
            _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 424 );
        }
        if ( !empty( $_obf_lI6Oh5CKh42Ri5STio2HjpE� ) )
        {
            foreach ( $_obf_lI6Oh5CKh42Ri5STio2HjpE� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
            {
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, "sync" );
                if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
                {
                    _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 430 );
                }
            }
        }
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ195.$_obf_lI2HjIqUkYqTho2HiJWUk5I�.QQ197.$_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday']."天".( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] != 0 ? $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'].QQ142 : "" )."。" );
    }
    else
    {
        _obf_jI2LjJOIhoeUi4iVjYmKh5U�( "kssdata".QQ196.$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."，\r\n".QQ198 );
    }
}
?>
