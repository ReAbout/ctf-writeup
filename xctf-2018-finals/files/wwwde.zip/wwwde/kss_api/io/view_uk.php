<?php

function _obf_lYqMiY2Mj4aIhouOlZOVjpI�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
_obf_kpSOkYmPh5SSi4mMlYePjY4�( 0 );
$_obf_k4yVh4iNjZOMk5OTiJWHiZA� = "";
$_obf_iIuTh4yVh4mShoiIiouMjIY� = array( 16, 24, 28, 29 );
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] = $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'];
    if ( !_obf_jpOIlY_HlIaJi46IiYySiJU�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) )
    {
        exit( "kssdata".QQ215 );
    }
    $_obf_jYaVkI6TlJGRipSPkIyRjYw� = strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] );
    if ( in_array( $_obf_jYaVkI6TlJGRipSPkIyRjYw�, $_obf_iIuTh4yVh4mShoiIiouMjIY� ) )
    {
        $_obf_jJOSkYeSjJSJkoaUkIaTkpI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_olddata where `oldkey`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey']."' and `softcode`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softcode'] );
        if ( empty( $_obf_jJOSkYeSjJSJkoaUkIaTkpI� ) )
        {
            exit( "kssdata".QQ216 );
        }
        $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] = $_obf_jJOSkYeSjJSJkoaUkIaTkpI�['newkey'];
        $_obf_k4yVh4iNjZOMk5OTiJWHiZA� = sprintf( GG_NEWKEY, $_obf_jJOSkYeSjJSJkoaUkIaTkpI�['newkey'] );
    }
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) != 32 )
    {
        exit( "kssdata".QQ203 );
    }
    if ( !_obf_joeQipOGjouJko_VlJSKiJE�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'] ) )
    {
        exit( "kssdata".QQ204 );
    }
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 0, 10 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 10, 10 );
    $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2'] = substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 20 );
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."' and `password`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password']."' and `password2`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['password2']."'" );
    if ( !empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
    {
        if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
        {
            exit( "kssdata".QQ220 );
        }
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� = sprintf( GG_KEYOUTPUT1, _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] ), _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + 86400 * $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] ), $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'], $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'], $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'], $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo'], $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['keyextattr'] );
    }
    else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['viewkey'] != 1 )
    {
        exit( "kssdata".QQ226 );
    }
    else
    {
        $_obf_j46GkYaTj5KIkIyUh4aTjYs� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `keys`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 4, 6 )."' and `keyfix`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 0, 4 )."' and `keyspassword`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['czkey'], 10 )."'" );
        if ( empty( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) )
        {
            _obf_kpSOkYmPh5SSi4mMlYePjY4�( 1 );
            exit( "kssdata".QQ130 );
        }
        if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
        {
            exit( "kssdata".QQ220 );
        }
        if ( 0 < $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cztime'] )
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� = sprintf( GG_KEYOUTPUT2, $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['points'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['linknum'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['tag'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['keyextattr'] );
        }
        else
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� = sprintf( GG_KEYOUTPUT3, $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['points'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['linknum'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['tag'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['keyextattr'] );
        }
    }
}
else
{
    $_obf_jYaVkI6TlJGRipSPkIyRjYw� = strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] );
    if ( in_array( $_obf_jYaVkI6TlJGRipSPkIyRjYw�, $_obf_iIuTh4yVh4mShoiIiouMjIY� ) && _obf_jpOIlY_HlIaJi46IiYySiJU�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) )
    {
        $_obf_jJOSkYeSjJSJkoaUkIaTkpI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_olddata where `oldkey`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'" );
        if ( empty( $_obf_jJOSkYeSjJSJkoaUkIaTkpI� ) )
        {
            exit( "kssdata".QQ216 );
        }
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softcode'] != $_obf_jJOSkYeSjJSJkoaUkIaTkpI�['softcode'] )
        {
            exit( "kssdata".QQ229 );
        }
        $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] = $_obf_jJOSkYeSjJSJkoaUkIaTkpI�['newkey'];
        $_obf_k4yVh4iNjZOMk5OTiJWHiZA� = sprintf( GG_NEWKEY, $_obf_jJOSkYeSjJSJkoaUkIaTkpI�['newkey'] );
    }
    if ( strlen( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) == 32 )
    {
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['viewkey'] != 1 )
        {
            exit( "kssdata".QQ230 );
        }
        if ( !_obf_joeQipOGjouJko_VlJSKiJE�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] ) )
        {
            exit( "kssdata".QQ204 );
        }
        $_obf_j46GkYaTj5KIkIyUh4aTjYs� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_key_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `keys`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 4, 6 )."' and `keyfix`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 0, 4 )."' and `keyspassword`='".substr( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'], 10 )."'" );
        if ( empty( $_obf_j46GkYaTj5KIkIyUh4aTjYs� ) )
        {
            _obf_kpSOkYmPh5SSi4mMlYePjY4�( 1 );
            exit( "kssdata".QQ130 );
        }
        if ( 0 < $_obf_j46GkYaTj5KIkIyUh4aTjYs�['islock'] )
        {
            exit( "kssdata".QQ150.$_obf_k4yVh4iNjZOMk5OTiJWHiZA� );
        }
        if ( 0 < $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cztime'] )
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� = sprintf( GG_KEYOUTPUT4, $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['points'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['linknum'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['tag'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['keyextattr'], _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cztime'] ), $_obf_j46GkYaTj5KIkIyUh4aTjYs�['czusername'] );
        }
        else
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� = sprintf( GG_KEYOUTPUT5, $_obf_j46GkYaTj5KIkIyUh4aTjYs�['cday'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['points'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['linknum'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['tag'], $_obf_j46GkYaTj5KIkIyUh4aTjYs�['keyextattr'] );
        }
    }
    else
    {
        $_obf_ho6VjYuRh5SJkomOjouOiY4� = _obf_iZONjY2Nk42Ji42LjIeOj5Q�( $_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username'] );
        if ( $_obf_ho6VjYuRh5SJkomOjouOiY4� !== TRUE )
        {
            exit( "kssdata".QQ177.$_obf_ho6VjYuRh5SJkomOjouOiY4� );
        }
        $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_jpOTkJCPjI_TipSPjoeTjYs�." where `username`='".$_obf_lYqUjoqMiomGlYiQio6Qi4Y�['username']."'" );
        if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
        {
            exit( "kssdata".QQ154 );
        }
        if ( 0 < $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['islock'] )
        {
            exit( "kssdata".QQ157 );
        }
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� = sprintf( GG_KEYOUTPUT6, _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] ), _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + 86400 * $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] ), $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'], $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'], $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'], $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo'], $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['keyextattr'], $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['tag'] );
    }
}
exit( "kssdata".$_obf_lI2HjIqUkYqTho2HiJWUk5I�.$_obf_k4yVh4iNjZOMk5OTiJWHiZA� );
?>
