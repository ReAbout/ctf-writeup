<?php

function _obf_h46RkpCLhpGPiIiJioiJhog�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_iImHhpCJi4eSkY_VjZOUj5Q� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softcode", "gp", "int", 0 );
$_obf_iIaJh5KJi42KkYuIh5SGhos� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "gdata", "gp", "int", 0 );
if ( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� == 0 || strlen( $_obf_iImHhpCJi4eSkY_VjZOUj5Q� ) != 7 )
{
    if ( $_obf_iIaJh5KJi42KkYuIh5SGhos� == 1 )
    {
        exit( "kssdata".QQ102.$_obf_iImHhpCJi4eSkY_VjZOUj5Q� );
    }
    exit( QQ102 );
}
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
$_obf_iImHhpCJi4eSkY_VjZOUj5Q� = ( integer )$_obf_iImHhpCJi4eSkY_VjZOUj5Q�;
$_obf_jZGRipSRkIeUiIeQjoaUjJI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where `softcode`=".$_obf_iImHhpCJi4eSkY_VjZOUj5Q� );
if ( empty( $_obf_jZGRipSRkIeUiIeQjoaUjJI� ) )
{
    if ( $_obf_iIaJh5KJi42KkYuIh5SGhos� == 1 )
    {
        exit( "kssdata".QQ104 );
    }
    exit( QQ104 );
}
if ( $_obf_iIaJh5KJi42KkYuIh5SGhos� == 1 )
{
    exit( "kssdata".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['ismustupdate'].":|:".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softversion'].":|:".base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softdownurl'] ).":|:".base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softnotice'] ).":|:".base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['updatelog'] ).":|:" );
}
echo "<html>\r\n<head>\r\n<title>软件更新日志</title>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n<style>\r\nbody{\r\nfont-family: Arial, Verdana, sans-serif;\r\nfont-size: 12px;\r\ncolor: #222;\r\nbackground-color: #fff;\r\n}\r\n</style>\r\n</head>\r\n<body>\r\n";
$_obf_kZOJj4uUh4_IjoaLkY_Vh5M� = base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softdownurl'] );
if ( 10 < strlen( $_obf_kZOJj4uUh4_IjoaLkY_Vh5M� ) )
{
    echo "<div><a href=".$_obf_kZOJj4uUh4_IjoaLkY_Vh5M�." target='_blank' style='color:#f00;font-weight:700'>如若自动更新失败，点击这里手动下载</a><br><br></div>";
}
echo "\r\n";
echo base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['updatelog'] );
echo "</body>\r\n</html>";
?>
