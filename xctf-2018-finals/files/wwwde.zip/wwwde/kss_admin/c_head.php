<?php

function _obf_ho_Sjo6LjpWGh4eVjIqVkI8�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\r\n<head>\r\n<title>";
echo $_obf_kouLj4_JkJWKkJCQkIaMjZE�;
echo "--KSS</title>\r\n<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />\r\n<link type=\"text/css\" rel=\"stylesheet\" href=\"";
echo INSTALLPATH;
echo "kss_inc/style/admin_style.css?version=20180105\" />\r\n<link type=\"text/css\" rel=\"stylesheet\" href=\"";
echo INSTALLPATH;
echo "kss_inc/style/contextMenu.css?version=20180105\" />\r\n<script type=\"text/javascript\" src=\"";
echo INSTALLPATH;
echo "kss_inc/js/jquery.1.3.2.pack.js?version=20180105\" charset=\"utf-8\"></script>\r\n<script type=\"text/javascript\" src=\"";
echo INSTALLPATH;
echo "kss_inc/js/jquery.form.js?version=20180105\" charset=\"utf-8\"></script>\t\r\n<script type=\"text/javascript\" src=\"";
echo INSTALLPATH;
echo "kss_inc/js/admin_pub.js?version=20180105\" charset=\"utf-8\"></script>\r\n<script type=\"text/javascript\" src=\"";
echo INSTALLPATH;
echo "kss_inc/js/contextMenu.js?version=20180105\" charset=\"utf-8\"></script>\r\n<script type=\"text/javascript\" src=\"";
echo INSTALLPATH;
echo "kss_inc/ZeroClipboard/ZeroClipboard.js?version=20180105\" charset=\"utf-8\"></script>\r\n</head>\r\n<body>\r\n<ul id=\"contextMenu\">\r\n<li><a href=\"javascript:history.go(0)\">刷新本页</a></li>\r\n</ul>\r\n<script type=\"text/javascript\">\r\n// initContextMenu();\r\nvar INSTALLPATH=\"";
echo INSTALLPATH;
echo "\";var fackie=0;\$(document).ready(function(){if (\$.browser.msie && \$.browser.version<\"8.0\"){fackie=1;\$(window).scroll(function(){\$(\".malertbox\").css(\"top\",\$(document).scrollTop()*1+100);});}});\r\nZeroClipboard.setMoviePath('";
echo INSTALLPATH;
echo "kss_inc/ZeroClipboard/ZeroClipboard.swf'); \r\n</script>\r\n";
?>
