<?php

echo $_SERVER['REMOTE_ADDR'];
echo "<br>";
echo md5( "kcnifIBa..123aBc" );
?>
