<?php

function _obf_kJGRiY6Mj5GMhoaTkYmQi5U�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
if ( !defined( "KSSROOTDIR" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 8 );
$_obf_k4mViI2Nj4mJkIuUj42JiIY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "op", "gp", "sql", "" );
$_obf_jpKNh4aRh4aQkY2PlIuRhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softid", "gp", "int", 0 );
$_obf_jZGRipSRkIeUiIeQjoaUjJI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where `id`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." and `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'] );
if ( empty( $_obf_jZGRipSRkIeUiIeQjoaUjJI� ) )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "未找到该软件" );
}
if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == "del" )
{
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    $_obf_komRjo6Qi4_Rh5KHi5SLhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "id", "gp", "int", 0 );
    $_obf_joqKkIaJhouMkJWNlJSTjpU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_keyset where `id`=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE�." and `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'] );
    if ( empty( $_obf_joqKkIaJhouMkJWNlJSTjpU� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你要删除的卡类似乎不存在或不是你能够管理的。" );
    }
    $_obf_lZSKjoiKi4yLiYeTi4aIjJM� = base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['zs_czset'] ).base64_decode( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['zs_tgset'] );
    if ( 0 < strpos( $_obf_lZSKjoiKi4yLiYeTi4aIjJM�, $_obf_joqKkIaJhouMkJWNlJSTjpU�['prefix'] ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "该软件参数设置，赠送策略里还有该卡类的信息，请手工删除后，再删卡类。" );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `keyfix`='".$_obf_joqKkIaJhouMkJWNlJSTjpU�['prefix']."' limit 0,1" );
    if ( !empty( $_obf_lY6RhpOJh46VkJOGkoeRiIY� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "为保证注册卡的正常统计，必须先删除该卡类的注册卡才可以删除该卡类<br>（批量删除注册卡可以到：【用户管理】->【批量加时.删除.导出.锁定】里操作）。" );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_keyset where  `id`=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE�." and `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'], "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "删除卡类时异常[执行delete语句时出错]".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "delok" );
}
if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == "save" )
{
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 && $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'] == 10001 && ( $_obf_jpKNh4aRh4aQkY2PlIuRhpE� == 146 || $_obf_jpKNh4aRh4aQkY2PlIuRhpE� == 147 ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "体验作者帐号，不允许添加或修改卡类" );
    }
    $_obf_komRjo6Qi4_Rh5KHi5SLhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "id", "gp", "int", 0 );
    $_obf_lJSPi4mVjpGMkI2GkIiRkY0� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keyname", "gp", "sqljs", "未命名" );
    if ( trim( $_obf_lJSPi4mVjpGMkI2GkIiRkY0� ) == "" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "卡类名不能为空" );
    }
    $_obf_iYmHlIeIio2Ni5CRjIeJkYk� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "cday", "gp", "num", "0.00" );
    if ( $_obf_iYmHlIeIio2Ni5CRjIeJkYk� <= 0 || 6000 < $_obf_iYmHlIeIio2Ni5CRjIeJkYk� )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "天数要大于0小于6000，你填写的是".$_obf_iYmHlIeIio2Ni5CRjIeJkYk� );
    }
    $_obf_iYmHlIeIio2Ni5CRjIeJkYk� = sprintf( "%01.2f", $_obf_iYmHlIeIio2Ni5CRjIeJkYk� );
    $_obf_kJCVjoaIiYeKiI6UiYuIjYo� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "linknum", "gp", "int", 1 );
    if ( $_obf_kJCVjoaIiYeKiI6UiYuIjYo� < 1 || 1000 < $_obf_kJCVjoaIiYeKiI6UiYuIjYo� )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "通道数要大于0小于1000" );
    }
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode2'] == 1 && 1 < $_obf_kJCVjoaIiYeKiI6UiYuIjYo� )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "软件参数-&gt;解绑换机设置-&gt;任意登陆 是开启状态<br>在此状态时，为避免不必要的数据产生，通道数只能填写1" );
    }
    $_obf_iI_TiI_HjoiGj4eIkZSIjog� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "points", "gp", "int", 0 );
    if ( $_obf_iI_TiI_HjoiGj4eIkZSIjog� < 0 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "次数要大于或等于0" );
    }
    $_obf_jo6RiJOSjpOJlIyKjY6UkIk� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "extattr1", "gp", "sqljs", "" );
    if ( 100 < _obf_ioqHi5WHiJKIkoeIhouHjYw�( $_obf_jo6RiJOSjpOJlIyKjY6UkIk� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "附属性长度必须小于100个字符" );
    }
    $_obf_lZWSiYeUhpCHlJKQiYyUjYY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "retailprice", "gp", "num", "0.00" );
    if ( $_obf_lZWSiYeUhpCHlJKQiYyUjYY� < 0 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "零售价不能小于0" );
    }
    $_obf_lZWSiYeUhpCHlJKQiYyUjYY� = sprintf( "%01.2f", $_obf_lZWSiYeUhpCHlJKQiYyUjYY� );
    $_obf_iYaNkZKGlIqVjoySiJKLi4c� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "islock", "gp", "int", 0 );
    $_obf_j42HkJGSkI6UhoaJlYuVk4k� = array(
        "islock" => $_obf_iYaNkZKGlIqVjoySiJKLi4c�,
        "keyname" => $_obf_lJSPi4mVjpGMkI2GkIiRkY0�,
        "cday" => $_obf_iYmHlIeIio2Ni5CRjIeJkYk�,
        "linknum" => $_obf_kJCVjoaIiYeKiI6UiYuIjYo�,
        "points" => $_obf_iI_TiI_HjoiGj4eIkZSIjog�,
        "extattr1" => $_obf_jo6RiJOSjpOJlIyKjY6UkIk�,
        "retailprice" => $_obf_lZWSiYeUhpCHlJKQiYyUjYY�
    );
    if ( $_obf_komRjo6Qi4_Rh5KHi5SLhpE� == 0 )
    {
        $_obf_lIeTkYqHioyIlJKMho6OiJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "prefix", "gp", "sql", "ABCD" );
        if ( !preg_match( "/^[a-z0-9A-Z]{4,4}\$/", $_obf_lIeTkYqHioyIlJKMho6OiJE� ) )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "卡类前缀四位，只能有由大小写英文字母和数字组成" );
        }
        if ( preg_match( "/e|o|0|char/i", $_obf_lIeTkYqHioyIlJKMho6OiJE�, $_obf_i4_Kj5CPh4qKkYyHj42Qkoc� ) )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "卡类前缀不能有字符(e,E,o,O,0,char)：".$_obf_i4_Kj5CPh4qKkYyHj42Qkoc�[0] );
        }
        $_obf_ipCJj5OVjo2Qk4aLioyOlY4� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_keyset where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." and `prefix`='".$_obf_lIeTkYqHioyIlJKMho6OiJE�."'" );
        if ( !empty( $_obf_ipCJj5OVjo2Qk4aLioyOlY4� ) )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "卡类前缀已存在，请更换一个" );
        }
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['pid'] = $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'];
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softid'] = $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['prefix'] = $_obf_lIeTkYqHioyIlJKMho6OiJE�;
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( "kss_tb_keyset", $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "添加卡类失败[执行insert语句时出错]".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
        }
        $_obf_koaTkJSOh5SKkoeNiZWJk4c� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_komUlJONiIqQk42JjYmOioY�( "kss_tb_keyset" );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "addok".$_obf_koaTkJSOh5SKkoeNiZWJk4c� );
    }
    else
    {
        $_obf_joqKkIaJhouMkJWNlJSTjpU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_keyset where `id`=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE�." and `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'] );
        if ( empty( $_obf_joqKkIaJhouMkJWNlJSTjpU� ) )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你要编辑的卡类似乎不存在或不是你能够管理的。" );
        }
        $_obf_j42HkJGSkI6UhoaJlYuVk4k� = array_diff_assoc( $_obf_j42HkJGSkI6UhoaJlYuVk4k�, $_obf_joqKkIaJhouMkJWNlJSTjpU� );
        if ( empty( $_obf_j42HkJGSkI6UhoaJlYuVk4k� ) )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "没改参数别乱点保存 -_-!" );
        }
        $_obf_io_Oh4eRj42VkIyLj4aLk5U� = array( "keyname" => 1, "cday" => 1, "linknum" => 1, "extattr1" => 1, "points" => 1 );
        $_obf_jomJh46Mi4eTipKJiImPkZA� = array_intersect_key( $_obf_j42HkJGSkI6UhoaJlYuVk4k�, $_obf_io_Oh4eRj42VkIyLj4aLk5U� );
        if ( !empty( $_obf_jomJh46Mi4eTipKJiImPkZA� ) )
        {
            $_obf_lIyRhoqSkpCHjYyJj4aIhpQ� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select id from kss_tb_order where `orderstatus`<8 and keygroupid=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE�." limit 0,1" );
            if ( !empty( $_obf_lIyRhoqSkpCHjYyJj4aIhpQ� ) )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "操作中断：卡类名、天数、通道数、次数、附属性暂时不可更改。<br>原因：有未完成的订单使用的是该卡类，该操作会使数据紊乱。<br>解决方法：请先删除属于该卡类的未完成订单。" );
            }
        }
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_tb_keyset", $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "id=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE�, "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "保置设置出错[执行update语句时出错]".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
        }
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "saveok" );
    }
}
$_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_keyset where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
echo "<script type=\"text/javascript\">\r\n\$(document).ready(function() { \r\n\$(\"[savegroup=1]\").css('cursor','pointer').live('click',function(e){\r\nvar tid=\$(this).attr(\"groupid\");\r\nvar thref='admin_soft.php?action=keygroup&isajax=1&op=save&softid=";
echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
echo "&id='+tid;\t\r\nthref=thref+'&keyname='+encodeURIComponent(\$(\"#keyname\"+tid).val());\t\r\nthref=thref+'&prefix='+\$(\"#prefix\"+tid).val();\t\r\nthref=thref+'&cday='+\$(\"#cday\"+tid).val();\t\r\nthref=thref+'&linknum='+\$(\"#linknum\"+tid).val();\t\r\nthref=thref+'&points='+\$(\"#points\"+tid).val();\t\r\nthref=thref+'&extattr1='+encodeURIComponent(\$(\"#extattra\"+tid).val());\t\r\nthref=thref+'&retailprice='+\$(\"#retailprice\"+tid).val();\t\r\nthref=thref+'&islock='+\$(\"#islock\"+tid+\":checked\").length;\r\nMouse(e);\r\n\$.ajax({\r\nurl: thref,\r\ncache: false,\r\nsuccess: function(html){\r\nif(html=='saveok'){\r\nmview('卡类设置保存成功！',-10,200);\t\t\r\n}else{\r\nmalert(html);\r\n}\r\n},\r\nerror:function(XMLHttpRequest, textStatus, errorThrown) {\r\nalert(ourl)\r\n} \r\n});\r\n});\r\n\$(\"[delgroup=1]\").css('cursor','pointer').live('click',function(e){\r\nvar tid=\$(this).attr(\"groupid\");\r\nvar thref='admin_soft.php?action=keygroup&isajax=1&op=del&softid=";
echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
echo "&id='+tid;\t\r\nMouse(e);\r\n\$.ajax({\r\nurl: thref,\r\ncache: false,\r\nsuccess: function(html){\r\nif(html=='delok'){\r\nmview('卡类删除成功！',-10,200);\r\n\$(\"#trkeygroupid\"+tid).remove();\t\t\r\n}else{\r\nmalert(html);\r\n}\r\n},\r\nerror:function(XMLHttpRequest, textStatus, errorThrown) {\r\nalert(ourl)\r\n} \r\n});\r\n});\r\n\$(\"#addgroup\").bind(\"click\",function(e){\r\nMouse(e);\r\n});\r\n\$('#admin_addkeygroup').ajaxForm({\r\nbeforeSubmit:function (arr, \$form, options) { \r\nreturn true;\r\nvar usernameValue = \$('input[name=username]').fieldValue();\r\nvar passwordValue = \$('input[name=password]').fieldValue();\r\nif (!usernameValue[0] || !passwordValue[0]) { \r\nmalert('请填写完整用户名或密码','出错'); \r\nreturn false; \r\n} \r\nreturn true;\r\n},\r\nsuccess:function (responseText, statusText, xhr, \$form) {\r\nif(responseText.substr(0,5)!='addok'){\r\nmalert(responseText); \r\n}else{\r\n\$(\"[nodata=1]\").remove();\r\nvar nkeyname=\$(\"#keyname\").attr(\"value\");\r\nvar tid=responseText.substr(5);\r\ninsertdata='<tr class=\"trd\" id=\"trkeygroupid\"'+tid+'>';\r\ninsertdata=insertdata+'<td align=center><img src='+INSTALLPATH+'kss_inc/images/bd_drop.png malt=\"删除该卡类\" groupid=\"'+tid+'\" delgroup=1 >&nbsp;&nbsp;&nbsp;&nbsp;<img src='+INSTALLPATH+'kss_inc/images/b_save.png malt=\"保存该卡类的修改\" groupid=\"'+tid+'\" savegroup=1 ></td>';\r\ninsertdata=insertdata+'<td><input type=checkbox id=\"islock'+tid+'\" value=\"1\"></td>';\r\ninsertdata=insertdata+'<td><input type=text class=smlinput maxlength=\"20\" id=\"keyname'+tid+'\" value=\"'+nkeyname+'\"></td>';\r\ninsertdata=insertdata+'<td class=dwidth>'+\$(\"#prefix\").val()+'</td>';\r\ninsertdata=insertdata+'<td><input type=text class=smlinput maxlength=\"6\" id=\"cday'+tid+'\" value=\"'+\$(\"#cday\").val()+'\"></td>';\r\ninsertdata=insertdata+'<td><input type=text class=sml3input  maxlength=\"4\" id=\"linknum'+tid+'\" value=\"'+\$(\"#linknum\").val()+'\"></td>';\r\ninsertdata=insertdata+'<td><input type=text class=sml3input maxlength=\"5\" id=\"points'+tid+'\" value=\"'+\$(\"#points\").val()+'\"></td>';\r\ninsertdata=insertdata+'<td><input type=text class=midinput maxlength=\"100\" id=\"extattra'+tid+'\" value=\"'+\$(\"#extattra\").val()+'\"></td>';\r\ninsertdata=insertdata+'<td><input type=text class=sml3input maxlength=\"7\" id=\"retailprice'+tid+'\" value=\"'+\$(\"#retailprice\").val()+'\"></td>';\r\n\r\ninsertdata=insertdata+'</tr>';\r\n\$(\"#admin_addkeygroup\").before(insertdata);\r\n\$(\"#reset__\").click();\r\nmview('添加卡类成功，新的卡类已经加入到列表！',-10,-400); \r\n}\r\n}\r\n});\r\n\r\n\r\n});\r\n</script>\r\n\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr class=\"trhead\">\r\n<td width=60>操作</td>\r\n<td malt=\"为防止统计数据出错，注册卡类添加后不可以删除，只能停用，停用后的注册卡类将不可用，但之前生成的该类的卡不受影响\">停用</td>\r\n<td malt=\"注册卡的名字，例如周卡、月卡、年卡之类的\">注册卡名</td>\r\n<td malt=\"注册卡号的前四位字符，只能用英文字母和数字，英文字母区分大小写的，该项录入后不可修改\">前缀</td>\r\n<td malt=\"注册卡的有效天数或可充值天数\">天数</td>\r\n<td malt=\"注册卡的通道数，指用户能在多少电脑上同时登陆使用软件。<br>只有在软件参数-&gt;解绑换机设置-&gt;任意登陆未勾选状态，且你需要用户能同时在多台电脑上登陆的时候，通道数才需要填大于1的数字<br>\">通道数</td>\r\n<td malt=\"注册卡的可使用点数，以满足有些需要按次计费的软件\">点数</td>\r\n<td malt=\"注册卡的扩展属性，注册卡添加后就会拥有此属性，可以来实现一些特殊的功能\">附属性</td>\r\n<td malt=\"注册卡在销售站上显示的零售价\">零售价</td>\r\n\r\n</tr>\r\n";
if ( empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
{
    echo "<tr nodata=1 class=trd><td colspan=9>没有任何卡类，请先添加</td></tr>";
}
else
{
    foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyname'] = str_replace( "<", "《", htmlspecialchars_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyname'] ) );
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyname'] = str_replace( ">", "》", htmlspecialchars_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyname'] ) );
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'] = str_replace( "<", "《", htmlspecialchars_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'] ) );
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'] = str_replace( ">", "》", htmlspecialchars_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'] ) );
        echo "\r\n<tr class=\"trd\" id=\"trkeygroupid";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\">\r\n<td align=center><img src='";
        echo INSTALLPATH;
        echo "kss_inc/images/bd_drop.png' malt=\"删除该卡类。注意：只有该卡类没有注册卡的情况下才可以删除，如果有该卡类的注册卡，必须先删除该类注册卡然后才可以删除该卡类。\" groupid=\"";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\" delgroup=1>&nbsp;&nbsp;&nbsp;&nbsp;<img src='";
        echo INSTALLPATH;
        echo "kss_inc/images/b_save.png' malt=\"保存该卡类的修改\" groupid=\"";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\" savegroup=1></td>\r\n<td><input type=checkbox id=\"islock";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\" value=\"1\" ";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['islock'] == 1 ? " checked" : "";
        echo "></td>\r\n<td><input type=text class=smlinput maxlength=\"20\" id=\"keyname";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\" value=\"";
        echo _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyname'] );
        echo "\" AUTOCOMPLETE=\"off\"></td>\r\n<td class=dwidth>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['prefix'];
        echo "</td>\r\n<td><input type=text class=smlinput maxlength=\"6\" id=\"cday";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\" value=\"";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cday'];
        echo "\" AUTOCOMPLETE=\"off\"></td>\r\n<td><input type=text class=sml3input  maxlength=\"4\" id=\"linknum";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\" value=\"";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linknum'];
        echo "\" AUTOCOMPLETE=\"off\"></td>\r\n<td><input type=text class=sml3input maxlength=\"8\" id=\"points";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\" value=\"";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['points'];
        echo "\" AUTOCOMPLETE=\"off\"></td>\r\n<td><input type=text class=midinput maxlength=\"100\" id=\"extattra";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\" value=\"";
        echo _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'] );
        echo "\" malt=\"";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'];
        echo "\"></td>\r\n<td><input type=text class=sml3input maxlength=\"7\" id=\"retailprice";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\" value=\"";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['retailprice'];
        echo "\" AUTOCOMPLETE=\"off\"></td>\r\n\r\n</tr>\r\n";
    }
}
echo "<form id=\"admin_addkeygroup\" action=\"?action=keygroup&op=save&softid=";
echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
echo "\" method=\"post\"> \r\n<tr class=\"trd\" id=\"trkeygroupid\">\r\n<td><input type=\"hidden\" alt=\"ajax提交必须添加此项\" name=\"isajax\" value=\"1\" /><input type=submit class=submitbtn value=\"添加卡类\" id=\"addgroup\"><input type=reset id=\"reset__\" style=\"display:none\"></td>\r\n<td><input malt=\"为防止统计数据出错，注册卡类添加后不可以删除，只能锁定，锁定后的注册卡类将不可用，但之前生成的该类的卡不受影响\" type=checkbox id=\"islock\" name=\"islock\" value=\"1\"></td>\r\n<td><input malt=\"注册卡的名字，便如周卡、月卡、年卡之类的\" type=text class=smlinput maxlength=\"20\" id=\"keyname\" name=\"keyname\" value=\"\" AUTOCOMPLETE=\"off\"></td>\r\n<td><input malt=\"注册卡号的前四位字符，只能用英文字母和数字，英文字母区分大小写的，该项录入后不可修改\" type=text class=sml3input maxlength=\"4\" id=\"prefix\" name=\"prefix\" value=\"\" AUTOCOMPLETE=\"off\"></td>\r\n<td><input malt=\"注册卡的有效天数或可充值天数\" type=text class=smlinput maxlength=\"6\" id=\"cday\" name=\"cday\" value=\"\" AUTOCOMPLETE=\"off\"></td>\r\n<td><input malt=\"注册卡的通道数，指用户能在多少电脑上同时登陆使用软件。<br>只有在软件参数-&gt;解绑换机设置-&gt;任意登陆未勾选状态，且你需要用户能同时在多台电脑上登陆的时候，通道数才需要填大于1的数字<br>\" type=text class=sml3input  maxlength=\"4\" id=\"linknum\" name=\"linknum\" value=\"1\"></td>\r\n<td><input malt=\"注册卡的可用点数，以满足有些需要按次计费的软件\" type=text class=sml3input maxlength=\"8\" id=\"points\" name=\"points\" value=\"0\"></td>\r\n<td><input malt=\"注册卡的扩展属性，注册卡添加后就会拥有此属性，可以来实现一些特殊的功能\" type=text class=midinput maxlength=\"20\" id=\"extattra\" name=\"extattr1\" value=\"\"></td>\r\n<td><input malt=\"注册卡在销售站上显示的零售价\" type=text class=sml3input maxlength=\"7\" id=\"retailprice\" name=\"retailprice\" value=\"0.00\" AUTOCOMPLETE=\"off\"></td>\r\n\r\n</tr>\r\n</form>\r\n</table>\r\n";
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
echo "<div id=pageruntime>页面运行时间"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_i5GVjZWQj4ePkJKMjJSRipM� )."毫秒</div>";
echo "</body>\r\n</html>";
?>
