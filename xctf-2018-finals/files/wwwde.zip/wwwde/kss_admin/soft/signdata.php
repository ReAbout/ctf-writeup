<?php

function _obf_kIaJlZWOkI_Nj4mQjpSUjok�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "KSSROOTDIR" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 8 );
$_obf_iJKRhpSOjIiGkJONkIqIjIg� = file( KSSINCDIR."signdata".DIRECTORY_SEPARATOR."_".rand( 1, 5 ).".php" );
$_obf_iI2PkIeKjpOQjIuVlIiMipA� = trim( $_obf_iJKRhpSOjIiGkJONkIqIjIg�[rand( 1, 100 )] );
echo "signDataǩ������ÿ��ȡ�õĿ��ܻ᲻ͬ����Ӱ��ʹ�ã�<br>\r\n<textarea style=\"width:450px;height:120px\">signData=\"";
echo $_obf_iI2PkIeKjpOQjIuVlIiMipA�;
echo "\"</textarea>\r\n<textarea style=\"display:none\" id=delphisdata>";
echo $_obf_lImJiJKVioeSipWQk4iHlJM�;
echo "</textarea>\r\n<textarea style=\"display:none\" id=vbsdata>";
echo $_obf_kI_TkI6UiIaJko2RlYqIh48�;
echo "</textarea>\r\n<textarea style=\"display:none\" id=vcsdata>";
echo $_obf_kJCMh5OGhpGTkIiTj4iHioY�;
echo "</textarea>\r\n<textarea style=\"display:none\" id=esdata>";
echo $_obf_kJWNiIiOh4uNlI6SkpSUkIw�;
echo "</textarea>\r\n";
?>
