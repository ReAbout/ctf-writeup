<?php

function _obf_k4mSi42SlImTlJOGjo2JkI0�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
if ( !defined( "KSSROOTDIR" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 8 );
$_obf_k4mViI2Nj4mJkIuUj42JiIY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "op", "gp", "sql", "" );
$_obf_jpKNh4aRh4aQkY2PlIuRhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softid", "gp", "int", 0 );
$_obf_k5WPhoeNjZOTk4yQlYyQj4c� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "sver", "gp", "int", 9 );
if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == "signdata" )
{
    ob_clean( );
    $_obf_iJKRhpSOjIiGkJONkIqIjIg� = file( KSSINCDIR."signdata".DIRECTORY_SEPARATOR."_".$_obf_k5WPhoeNjZOTk4yQlYyQj4c�.".php" );
    $_obf_iI2PkIeKjpOQjIuVlIiMipA� = trim( $_obf_iJKRhpSOjIiGkJONkIqIjIg�[rand( 1, 100 )] );
    $_obf_kJWNiIiOh4uNlI6SkpSUkIw� = "\tsignData= “".$_obf_iI2PkIeKjpOQjIuVlIiMipA�."”\r\n";
    $_obf_lImJiJKVioeSipWQk4iHlJM� = "\tsignData := '';\r\n";
    $_obf_kI_TkI6UiIaJko2RlYqIh48� = "\tsignData = ".YH2.YH2."\r\n";
    $_obf_kJCMh5OGhpGTkIiTj4iHioY� = "\tsignData = __TEXT(".YH2.YH2.");\r\n";
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    do
    {
        $_obf_jJWVlI2Kh4uIkouNkI6QkoY� = substr( $_obf_iI2PkIeKjpOQjIuVlIiMipA�, $_obf_jpKPlJSUiZOHkYaPlIeOiY4�, 100 );
        $_obf_lImJiJKVioeSipWQk4iHlJM� .= "\tsignData := signData + '".$_obf_jJWVlI2Kh4uIkouNkI6QkoY�."';\r\n";
        $_obf_kI_TkI6UiIaJko2RlYqIh48� .= "\tsignData = signData & ".YH2.$_obf_jJWVlI2Kh4uIkouNkI6QkoY�.YH2."\r\n";
        $_obf_kJCMh5OGhpGTkIiTj4iHioY� .= "\tsignData += __TEXT(".YH2.$_obf_jJWVlI2Kh4uIkouNkI6QkoY�.YH2.");\r\n";
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 100;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < strlen( $_obf_iI2PkIeKjpOQjIuVlIiMipA� ) );
    echo "signData签名数据每次取得的可能会不同，不影响使用！<br>\r\n<input type=button class=submitbtn  id='copy_";
    echo _obf_iI6QhpSTiJCJiI_KlYePlZI�( 16 );
    echo "' value=\"标准格式\"  onmouseover=\"toClipboard(this.id,\$('#basel').html());\">\r\n<input type=button class=submitbtn  id='copy_";
    echo _obf_iI6QhpSTiJCJiI_KlYePlZI�( 16 );
    echo "' value=\"易格式\"  onmouseover=\"toClipboard(this.id,\$('#esdata').html());\">\r\n<input type=button class=submitbtn  id='copy_";
    echo _obf_iI6QhpSTiJCJiI_KlYePlZI�( 16 );
    echo "' value=\"按键格式\"  onmouseover=\"toClipboard(this.id,\$('#vbsdata').text().toString().replace(/\tsignData = signData/g,'\\r\\n\tsignData = signData'));\">\r\n<input type=button class=submitbtn  id='copy_";
    echo _obf_iI6QhpSTiJCJiI_KlYePlZI�( 16 );
    echo "' value=\"VB格式\"  onmouseover=\"toClipboard(this.id,\$('#vbsdata').text().toString().replace(/\tsignData = signData/g,'\\r\\n\tsignData = signData'));\">\r\n<input type=button class=submitbtn  id='copy_";
    echo _obf_iI6QhpSTiJCJiI_KlYePlZI�( 16 );
    echo "' value=\"VC格式\"  onmouseover=\"toClipboard(this.id,\$('#vcsdata').html());\">\r\n<input type=button class=submitbtn  id='copy_";
    echo _obf_iI6QhpSTiJCJiI_KlYePlZI�( 16 );
    echo "' value=\"Delphi格式\"  onmouseover=\"toClipboard(this.id,\$('#delphisdata').html());\"></span><br>\r\n<textarea style=\"width:570px;height:80px\" id=\"viewtbase\">signData=\"";
    echo $_obf_iI2PkIeKjpOQjIuVlIiMipA�;
    echo "\"</textarea>\r\n<textarea style=\"display:none\" id=basel>";
    echo $_obf_lImJiJKVioeSipWQk4iHlJM�;
    echo "</textarea>\r\n<textarea style=\"display:none\" id=delphisdata>";
    echo $_obf_lImJiJKVioeSipWQk4iHlJM�;
    echo "</textarea>\r\n<textarea style=\"display:none\" id=vbsdata>";
    echo $_obf_kI_TkI6UiIaJko2RlYqIh48�;
    echo "</textarea>\r\n<textarea style=\"display:none\" id=vcsdata>";
    echo $_obf_kJCMh5OGhpGTkIiTj4iHioY�;
    echo "</textarea>\r\n<textarea style=\"display:none\" id=esdata>";
    echo $_obf_kJWNiIiOh4uNlI6SkpSUkIw�;
    echo "</textarea>\r\n";
    exit( );
}
if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == "del" )
{
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "只有管理员才可以删除软件" );
    }
    $_obf_lIiIk4yNiY_VhpGJjpOTh44� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where `id`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
    if ( empty( $_obf_lIiIk4yNiY_VhpGJjpOTh44� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你要删除的软件好像不正在" );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_agentprice where `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "清理折扣表kss_tb_agentprice出错:".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_order where `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "清理订单表kss_tb_order出错:".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_keyset where `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "清理卡类表kss_tb_keyset出错:".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
    }
    $_obf_hoqPjpSQiImSkImUjoqJj4o� = array( );
    $_obf_hoqPjpSQiImSkImUjoqJj4o�[] = "`kss_z_user_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['pid']."_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['id']."`";
    $_obf_hoqPjpSQiImSkImUjoqJj4o�[] = "`kss_z_key_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['pid']."_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['id']."`";
    $_obf_hoqPjpSQiImSkImUjoqJj4o�[] = "`kss_z_user_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['pid']."_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['id']."_recycle`";
    $_obf_hoqPjpSQiImSkImUjoqJj4o�[] = "`kss_z_key_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['pid']."_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['id']."_recycle`";
    $_obf_hoqPjpSQiImSkImUjoqJj4o�[] = "`kss_z_log_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['pid']."_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['id']."`";
    $_obf_hoqPjpSQiImSkImUjoqJj4o�[] = "`kss_z_client_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['pid']."_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['id']."`";
    $_obf_hoqPjpSQiImSkImUjoqJj4o�[] = "`kss_z_cz_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['pid']."_".$_obf_lIiIk4yNiY_VhpGJjpOTh44�['id']."`";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "drop table if exists ".implode( ",", $_obf_hoqPjpSQiImSkImUjoqJj4o� ), "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "删除会员数据表kss_z_*出错:".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_soft where `id`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "清理软件表kss_tb_soft出错:".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "delok" );
}
$_obf_lYmNk4uUiImKhoqPlIyQjpE� = array(
    "USOFT" => array( "正常", "停止使用", "禁止注册帐号", "禁止用户充值", "禁止注册帐号和充值", "冻结用户时间，正常使用软件", "冻结用户时间，停止使用软件", "", "", "-" ),
    "KSOFT" => array( "正常", "停止使用", "禁止新卡号激活", "", "", "冻结用户时间，正常使用软件", "冻结用户时间，停止使用软件", "", "", "-" )
);
$_obf_kIiSjIaLi4qUi4qRjJKRlYk� = array( "USOFT" => "用户名+密码登陆", "KSOFT" => "注册卡号登陆" );
$_obf_i4uIkYuKkJGQlJKOjoiMj4c� = array(
    "action" => $_obf_lZOThomRipOIi5SRhpWRjY4�
);
$_obf_k42Rh4mVlYqGi4mOiZWMjJA� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "page", "gp", "int", 1 );
$_obf_iYqPiJGIjoaVhoaQiI2Ti4w� = "SELECT `id` ";
$_obf_jpCQi4aKkYaIjpSUhpWNipM� = "SELECT * ";
$_obf_homTioySho6Vh5ORiYmUkok� = " where `id` in";
$_obf_kZCPiJCHiI_IlY2Ok4_JlIc� = "SELECT count(*) as tnum ";
$_obf_lJSNlZWKlYmGi4iSkIqHjpA� = "from `kss_tb_soft`  ";
$_obf_lI6IkIyPlJWMioaUiIiVlY0� = array( );
$_obf_h4eJlYuIjpKNio6QkIuJlIY�[] = " `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'];
$_obf_j4mJh4aKjZKHhpOSiJKSjJI� = "";
if ( !empty( $_obf_h4eJlYuIjpKNio6QkIuJlIY� ) )
{
    $_obf_j4mJh4aKjZKHhpOSiJKSjJI� = " where".implode( " and ", $_obf_h4eJlYuIjpKNio6QkIuJlIY� );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_lI_KipSOk4iQkI_MjIuVkpQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "recordnum", "gp", "int", 0 );
if ( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� == 1 )
{
    $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( $_obf_kZCPiJCHiI_IlY2Ok4_JlIc�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI� );
    $_obf_lI_KipSOk4iQkI_MjIuVkpQ� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['recordnum'] = $_obf_lI_KipSOk4iQkI_MjIuVkpQ�;
$_obf_jIiNjZCPkoeUjI2LipCQk5Q� = abs( floor( $_obf_lI_KipSOk4iQkI_MjIuVkpQ� / ZPAGESIZE * -1 ) );
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_iZWHjpGQkoqPlYmJjYmIhpU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_iIiHi4aTkoySkpCNio_UjYo� = "";
if ( !empty( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� ) )
{
    foreach ( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� as $_obf_kYqOi5CTjoySj4mIkYmIlY4� )
    {
        $_obf_iIiHi4aTkoySkpCNio_UjYo� .= $_obf_kYqOi5CTjoySj4mIkYmIlY4�['id'].",";
    }
    $_obf_iIiHi4aTkoySkpCNio_UjYo� = substr( $_obf_iIiHi4aTkoySkpCNio_UjYo�, 0, strlen( $_obf_iIiHi4aTkoySkpCNio_UjYo� ) - 1 );
}
$_obf_iYeIjIaVlYaIj4yTiJWHk40� = FALSE;
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
if ( $_obf_iIiHi4aTkoySkpCNio_UjYo� != "" )
{
    $_obf_homTioySho6Vh5ORiYmUkok� .= "(".$_obf_iIiHi4aTkoySkpCNio_UjYo�.")";
    $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_k4yVk4iOipWPioqJlIuVkpE� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iouHh42RkIeKkYaSipWKiog�( $_obf_k42Rh4mVlYqGi4mOiZWMjJA�, $_obf_jIiNjZCPkoeUjI2LipCQk5Q�, $_obf_i4uIkYuKkJGQlJKOjoiMj4c� )."<span class=page_nav_a>".$_obf_lI_KipSOk4iQkI_MjIuVkpQ�."行  耗时"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_lJKOiJSHjo_Sj4yKk4aIh5I� )."毫秒</span>";
echo "<script type=\"text/javascript\">\r\n\$(document).ready(function() { \r\n\r\n\$(\"[delid]\").css('cursor','pointer').bind('click',function(){\r\nvar tid=\$(this).attr(\"delid\");\r\nvar thref='admin_soft.php?action=softlist&isajax=1&op=del&softid='+tid;\t\r\nvar tlevel=\t";
echo $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'];
echo ";\t\r\n\r\nif(tlevel<8){\r\nmalert('无权限删除软件!');\r\nreturn false;\r\n}\r\nmalert('删除软件操作不可恢复，为防意外请做好数据库备份工作!<br>是否真的要删除该软件？','警告',500,60,function(){\r\n\$.ajax({\r\nurl: thref,\r\ncache: false,\r\nsuccess: function(html){\r\nif(html=='delok'){\r\n\$(\"#trsoftid\"+tid).remove();\t\r\nmalert('软件删除成功！');\t\t\r\n}else{\r\nmalert(html);\r\n}\r\n},\r\nerror:function(XMLHttpRequest, textStatus, errorThrown) {\r\nalert(ourl)\r\n} \r\n});\r\n});\r\n});\r\n\$(\"#getsign2\").bind(\"click\",function(){\r\n\$.ajax({\r\nurl: './admin_soft.php?action=softlist&op=signdata&isajax=1&sver=9&ver=2',\r\ncache: false,\r\nsuccess: function(html){\r\nif(html.substr(0,8)=='signData'){\r\nmalert(html,'9.5和新版本签名数据，请单击不同按钮可获取相应语言格式化后的签名数据',620,180);\r\n}else{\r\nmalert('取签名数据出错<br>'+html);\r\n}\r\n},\r\nerror:function(XMLHttpRequest, textStatus, errorThrown) {\r\nmalert('err');\r\n} \r\n});\t\r\n});\r\n\r\n});\r\n</script>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td><td style=\"background:#f6f6f6;padding:5px 0\" align=center width=220> <input malt=\"9.5和9.5+版本的客户端签名数据\" title=\"9.5和9.5+版本的客户端签名数据\" type=button class=submitbtn id=\"getsign2\" value=\"新签名数据\" /></td>\r\n</tr>\r\n</table>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr class=\"trhead\">\r\n<td malt=\"软件ID\" width=50>软件ID</td>\r\n<td>软件名</td>\r\n<td>模式</td>\r\n<td>软件编号</td>\r\n<td>软件密钥</td>\r\n<td>软件状态</td>\r\n<td width=\"80\">操作</td>\r\n</tr>\r\n";
if ( empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
{
    echo "<tr class=trd><td colspan=9>没有软件，请先添加软件</td></tr>";
}
else
{
    foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softname'] = _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softname'] );
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softkey'] = _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softkey'] );
        echo "<tr class=\"trd\" id=\"trsoftid";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\">\r\n<td style=\"font-size:16px;color:#00f;font-weight:700\">";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "</td>\r\n<td>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softname'];
        echo "</td>\r\n<td>";
        echo $_obf_kIiSjIaLi4qUi4qRjJKRlYk�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softmode']];
        echo "</td>\r\n<td>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softcode'];
        echo "</td>\r\n<td>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softkey'];
        echo "</td>\r\n<td>";
        echo $_obf_lYmNk4uUiImKhoqPlIyQjpE�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softmode']][$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus']];
        echo "</td>\r\n<td>\r\n<a href=\"javascript:void(0)\"  onclick=\"dwin('soft_set_";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "','";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softname'];
        echo "参数设置','admin_soft.php?action=addsoft&softid=";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "')\"><img malt=\"软件参数设置\" src=\"";
        echo INSTALLPATH;
        echo "kss_inc/images/b_edit.png\" ></a>";
        if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 9 )
        {
            echo "&nbsp;&nbsp;<a href=\"javascript:void(0)\"  onclick=\"dwin('user_report_";
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
            echo "','";
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softname'];
            echo "注册卡报表','admin_key.php?action=report&softid=";
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
            echo "')\"><img malt=\"查看该软件注册卡的使用报表\" src=\"";
            echo INSTALLPATH;
            echo "kss_inc/images/b_calendar.png\"></a>\r\n&nbsp;&nbsp;<img  delid=\"";
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
            echo "\" malt=\"删除该软件\" src=\"";
            echo INSTALLPATH;
            echo "kss_inc/images/bd_drop.png\">";
        }
        echo "</td>\r\n</tr>\r\n";
    }
}
echo "</table>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n";
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
echo "<div id=pageruntime>页面运行时间"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_i5GVjZWQj4ePkJKMjJSRipM� )."毫秒</div>";
echo "</body>\r\n</html>";
?>
