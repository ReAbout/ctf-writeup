<?php

function _obf_jJCHiJCQiI6MlYiPk4eTkpQ�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_i46IiJSKkYqJk5CNlJGSiZI�( $_obf_kJSPlYqRjouVi4uTjZKMjoc�, $_obf_jpKNh4aRh4aQkY2PlIuRhpE�, $_obf_h5WSh5WPkoaVjJWVkoiQjoc�, $_obf_lIeVh5WRjImJjpGSiJOGiIY�, $_obf_j4yOlY6Pi5SJi4_UkYyPjJU� )
{
    $_obf_iouGh4aRkYmSioiOlImUio4� = array(
        "advapicode" => $_obf_h5WSh5WPkoaVjJWVkoiQjoc�,
        "scode" => $_obf_lIeVh5WRjImJjpGSiJOGiIY�,
        "rsacode" => $_obf_j4yOlY6Pi5SJi4_UkYyPjJU�
    );
    return _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC2URL."?step=bsaveapicode&fname=".$_obf_kJSPlYqRjouVi4uTjZKMjoc�.$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."&pwd=".MYSQLBAKPASSWORD, $_obf_iouGh4aRkYmSioiOlImUio4�, 20 );
}

$_obf_h4qRkYiVi4uHlZWKk42JlI0� = "�����������������";
if ( !defined( "KSSROOTDIR" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$$_obf_h4qRkYiVi4uHlZWKk42JlI0� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 8 );
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 9 )
{
    _obf_lI_NjpSLio_JjZCVh4qUjYc�( );
}
$_obf_jI6Lho6UhomJio_IhoaQkJA� = "?";
if ( $_obf_lZOThomRipOIi5SRhpWRjY4� == "addsoft_rsatest" )
{
    $_obf_jpCVlIqLkZGGho2Ri5OHjIk� = "-----BEGIN RSA PRIVATE KEY-----\r\nMIICXAIBAAKBgQDmFAcE89dOn4OXvkp6sbzU+owwqrANjyiyZT8vAtb42iVnUIVR\r\n1Wog3y8mfzKEUJcag01uBAO6SB8IRLZfjOF2kWzd79BpxLwqiQOV3TdVfXs9Q/1q\r\nVcIziq4Tg69m3F5PCnCmCqumL1x3uMYUpjjcsvM/VBUUn8QojHVm1l00swIDAQAB\r\nAoGBAMyPKd6BXgCNWlZj3ZxQwm8pg9MRLw4fJjPWSOLnR3JhobfFo4Mql/058ZXs\r\nqWFytaXg78rMzvOkg9K6JNu3SgyNNHk5QILqHgk1DrO2g+ZqbdyWNkjsmfo2n60J\r\nmh02xnMqqkHZkyBGmC1o6nYuCKybtRN6NEe4joz617XYG5iBAkEA/UX/w8zGHgUd\r\n++Zv7jZhD0zu66cMW04Dtc78bVP3j5iIhf4Pn/Xco87/zzsTSdwOCUq+OAfW7T7L\r\n4wp/3UDCYwJBAOiOGrBoq9jC8xcs5B0emRaXTBhkAh/EqcrPkuhsK55etpKooBDQ\r\nodaFa2USK7G97U9fk3FAWu/PGHf6nn+0LXECQCmMVSPKsOl1z3BmYhBC7XM0HLGd\r\nysIjryohFXnd32u4CxVoEyobjCF3MLHPMB/asJbHoyLP7msm9Q1+yHEEUZ8CQD+v\r\nIpnqoBzFDkLrdTCQP4YTOrB3OqmudnzmqSli7fL5pu+0o9jW+WrAsK9F8ZdEFqek\r\n2cCqyfxf7yh0BlGcatECQAQuuEbEQ9rc7R/RXzVpysVK/uyeRrLGLxkm2x4P1hgi\r\nbv3OBiKqFCOUJ/z9+4noY2RHuA9o7qQZYqPFfBWWnxE=\r\n-----END RSA PRIVATE KEY-----";
    $_obf_k4aGio_QiJOGkIiVjIqVk5E� = "-----BEGIN RSA PRIVATE KEY-----\r\nMIIBOwIBAAJBAKgs3HGLFt51G53ZQMtRnlK9UDvflzx5KxMhrTyGjDwqXDqajM4g\r\nR0wF2dqnKcH9680Tv/XJ3o7HsmR4hSFTAZ0CAwEAAQJBAJpO11IjYi9p2pYiMm6c\r\nDB408HqPdLAbKafbPZ4Mgn3sj1E0VbVBpI+J6imD9ZhYhZuZzagj80rX0WKhbCzK\r\nvqECIQDWB5skBa8gGrgqNzhg2WEMBYGfl1MnakASIH0m4BmT6QIhAMknVq/pBn0t\r\n6aWPSXps4VJzqLftNu6Gn9lEmIQhZLOVAiEAruzafE90+R09ZatqFaW0rnmVnpS0\r\nLqOlJ+uLvgksfnkCIBAPA+ynPc1gjPaaqdMMPjDG6wFD/s6sELbXsxVZVSDBAiAR\r\nSdmzQ3IvnA3a9JUf5HVXl7RJBMq4fnYSqlWdM154Kg==\r\n-----END RSA PRIVATE KEY-----";
    $_obf_iI6LhoeRh5ONj4eMkYmTjok� = "-----BEGIN RSA PRIVATE KEY-----\r\nMIGrAgEAAiEA3REKHIdQHOg1APos4e9jUILVA7/YVpYHIN+Js/0REz0CAwEAAQIg\r\nfh5zg1UbOnKrkpQnuPpG0J9KgoDpqH2YgZ7OBPfb1MECEQD2HRjCAM/RQxHGcEKL\r\n5IWtAhEA5fJfIhomtFOON1E/SEPV0QIRANWvsb1QAyBIQXiwI7detQkCEQCgid2n\r\nVnCtNyS0NDIlRs7xAhA/KLa15wipXwi/aZZD6uJ8\r\n-----END RSA PRIVATE KEY-----";
    $_obf_lY6ViI_KiJWHj4aTlZKNjYw� = "TestData";
    $_obf_kY6UiIaHh4yRiYeJlYaMkpQ� = microtime( TRUE );
    crypt_rsa_ex( $_obf_lY6ViI_KiJWHj4aTlZKNjYw�, $_obf_jpCVlIqLkZGGho2Ri5OHjIk�, "encrypt" );
    $_obf_kIaRjYyKlYaPiI6QhoeIiY0� = microtime( TRUE );
    crypt_rsa_ex( $_obf_lY6ViI_KiJWHj4aTlZKNjYw�, $_obf_k4aGio_QiJOGkIiVjIqVk5E�, "encrypt" );
    $_obf_komKiY2Kh4eQk5WVj4uVjYg� = microtime( TRUE );
    crypt_rsa_ex( $_obf_lY6ViI_KiJWHj4aTlZKNjYw�, $_obf_iI6LhoeRh5ONj4eMkYmTjok�, "encrypt" );
    $_obf_jomHkImLlZSJiYiJk5WVjZU� = microtime( TRUE );
    echo "当前使用的RSA算法核心是：".rsaisok( )."<br>";
    $_obf_jI_KjZKPk46QkomOjZWPlZU� = substr( round( $_obf_kIaRjYyKlYaPiI6QhoeIiY0� - $_obf_kY6UiIaHh4yRiYeJlYaMkpQ�, 6 )."000", 0, 8 );
    $_obf_h4qMkJWSlZGNj5WLj4aJk44� = substr( round( $_obf_komKiY2Kh4eQk5WVj4uVjYg� - $_obf_kIaRjYyKlYaPiI6QhoeIiY0�, 6 )."000", 0, 8 );
    $_obf_h5CVjJKNi4iGlJOPlZCJkIk� = substr( round( $_obf_jomHkImLlZSJiYiJk5WVjZU� - $_obf_komKiY2Kh4eQk5WVj4uVjYg�, 6 )."000", 0, 8 );
    echo "１０２４私钥加密用时".$_obf_jI_KjZKPk46QkomOjZWPlZU�."秒，最多只能加密117个字节<br>";
    echo "　５１２私钥加密用时".$_obf_h4qMkJWSlZGNj5WLj4aJk44�."秒，最多只能加密53个字节<br>";
    echo "　２５６私钥加密用时".$_obf_h5CVjJKNi4iGlJOPlZCJkIk�."秒，最多只能加密21个字节<br>";
    if ( 0.2 < $_obf_jI_KjZKPk46QkomOjZWPlZU� )
    {
        if ( 0.2 < $_obf_h4qMkJWSlZGNj5WLj4aJk44� )
        {
            echo "建议使用256位的RSA私钥<br>";
            exit( );
        }
        else
        {
            echo "建议使用512位的RSA私钥<br>";
            exit( );
        }
    }
    else
    {
        echo "建议使用1024位的RSA私钥<br>";
        exit( );
    }
}
else
{
    if ( $_obf_lZOThomRipOIi5SRhpWRjY4� == "addsoft_save" )
    {
        _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
        $_obf_jpKNh4aRh4aQkY2PlIuRhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softid", "p", "int", 0 );
        $_obf_koeLiIiJjJOQlIaJi4aUh5A� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "pid", "p", "int", 10000 );
        if ( $_obf_koeLiIiJjJOQlIaJi4aUh5A� < 10000 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你填写的PID非法。PID:".$_obf_koeLiIiJjJOQlIaJi4aUh5A� );
        }
        if ( LICTYPE < $_obf_koeLiIiJjJOQlIaJi4aUh5A� - 9999 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你使用的服务端授权不能给该作者添加软件。PID:".$_obf_koeLiIiJjJOQlIaJi4aUh5A� );
        }
        if ( LICTYPE == 1 )
        {
            $_obf_koeLiIiJjJOQlIaJi4aUh5A� = 10000;
        }
        $_obf_h4mRiI2JlYmThoyOjIqQjok� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softmode", "p", "sqljs", "USOFT" );
        $_obf_h4mOjIyTkYmOhpKJk4mPi5I� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softmode2", "p", "int", 0 );
        $_obf_ho2MkouGjomGioiSi4yGlJQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "viewkey", "p", "int", 1 );
        $_obf_koaPj4eRiYyMiZSGlJKKi4o� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softkey", "p", "sqljs", "notkey" );
        $_obf_jIiTj4yOk5KGk4mViI_QkZE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softname", "p", "sqljs", "未命名软件" );
        $_obf_i4yQh4_Ik42IjoeRjpOVlYc� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "dkbindpc", "p", "int", 0 );
        $_obf_jI_Rj5KHiYeHlJOPlZSJiIY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "nodebuger", "p", "int", 0 );
        $_obf_iI_LkYuKho6Lh4qPlYyGho8� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "pccodestep", "p", "int", 0 );
        $_obf_j46NlZGIiJCKjImHkYaIlI0� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "rsaenable", "p", "int", 0 );
        $_obf_i5OPlJWHi5KQkIyJh4uTh5A� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "rsaekey", "p", "num", "" );
        $_obf_lIqNlZSKiJCGioqQk5KMlZE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "rsankey", "p", "num", "" );
        $_obf_iJCQko6LiI2SkouKkoqSkIk� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "freeregs", "p", "int", 0 );
        $_obf_h5CPlYuViomKj5GMiI6NiYo� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "fregmanagerid", "p", "int", 0 );
        $_obf_jpOIlIuRipSRlJWNkoeJipM� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "fregtag", "p", "sqljs", "" );
        $_obf_k5WQiJOHiIiVkYiPh5CPlJM� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "fregattr", "p", "sqljs", "" );
        $_obf_i4yUjIuHj46IiJKVlZOGi4w� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "onlyonebdinfo", "p", "int", 0 );
        $_obf_lYmMiJWRiIeUio6Gk4iThoc� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softstatus", "p", "int", 0 );
        $_obf_lZKIi46UkYmVho2JhpOHlIo� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "onetimeskeyattrid", "p", "sqljs", "" );
        $_obf_j46NjIiQkZCNlY_Kj5KJhpU� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softhead", "p", "sql", "" );
        $_obf_k4yOh46UjoqJkImUjouJjI4� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "returninfo1", "p", "sql", "" );
        $_obf_iIyUi5KQkY2GjJSTkIeJj5A� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "returninfo2", "p", "sql", "" );
        $_obf_hpOIhouMlJCRiZWRiZWUipA� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softversion", "p", "int", 1 );
        $_obf_jYiPk4aKhpKLjo2Pj4qMhpQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softdownurl", "p", "sql", "http://" );
        $_obf_jYiPk4aKhpKLjo2Pj4qMhpQ� = base64_encode( $_obf_jYiPk4aKhpKLjo2Pj4qMhpQ� );
        $_obf_h4_IioiHiouTlJSGkYaJkZI� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "ismustupdate", "p", "int", 0 );
        $_obf_j4_HhpOTk4yHiouMk5CLj4k� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "connectpenli", "p", "int", 15 );
        if ( $_obf_j4_HhpOTk4yHiouMk5CLj4k� < 5 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "验证频率最小只能填5！" );
        }
        $_obf_jIyPj5CUh4aOkJWMkJKMkok� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "points_set", "p", "int", 0 );
        $_obf_hpCGjIeHiJGKjZOGiZSIkoY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "test_timearea", "p", "sqljs", "" );
        $_obf_hpCGjIeHiJGKjZOGiZSIkoY� = str_replace( " ", "", $_obf_hpCGjIeHiJGKjZOGiZSIkoY� );
        $_obf_kY_TjpCUkIePjoaHkIiJkZU� = explode( ",", $_obf_hpCGjIeHiJGKjZOGiZSIkoY� );
        if ( $_obf_kY_TjpCUkIePjoaHkIiJkZU�[1] < $_obf_kY_TjpCUkIePjoaHkIiJkZU�[0] || $_obf_kY_TjpCUkIePjoaHkIiJkZU�[0] < 0 || 23 < $_obf_kY_TjpCUkIePjoaHkIiJkZU�[0] || $_obf_kY_TjpCUkIePjoaHkIiJkZU�[1] < 0 || 23 < $_obf_kY_TjpCUkIePjoaHkIiJkZU�[1] )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "试用设置里的可用时间段填写错误" );
        }
        $_obf_k4iRjZCGj4eSkJSUj5WNj4Y� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "autolock_times", "p", "int", 0 );
        $_obf_hoyNjZGGjYeUhpKNjIeIjYw� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "autolock_time", "p", "int", 0 );
        $_obf_ko2RlI6QkZKKlJGRjYqNiJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "autolock_times_advapi", "p", "int", 0 );
        $_obf_lZKUlIyRkoyJho2KjpKUjos� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "autolock_time_advapi", "p", "int", 0 );
        $_obf_iZCOjImGkJKQjpOGkYmLkoY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "autolock_ipnum", "p", "int", 0 );
        $_obf_kIuJioiGi4iHkoyNiYmIho4� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "autolock_time_ip", "p", "int", 0 );
        $_obf_iJWJk5CKj4uPiJCKh5KJjIs� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "mac_blacklist", "p", "sqljs", "" );
        $_obf_jpGUjoeKi5GGlIyJh5KOjYw� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "test_times", "p", "int", 1 );
        $_obf_jZGMlZCNiY_Ii5ORkoqSjZQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "test_day", "p", "int", 1 );
        $_obf_iYaSjI6GipOIkY2UjpWOjIk� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "test_time", "p", "int", 15 );
        $_obf_j4aTjZGOjpOHh4qUkoaJkJQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "chkonline", "p", "int", 0 );
        $_obf_ipSRjIuMk5WVjYmTlZKJh5I� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "outlinetime", "p", "int", 360 );
        $_obf_i4qIiJKGiIuTkI6MjpCKj5E� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "outlinetimes", "p", "int", 1 );
        $_obf_joqGjI6HkI2NjoqUhoqIjYw� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "outlinelock", "p", "int", 2 );
        $_obf_iI_Hk4_TkJSKkpSNkI2QjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "outline_addtime", "p", "num", 0 );
        $_obf_kpSTkJOMi5WIjZKKioiVlZI� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "unbindpc_set", "p", "int", 0 );
        $_obf_jZOKkoeRh5KJkJKLiYuPjIY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "unbindpc_autotime", "p", "int", 0 );
        $_obf_kIaRi5KVio_TlY6TkpKLjYg� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "unbindpc_times", "p", "int", 1 );
        $_obf_kY_JjY2Pko6MkIuQkZOUjpI� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "unbindpc_ctset", "p", "int", 0 );
        $_obf_ho6MjomOjYuKjYeNh5SIho0� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "unbindpc_changetime", "p", "num", "0.00" );
        $_obf_lY2GjpGVkJKUi5SOlJWSh5Q� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "editbdinfo_changetime", "p", "num", "0.00" );
        $_obf_hpOQiJGNk42RhoeJiY6Oi48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "czzs_keytypeid", "p", "sqljs", "" );
        $_obf_iIyPkJCOj4aNiIaPjouMiow� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "czzs_number", "p", "int", 3 );
        $_obf_iYmNiYeIkY_ShoeOiJCNkYw� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "czzs_cday", "p", "num", "1.00" );
        $_obf_kIeOlZOTjoyVkJKOkZOQj5U� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "czzs_points", "p", "int", 0 );
        $_obf_ipKJj5CPh4eTjIiKh4eRk4Y� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "nokeyreg", "p", "num", "0.00" );
        $_obf_h4_UjZKLiZWMjIaPiI_Qkoo� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "nokeyreg_points", "p", "int", 0 );
        $_obf_lYuIj4_KhpGTjYqPj5OGlJM� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "tg_addtimetype", "p", "int", 0 );
        $_obf_jY_UjJKOiY_Uj4iKlY2Viow� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "tg_parentuseraddtime", "p", "int", 0 );
        $_obf_lYeNjo6UhoiTiYuOhouOho4� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "tg_newuseraddtime", "p", "int", 0 );
        $_obf_h5OSkY6VkpSPkY6Th4mVlZA� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "tg_points1", "p", "int", 0 );
        $_obf_joiNk4aLk4_OiI2UlZSHj5E� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "tg_points2", "p", "int", 0 );
        $_obf_kouUjYyRjYaSk5SThpKIj5Q� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "advapi", "p", "", "" );
        $_obf_kouUjYyRjYaSk5SThpKIj5Q� = str_replace( "<".$_obf_jI6Lho6UhomJio_IhoaQkJA�."php", "", $_obf_kouUjYyRjYaSk5SThpKIj5Q� );
        $_obf_kouUjYyRjYaSk5SThpKIj5Q� = str_replace( $_obf_jI6Lho6UhomJio_IhoaQkJA�.">", "", $_obf_kouUjYyRjYaSk5SThpKIj5Q� );
        $_obf_k5GSkIaRi5STi5CIlI2RjIw� = base64_encode( $_obf_kouUjYyRjYaSk5SThpKIj5Q� );
        function zsarr_sort1( $_obf_iJSNjIuPjoqSjYyUiIyIi5A�, $_obf_j4qUhoiVipWQj4iNh5CJj4w� )
        {
            if ( $_obf_iJSNjIuPjoqSjYyUiIyIi5A�['num'] == $_obf_j4qUhoiVipWQj4iNh5CJj4w�['num'] )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "相同卡类不能出现相同张数的设置！" );
            }
        }
        $_obf_joeIkY2Jko_PjoiSlJWQhoc� = "";
        if ( isset( $_POST['zs_czset'] ) && $_obf_jpKNh4aRh4aQkY2PlIuRhpE� != 0 )
        {
            $_obf_joeIkY2Jko_PjoiSlJWQhoc� = $_POST['zs_czset'];
            if ( !is_array( $_obf_joeIkY2Jko_PjoiSlJWQhoc� ) )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "数据异常，非数组1！" );
            }
            foreach ( $_obf_joeIkY2Jko_PjoiSlJWQhoc� as $_obf_k46Vj4eUiI6KkZOVkoaKkYk� => $_obf_jI2OkYiTkpGLjJCRh4yGh4w� )
            {
                if ( strlen( $_obf_k46Vj4eUiI6KkZOVkoaKkYk� ) != 4 )
                {
                    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "卡前缀数据异常！" );
                }
                if ( !is_array( $_obf_jI2OkYiTkpGLjJCRh4yGh4w� ) )
                {
                    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "数据异常，非数组2！" );
                }
                uasort( &$_obf_joeIkY2Jko_PjoiSlJWQhoc�[$_obf_k46Vj4eUiI6KkZOVkoaKkYk�], "zsarr_sort1" );
                foreach ( $_obf_jI2OkYiTkpGLjJCRh4yGh4w� as $_obf_jIiJhoaRhpWMh5WSlI2JkpI� => $_obf_koiSlIqKkYmLh4_GhomKjYw� )
                {
                    if ( 4 < $_obf_jIiJhoaRhpWMh5WSlI2JkpI� )
                    {
                        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "数据异常，索引最大为4！" );
                    }
                    if ( !is_array( $_obf_koiSlIqKkYmLh4_GhomKjYw� ) )
                    {
                        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "数据异常，非数组3！" );
                    }
                    if ( !isset( $_obf_koiSlIqKkYmLh4_GhomKjYw�['num'] ) && !_obf_i46Ti46MkZCVkYaOkYmVi4w�( $_obf_koiSlIqKkYmLh4_GhomKjYw�['num'] ) && $_obf_koiSlIqKkYmLh4_GhomKjYw�['num'] < 1 || 5 < $_obf_koiSlIqKkYmLh4_GhomKjYw�['num'] )
                    {
                        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "使用张数只能是1-5！" );
                    }
                    if ( !isset( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zsday'] ) && !_obf_i46Ti46MkZCVkYaOkYmVi4w�( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zsday'] ) )
                    {
                        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "增送天数只能为数字（可用小数）！" );
                    }
                    if ( !isset( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zspoints'] ) && !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zspoints'] ) )
                    {
                        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "增送点数只能为整数！" );
                    }
                    if ( !( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zsday'] == 0 ) && !( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zspoints'] == 0 ) )
                    {
                        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "天数和点数不能都为0！" );
                    }
                }
            }
            $_obf_joeIkY2Jko_PjoiSlJWQhoc� = base64_encode( json_encode( $_obf_joeIkY2Jko_PjoiSlJWQhoc� ) );
        }
        $_obf_lZOKlYePj5CUh5GQhpOMk5M� = "";
        if ( isset( $_POST['zs_tgset'] ) && $_obf_jpKNh4aRh4aQkY2PlIuRhpE� != 0 )
        {
            $_obf_lZOKlYePj5CUh5GQhpOMk5M� = $_POST['zs_tgset'];
            if ( !is_array( $_obf_lZOKlYePj5CUh5GQhpOMk5M� ) )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "数据异常，非数组1！" );
            }
            foreach ( $_obf_lZOKlYePj5CUh5GQhpOMk5M� as $_obf_k46Vj4eUiI6KkZOVkoaKkYk� => $_obf_koiSlIqKkYmLh4_GhomKjYw� )
            {
                if ( strlen( $_obf_k46Vj4eUiI6KkZOVkoaKkYk� ) != 4 )
                {
                    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "卡前缀数据异常！" );
                }
                if ( !is_array( $_obf_koiSlIqKkYmLh4_GhomKjYw� ) )
                {
                    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "数据异常，非数组2！" );
                }
                if ( !isset( $_obf_koiSlIqKkYmLh4_GhomKjYw�['cj'] ) && !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_koiSlIqKkYmLh4_GhomKjYw�['cj'] ) )
                {
                    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "场景设置错误！" );
                }
                if ( !isset( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zsday1'] ) && !_obf_i46Ti46MkZCVkYaOkYmVi4w�( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zsday1'] ) )
                {
                    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "增送天数只能为数字（可用小数）！" );
                }
                if ( !isset( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zspoints1'] ) && !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zspoints1'] ) )
                {
                    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "增送点数只能为整数！" );
                }
                if ( !isset( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zsday2'] ) && !_obf_i46Ti46MkZCVkYaOkYmVi4w�( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zsday2'] ) )
                {
                    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "增送天数只能为数字（可用小数）！" );
                }
                if ( !isset( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zspoints2'] ) && !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zspoints2'] ) )
                {
                    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "增送点数只能为整数！" );
                }
                if ( !( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zsday1'] == 0 ) && !( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zspoints1'] == 0 ) && !( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zsday1'] == 0 ) && !( $_obf_koiSlIqKkYmLh4_GhomKjYw�['zspoints1'] == 0 ) )
                {
                    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "天数和点数不能都为0！" );
                }
            }
            $_obf_lZOKlYePj5CUh5GQhpOMk5M� = base64_encode( json_encode( $_obf_lZOKlYePj5CUh5GQhpOMk5M� ) );
        }
        $_obf_jZSGiIuOjZSIi5GKkoiMkos� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "resstring", "p", "", "" );
        $_obf_hpWQjpGGipGNh5KPkIiTjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softintro", "p", "", "" );
        $_obf_ioyVjIyOipCJkI6UkY_Sh48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softnotice", "p", "", "" );
        $_obf_i46UiJCSiY2Hko_ShpCOkZU� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "updatelog", "p", "", "" );
        $_obf_hpOTlJCMlImSlJKKlI6MjJQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "mailtext", "p", "", "" );
        $_obf_jZSGiIuOjZSIi5GKkoiMkos� = base64_encode( $_obf_jZSGiIuOjZSIi5GKkoiMkos� );
        $_obf_hpWQjpGGipGNh5KPkIiTjJE� = base64_encode( $_obf_hpWQjpGGipGNh5KPkIiTjJE� );
        $_obf_ioyVjIyOipCJkI6UkY_Sh48� = base64_encode( $_obf_ioyVjIyOipCJkI6UkY_Sh48� );
        $_obf_i46UiJCSiY2Hko_ShpCOkZU� = base64_encode( $_obf_i46UiJCSiY2Hko_ShpCOkZU� );
        $_obf_hpOTlJCMlImSlJKKlI6MjJQ� = base64_encode( $_obf_hpOTlJCMlImSlJKKlI6MjJQ� );
        if ( $_obf_h4mOjIyTkYmOhpKJk4mPi5I� == 1 )
        {
            if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 && 1000 < LICTYPE )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "任意登陆功能禁止使用！" );
            }
            $_obf_j4aTjZGOjpOHh4qUkoaJkJQ� = 0;
        }
        if ( 1 < $_obf_ipKJj5CPh4eTjIiKh4eRk4Y� && $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 && 1000 < LICTYPE )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "月租官网无卡注册赠送天数不能大于1！" );
        }
        if ( 10 < $_obf_iYmNiYeIkY_ShoeOiJCNkYw� && $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 && 1000 < LICTYPE )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "月租官网赠送天数大于10需要管理员验证！" );
        }
        $_obf_j42HkJGSkI6UhoaJlYuVk4k� = array(
            "softmode2" => $_obf_h4mOjIyTkYmOhpKJk4mPi5I�,
            "viewkey" => $_obf_ho2MkouGjomGioiSi4yGlJQ�,
            "softkey" => $_obf_koaPj4eRiYyMiZSGlJKKi4o�,
            "softname" => $_obf_jIiTj4yOk5KGk4mViI_QkZE�,
            "softstatus" => $_obf_lYmMiJWRiIeUio6Gk4iThoc�,
            "dkbindpc" => $_obf_i4yQh4_Ik42IjoeRjpOVlYc�,
            "nodebuger" => $_obf_jI_Rj5KHiYeHlJOPlZSJiIY�,
            "pccodestep" => $_obf_iI_LkYuKho6Lh4qPlYyGho8�,
            "rsaenable" => $_obf_j46NlZGIiJCKjImHkYaIlI0�,
            "rsaekey" => $_obf_i5OPlJWHi5KQkIyJh4uTh5A�,
            "rsankey" => $_obf_lIqNlZSKiJCGioqQk5KMlZE�,
            "onlyonebdinfo" => $_obf_i4yUjIuHj46IiJKVlZOGi4w�,
            "freeregs" => $_obf_iJCQko6LiI2SkouKkoqSkIk�,
            "fregmanagerid" => $_obf_h5CPlYuViomKj5GMiI6NiYo�,
            "fregtag" => $_obf_jpOIlIuRipSRlJWNkoeJipM�,
            "fregattr" => $_obf_k5WQiJOHiIiVkYiPh5CPlJM�,
            "onetimeskeyattrid" => $_obf_lZKIi46UkYmVho2JhpOHlIo�,
            "softhead" => $_obf_j46NjIiQkZCNlY_Kj5KJhpU�,
            "returninfo1" => $_obf_k4yOh46UjoqJkImUjouJjI4�,
            "returninfo2" => $_obf_iIyUi5KQkY2GjJSTkIeJj5A�,
            "softversion" => $_obf_hpOIhouMlJCRiZWRiZWUipA�,
            "softdownurl" => $_obf_jYiPk4aKhpKLjo2Pj4qMhpQ�,
            "ismustupdate" => $_obf_h4_IioiHiouTlJSGkYaJkZI�,
            "connectpenli" => $_obf_j4_HhpOTk4yHiouMk5CLj4k�,
            "points_set" => $_obf_jIyPj5CUh4aOkJWMkJKMkok�,
            "test_timearea" => $_obf_hpCGjIeHiJGKjZOGiZSIkoY�,
            "test_day" => $_obf_jZGMlZCNiY_Ii5ORkoqSjZQ�,
            "test_times" => $_obf_jpGUjoeKi5GGlIyJh5KOjYw�,
            "test_time" => $_obf_iYaSjI6GipOIkY2UjpWOjIk�,
            "chkonline" => $_obf_j4aTjZGOjpOHh4qUkoaJkJQ�,
            "outlinetime" => $_obf_ipSRjIuMk5WVjYmTlZKJh5I�,
            "outlinetimes" => $_obf_i4qIiJKGiIuTkI6MjpCKj5E�,
            "outlinelock" => $_obf_joqGjI6HkI2NjoqUhoqIjYw�,
            "outline_addtime" => $_obf_iI_Hk4_TkJSKkpSNkI2QjJE�,
            "unbindpc_set" => $_obf_kpSTkJOMi5WIjZKKioiVlZI�,
            "unbindpc_autotime" => $_obf_jZOKkoeRh5KJkJKLiYuPjIY�,
            "unbindpc_times" => $_obf_kIaRi5KVio_TlY6TkpKLjYg�,
            "unbindpc_ctset" => $_obf_kY_JjY2Pko6MkIuQkZOUjpI�,
            "unbindpc_changetime" => $_obf_ho6MjomOjYuKjYeNh5SIho0�,
            "editbdinfo_changetime" => $_obf_lY2GjpGVkJKUi5SOlJWSh5Q�,
            "czzs_keytypeid" => $_obf_hpOQiJGNk42RhoeJiY6Oi48�,
            "czzs_number" => $_obf_iIyPkJCOj4aNiIaPjouMiow�,
            "czzs_cday" => $_obf_iYmNiYeIkY_ShoeOiJCNkYw�,
            "czzs_points" => $_obf_kIeOlZOTjoyVkJKOkZOQj5U�,
            "nokeyreg" => $_obf_ipKJj5CPh4eTjIiKh4eRk4Y�,
            "nokeyreg_points" => $_obf_h4_UjZKLiZWMjIaPiI_Qkoo�,
            "tg_addtimetype" => $_obf_lYuIj4_KhpGTjYqPj5OGlJM�,
            "tg_parentuseraddtime" => $_obf_jY_UjJKOiY_Uj4iKlY2Viow�,
            "tg_newuseraddtime" => $_obf_lYeNjo6UhoiTiYuOhouOho4�,
            "tg_points1" => $_obf_h5OSkY6VkpSPkY6Th4mVlZA�,
            "tg_points2" => $_obf_joiNk4aLk4_OiI2UlZSHj5E�,
            "advapi" => $_obf_k5GSkIaRi5STi5CIlI2RjIw�,
            "resstring" => $_obf_jZSGiIuOjZSIi5GKkoiMkos�,
            "zs_czset" => $_obf_joeIkY2Jko_PjoiSlJWQhoc�,
            "zs_tgset" => $_obf_lZOKlYePj5CUh5GQhpOMk5M�,
            "softintro" => $_obf_hpWQjpGGipGNh5KPkIiTjJE�,
            "softnotice" => $_obf_ioyVjIyOipCJkI6UkY_Sh48�,
            "updatelog" => $_obf_i46UiJCSiY2Hko_ShpCOkZU�,
            "mailtext" => $_obf_hpOTlJCMlImSlJKKlI6MjJQ�,
            "autolock_time" => $_obf_hoyNjZGGjYeUhpKNjIeIjYw�,
            "autolock_times" => $_obf_k4iRjZCGj4eSkJSUj5WNj4Y�,
            "autolock_time_advapi" => $_obf_lZKUlIyRkoyJho2KjpKUjos�,
            "autolock_times_advapi" => $_obf_ko2RlI6QkZKKlJGRjYqNiJE�,
            "autolock_time_ip" => $_obf_kIuJioiGi4iHkoyNiYmIho4�,
            "autolock_ipnum" => $_obf_iZCOjImGkJKQjpOGkYmLkoY�,
            "mac_blacklist" => $_obf_iJWJk5CKj4uPiJCKh5KJjIs�
        );
        $_obf_komQjZGUj5KNiZKPho2JlYg� = "";
        if ( $_obf_jpKNh4aRh4aQkY2PlIuRhpE� == 0 )
        {
            if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您没有权限添加软件，请与管理员联系" );
            }
            if ( md5( $_POST['syspassword'] ) != MYSQLBAKPASSWORD )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "安全接口密码错误!" );
            }
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['zs_czset'] = "";
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['zs_tgset'] = "";
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['pid'] = $_obf_koeLiIiJjJOQlIaJi4aUh5A�;
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softmode'] = $_obf_h4mRiI2JlYmThoyOjIqQjok�;
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softid'] = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_ioeOiIuTiJGQi42VkY_Vios�( "kss_tb_soft" );
            $_obf_i4_NkZGMh5KJipKMk5WHlJI� = _obf_lImPlIqVi5SQjpOHkIyHi5Q�( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['pid'], $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softid'], $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softmode'] );
            if ( $_obf_i4_NkZGMh5KJipKMk5WHlJI� !== TRUE )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_i4_NkZGMh5KJipKMk5WHlJI� );
            }
            $_obf_iZSVi4iGiIyJjpSIj5OHjIs� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_soft where pid=".$_obf_koeLiIiJjJOQlIaJi4aUh5A�." order by `softcode` asc" );
            if ( empty( $_obf_iZSVi4iGiIyJjpSIj5OHjIs� ) )
            {
                $_obf_iImHhpCJi4eSkY_VjZOUj5Q� = $_obf_koeLiIiJjJOQlIaJi4aUh5A�."001";
            }
            else
            {
                $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = intval( $_obf_koeLiIiJjJOQlIaJi4aUh5A�."000" );
                foreach ( $_obf_iZSVi4iGiIyJjpSIj5OHjIs� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
                {
                    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 1;
                    $_obf_jouMkI6Ii42Mh5WGiouIiIk� = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softcode'];
                    if ( strlen( $_obf_jouMkI6Ii42Mh5WGiouIiIk� ) == 7 )
                    {
                        $_obf_jouMkI6Ii42Mh5WGiouIiIk� = intval( substr( $_obf_jouMkI6Ii42Mh5WGiouIiIk�, 0, 5 )."0".substr( $_obf_jouMkI6Ii42Mh5WGiouIiIk�, 5, 2 ) );
                    }
                    if ( $_obf_jouMkI6Ii42Mh5WGiouIiIk� != $_obf_jpKPlJSUiZOHkYaPlIeOiY4� )
                    {
                        $_obf_iImHhpCJi4eSkY_VjZOUj5Q� = $_obf_jpKPlJSUiZOHkYaPlIeOiY4�;
                    }
                    else
                    {
                        $_obf_iImHhpCJi4eSkY_VjZOUj5Q� = $_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1;
                    }
                }
            }
            if ( substr( $_obf_iImHhpCJi4eSkY_VjZOUj5Q�, 5, 1 ) == "0" )
            {
                $_obf_iImHhpCJi4eSkY_VjZOUj5Q� = substr( $_obf_iImHhpCJi4eSkY_VjZOUj5Q�, 0, 5 ).substr( $_obf_iImHhpCJi4eSkY_VjZOUj5Q�, 6, 2 );
            }
            $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softcode'] = $_obf_iImHhpCJi4eSkY_VjZOUj5Q�;
            $_obf_kouPjI2Jj46NhpSOjpCLkYY� = "<";
            $_obf_kouPjI2Jj46NhpSOjpCLkYY� .= "?";
            $_obf_kouPjI2Jj46NhpSOjpCLkYY� .= "php define('SOFTRSAMODE',".$_obf_j46NlZGIiJCKjImHkYaIlI0�."); define('SOFTRSAEKEY','".$_obf_i5OPlJWHi5KQkIyJh4uTh5A�."');  define('SOFTRSANKEY','".$_obf_lIqNlZSKiJCGioqQk5KMlZE�."'); ?";
            $_obf_kouPjI2Jj46NhpSOjpCLkYY� .= ">";
            $_obf_kouUjYyRjYaSk5SThpKIj5Q� = "<".$_obf_jI6Lho6UhomJio_IhoaQkJA�."php /* 编码 */ defined('YH2') or exit('Access denied to view this page!');\r\n".$_obf_kouUjYyRjYaSk5SThpKIj5Q�."\r\n".$_obf_jI6Lho6UhomJio_IhoaQkJA�.">";
            file_put_contents( "../kss_inc/advapi/".$_obf_koeLiIiJjJOQlIaJi4aUh5A�.$_obf_j42HkJGSkI6UhoaJlYuVk4k�['softid'].".php", $_obf_kouUjYyRjYaSk5SThpKIj5Q� );
            file_put_contents( "../kss_inc/advapi/rsa".$_obf_iImHhpCJi4eSkY_VjZOUj5Q�.".php", $_obf_kouPjI2Jj46NhpSOjpCLkYY� );
            if ( IS2SVR == 1 && SVRID == 1 )
            {
                $_obf_komQjZGUj5KNiZKPho2JlYg� = _obf_i46IiJSKkYqJk5CNlJGSiZI�( $_obf_koeLiIiJjJOQlIaJi4aUh5A�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softid'], _obf_kpOMkpCVi46VlYaSi5KPh44�( $_obf_kouUjYyRjYaSk5SThpKIj5Q� ), $_obf_iImHhpCJi4eSkY_VjZOUj5Q�, _obf_kpOMkpCVi46VlYaSi5KPh44�( $_obf_kouPjI2Jj46NhpSOjpCLkYY� ) );
            }
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( "kss_tb_soft", $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "sync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
            {
                $_obf_j4qHkYeUhpKLjYmGkpWNjYw� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_komUlJONiIqQk42JjYmOioY�( "kss_tb_soft" );
                _obf_k42GhouUh5SVj4uSlYqRlYg�( $_obf_j4qHkYeUhpKLjYmGkpWNjYw� );
                $_obf_lZSUkI_SkpGHho_JjJCNho4� = "<script>\$(window.top.document).find('#refeshsoftlist').click();</script>";
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "添加软件成功".$_obf_lZSUkI_SkpGHho_JjJCNho4�.$_obf_komQjZGUj5KNiZKPho2JlYg� );
            }
            else
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "添加软件失败".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
            }
        }
        else
        {
            $_obf_iIeJiZSMkZWQiIeQkJOPjIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and `id`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
            if ( empty( $_obf_iIeJiZSMkZWQiIeQkJOPjIY� ) )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你要编辑的软件不存在" );
            }
            $_obf_kouPjI2Jj46NhpSOjpCLkYY� = "<";
            $_obf_kouPjI2Jj46NhpSOjpCLkYY� .= "?";
            $_obf_kouPjI2Jj46NhpSOjpCLkYY� .= "php  /* 编码 */ define('SOFTRSAMODE',".$_obf_j46NlZGIiJCKjImHkYaIlI0�."); define('SOFTRSAEKEY','".$_obf_i5OPlJWHi5KQkIyJh4uTh5A�."');  define('SOFTRSANKEY','".$_obf_lIqNlZSKiJCGioqQk5KMlZE�."'); ?";
            $_obf_kouPjI2Jj46NhpSOjpCLkYY� .= ">";
            $_obf_kouUjYyRjYaSk5SThpKIj5Q� = "<".$_obf_jI6Lho6UhomJio_IhoaQkJA�."php defined('YH2') or exit('Access denied to view this page!');\r\n".$_obf_kouUjYyRjYaSk5SThpKIj5Q�."\r\n".$_obf_jI6Lho6UhomJio_IhoaQkJA�.">";
            $_obf_j42HkJGSkI6UhoaJlYuVk4k� = array_diff_assoc( $_obf_j42HkJGSkI6UhoaJlYuVk4k�, $_obf_iIeJiZSMkZWQiIeQkJOPjIY� );
            if ( empty( $_obf_j42HkJGSkI6UhoaJlYuVk4k� ) )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "软件设置未做任何修改" );
            }
            if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 && 1000 < LICTYPE && substr( $_obf_iIeJiZSMkZWQiIeQkJOPjIY�['softcode'], 0, 5 ) == "10001" )
            {
                if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softkey'] ) )
                {
                    unset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softkey'] );
                }
                if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsaenable'] ) )
                {
                    unset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsaenable'] );
                }
                if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsankey'] ) )
                {
                    unset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsankey'] );
                }
                if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsaekey'] ) )
                {
                    unset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsaekey'] );
                }
                if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softname'] ) )
                {
                    unset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softname'] );
                }
                if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softnotice'] ) )
                {
                    unset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softnotice'] );
                }
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "作者体验帐号禁止修改软件的任何设置" );
            }
            if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsaenable'] ) || isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsankey'] ) || isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsaekey'] ) || isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsaekey'] ) )
            {
                if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['advapi'], $_obf_j42HkJGSkI6UhoaJlYuVk4k�['advapi'] ) )
                {
                    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 )
                    {
                        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你无权修改软件设置的advapi区，为安全起见advapi代码需提交给管理员认证，由管理员代为编辑！" );
                    }
                    if ( md5( $_POST['syspassword'] ) != MYSQLBAKPASSWORD )
                    {
                        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "安全接口密码错误!" );
                    }
                    file_put_contents( "../kss_inc/advapi/".$_obf_koeLiIiJjJOQlIaJi4aUh5A�.$_obf_jpKNh4aRh4aQkY2PlIuRhpE�.".php", $_obf_kouUjYyRjYaSk5SThpKIj5Q� );
                }
                if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsaenable'] ) || isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsankey'] ) || isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['rsaekey'] ) )
                {
                    file_put_contents( "../kss_inc/advapi/rsa".$_obf_iIeJiZSMkZWQiIeQkJOPjIY�['softcode'].".php", $_obf_kouPjI2Jj46NhpSOjpCLkYY� );
                }
                if ( IS2SVR == 1 && SVRID == 1 )
                {
                    $_obf_komQjZGUj5KNiZKPho2JlYg� = _obf_i46IiJSKkYqJk5CNlJGSiZI�( $_obf_koeLiIiJjJOQlIaJi4aUh5A�, $_obf_jpKNh4aRh4aQkY2PlIuRhpE�, _obf_kpOMkpCVi46VlYaSi5KPh44�( $_obf_kouUjYyRjYaSk5SThpKIj5Q� ), $_obf_iIeJiZSMkZWQiIeQkJOPjIY�['softcode'], _obf_kpOMkpCVi46VlYaSi5KPh44�( $_obf_kouPjI2Jj46NhpSOjpCLkYY� ) );
                }
            }
            $_obf_iYyIk4qVjJCPiZGSiYeKiZM� = "";
            $_obf_lZSKk42VlYeShoeOkImPh4k� = FALSE;
            if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softstatus'] ) )
            {
                if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softstatus'] == 5 )
                {
                    $_obf_iYyIk4qVjJCPiZGSiYeKiZM� = "，客户可以使用软件，但不计时，下次修改软件状态为非冻结状态时，会给客户补上冻结期间的时间（不影响已单独冻结的用户）";
                    $_obf_iYyIk4qVjJCPiZGSiYeKiZM� .= "<script>\$('#pausetimelab').text('".date( "Y-m-d H:i" )."');</script>";
                    if ( $_obf_iIeJiZSMkZWQiIeQkJOPjIY�['softstatus'] != 6 )
                    {
                        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['pausetime'] = time( );
                    }
                }
                else if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softstatus'] == 6 )
                {
                    $_obf_iYyIk4qVjJCPiZGSiYeKiZM� = "，客户不可以使用软件，也不计时，下次修改软件状态为非冻结状态时，会给客户补上冻结期间的时间（不影响已单独冻结的用户）";
                    $_obf_iYyIk4qVjJCPiZGSiYeKiZM� .= "<script>\$('#pausetimelab').text('".date( "Y-m-d H:i" )."');</script>";
                    if ( $_obf_iIeJiZSMkZWQiIeQkJOPjIY�['softstatus'] != 5 )
                    {
                        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['pausetime'] = time( );
                    }
                }
                else if ( ( $_obf_iIeJiZSMkZWQiIeQkJOPjIY�['softstatus'] == 5 || $_obf_iIeJiZSMkZWQiIeQkJOPjIY�['softstatus'] == 6 ) && $_obf_iIeJiZSMkZWQiIeQkJOPjIY�['pausetime'] != 0 )
                {
                    $_obf_lZSKk42VlYeShoeOkImPh4k� = TRUE;
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['pausetime'] = 0;
                }
                if ( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['softstatus'] == 0 && $_obf_iIeJiZSMkZWQiIeQkJOPjIY�['softstatus'] == 9 )
                {
                    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_iIeJiZSMkZWQiIeQkJOPjIY�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set hstats=0", "sync" );
                }
            }
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_tb_soft", $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "id=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�, "sync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
            {
                _obf_k42GhouUh5SVj4uSlYqRlYg�( $_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
                if ( $_obf_lZSKk42VlYeShoeOkImPh4k� )
                {
                    $_obf_lJWUjouNjoaVk4yRj4uQj5I� = time( ) - $_obf_iIeJiZSMkZWQiIeQkJOPjIY�['pausetime'];
                    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update kss_z_user_".$_obf_iIeJiZSMkZWQiIeQkJOPjIY�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set starttime=starttime+".$_obf_lJWUjouNjoaVk4yRj4uQj5I�.",endtime=endtime+".$_obf_lJWUjouNjoaVk4yRj4uQj5I�." where `ispause`=0 and endtime<>".PETIME;
                    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
                    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
                    {
                        $_obf_iYyIk4qVjJCPiZGSiYeKiZM� = "，并已解冻，用户时间已补".round( $_obf_lJWUjouNjoaVk4yRj4uQj5I� / 60, 2 )."分钟（不影响已单独冻结的用户）！";
                        $_obf_iYyIk4qVjJCPiZGSiYeKiZM� .= "<script>\$('#pausetimelab').text('未冻结');</script>";
                    }
                    else
                    {
                        $_obf_iYyIk4qVjJCPiZGSiYeKiZM� = "，并已解冻，<font color=red>但给用户补时间时出错,请记录SQL：[".$_obf_i4qPjo_Oj5GJiIyIi4qKh5U�."]</font>";
                        $_obf_iYyIk4qVjJCPiZGSiYeKiZM� .= "<script>\$('#pausetimelab').text('未冻结');</script>";
                    }
                }
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "软件设置保存成功".$_obf_iYyIk4qVjJCPiZGSiYeKiZM�.$_obf_komQjZGUj5KNiZKPho2JlYg� );
            }
            else
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "编辑软件失败".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
            }
        }
    }
    else
    {
        $_obf_jpKNh4aRh4aQkY2PlIuRhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softid", "g", "int", 0 );
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from `kss_tb_soft` where id=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
        if ( empty( $_obf_kY_OlYeUlIiVjo6Hio_MkpI� ) )
        {
            _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
            if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'] != 1 )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您没有权限添加软件！" );
            }
            $_obf_koeLiIiJjJOQlIaJi4aUh5A� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "pid", "g", "int", 10000 );
            $_obf_iY2HkZGJi5WKj4qLkouThoc� = "添加软件";
            $_obf_kY_OlYeUlIiVjo6Hio_MkpI� = array(
                "id" => 0,
                "pid" => $_obf_koeLiIiJjJOQlIaJi4aUh5A�,
                "softmode" => "USOFT",
                "softmode2" => 0,
                "viewkey" => 1,
                "softkey" => _obf_iI6QhpSTiJCJiI_KlYePlZI�( 24 ),
                "softname" => "未命名软件"._obf_iI6QhpSTiJCJiI_KlYePlZI�( 5 ),
                "softstatus" => 0,
                "dkbindpc" => 0,
                "nodebuger" => 0,
                "pccodestep" => 1,
                "rsaenable" => 0,
                "rsaekey" => "",
                "rsankey" => "",
                "onlyonebdinfo" => 0,
                "freeregs" => 0,
                "fregmanagerid" => 0,
                "fregtag" => "",
                "fregattr" => "",
                "onetimeskeyattrid" => "",
                "softhead" => "_Data",
                "returninfo1" => "",
                "returninfo2" => "",
                "softversion" => 1,
                "softdownurl" => "aHR0cDovLw==",
                "ismustupdate" => 0,
                "connectpenli" => 15,
                "points_set" => 0,
                "test_timearea" => "0,23",
                "test_day" => 1,
                "test_times" => 1,
                "test_time" => 15,
                "chkonline" => 0,
                "outlinetime" => 120,
                "outlinetimes" => 1,
                "outlinelock" => 2,
                "outline_addtime" => 0,
                "unbindpc_set" => 1,
                "unbindpc_autotime" => 15,
                "unbindpc_times" => 1,
                "unbindpc_ctset" => 0,
                "unbindpc_changetime" => "0.00",
                "editbdinfo_changetime" => "0.00",
                "czzs_keytypeid" => 0,
                "czzs_number" => 3,
                "czzs_cday" => "1.00",
                "czzs_points" => 0,
                "nokeyreg" => "0.00",
                "nokeyreg_points" => 0,
                "tg_addtimetype" => 0,
                "tg_parentuseraddtime" => 0,
                "tg_newuseraddtime" => 0,
                "tg_points1" => 0,
                "tg_points2" => 0,
                "advapi" => "Ly8kZGF0Yea6kOaVsOaNru+8jOWvuei+k+WHuuWIsOWuouaIt+err+eahOaVsOaNrui/m+ihjOiHquWumuS5ieWKoOWvhizku6XkuIvmmK/kvovlrZDph4znm7jlr7nlupTnmoTliqDlr4bmlrnms5UKZnVuY3Rpb24gX19teUVuY3J5cHQoJGRhdGEpewoJaWYoaXNzZXQoJF9HRVRbJ3InXSkpewkJLy/kuLrkuI3mlK/mjIFSU0HnmoTlrqLmiLfnq6/or63oqIDlhpnnmoTkvovlrZAgc2V05ZG95Luk5pyJ6K6+572ucnNh5Y2V5YWD55qE6K+d5bCx5Lya5pyJJF9HRVRbJ3InXeWPmOmHjwoJCSRyYzTlr4bpkqUyID0gX3JzKDIpOwoJCSRyYzTlr4bpkqUzID0gX3JzKDMpOwkJCgkJJHJjNOWKoOWvhiA9IHJjNGJ5dGUoJHJjNOWvhumSpTIsJGRhdGEpOwkKCQkkcmM05Yqg5a+GID0gcmM0Ynl0ZSgkcmM05a+G6ZKlMywkcmM05Yqg5a+GKTsKCQkkYmFzZTY057yW56CB5pWw5o2uID0gYmFzZTY0X2VuY29kZSgkcmM05Yqg5a+GKTsgICAvL+W/hemhu2Jhc2U2NF9lbmNvZGUKCQlyZXR1cm4gJGJhc2U2NOe8lueggeaVsOaNrjsKCX1lbHNlewoJCSRyYzTlr4bpkqUgPSBfcnMoMik7ICAgICAvL21ha2Vfa2V5KCk7CS8v55Sf5oiQ6ZqP5py65a2X56ym5LiyCgkJJHJzYeWKoOWvhueahHJjNOWvhumSpSA9IGVuY29kZV9yc2EyKF9ycygxKSwkcmM05a+G6ZKlKTsKCQkk5Yqg5a+G5ZCO55qE5pWw5o2uID0gYmFzZTY0X2VuY29kZShyYzRieXRlKCRyYzTlr4bpkqUsJGRhdGEpKTsgICAvL+WKoOWvhuWQjuacgOWlvWJhc2U2NF9lbmNvZGXkuIDkuIsJCgkJJOi/lOWbnuaVsOaNriA9ICRyc2HliqDlr4bnmoRyYzTlr4bpkqUgLiAnLCcgLiAk5Yqg5a+G5ZCO55qE5pWw5o2uOwoJCXJldHVybiAk6L+U5Zue5pWw5o2uOwkJCgl9Cn0KCi8v5aaC5p6c6L2v5Lu25Z+65pys6K6+572u6YeM55qE6L+U5Zue5L+h5oGv5Li6QeS4uuepuu+8jOW5tuS4lOacrOWHveaVsOWtmOWcqO+8jOWuouaIt+err+WPluW+l+eahOi/lOWbnuS/oeaBr0HlsIbmmK/mraTlh73mlbDov5Tlm57nmoTlgLwKZnVuY3Rpb24gYWJfYSgpewoJcmV0dXJuICfov5Tlm57kv6Hmga/kuLpBJzsKfQoKLy/lpoLmnpzova/ku7bln7rmnKzorr7nva7ph4znmoTov5Tlm57kv6Hmga/kuLpC5Li656m677yM5bm25LiU5pys5Ye95pWw5a2Y5Zyo77yM5a6i5oi356uv5Y+W5b6X55qE6L+U5Zue5L+h5oGvQuWwhuaYr+atpOWHveaVsOi/lOWbnueahOWAvApmdW5jdGlvbiBhYl9iKCl7CglyZXR1cm4gJ+i/lOWbnuS/oeaBr+S4ukInOwp9CgovL+aJo+eCueaOpeWPo2FkdmFwaSgidl9wb2ludHMs6KaB5omj55qE54K55pWwIikKZnVuY3Rpb24gdl9wb2ludHMoJHBvaW50cywkc3lzZ3VpZCl7CSAvL+esrOS4gOS4quWPguaVsOaYr+imgeaJo+eahOeCueaVsO+8jOesrOS6jOS4quWPguaVsOaYr+ezu+e7n+iHquWKqOmZhOWKoOeahOWPguaVsCAgCQoJJGVycmluZm8gPSAnJzsKCSRydCA9IGFwaV9wb2ludHMoJGVycmluZm8sJHBvaW50cywkc3lzZ3VpZCk7CglpZigkcnQgIT09IGZhbHNlKXsKCQkvL+aJo+eCueaIkOWKnwoJCXJldHVybiAkcnQ7Cgl9ZWxzZXsKCQkvL+aJo+eCueWksei0pe+8jOi/lOWbnuWksei0peS/oeaBrwoJCXJldHVybiAkZXJyaW5mbzsKCX0KfQovL+S7peS4iumDveaYr+ezu+e7n+eahOWFs+mUruaOpeWPo++8jOS4jeWPr+S7peWIoOmZpAoKLy/kuIvovrnkvaDlj6/ku6Xoh6rnlLHmt7vliqDoh6rlt7HnmoTmjqXlj6PlrprkuYkKLy/kvovlrZAx77ya6L+Z5Liq5piv5pyA566A5Y2V55qEYWR2YXBp5o6l5Y+j77yM5Y+q5pyJ5o6l5Y+j5ZCN5peg5Y+C5pWwIOOAkGFkdmFwaSgidl9nZXRhIinjgJEKZnVuY3Rpb24gdl9nZXRhKCl7CglyZXR1cm4gJ3ZfZ2V0YeeahOi/lOWbnuaVsOaNric7Cn0KCi8v5L6L5a2QMu+8mui/meS4quaYr+W4puWPguaVsOeahOaOpeWPo++8jCDmjqXlj6PlkI3lkI7mnIky5Liq5Y+C5pWwIOOAkGFkdmFwaSgidl9nZXRiLDEwMCwyMDAiKSDnrKzkuIDkuKrmmK/lh73mlbDlkI3vvIzlkI7ovrnnmoTkuKTkuKrmiY3mmK/lj4LmlbDjgJEKZnVuY3Rpb24gdl9nZXRiKCR2YWwxLCR2YWwyKXsKCXJldHVybiAkdmFsMSArICR2YWwyOyAgIC8v5a+55Lyg6YCS6L+H5p2l55qE5Y+C5pWw6L+b6KGM566A5Y2V55qE5Yqg5rOV6L+Q566XCn0=",
                "resstring" => "PT09PU5FVyBSRVNTVFI9PT09W+S+i+WtkOeUqOeahFJTQeWFrOmSpeWvueW6lOeahOengemSpV0KLS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQpNSUlCUEFJQkFBSkJBTUpGK296azdqblBxOW5mVjdqOG02bGxsMWdza2szVUpkOTg2UEIxcUVxQ3JpOC9QaHlrCnFiSlhLTXRURE1zTk94Z083SEpUZ3pHZjV0U3JSOHZ4V0s4Q0F3RUFBUUpCQUk2TWVvUFhsMVdrSkIwQjNJUkkKRm8vOWswZUhyUEtlc0F1RXhBZHN6Y2VkUkpDSWRnQWNDZUdqN1BadXpQaEdBVVZncGVHemVPUFpEUHJaQWJMTApKb0VDSVFEaXJ1YmJqVVV3dXZPODZJYWVGRkkwb1hGYXFLdkhOT05UTThDMDkxOXNGd0loQU50bUNwVmRmYWhBCmhrOFZYNitKM25OakRwLzFDN2Z4NktiRnp3bUJKOThwQWlFQXJPejJLZWpFTHA5L3pzMm4zREh1WUQ0RVpqK2sKQTJ5aU9sZVJtN3ZXYkhNQ0lRQ2ZqaFVTVFJ4dU9RYTBDcm84b2NvNkpnYmp3MFRUY0VVZXkrcG1ZaHhLQ1FJZwpjMTlLTVRyZktodHRvaGtkMlhLU2NxMGRGUTRPeTNOMVZiMFJyUUJrN0ZzPQotLS0tLUVORCBSU0EgUFJJVkFURSBLRVktLS0tLQoKPT09PU5FVyBSRVNTVFI9PT09W+aooeadv+eahFJDNOWvhumSpTFdCkNJUURpcnViYmpVVXd1dk84NklhZUZGSTBvWEZhCgo9PT09TkVXIFJFU1NUUj09PT1b5qih5p2/55qEUkM05a+G6ZKlMl0KRkM3Zng2S2J6d21CSjk4cEFpRUFyT3oyS2VqCgo9PT09TkVXIFJFU1NUUj09PT1b5p+Q5p+Q5YaF5a2Y5Zyw5Z2AXQowMEZBNDVFRgoKPT09PU5FVyBSRVNTVFI9PT09CuayoeacieazqOmHiuS5n+WPr+S7peeahA==",
                "zs_czset" => "",
                "zs_tgset" => "",
                "softintro" => "",
                "softnotice" => "",
                "updatelog" => "",
                "mailtext" => "",
                "autolock_time" => 0,
                "autolock_times" => 0,
                "autolock_time_advapi" => 0,
                "autolock_times_advapi" => 0,
                "autolock_time_ip" => 0,
                "autolock_ipnum" => 0,
                "mac_blacklist" => ""
            );
        }
        else
        {
            $_obf_iY2HkZGJi5WKj4qLkouThoc� = "保存设置";
        }
        $_obf_hpCGjIeHiJGKjZOGiZSIkoY� = str_replace( " ", "", $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['test_timearea'] );
        $_obf_kY_TjpCUkIePjoaHkIiJkZU� = explode( ",", $_obf_hpCGjIeHiJGKjZOGiZSIkoY� );
        $_obf_joeIkY2Jko_PjoiSlJWQhoc� = "";
        if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['zs_czset'] != "" )
        {
            $_obf_joeIkY2Jko_PjoiSlJWQhoc� = json_decode( base64_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['zs_czset'] ), TRUE );
        }
        $_obf_lZOKlYePj5CUh5GQhpOMk5M� = "";
        if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['zs_tgset'] != "" )
        {
            $_obf_lZOKlYePj5CUh5GQhpOMk5M� = json_decode( base64_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['zs_tgset'] ), TRUE );
        }
    }
    $_obf_hpGKj4uOhpWJj5OPlZWTiIw� = array( "advapi", "resstring", "softintro", "softdownurl", "updatelog", "softnotice", "mailtext" );
    foreach ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI� as $_obf_jpWPlIySk4qGlY_Ph5SOi44� => $_obf_iYaNiYyJh4_SjoqTi5OGiI0� )
    {
        if ( !in_array( $_obf_jpWPlIySk4qGlY_Ph5SOi44�, $_obf_hpGKj4uOhpWJj5OPlZWTiIw� ) )
        {
            $_obf_kY_OlYeUlIiVjo6Hio_MkpI�[$_obf_jpWPlIySk4qGlY_Ph5SOi44�] = _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_iYaNiYyJh4_SjoqTi5OGiI0� );
        }
    }
    echo "<script type=\"text/javascript\">\r\nvar softmode=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softmode'];
    echo "\";\r\nvar softmode2=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softmode2'];
    echo "\";\r\nvar unbindpc_set=";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unbindpc_set'];
    echo ";\r\nvar line_set=";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['chkonline'];
    echo ";\r\n</script>\r\n";
    echo "<script type='text/javascript' src='".INSTALLPATH."kss_inc/js/bin_addsoft.js?version=2017021501'></script>\r\n";
    if ( is_file( "../kss_editor/ckeditor.js" ) )
    {
        echo "<script type='text/javascript' src='".INSTALLPATH."kss_editor/ckeditor.js'></script>\r\n";
    }
    echo "<form id=\"admin_addsoft\" action=\"?action=addsoft_save\" method=\"post\"> \r\n<input type=\"hidden\" alt=\"ajax提交必须添加此项\" name=\"isajax\" value=\"1\" />\r\n<input type=\"hidden\" name=\"softid\" id=\"softid\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
    echo "\" />\r\n<input type=\"hidden\" name=\"points_set\" value=\"0\" />\r\n<div id=\"tabs01\">\r\n<div>\r\n<div tbtid=\"11\">基本</div>\r\n<div tbtid=\"12\">试用设置</div>\r\n<div tbtid=\"13\">解绑换机设置</div>\r\n<div tbtid=\"18\">赠送策略</div>\r\n<div tbtid=\"19\">安全策略</div>\r\n<div tbtid=\"14\">高级API</div>\r\n<div tbtid=\"15\">软件简介</div>\r\n<div tbtid=\"16\">自动更新</div>\r\n<div tbtid=\"17\">软件公告</div>\r\n<div tbtid=\"20\">附加邮件正文</div>\r\n</div>\r\n<div>\r\n<div tbdid=\"11\">\r\n<table border=0  cellpadding=\"0\" cellspacing=\"0\" width='100%'>\r\n<tr><td valitn=top>\r\n<table border=0  cellpadding=\"5\" cellspacing=\"5\" >\r\n<tr malt=\"软件名称\">\r\n<td align=right>软件名称</td>\r\n<td align=left><input class=\"longinput\" type=\"text\" maxlength=\"20\" id=softname name=\"softname\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softname'];
    echo "\" /></td>\r\n</tr>\r\n";
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] != 0 )
    {
        echo "<tr><td align=right malt=该编号需要填入客户端接口>软件编号</td><td><input type=text name=pid class=smlinput readOnly value=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softcode']."><input type=hidden name=pid value=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."></td></tr>";
    }
    echo "<tr malt=\"加密数据头标识需与客户端设置的一样\">\r\n<td align=right>加密数据头标识</td>\r\n<td align=left><input class=\"longinput\" type=\"text\" maxlength=\"10\" id=softhead name=\"softhead\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softhead'];
    echo "\" /></td>\r\n</tr>\r\n<tr malt=\"用于和客户端通讯交互加解密数据用\" style=\"background-color:#fc9\">\r\n<td align=right style=\"TEXT-DECORATION: line-through\">软件密钥</td>\r\n<td align=left><input class=\"longinput\" ";
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 )
    {
        echo "readOnly";
    }
    echo "  type=\"text\" maxlength=\"24\" id=softkey name=\"softkey\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softkey'];
    echo "\" /><span style=\"color:#f00\">软件密钥为老版本兼容保留，新版本不再使用</span></td>\r\n</tr>\r\n<tr malt=\"返回信息A，在客户端登陆成功后可以通过API ks_GetData(1)获取\">\r\n<td align=right>返回信息A</td>\r\n<td align=left><input class=\"longinput\" type=\"text\" maxlength=\"250\" name=\"returninfo1\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['returninfo1'];
    echo "\" /></td>\r\n</tr>\r\n<tr malt=\"返回信息B，在客户端登陆成功后可以通过API ks_GetData(2)获取\">\r\n<td align=right>返回信息B</td>\r\n<td align=left><input class=\"longinput\" type=\"text\" maxlength=\"250\" name=\"returninfo2\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['returninfo2'];
    echo "\" /></td>\r\n</tr>\r\n</table></td><td valign=top>\r\n<table border=0  cellpadding=\"5\" cellspacing=\"5\" >\r\n<tr malt=\"软件模式一经确定不可修改\">\r\n<td align=right>软件模式</td>\r\n<td align=left malt=\"1、用户名+密码登陆：客户端以用户名+密码的形式登陆，可以使用注册卡号对用户充值；<br>2、注册卡号登陆：客户端用一张注册卡号即可登陆，不可以对注册卡号充值<br>注册卡激活后在注册卡列表表里显示为已充值，并自动在用户表新增一个用户，用户名为注册卡前10位，密码和安全密码为后22位。<br>在注册卡列表中删除已充值的注册卡不影响注册卡的登陆，因为登陆是判断用户表\">";
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] != 0 )
    {
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softmode'] == "USOFT" ? "用户名+密码登陆" : "注册卡号登陆";
    }
    else
    {
        echo "<input type=radio value='USOFT' name=\"softmode\" id=\"softmode_1\"";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softmode'] == "USOFT" ? " checked" : "";
        echo "><label for=\"softmode_1\" >用户名+密码登陆</label>&nbsp;&nbsp;&nbsp;&nbsp;\r\n<input type=radio value='KSOFT' name=\"softmode\" id=\"softmode_2\"";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softmode'] == "KSOFT" ? " checked" : "";
        echo "><label for=\"softmode_2\" >注册卡号登陆</label>\r\n";
    }
    echo "</td>\r\n</tr>\r\n<tr malt=\"在同一电脑上同一帐号可以登陆多次\">\r\n<td align=right>单机可重复登陆</td>\r\n<td align=left><input type='checkbox' ";
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['dkbindpc'] == 1 )
    {
        echo "checked";
    }
    echo " name='dkbindpc' value='1' id='dkbindpc'></td>\r\n</tr>\r\n<tr malt=\"绑定信息唯一指的是：绑定信息被一个帐号使用了，就不能再被另一帐号在客户端注册或修改时使用。<br>如果勾选就表示启用了本功能。<br>本参数对后台修改绑定信息不影响\">\r\n<td align=right>绑定信息唯一</td>\r\n<td align=left><input type='checkbox' ";
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['onlyonebdinfo'] == 1 )
    {
        echo "checked";
    }
    echo " name='onlyonebdinfo' value='1' id='onlyonebdinfo'> </td>\r\n</tr>\r\n<tr>\r\n<td align=right malt='如果你担心用户通过查询注册卡功能来猜卡，可以关闭查询注册卡功能'>查询注册卡功能</td>\r\n<td align=left>\r\n<input type=radio value='0' name=\"viewkey\" id=\"viewkey_1\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['viewkey'] == "0" ? " checked" : "";
    echo "><label for=\"viewkey_1\">禁止</label>&nbsp;&nbsp;&nbsp;&nbsp;\r\n<input type=radio value='1' name=\"viewkey\" id=\"viewkey_2\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['viewkey'] == "1" ? " checked" : "";
    echo "><label for=\"viewkey_2\">允许</label>\r\n</td>\r\n</tr>\r\n<tr malt=\"可控制该软件是否允许使用、允许注册新帐号、允许给帐号充值等等\">\r\n<td align=right>软件状态</td>\r\n<td align=left id=\"softstatus\"></td>\r\n</tr>\r\n<tr malt=\"\">\r\n<td align=right>冻结日期</td>\r\n<td align=left id=pausetimelab>";
    if ( isset( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pausetime'] ) && $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pausetime'] != 0 )
    {
        echo date( "Y-m-d H:i", $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pausetime'] );
    }
    else
    {
        echo "未冻结";
    }
    echo "</td>\r\n</tr>\r\n<tr malt=\"指的是你客户端经常调用验证接口ks_CheckKeyE时每隔多长时间才会连接服务器验证，最小值只能填15\">\r\n<td align=right>验证频率</td>\r\n<td align=left><input class=\"smlinput\" type=\"text\" maxlength=\"3\" name=\"connectpenli\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['connectpenli'];
    echo "\" />分钟</td>\r\n</tr>\r\n";
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] == 0 )
    {
        if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 9 && 1 < LICTYPE )
        {
            echo "<tr malt=\"默认给自己添加软件，如果你想给其它作者添加软件，请输入其它作者的PID号\">\r\n<td align=right>作者PID</td>\r\n<td align=left><input class=\"smlinput\" type=\"text\"  maxlength=\"5\" name=\"pid\" value=\"";
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid'];
            echo "\" /></td>\r\n</tr>\r\n";
        }
        else
        {
            echo "<tr style='display:none'><td>PID</td><td><input type=text name=pid value=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."></td></tr>";
        }
    }
    echo "</table>\t\t\t\r\n</td></tr>\r\n</table>\t\t\t\r\n</div>\r\n<div tbdid=\"12\">\r\n<table border=0  cellpadding=\"10\" cellspacing=\"5\" >\r\n<tr>\r\n<td colspan=2><p style=\"padding:5px;background:#FFFF99;border:1px solid #999;color:#f00;\">试用设置是针对公用帐号的<br>设置公用帐号的方法：到 用户管理-> 用户列表，找一个你想设置为公用帐号的帐号或注册卡号，点击前面的<img src=\"../kss_inc/images/b_edit.png\">图标<br>在弹出的窗口中单击设为公用，该帐号或注册卡号就变成了公用帐号。</p></td>\r\n</tr>\r\n<tr malt=\"可使用时段的设置只对试用帐号、试用注册卡、用户模式的未充值帐号起作用\">\r\n<td align=right>每天可使用的时段</td>\r\n<td align=left>　<input maxlength=\"2\" type=\"text\" name=\"test_timearea[]\" class=\"sml2input\" value=\"";
    echo $_obf_kY_TjpCUkIePjoaHkIiJkZU�[0];
    echo "\" >点 至<input maxlength=\"2\" type=\"text\" name=\"test_timearea[]\" class=\"sml2input\" value=\"";
    echo $_obf_kY_TjpCUkIePjoaHkIiJkZU�[1];
    echo "\" >点</td>\r\n</tr>\r\n<tr malt=\"试用注册卡、试用帐号每台电脑可使用的次数。如果次数设为0表示不限制，那么每次可试用时间也不限制\">\r\n<td align=right>可试用次数</td>\r\n<td align=left>每<input maxlength=\"3\" type=\"text\" name=\"test_day\" class=\"sml2input\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['test_day'];
    echo "\" >天可试用<input maxlength=\"4\" type=\"text\" name=\"test_times\" class=\"sml2input\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['test_times'];
    echo "\" >次 <span style=\"padding-left:30px;color:#f00\">如果1次可使用10小时，那么10小时内无论用户登陆多少次软件都只算一次。</span></td>\r\n</tr>\r\n<tr malt=\"试用注册卡、试用帐号每次试用可使用的时间\">\r\n<td align=right>每次可试用时间</td>\r\n<td align=left>　<input maxlength=\"4\" type=\"text\" name=\"test_time\" class=\"smlinput\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['test_time'];
    echo "\" >分钟</td>\r\n</tr>\r\n</table></div>\r\n<div tbdid=\"13\">\r\n<table border=0  cellpadding=\"10\" cellspacing=\"5\" >\r\n<tr malt=\"绑定的文本信息不是机器码，可以用绑定的文本信息来实现绑定游戏帐号或其它功能\">\r\n<td align=right>修改绑定文本信息</td>\r\n<td align=left>扣除<input type=\"text\" maxlength=\"5\" name=\"editbdinfo_changetime\" class=\"smlinput\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['editbdinfo_changetime'];
    echo "\" >天 * <span style=\"color:#f00;font-weight:700\">0.00为不允许用户修改绑定的文本信息</span></td>\r\n</tr>\r\n<tr malt=\"勾选时，帐号可以同时在任意电脑上登陆<br>最好与扣点配合使用，即客户每次登陆软件或执行软件某功能时扣除一定的点数<br>或者与绑定信息配合使用，即把注册系统帐号绑定一些游戏帐号，只有绑定的游戏帐号才可以登陆\">\r\n<td align=right>任意登陆</td>\r\n<td align=left><input type='checkbox' ";
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softmode2'] == 1 )
    {
        echo "checked";
    }
    echo " name='softmode2' value='1' id='softmode2'> *除非你是了解该功能的意义，否则请不要勾选。\r\n</td>\r\n</tr>\r\n<tr class=\"chionlineset_\" malt=\"用户在线的情况下禁止再登陆\">\r\n<td align=right valign=top>判断在线标识</td>\r\n<td align=left><input type='checkbox' ";
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['chkonline'] == 1 )
    {
        echo "checked";
    }
    echo " name='chkonline' value='1' id=\"chkonline\">&nbsp;&nbsp;&nbsp;&nbsp;<span stylc=\"color:#f00\">勾选时，客户端在退出时必须调用ks_exit()来退出登陆状态</span></td>\r\n</tr>\r\n<tr style=\"display:none\" class=\"chkonlineset\" >\r\n<td align=right valign=top>强制登陆</td>\r\n<td align=left>用户上次连接服务器在<input type='text' maxlength=\"3\"  name='outlinetime' value='";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['outlinetime'];
    echo "' class=\"smlinput\">分钟前并且卡在线上，可在其它电脑上强制登陆<input malt=\"每天可强制登陆的次数\" type='text' maxlength=\"3\"  name='outlinetimes' value='";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['outlinetimes'];
    echo "' class=\"sml2input\">次。<span style=\"display:none\">每次强登扣时<input type='text' maxlength=\"5\"  name='outline_addtime' value='";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['outline_addtime'];
    echo "' class=\"smlinput\">天</span></td>\r\n</tr>\r\n<tr style=\"display:none\" class=\"chkonlineset\">\r\n<td align=right valign=top>锁定帐号</td>\r\n<td align=left>当日非法自动下线<input type='text' maxlength=\"4\"  name='outlinelock' value='";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['outlinelock'];
    echo "' class=\"sml2input\">次，锁定帐号。【非法自动下线：原程序还未关闭，到了可自动下线时间又到新电脑上登陆。】</td>\r\n</tr>\r\n<tr malt=\"自定义机器码格式= 硬件1信息,硬件2信息,...,硬件n信息 硬件信息以逗号分隔<br>自定义机器码中有<font color=blue>机器码判断阈值</font>个硬件信息相符就认为机器码未变动<br>例如数据库中用户的机器码是abc,def,ghi，用户验证或解绑时发送来的自定义机器码是abc,ccc,bbb<br>机器码判断阈值设为1时会认为机器码没变，因为它们中有1个硬件信息abc是相同的<br>如果机器码判断阈值是2那么就会被判断为机器码变动，因为它们中没有2个硬件信息是相同的\">\r\n<td align=right>机器码判断阈值</td>\r\n<td align=left><input class=\"smlinput\"  type=\"text\" maxlength=\"1\" name=\"pccodestep\" id=\"pccodestep\" value='";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pccodestep'];
    echo "' /> <span style=\"color:#ff0000\">* 如果没有自定义机器码该值请填写1</span>\r\n</td></tr>\t\t\t\t\r\n<tr class=\"unbindpc_\" malt=\"机器码指用户电脑的特征码，解绑机器码就可以让用户在新的电脑上登陆\">\r\n<td align=right valign=top>解绑机器码策略</td>\r\n<td align=left><select name=\"unbindpc_set\" id=\"unbindpc_set\">\r\n<option value=0 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unbindpc_set'] == 0 ? "selected" : "";
    echo ">不允许解绑机器码</option>\r\n<option value=1 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unbindpc_set'] == 1 ? "selected" : "";
    echo ">只能在原电脑上解绑机器码</option>\r\n<option value=3 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unbindpc_set'] == 3 ? "selected" : "";
    echo ">可在任意电脑上解绑机器码</option>\r\n<option value=2 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unbindpc_set'] == 2 ? "selected" : "";
    echo ">自动解绑</option>\r\n</select><span id='canautounbind'>&nbsp;&nbsp;用户最后一次验证在<input type=text value=";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unbindpc_autotime'];
    echo " name=\"unbindpc_autotime\" class=sml3input />分钟之前才可解绑</span><br>\r\n<span id=\"unbindtext\"></span></td>\r\n</tr>\r\n<tr malt=\"每天修改解绑机器码绑定，也就是换电脑的次数\" class=\"unbindpc_set\">\r\n<td align=right>可解绑机器码</td>\r\n<td align=left><input type=\"text\" name=\"unbindpc_times\" class=\"smlinput\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unbindpc_times'];
    echo "\" >次</td>\r\n</tr>\r\n<tr malt=\"解绑扣时策略\" class=\"unbindpc_set\">\r\n<td align=right>解绑扣时策略</td>\r\n<td align=left>\r\n<input type=radio value='0' name=\"unbindpc_ctset\" id=\"unbindpc_ctset_0\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unbindpc_ctset'] == "0" ? " checked" : "";
    echo "><label for=\"unbindpc_ctset_0\">不扣时</label>&nbsp;&nbsp;&nbsp;&nbsp;\r\n<input type=radio value='1' name=\"unbindpc_ctset\" id=\"unbindpc_ctset_1\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unbindpc_ctset'] == "1" ? " checked" : "";
    echo "><label for=\"unbindpc_ctset_1\">只要解绑就扣时</label>&nbsp;&nbsp;&nbsp;&nbsp;\r\n<input type=radio value='2' name=\"unbindpc_ctset\" id=\"unbindpc_ctset_2\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unbindpc_ctset'] == "2" ? " checked" : "";
    echo "><label for=\"unbindpc_ctset_2\">超出解绑次数限制才扣时</label></td>\r\n</tr>\r\n<tr malt=\"每次修改解绑机器码绑定，也就是每次换电脑扣除的天数\" class=\"unbindpc_set\">\r\n<td align=right>解绑扣时</td>\r\n<td align=left><input maxlength=\"5\" type=\"text\" name=\"unbindpc_changetime\" class=\"smlinput\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unbindpc_changetime'];
    echo "\" >天</td>\r\n</tr>\r\n</table>\t\t\r\n</div>\r\n<div tbdid=\"18\">\r\n<table border=0  cellpadding=\"10\" cellspacing=\"5\" >\r\n<tr malt=\"这里可以设置某一种卡，一个帐号只能使用一次，比如你免费发布了一批天卡，只想一个用户最多使用一次的话就可以这样\">\r\n<td align=right>安全策略</td>\r\n<td align=left>帐号如果是无卡注册的，或使用过<select name=\"onetimeskeyattrid\">\r\n<option value=''>------不判断-------</option>\r\n";
    echo _obf_lIeLiY6Gk4aNiY2Si4uJiIs�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'], $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['onetimeskeyattrid'], 2 );
    echo "</select>， 就不能再使用该类卡充值。";
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] == 0 )
    {
        echo "<span style='color:#f00'>注：该参数只能在添加软件并设置好软件卡类才可以设定</span>";
    }
    echo "</td>\r\n</tr>\r\n<tr malt=\"客户注册帐号时是否必须使用注册卡，如果你想让客户不使用注册卡就可以注册帐号，请在该项填写一个有效的时间，1小时约等于0.04天\">\r\n<td align=right>无卡注册帐号</td>\r\n<td align=left>赠送<input type=\"text\" maxlength=\"5\" name=\"nokeyreg\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['nokeyreg'];
    echo "\" class=\"smlinput\">天，<input type=\"text\" maxlength=\"5\" name=\"nokeyreg_points\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['nokeyreg_points'];
    echo "\" class=\"smlinput\">点   * <span style=\"color:#f00;\">0.00天为必须使用注册卡才可以注册帐号</span></td>\r\n</tr>\r\n<tr>\r\n<td align=right>无卡注册帐号设置</td>\r\n<td align=left ><span malt=\"未勾选表示同一电脑只能无卡注册该软件的帐号一次<br>勾选表示同一电脑不限制无卡注册该软件帐号的次数\">可多次注册帐号</span>=<input type='checkbox' ";
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['freeregs'] == 1 )
    {
        echo "checked";
    }
    echo " name='freeregs' value='1' id='freeregs'>，  \r\n&nbsp;&nbsp;帐号标签=<input type=\"text\" maxlength=\"100\" name=\"fregtag\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['fregtag'];
    echo "\" class=\"smlinput\">，\r\n&nbsp;&nbsp;帐号附属性=<input type=\"text\" maxlength=\"100\" name=\"fregattr\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['fregattr'];
    echo "\" class=\"smlinput\">，\r\n&nbsp;&nbsp;帐号所属后台用户=<select name=\"fregmanagerid\">\r\n<option value=0>作者自己</option>\r\n";
    $_obf_kImLj4ePhoqGjoaQjJOHkZA� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_manager where pid=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and level=6 and isdel=0" );
    if ( !empty( $_obf_kImLj4ePhoqGjoaQjJOHkZA� ) )
    {
        foreach ( $_obf_kImLj4ePhoqGjoaQjJOHkZA� as $_obf_jIqVio2Sk4_QjYqTho_Thow� )
        {
            echo "<option value=".$_obf_jIqVio2Sk4_QjYqTho_Thow�['id'];
            if ( $_obf_jIqVio2Sk4_QjYqTho_Thow�['id'] == $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['fregmanagerid'] )
            {
                echo " selected";
            }
            echo ">代理：".$_obf_jIqVio2Sk4_QjYqTho_Thow�['username']."</option>";
        }
    }
    echo "</select></td>\r\n</tr>\r\n<tr malt=\"例如你想实现三张周卡包月的功能，此项就可以设置成一次性充值3张周卡，赠送9天\">\r\n<td align=right>注册充值套餐<br>X版本功能</td>\r\n<td align=left>\r\n<table class=\"listtable\" border=0  cellpadding=\"5\" cellspacing=\"1\" >\r\n<tr class=\"trhead\"><td>注册或充值时使用的卡类</td><td>一次使用张数</td><td>赠送天数</td><td>赠送点数</td><td>操作</td></tr>\r\n";
    $_obf_i4eIkYmJiIyQk4iMj4iGh4o� = array( );
    $_obf_lJWTkIeKiIePjY2MkomMjYw� = _obf_lIuHjouPkIaTk46Ih5SVjIw�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'], &$_obf_i4eIkYmJiIyQk4iMj4iGh4o� );
    $_obf_hpOUiIaPhomMko6NlZKHlIo� = "";
    if ( is_array( $_obf_joeIkY2Jko_PjoiSlJWQhoc� ) )
    {
        foreach ( $_obf_joeIkY2Jko_PjoiSlJWQhoc� as $_obf_ipWNhoeHlIaHkIaVlY6TlIs� => $_obf_i4_NjImUi4_Jj5WIlYqGjoo� )
        {
            foreach ( $_obf_i4_NjImUi4_Jj5WIlYqGjoo� as $_obf_ho_PjYeLkIqJiJOUiJWOkog� => $_obf_jZCMhomOkY6LjoqUlIaIjZE� )
            {
                $_obf_hpOUiIaPhomMko6NlZKHlIo� = $_obf_hpOUiIaPhomMko6NlZKHlIo�."<tr class=trd id='tr".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�.$_obf_ho_PjYeLkIqJiJOUiJWOkog�."' g='g".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�.$_obf_jZCMhomOkY6LjoqUlIaIjZE�['num']."' ><td>".$_obf_i4eIkYmJiIyQk4iMj4iGh4o�[$_obf_ipWNhoeHlIaHkIaVlY6TlIs�]."</td><td><input type=text class=sml2input  maxlength=1 name='zs_czset[".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�."][".$_obf_ho_PjYeLkIqJiJOUiJWOkog�."][num]' value='".$_obf_jZCMhomOkY6LjoqUlIaIjZE�['num']."' AUTOCOMPLETE=off onkeyup=".YH2."this.value=this.value.replace(/[^0-5]/g, '')".YH2."></td>";
                $_obf_hpOUiIaPhomMko6NlZKHlIo� = $_obf_hpOUiIaPhomMko6NlZKHlIo�."<td><input type=text  maxlength=5 class=smlinput name='zs_czset[".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�."][".$_obf_ho_PjYeLkIqJiJOUiJWOkog�."][zsday]' value='".$_obf_jZCMhomOkY6LjoqUlIaIjZE�['zsday']."' AUTOCOMPLETE=off onkeyup=".YH2."this.value=this.value.replace(/[^0-9\\.]/g, '')".YH2."></td>";
                $_obf_hpOUiIaPhomMko6NlZKHlIo� = $_obf_hpOUiIaPhomMko6NlZKHlIo�."<td><input type=text  maxlength=5 class=smlinput name='zs_czset[".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�."][".$_obf_ho_PjYeLkIqJiJOUiJWOkog�."][zspoints]' value='".$_obf_jZCMhomOkY6LjoqUlIaIjZE�['zspoints']."' AUTOCOMPLETE=off onkeyup=".YH2."this.value=this.value.replace(/\\D]/g, '')".YH2."></td>";
                $_obf_hpOUiIaPhomMko6NlZKHlIo� = $_obf_hpOUiIaPhomMko6NlZKHlIo�."<td><img src='../kss_inc/images/b_drop.png' delczzs='tr".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�.$_obf_ho_PjYeLkIqJiJOUiJWOkog�."'  malt='删除该赠送设置' style='cursor:pointer'></td></tr>";
            }
        }
    }
    echo $_obf_hpOUiIaPhomMko6NlZKHlIo�;
    echo "<tr id='tmpoparea' class=trd>\r\n<td><select name=\"tmpopkeyfix\" id=\"tmpopkeyfix\">";
    echo $_obf_lJWTkIeKiIePjY2MkomMjYw�;
    echo "</td>\r\n<td><select name=\"tmpop_num\" style=\"width:50px\" id=\"tmpop_num\">\r\n<option value=1>1张</option>\r\n<option value=2>2张</option>\r\n<option value=3>3张</option>\r\n<option value=4>4张</option>\r\n<option value=5>5张</option></select></td>\r\n<td><input type=\"text\" name=\"tmpop_day\" maxlength=\"5\" id=\"tmpop_day\" value=\"0\" class=\"smlinput\" AUTOCOMPLETE=\"off\" onkeyup=\"this.value=this.value.replace(/[^0-9\\.]/g, '')\"></td>\r\n<td><input type=\"text\" name=\"tmpop_points\" maxlength=\"5\"  id=\"tmpop_points\" value=\"0\" class=\"smlinput\" AUTOCOMPLETE=\"off\" onkeyup=\"this.value=this.value.replace(/\\D/g, '')\"></td>\r\n<td><img src='../kss_inc/images/arrow_rtl.png'  malt=\"添加\" id=\"tmpopadd\" style=\"cursor:pointer\"></td>\r\n</tr>\r\n</table>\r\n<p style=\"line=height:250%\">注册充值套餐和推广套餐说明：<br>\r\n这两个操作区的最后一行都是用来操作的<font color=red>临时操作行</font>，并不会保存到数据库<br>\r\n<font color=red>临时操作行</font>的数据设定好后，点最后边的那个绿色箭头图标<img src=\"../kss_inc/images/arrow_rtl.png\"><br>\r\n<font color=red>临时操作行</font>上边就会多出一行你刚才想设定的数据，可以进行修改操作<br>\r\n你可以重复进行以上操作，添加多行套餐<br>\r\n在你点击保存设置按钮前，这些数据并没有保存到数据库，所以添加或修改了数据请点击软件的保存设置按钮。</p></td>\r\n</tr>\r\n<tr malt=\"本帐号指客户注册或充值时在用户名那填写的帐号<br>父帐号，指客户注册帐号时在推广那里填写的帐号\">\r\n<td align=right>推广套餐<br>X版本功能</td>\r\n<td align=left><table class=\"listtable\" border=0  cellpadding=\"5\" cellspacing=\"1\" >\r\n<tr class=\"trhead\"><td>注册或充值时使用的卡类</td><td>场景</td><td>本帐号赠送天数</td><td>本帐号赠送点数</td><td>父帐号赠送天数</td><td>父帐号赠送点数</td><td>操作</td></tr>\r\n";
    $_obf_hpOUiIaPhomMko6NlZKHlIo� = "";
    if ( is_array( $_obf_lZOKlYePj5CUh5GQhpOMk5M� ) )
    {
        foreach ( $_obf_lZOKlYePj5CUh5GQhpOMk5M� as $_obf_ipWNhoeHlIaHkIaVlY6TlIs� => $_obf_jZCMhomOkY6LjoqUlIaIjZE� )
        {
            $_obf_hpOUiIaPhomMko6NlZKHlIo� = $_obf_hpOUiIaPhomMko6NlZKHlIo�."<tr class=trd id=ttr".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�." ><td>".$_obf_i4eIkYmJiIyQk4iMj4iGh4o�[$_obf_ipWNhoeHlIaHkIaVlY6TlIs�]."</td><td>";
            $_obf_hpOUiIaPhomMko6NlZKHlIo� = $_obf_hpOUiIaPhomMko6NlZKHlIo�."<select name='zs_tgset[".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�."][cj]' >";
            $_obf_hpOUiIaPhomMko6NlZKHlIo� .= "<option value=1";
            if ( $_obf_jZCMhomOkY6LjoqUlIaIjZE�['cj'] == 1 )
            {
                $_obf_hpOUiIaPhomMko6NlZKHlIo� .= " selected";
            }
            $_obf_hpOUiIaPhomMko6NlZKHlIo� .= ">只在注册时赠送</option>";
            $_obf_hpOUiIaPhomMko6NlZKHlIo� .= "<option value=2";
            if ( $_obf_jZCMhomOkY6LjoqUlIaIjZE�['cj'] == 2 )
            {
                $_obf_hpOUiIaPhomMko6NlZKHlIo� .= " selected";
            }
            $_obf_hpOUiIaPhomMko6NlZKHlIo� .= ">注册和充值都赠送</option></select></td>";
            $_obf_hpOUiIaPhomMko6NlZKHlIo� = $_obf_hpOUiIaPhomMko6NlZKHlIo�."<td><input type=text class=smlinput maxlength=4 name='zs_tgset[".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�."][zsday1]' value=".$_obf_jZCMhomOkY6LjoqUlIaIjZE�['zsday1']." onkeyup=".YH2."this.value=this.value.replace(/[^0-9\\.]/g, '')".YH2."></td>";
            $_obf_hpOUiIaPhomMko6NlZKHlIo� = $_obf_hpOUiIaPhomMko6NlZKHlIo�."<td><input type=text class=smlinput maxlength=5 name='zs_tgset[".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�."][zspoints1]' value=".$_obf_jZCMhomOkY6LjoqUlIaIjZE�['zspoints1']." onkeyup=".YH2."this.value=this.value.replace(/\\D/g, '')".YH2."></td>";
            $_obf_hpOUiIaPhomMko6NlZKHlIo� = $_obf_hpOUiIaPhomMko6NlZKHlIo�."<td><input type=text class=smlinput maxlength=4 name='zs_tgset[".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�."][zsday2]' value=".$_obf_jZCMhomOkY6LjoqUlIaIjZE�['zsday2']." onkeyup=".YH2."this.value=this.value.replace(/[^0-9\\.]/g, '')".YH2."></td>";
            $_obf_hpOUiIaPhomMko6NlZKHlIo� = $_obf_hpOUiIaPhomMko6NlZKHlIo�."<td><input type=text class=smlinput maxlength=5 name='zs_tgset[".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�."][zspoints2]' value=".$_obf_jZCMhomOkY6LjoqUlIaIjZE�['zspoints2']." onkeyup=".YH2."this.value=this.value.replace(/\\D/g, '')".YH2."></td>";
            $_obf_hpOUiIaPhomMko6NlZKHlIo� = $_obf_hpOUiIaPhomMko6NlZKHlIo�."<td><img src='../kss_inc/images/b_drop.png' delczzs='ttr".$_obf_ipWNhoeHlIaHkIaVlY6TlIs�."'  malt='删除该推广增送设置' style='cursor:hand'></td></tr>";
        }
    }
    echo $_obf_hpOUiIaPhomMko6NlZKHlIo�;
    echo "<tr id='tmpoparea2' class=trd>\r\n<td><select name=\"tmpopkeyfix2\" id=\"tmpopkeyfix2\">";
    echo $_obf_lJWTkIeKiIePjY2MkomMjYw�;
    echo "</td>\r\n<td><select name=\"tmpop_cj\" style=\"width:150px\" id=\"tmpop_cj\">\r\n<option value=1>只在注册时赠送</option>\r\n<option value=2>注册和充值都赠送</option></select></td>\r\n<td><input type=\"text\" name=\"tmpop_day1\" maxlength=\"4\" id=\"tmpop_day1\" value=\"0\" class=\"smlinput\" AUTOCOMPLETE=\"off\" onkeyup=\"this.value=this.value.replace(/[^0-9\\.]/g, '')\"></td>\r\n<td><input type=\"text\" name=\"tmpop_points1\" maxlength=\"5\"  id=\"tmpop_points1\" value=\"0\" class=\"smlinput\" AUTOCOMPLETE=\"off\" onkeyup=\"this.value=this.value.replace(/\\D/g, '')\"></td>\r\n<td><input type=\"text\" name=\"tmpop_day2\" maxlength=\"4\" id=\"tmpop_day2\" value=\"0\" class=\"smlinput\" AUTOCOMPLETE=\"off\" onkeyup=\"this.value=this.value.replace(/[^0-9\\.]/g, '')\"></td>\r\n<td><input type=\"text\" name=\"tmpop_points2\" maxlength=\"5\"  id=\"tmpop_points2\" value=\"0\" class=\"smlinput\" AUTOCOMPLETE=\"off\" onkeyup=\"this.value=this.value.replace(/\\D/g, '')\"></td>\r\n<td><img src='../kss_inc/images/arrow_rtl.png'  malt=\"添加\" id=\"tmpopadd2\" style=\"cursor:pointer\"></td>\r\n</tr>\r\n</table>\r\n</td>\r\n</tr>\t\t\t\t\r\n<tr malt=\"\" >\r\n<td align=right>友情提示</td>\r\n<td align=left><span style=\"color:#f00\">以下两项背景色不同的设置为老版本兼容保留，X系列版本不再使用</span>\r\n</td></tr>\t\r\n<tr malt=\"例如你想实现三张周卡包月的功能，此项就可以设置成一次性充值3张周卡，赠送9天\" style=\"background-color:#fc9;TEXT-DECORATION: line-through\">\r\n<td align=right>充值套餐</td>\r\n<td align=left>在充值的时候一次性充值<input type=\"text\" name=\"czzs_number\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['czzs_number'];
    echo "\" class=\"sml2input\">张\r\n<select name=\"czzs_keytypeid\">\r\n<option value=''>------不使用充值套餐-------</option>\r\n";
    echo _obf_lIeLiY6Gk4aNiY2Si4uJiIs�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'], $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['czzs_keytypeid'], 2 );
    echo "</select>，赠送<input type=\"text\" maxlength=\"5\" name=\"czzs_cday\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['czzs_cday'];
    echo "\" class=\"smlinput\">天，<input type=\"text\" maxlength=\"5\" name=\"czzs_points\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['czzs_points'];
    echo "\" class=\"smlinput\">点</td>\r\n</tr>\r\n<tr malt=\"子帐号，指客户注册或充值时在用户名那填写的帐号<br>父帐号，指客户注册帐号时在推广那里填写的帐号\" style=\"background-color:#fc9;TEXT-DECORATION: line-through\">\r\n<td align=right valign=top>推广赠送</td>\r\n<td align=left style=\"line-height:200%\">\r\n<select name=\"tg_addtimetype\">\r\n<option value=0 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['tg_addtimetype'] == 0 ? " selected" : "";
    echo ">不开启推广增送</option>\r\n<option value=1 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['tg_addtimetype'] == 1 ? " selected" : "";
    echo ">只在注册操作加时</option>\r\n<option value=2 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['tg_addtimetype'] == 2 ? " selected" : "";
    echo ">注册和充值操作都加时</option>\r\n</select><br>\r\n<p>子帐号赠时 = 子帐号使用的注册卡天数 <span style=\"color:#f00\">╳</span> <input type='text' maxlength=\"2\" class=\"sml2input\" name=tg_newuseraddtime value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['tg_newuseraddtime'];
    echo "\">%，点数 <span style=\"color:#f00\">╳</span> <input type='text' maxlength=\"2\" class=\"sml2input\" name=tg_points1 value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['tg_points1'];
    echo "\">%  【注：0为不给子帐号加时】</p>\r\n<p>父帐号赠时 = 子帐号使用的注册卡天数 <span style=\"color:#f00\">╳</span> <input type='text' maxlength=\"2\" class=\"sml2input\" name=tg_parentuseraddtime value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['tg_parentuseraddtime'];
    echo "\">%，点数 <span style=\"color:#f00\">╳</span> <input type='text' maxlength=\"2\" class=\"sml2input\" name=tg_points2 value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['tg_points2'];
    echo "\">% 【注：0为不给父帐号加时】</p>\r\n<p>比如你月卡送5天：5 除以 30(月卡)  再乘以 100  四舍五入取整 得到的值(5 / 30)*100 ≈ 17  将17填到相应框 <br>\r\n比如你周卡送1天：1 除以 7(周卡)  再乘以 100  四舍五入取整 得到的值(1 / 7)*100 ≈ 14 将14填到相应框 </p>\r\n\r\n</td>\r\n</tr>\r\n</table></div>\r\n<div tbdid=\"19\">\r\n<table border=0  cellpadding=\"10\" cellspacing=\"5\" >\r\n<tr malt=\"该机制可以自动锁定异常登陆的帐号，并将该用户的机器码列入黑名单。两个参数任何一个参数为0将不自动锁定\">\r\n<td align=right>自动锁定</td>\r\n<td align=left>单用户<input type=\"text\" name=\"autolock_time\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['autolock_time'];
    echo "\" class=\"sml2input\">分钟内登陆超过<input type=\"text\" name=\"autolock_times\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['autolock_times'];
    echo "\" class=\"sml2input\">次，自动锁定该用户</td>\r\n</tr>\r\n<tr malt=\"该机制可以自动锁定异常登陆的帐号，并将该用户的机器码列入黑名单。两个参数任何一个参数为0将不自动锁定\">\r\n<td align=right>自动锁定</td>\r\n<td align=left>单用户<input type=\"text\" name=\"autolock_time_ip\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['autolock_time_ip'];
    echo "\" class=\"sml2input\">分钟内登陆过的IP数量超出<input type=\"text\" name=\"autolock_ipnum\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['autolock_ipnum'];
    echo "\" class=\"sml2input\">个，自动锁定该用户</td>\r\n</tr>\r\n<tr malt=\"该机制可以自动锁定异常登陆的帐号，并将该用户的机器码列入黑名单。两个参数任何一个参数为0将不自动锁定\">\r\n<td align=right>自动锁定</td>\r\n<td align=left>单用户<input type=\"text\" name=\"autolock_time_advapi\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['autolock_time_advapi'];
    echo "\" class=\"sml2input\">分钟内调用advapi超过<input type=\"text\" name=\"autolock_times_advapi\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['autolock_times_advapi'];
    echo "\" class=\"sml2input\">次，自动锁定该用户</td>\r\n</tr>\r\n<tr malt=\"\">\r\n<td align=right>禁止调试(X版本功能)</td>\r\n<td align=left><input type='checkbox' ";
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['nodebuger'] == 1 )
    {
        echo "checked";
    }
    echo " name='nodebuger' value='1' id=\"nodebuger\">&nbsp;&nbsp;&nbsp;&nbsp;<span stylc=\"color:#f00\">勾选时，如果发现调试登陆会自动锁定用户帐号</span>\r\n</td></tr>\t\r\n<tr malt=\"\" >\r\n<td align=right>友情提示</td>\r\n<td align=left><span style=\"color:#f00\">以下三项背景色不同的设置为老版本兼容保留，新版本不再使用</span>\r\n</td></tr>\t\t\t\t\r\n<tr malt=\"\" style=\"background-color:#fc9\">\r\n<td align=right style=\"TEXT-DECORATION: line-through\" malt=\"服务端数据公钥加密，客户端私钥解密，有效的防止IP劫持\">RSA不对称算法</td>\r\n<td align=left>\r\n<input type=radio value='1' name=\"rsaenable\" id=\"rsaenable_1\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['rsaenable'] == 1 ? " checked" : "";
    echo "><label for=\"rsaenable_1\" >启用</label>，\r\n&nbsp;&nbsp;&nbsp;&nbsp;<input type=radio value='2' name=\"rsaenable\" id=\"rsaenable_2\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['rsaenable'] == 2 ? " checked" : "";
    echo "><label for=\"rsaenable_2\" >不启用</label>，\r\n&nbsp;&nbsp;&nbsp;&nbsp;<input type=radio value='0' name=\"rsaenable\" id=\"rsaenable_0\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['rsaenable'] == 0 ? " checked" : "";
    echo "><label for=\"rsaenable_0\" >使用全局设置</label>\r\n<span style=\"color:#ff0000\">*全局设置指的是使用高级管理，系统参数设置里的RSA设置项</span>\r\n</td></tr>\r\n<tr malt=\"\" style=\"background-color:#fc9\">\r\n<td align=right style=\"TEXT-DECORATION: line-through\">RSA私钥 Private Exp.(D)</td>\r\n<td align=left><input class=\"longinput\" onClick=this.select() type=\"text\" maxlength=\"256\" name=\"rsaekey\" id=\"rsaekey\" value='";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['rsaekey'];
    echo "' /> * <a href=\"http://www.hphu.com/_soft/pan.php?id=rsatool\" target=_blank>请使用RSATool工具计算获取 (256位)</a>\r\n</td></tr>\r\n<tr malt=\"请使用RSATool工具计算 Modulus(N)\" style=\"background-color:#fc9\">\r\n<td align=right style=\"TEXT-DECORATION: line-through\">RSA模数 Modulus(N)</td>\r\n<td align=left><input class=\"longinput\" onClick=this.select() type=\"text\" maxlength=\"256\" name=\"rsankey\" id=\"rsankey\" value='";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['rsankey'];
    echo "' /> * <a href=\"http://www.hphu.com/_soft/pan.php?id=rsatool\" target=_blank>请使用RSATool工具计算获取 (256位)</a>\r\n</td></tr>\r\n\r\n<tr malt=\"机器码黑名单\">\r\n<td valign=top>机器码、IP黑名单<br>多个用英文逗号分隔</td>\r\n<td align=left><textarea name=\"mac_blacklist\" class=\"softtextarea\">";
    echo htmlspecialchars( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['mac_blacklist'] == "" ? "" : $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['mac_blacklist'] );
    echo "</textarea></td>\r\n</tr>\r\n</table></div>\r\n<div tbdid=\"14\" malt=\"与客户端通讯的自定义高级接口，按php语法填写\">\r\n<table border=0  cellpadding=\"5\" cellspacing=\"5\">\r\n<tr>\r\n<td align=right valign=top><div  id='advapilib'>ADVAPI</span></td>\r\n<td align=left><span style=\"display:none\" id=\"advapilib2\"><input type=password name='syspassword' id='softsyspassword' value=''><input type=text name='debugmode' id='debugmode' value='0'></span>\t<input type=\"button\" value=\"放大\" onClick=\$(\"#advapivv\").attr(\"rows\",30)>&nbsp;&nbsp;&nbsp;&nbsp;\t<input type=\"button\" value=\"缩小\" onClick=\$(\"#advapivv\").attr(\"rows\",10)>　　<input type=\"button\" value=\"RSA运算速度测试\" onClick=malert('./admin_soft.php?action=addsoft_rsatest','RSA运算速度测试')>&nbsp;&nbsp;&nbsp;&nbsp;\t　　<span style=\"font-family: Georgia,Verdana;font-size:18px;font-weight:700;color:#ff0000\">PHP参考手册:<a href=\"http://www.php100.com/manual/w3school/php/\" target=\"_blank\">http://www.php100.com/manual/w3school/php/</a></span><br>\r\n<textarea name=\"advapi\" id=\"advapivv\" style=\"font-family:宋体;line-height:180%;width\" rows=\"15\" cols=\"150\" class=\"softtextarea8\">";
    echo htmlspecialchars( base64_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['advapi'] ) );
    echo "</textarea>\t</td>\r\n</tr>\r\n<tr>\r\n<td align=right valign=top>ADVAPI字符串资源<br><br>X版本功能</td>\r\n<td align=left><textarea name=\"resstring\" id=\"resstring\" style=\"font-family:宋体;line-height:180%\"  rows=\"10\" cols=\"150\" class=\"softtextarea8\">";
    echo htmlspecialchars( base64_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['resstring'] ) );
    echo "</textarea><br>\t\t\t\t\t\r\nADVAPI字符串资源，可以存放最多20000个字节，供ADVAPI代码区用的。<br>\r\n可存多个字符串到本区，每个字符串需要以一行<span style=\"font-family: Georgia,Verdana;font-size:18px;font-weight:700;color:#ff0000\">====NEW RESSTR====[注释]</span>开头<br>\r\n注释可写可不写，需同<span style=\"font-family: Georgia,Verdana;font-size:18px;font-weight:700;color:#ff0000\">====NEW RESSTR====</span>在同一行。然后下边一行或多行就是你的字符串数据。<br>ADVAPI代码区可以用函数 <span style=\"font-family: Georgia,Verdana;font-size:18px;font-weight:700;color:#ff0000\">_rs(1..n)</span>读取相应的字符串<br>第1个字符串是 <span style=\"font-family: Georgia,Verdana;font-size:18px;font-weight:700;color:#ff0000\">_rs(1)</span>,&nbsp;&nbsp;&nbsp;&nbsp;第n个字符串就是<span style=\"font-family: Georgia,Verdana;font-size:18px;font-weight:700;color:#ff0000\">_rs(n)</span>  </td>\r\n</tr>\r\n</table></div>\r\n<div tbdid=\"15\" malt=\"这里填软件简介，会显示在销售系统里，支持html语法\">\r\n<table border=0  cellpadding=\"5\" cellspacing=\"5\">\r\n<tr>\r\n<td align=right valign=top>软件简介</td>\r\n<td align=left><textarea name=\"softintro\" class=\"softtextarea ckeditor\">";
    echo htmlspecialchars( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softintro'] == "" ? "" : base64_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softintro'] ) );
    echo "</textarea></td>\r\n</tr>\r\n</table></div>\r\n<div tbdid=\"16\">\r\n<table border=0  cellpadding=\"5\" cellspacing=\"5\">\r\n<tr malt=\"如果选是的话，有新版本无论客户有没有勾选检查更新都会强制让用户更新软件<br>选否的话，有新版本的话只有当客户勾选了检查更新才会更新客户端\">\r\n<td align=right>强制更新</td>\r\n<td align=left>\r\n<input type=radio value=1 name=\"ismustupdate\" id=\"ismustupdate_2\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ismustupdate'] == "1" ? " checked" : "";
    echo "><label for=\"ismustupdate_2\">是</label>&nbsp;&nbsp;&nbsp;&nbsp;\r\n<input type=radio value=0 name=\"ismustupdate\" id=\"ismustupdate_1\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ismustupdate'] == "0" ? " checked" : "";
    echo "><label for=\"ismustupdate_1\">否</label></td>\r\n</tr>\r\n<tr malt=\"你发布的软件最新版本号，只能是一个整数\">\r\n<td align=right>最新软件版本</td>\r\n<td align=left><input class=\"smlinput\" type=\"text\" maxlength=\"6\" name=\"softversion\" value=\"";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softversion'];
    echo "\" /></td>\r\n</tr>\r\n<tr malt=\"自动更新时，软件最新版本的下载地址，只能是exe文件地址，如果有多个文件请用winrar制作exe的自解压包\">\r\n<td align=right>升级包下载地址</td>\r\n<td align=left><input class=\"biginput\" type=\"text\" maxlength=\"256\" name=\"softdownurl\" value=\"";
    echo _obf_j5CKkY_GkomSkoaUlIuLlYk�( base64_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softdownurl'] ) );
    echo "\" /></td>\r\n</tr>\r\n<tr malt=\"这里填更新日志，客户端自动更新调用自动更新程序update.exe时会显示该段文本，支持html语法\">\r\n<td align=right valign=top>更新日志</td>\r\n<td align=left><textarea name=\"updatelog\" class=\"softtextarea ckeditor\">";
    echo htmlspecialchars( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['updatelog'] == "" ? "" : base64_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['updatelog'] ) );
    echo "</textarea></td>\r\n</tr>\r\n</table></div>\r\n<div tbdid=\"17\" malt=\"这里填公告，可通过客户端API获取，不支持html语法\">\r\n<table border=0  cellpadding=\"5\" cellspacing=\"5\">\r\n<tr>\r\n<td align=right valign=top>软件公告</td>\r\n<td align=left><textarea name=\"softnotice\" class=\"softtextarea\">";
    echo htmlspecialchars( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softnotice'] == "" ? "" : base64_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softnotice'] ) );
    echo "</textarea></td>\r\n</tr>\r\n</table></div>\r\n<div tbdid=\"20\" malt=\"售卡系统自动发送邮件时，附件里附加的文本\">\r\n<table border=0  cellpadding=\"5\" cellspacing=\"5\">\r\n<tr>\r\n<td align=right valign=top>售卡系统自动发送邮件时<br>附加的邮件正文内容</td>\r\n<td align=left><textarea name=\"mailtext\" class=\"softtextarea ckeditor\">";
    echo htmlspecialchars( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['mailtext'] == "" ? "" : base64_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['mailtext'] ) );
    echo "</textarea></td>\r\n</tr>\r\n</table></div>\r\n</div>\r\n<div>&nbsp;&nbsp;&nbsp;&nbsp;<input type=submit class=\"submitbtn\" id=\"softsubmit\" value=\"";
    echo $_obf_iY2HkZGJi5WKj4qLkouThoc�;
    echo "\"></div>\r\n</div>\t\t\r\n</form>\r\n<div style=\"display:none\">\r\n<div id=\"ustatus\"><select name=\"softstatus\">\r\n<option value=0 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 0 ? " selected" : "";
    echo ">正常使用</option>\r\n<option value=1 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 1 ? " selected" : "";
    echo ">停止使用</option>\r\n<option value=2 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 2 ? " selected" : "";
    echo ">禁止注册新帐号</option>\r\n<option value=3 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 3 ? " selected" : "";
    echo ">禁止用户充值</option>\r\n<option value=4 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 4 ? " selected" : "";
    echo ">禁止注册新帐号和充值</option>\r\n<option value=5 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 5 ? " selected" : "";
    echo ">冻结用户时间，正常使用软件</option>\r\n<option value=6 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 6 ? " selected" : "";
    echo ">冻结用户时间，停止使用软件</option>\r\n</select></div>\r\n<div id=\"kstatus\"><select name=\"softstatus\">\r\n<option value=0 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 0 ? " selected" : "";
    echo ">正常使用</option>\r\n<option value=1 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 1 ? " selected" : "";
    echo ">停止使用</option>\r\n<option value=2 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 2 ? " selected" : "";
    echo ">禁止新卡号激活</option>\r\n<option value=5 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 5 ? " selected" : "";
    echo ">冻结用户时间，正常使用软件</option>\r\n<option value=6 ";
    echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softstatus'] == 6 ? " selected" : "";
    echo ">冻结用户时间，停止使用软件</option>\r\n</select>\r\n</div>\r\n</div>\r\n";
    $_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
    echo "<div id=pageruntime>页面运行时间"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_i5GVjZWQj4ePkJKMjJSRipM� )."毫秒</div>";
    echo "</body>\r\n</html>";
}
?>
