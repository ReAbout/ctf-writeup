<?php

function _obf_k5KVkZGHkYeVk4uSh4yLlYw�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 6 );
$_obf_k4mViI2Nj4mJkIuUj42JiIY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "op", "gp", "sql", "" );
$_obf_k42Rh4mVlYqGi4mOiZWMjJA� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "page", "gp", "int", 1 );
$_obf_jpKNh4aRh4aQkY2PlIuRhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softid", "gp", "int", 0 );
$_obf_lImLiIqUj5OSipGOko6RlJQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keywords", "gp", "sql", "" );
$_obf_lImLiIqUj5OSipGOko6RlJQ� = trim( $_obf_lImLiIqUj5OSipGOko6RlJQ� );
$_obf_i4uIkYuKkJGQlJKOjoiMj4c� = array(
    "action" => $_obf_lZOThomRipOIi5SRhpWRjY4�
);
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['softid'] = $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['keywords'] = $_obf_lImLiIqUj5OSipGOko6RlJQ�;
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_ho2NhoaMhoqMlYuLiJSKjo4� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_agentprice where `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id']." and `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
    if ( empty( $_obf_ho2NhoaMhoqMlYuLiJSKjo4� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没有该软件的授权", 1 );
    }
}
$_obf_jZGRipSRkIeUiIeQjoaUjJI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where `id`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
$_obf_iYqPiJGIjoaVhoaQiI2Ti4w� = "SELECT `id` ";
$_obf_jpCQi4aKkYaIjpSUhpWNipM� = "SELECT * ";
$_obf_homTioySho6Vh5ORiYmUkok� = " where `id` ";
$_obf_kZCPiJCHiI_IlY2Ok4_JlIc� = "SELECT count(*) as tnum ";
$_obf_lJSNlZWKlYmGi4iSkIqHjpA� = "from `kss_olddata` ";
$_obf_h4eJlYuIjpKNio6QkIuJlIY� = array( );
if ( 15 < strlen( $_obf_lImLiIqUj5OSipGOko6RlJQ� ) )
{
    $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� = preg_replace( "/([^a-zA-Z0-9\\n])/", "", $_obf_lImLiIqUj5OSipGOko6RlJQ� );
    $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� = str_replace( "\n\n", "\n", $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� );
    $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� = str_replace( "\n\n", "\n", $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� );
    $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� = str_replace( "\n\n", "\n", $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� );
    if ( strlen( $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� ) < 16 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没输入任何卡号或输入的卡号格式非法", 1 );
    }
    $_obf_h5OVi5KSi5OIhpCSk42KiI4� = explode( "\n", $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� );
    $_obf_joeNkJKLko2Hi4aNjomOj4s� = "";
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    $_obf_kYiQkJKGlI6JlZWRioaKlYg� = array( );
    foreach ( $_obf_h5OVi5KSi5OIhpCSk42KiI4� as $_obf_ko2HkJOUh5WSiZKSjomUk4w� )
    {
        if ( strlen( $_obf_ko2HkJOUh5WSiZKSjomUk4w� ) != 16 && strlen( $_obf_ko2HkJOUh5WSiZKSjomUk4w� ) != 24 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "注册卡号必须是16或24位", 1 );
        }
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 1;
        if ( ZPAGESIZE < $_obf_jpKPlJSUiZOHkYaPlIeOiY4� )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "每次最多只能查询".ZPAGESIZE."条", 1 );
        }
        $_obf_joeNkJKLko2Hi4aNjomOj4s� .= "'".$_obf_ko2HkJOUh5WSiZKSjomUk4w�."',";
    }
    if ( $_obf_joeNkJKLko2Hi4aNjomOj4s� == "" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没输入任何卡号或输入的卡号格式非法", 1 );
    }
    $_obf_joeNkJKLko2Hi4aNjomOj4s� = substr( $_obf_joeNkJKLko2Hi4aNjomOj4s�, 0, strlen( $_obf_joeNkJKLko2Hi4aNjomOj4s� ) - 1 );
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `oldkey` in (".$_obf_joeNkJKLko2Hi4aNjomOj4s�.") ";
}
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['b'] = " `agentid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
}
$_obf_h4eJlYuIjpKNio6QkIuJlIY�['c'] = " `softcode`=".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softcode'];
$_obf_j4mJh4aKjZKHhpOSiJKSjJI� = "";
if ( !empty( $_obf_h4eJlYuIjpKNio6QkIuJlIY� ) )
{
    $_obf_j4mJh4aKjZKHhpOSiJKSjJI� = " where".implode( " and ", $_obf_h4eJlYuIjpKNio6QkIuJlIY� );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_lI_KipSOk4iQkI_MjIuVkpQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "recordnum", "gp", "int", 0 );
if ( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� == 1 )
{
    $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( $_obf_kZCPiJCHiI_IlY2Ok4_JlIc�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI� );
    $_obf_lI_KipSOk4iQkI_MjIuVkpQ� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
}
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['recordnum'] = $_obf_lI_KipSOk4iQkI_MjIuVkpQ�;
$_obf_jIiNjZCPkoeUjI2LipCQk5Q� = abs( floor( $_obf_lI_KipSOk4iQkI_MjIuVkpQ� / ZPAGESIZE * -1 ) );
$_obf_iZWHjpGQkoqPlYmJjYmIhpU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." order by id asc LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
echo "<textarea id=viewsql>";
echo htmlspecialchars( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
echo "\r\n";
$_obf_iIiHi4aTkoySkpCNio_UjYo� = "";
$_obf_j4aSkImMlYyRiY6Mho2VkZM� = "";
if ( !empty( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� ) )
{
    foreach ( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� as $_obf_kYqOi5CTjoySj4mIkYmIlY4� )
    {
        $_obf_iIiHi4aTkoySkpCNio_UjYo� .= $_obf_kYqOi5CTjoySj4mIkYmIlY4�['id'].",";
        $_obf_j4aSkImMlYyRiY6Mho2VkZM� = "=".$_obf_kYqOi5CTjoySj4mIkYmIlY4�['id'];
    }
    $_obf_iIiHi4aTkoySkpCNio_UjYo� = substr( $_obf_iIiHi4aTkoySkpCNio_UjYo�, 0, strlen( $_obf_iIiHi4aTkoySkpCNio_UjYo� ) - 1 );
}
$_obf_iYeIjIaVlYaIj4yTiJWHk40� = FALSE;
$_obf_koeUkImOlYeQiZSJkZWPiJU� = "";
if ( $_obf_iIiHi4aTkoySkpCNio_UjYo� != "" )
{
    $_obf_homTioySho6Vh5ORiYmUkok� .= 1 < count( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� ) ? " in (".$_obf_iIiHi4aTkoySkpCNio_UjYo�.") order by id asc" : $_obf_j4aSkImMlYyRiY6Mho2VkZM�;
    $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
    echo htmlspecialchars( $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_k4yVk4iOipWPioqJlIuVkpE� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iouHh42RkIeKkYaSipWKiog�( $_obf_k42Rh4mVlYqGi4mOiZWMjJA�, $_obf_jIiNjZCPkoeUjI2LipCQk5Q�, $_obf_i4uIkYuKkJGQlJKOjoiMj4c� )."<span class=page_nav_a>".$_obf_lI_KipSOk4iQkI_MjIuVkpQ�."行  耗时"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_lJKOiJSHjo_Sj4yKk4aIh5I� )."毫秒</span>";
echo "</textarea><script>\r\n\$(document).ready(function() { \r\n\$(\"[cls='newkey']\").bind(\"click\",function(e){\r\nMouse(e);//计算显示层的位置\r\nif(tcopy(this.innerText)){\r\nmview(\"已复制到剪贴板\");\r\n}\r\n});\r\n});\r\n</script>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<form id=\"find_key\" action=\"?action=v8data&softid=";
echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
echo "\" method=\"post\">\r\n<tr>\r\n<td class=\"findorpage\">\r\n搜索旧的注册卡号，每行一张，每次最多可查询";
echo ZPAGESIZE;
echo "张卡号<br><textarea style=\"display:block;width:500px;height:100px;margin:5px 0 0 0;font-family:Fixedsys,Arial,Verdana;color:#333\" name=\"keywords\" >";
echo $_obf_lImLiIqUj5OSipGOko6RlJQ�;
echo "</textarea>\r\n<input type=\"submit\" name=\"submit\" class=\"submitbtn\" value=\"搜索\" />\r\n</td>\r\n</tr>\r\n</form>\r\n</table>\r\n\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr class=\"trhead\">\r\n<td nowrap=\"nowrap\">ID</td>\r\n<td nowrap=\"nowrap\">所属</td>\t\r\n<td nowrap=\"nowrap\">旧卡号</td>\t\r\n<td nowrap=\"nowrap\">新卡号</td>\t\r\n<td nowrap=\"nowrap\">状态</td>\t\t\r\n<td nowrap=\"nowrap\">属性</td>\t\r\n</tr>\r\n";
if ( empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
{
    echo "<tr nodata=1 class=trd><td colspan=6>没找到任何数据</td></tr>";
}
else
{
    foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        echo "<tr class='trd' id='trd'><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "</td><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['agentid'];
        echo "</td><td nowrap='nowrap' class=dwidth>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['oldkey'];
        echo "</td>";
        echo "<td nowrap='nowrap' class='dwidth' id='copy_"._obf_iI6QhpSTiJCJiI_KlYePlZI�( 16 )."' class='keynum' copyt='";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['newkey'];
        echo "'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['newkey'];
        echo "</td><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ext1'] == "0" ? "未使用" : "<font color=red>已使用</font>";
        echo "</td><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ext2'];
        echo "</td></tr>\r\n";
    }
}
echo "</table>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n";
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
echo "<div id=pageruntime>页面运行时间"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_i5GVjZWQj4ePkJKMjJSRipM� )."毫秒</div>";
echo "</body>\r\n</html>";
?>
