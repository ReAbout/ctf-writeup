<?php

function _obf_i4qHlIyKkoiJlYiKjY6Mko8�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 8 );
$_obf_k4mViI2Nj4mJkIuUj42JiIY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "op", "gp", "sql", "" );
$_obf_k42Rh4mVlYqGi4mOiZWMjJA� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "page", "gp", "int", 1 );
$_obf_jpKNh4aRh4aQkY2PlIuRhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softid", "gp", "int", 0 );
$_obf_i4uIkYuKkJGQlJKOjoiMj4c� = array(
    "action" => $_obf_lZOThomRipOIi5SRhpWRjY4�
);
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['softid'] = $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
$_obf_jZGRipSRkIeUiIeQjoaUjJI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where `id`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." and `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'] );
if ( empty( $_obf_jZGRipSRkIeUiIeQjoaUjJI� ) )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没有该软件的授权", 1 );
}
$_obf_iYqPiJGIjoaVhoaQiI2Ti4w� = "SELECT `id` ";
$_obf_jpCQi4aKkYaIjpSUhpWNipM� = "SELECT * ";
$_obf_homTioySho6Vh5ORiYmUkok� = " where `id` ";
$_obf_kZCPiJCHiI_IlY2Ok4_JlIc� = "SELECT count(*) as tnum ";
$_obf_lJSNlZWKlYmGi4iSkIqHjpA� = "from `kss_tb_log_pubuser` ";
$_obf_h4eJlYuIjpKNio6QkIuJlIY� = array( );
$_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
$_obf_j4mJh4aKjZKHhpOSiJKSjJI� = "";
if ( !empty( $_obf_h4eJlYuIjpKNio6QkIuJlIY� ) )
{
    $_obf_j4mJh4aKjZKHhpOSiJKSjJI� = " where".implode( " and ", $_obf_h4eJlYuIjpKNio6QkIuJlIY� );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_lI_KipSOk4iQkI_MjIuVkpQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "recordnum", "gp", "int", 0 );
if ( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� == 1 )
{
    $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( $_obf_kZCPiJCHiI_IlY2Ok4_JlIc�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI� );
    $_obf_lI_KipSOk4iQkI_MjIuVkpQ� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
}
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['recordnum'] = $_obf_lI_KipSOk4iQkI_MjIuVkpQ�;
$_obf_jIiNjZCPkoeUjI2LipCQk5Q� = abs( floor( $_obf_lI_KipSOk4iQkI_MjIuVkpQ� / ZPAGESIZE * -1 ) );
$_obf_iZWHjpGQkoqPlYmJjYmIhpU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
echo "<textarea id=viewsql>";
echo htmlspecialchars( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
echo "\r\n";
$_obf_iIiHi4aTkoySkpCNio_UjYo� = "";
$_obf_j4aSkImMlYyRiY6Mho2VkZM� = "";
if ( !empty( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� ) )
{
    foreach ( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� as $_obf_kYqOi5CTjoySj4mIkYmIlY4� )
    {
        $_obf_iIiHi4aTkoySkpCNio_UjYo� .= $_obf_kYqOi5CTjoySj4mIkYmIlY4�['id'].",";
        $_obf_j4aSkImMlYyRiY6Mho2VkZM� = "=".$_obf_kYqOi5CTjoySj4mIkYmIlY4�['id'];
    }
    $_obf_iIiHi4aTkoySkpCNio_UjYo� = substr( $_obf_iIiHi4aTkoySkpCNio_UjYo�, 0, strlen( $_obf_iIiHi4aTkoySkpCNio_UjYo� ) - 1 );
}
$_obf_iYeIjIaVlYaIj4yTiJWHk40� = FALSE;
$_obf_koeUkImOlYeQiZSJkZWPiJU� = "";
if ( $_obf_iIiHi4aTkoySkpCNio_UjYo� != "" )
{
    $_obf_homTioySho6Vh5ORiYmUkok� .= 1 < count( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� ) ? " in (".$_obf_iIiHi4aTkoySkpCNio_UjYo�.")" : $_obf_j4aSkImMlYyRiY6Mho2VkZM�;
    $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
    echo htmlspecialchars( $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_k4yVk4iOipWPioqJlIuVkpE� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iouHh42RkIeKkYaSipWKiog�( $_obf_k42Rh4mVlYqGi4mOiZWMjJA�, $_obf_jIiNjZCPkoeUjI2LipCQk5Q�, $_obf_i4uIkYuKkJGQlJKOjoiMj4c� )."<span class=page_nav_a>".$_obf_lI_KipSOk4iQkI_MjIuVkpQ�."行  耗时"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_lJKOiJSHjo_Sj4yKk4aIh5I� )."毫秒</span>";
echo "</textarea>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr class=\"trhead\">\r\n<td nowrap=\"nowrap\">ID</td>\r\n<td nowrap=\"nowrap\" >机器码</td>\t\t\r\n<td nowrap=\"nowrap\" >周期开始天</td>\r\n<td nowrap=\"nowrap\" >周期已使用次数</td>\r\n<td nowrap=\"nowrap\" >最后一次验证</td>\r\n</tr>\r\n";
if ( empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
{
    echo "<tr nodata=1 class=trd><td colspan=5>没找到任何日志</td></tr>";
}
else
{
    foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        echo "<tr class='trd' id='trd'><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "</td><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pccode'];
        echo "</td><td nowrap='nowrap'>";
        echo _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['nday'], "Y-m-d" );
        echo "</td><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ntimes'];
        echo "</td><td nowrap='nowrap'>";
        echo _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['lasttime'], "y-m-d H:i:s" );
        echo "</td></tr>\r\n";
    }
}
echo "</table>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n";
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
echo "<div id=pageruntime>页面运行时间"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_i5GVjZWQj4ePkJKMjJSRipM� )."毫秒</div>";
echo "</body>\r\n</html>";
?>
