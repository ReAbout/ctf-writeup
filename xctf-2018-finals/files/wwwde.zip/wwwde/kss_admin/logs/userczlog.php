<?php

function _obf_iZGUkJSMlZCNjYeJkouTlY4�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 6 );
$_obf_k4mViI2Nj4mJkIuUj42JiIY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "op", "gp", "sql", "" );
$_obf_iY6GioqOjomTiIiKh4mGkZE� = array( 0 => "用户注册", 1 => "用户充值", 2 => "手工操作", 3 => "推广赠送P", 4 => "推广赠送S", 5 => "修改绑定信息", 6 => "解绑机器", 7 => "充值套餐", 8 => "免费注册", 9 => "充值（充值前过期）", 10 => "批量加时" );
$_obf_k42Rh4mVlYqGi4mOiZWMjJA� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "page", "gp", "int", 1 );
$_obf_jpKNh4aRh4aQkY2PlIuRhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softid", "gp", "int", 0 );
$_obf_lImLiIqUj5OSipGOko6RlJQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keywords", "gp", "sql", "" );
$_obf_lImLiIqUj5OSipGOko6RlJQ� = trim( $_obf_lImLiIqUj5OSipGOko6RlJQ� );
$_obf_i4uIkYuKkJGQlJKOjoiMj4c� = array(
    "action" => $_obf_lZOThomRipOIi5SRhpWRjY4�
);
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['softid'] = $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['keywords'] = $_obf_lImLiIqUj5OSipGOko6RlJQ�;
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_ho2NhoaMhoqMlYuLiJSKjo4� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_agentprice where `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id']." and `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
    if ( empty( $_obf_ho2NhoaMhoqMlYuLiJSKjo4� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没有该软件的授权", 1 );
    }
}
$_obf_jZGRipSRkIeUiIeQjoaUjJI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where `id`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
$_obf_iYqPiJGIjoaVhoaQiI2Ti4w� = "SELECT `id` ";
$_obf_jpCQi4aKkYaIjpSUhpWNipM� = "SELECT * ";
$_obf_homTioySho6Vh5ORiYmUkok� = " where `id` ";
$_obf_kZCPiJCHiI_IlY2Ok4_JlIc� = "SELECT count(*) as tnum ";
$_obf_lJSNlZWKlYmGi4iSkIqHjpA� = "from `kss_z_cz_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."` ";
$_obf_h4eJlYuIjpKNio6QkIuJlIY� = array( );
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    $_obf_lImLiIqUj5OSipGOko6RlJQ� = substr( $_obf_lImLiIqUj5OSipGOko6RlJQ�, 0, 10 );
}
if ( 1 < strlen( $_obf_lImLiIqUj5OSipGOko6RlJQ� ) )
{
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `username`='".$_obf_lImLiIqUj5OSipGOko6RlJQ�."' ";
}
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `username`=(select `czusername` from `kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."` where `czusername`='".$_obf_lImLiIqUj5OSipGOko6RlJQ�."' and `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id']." limit 0,1)";
}
$_obf_j4mJh4aKjZKHhpOSiJKSjJI� = "";
if ( !empty( $_obf_h4eJlYuIjpKNio6QkIuJlIY� ) )
{
    $_obf_j4mJh4aKjZKHhpOSiJKSjJI� = " where".implode( " and ", $_obf_h4eJlYuIjpKNio6QkIuJlIY� );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_lI_KipSOk4iQkI_MjIuVkpQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "recordnum", "gp", "int", 0 );
if ( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� == 1 )
{
    $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( $_obf_kZCPiJCHiI_IlY2Ok4_JlIc�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI� );
    $_obf_lI_KipSOk4iQkI_MjIuVkpQ� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
}
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['recordnum'] = $_obf_lI_KipSOk4iQkI_MjIuVkpQ�;
$_obf_jIiNjZCPkoeUjI2LipCQk5Q� = abs( floor( $_obf_lI_KipSOk4iQkI_MjIuVkpQ� / ZPAGESIZE * -1 ) );
$_obf_iZWHjpGQkoqPlYmJjYmIhpU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
echo "<textarea id=viewsql>";
echo htmlspecialchars( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
echo "\r\n";
$_obf_iIiHi4aTkoySkpCNio_UjYo� = "";
$_obf_j4aSkImMlYyRiY6Mho2VkZM� = "";
if ( !empty( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� ) )
{
    foreach ( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� as $_obf_kYqOi5CTjoySj4mIkYmIlY4� )
    {
        $_obf_iIiHi4aTkoySkpCNio_UjYo� .= $_obf_kYqOi5CTjoySj4mIkYmIlY4�['id'].",";
        $_obf_j4aSkImMlYyRiY6Mho2VkZM� = "=".$_obf_kYqOi5CTjoySj4mIkYmIlY4�['id'];
    }
    $_obf_iIiHi4aTkoySkpCNio_UjYo� = substr( $_obf_iIiHi4aTkoySkpCNio_UjYo�, 0, strlen( $_obf_iIiHi4aTkoySkpCNio_UjYo� ) - 1 );
}
$_obf_iYeIjIaVlYaIj4yTiJWHk40� = FALSE;
$_obf_koeUkImOlYeQiZSJkZWPiJU� = "";
if ( $_obf_iIiHi4aTkoySkpCNio_UjYo� != "" )
{
    $_obf_homTioySho6Vh5ORiYmUkok� .= 1 < count( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� ) ? " in (".$_obf_iIiHi4aTkoySkpCNio_UjYo�.")" : $_obf_j4aSkImMlYyRiY6Mho2VkZM�;
    $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
    echo htmlspecialchars( $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_k4yVk4iOipWPioqJlIuVkpE� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iouHh42RkIeKkYaSipWKiog�( $_obf_k42Rh4mVlYqGi4mOiZWMjJA�, $_obf_jIiNjZCPkoeUjI2LipCQk5Q�, $_obf_i4uIkYuKkJGQlJKOjoiMj4c� )."<span class=page_nav_a>".$_obf_lI_KipSOk4iQkI_MjIuVkpQ�."行  耗时"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_lJKOiJSHjo_Sj4yKk4aIh5I� )."毫秒</span>";
echo "</textarea><table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<form id=\"find_key\" action=\"?action=userczlog&softid=";
echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
echo "\" method=\"post\">\r\n<tr>\r\n<td class=\"findorpage\">\r\n用户名：<input class=\"longinput\" type=text name=\"keywords\" value=\"";
echo $_obf_lImLiIqUj5OSipGOko6RlJQ�;
echo "\">\r\n<input type=\"submit\" name=\"submit\" class=\"submitbtn\" value=\"搜索\" />\r\n</td>\r\n</tr>\r\n</form>\r\n</table>\r\n\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr class=\"trhead\">\r\n<td nowrap=\"nowrap\">ID</td>\r\n";
if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "USOFT" )
{
    echo "<td nowrap='nowrap' malt='用户名'>用户名</td>";
}
else
{
    echo "<td nowrap='nowrap' malt='注册卡号前十位'>用户名</td>";
}
echo "<td nowrap=\"nowrap\">日期</td>\r\n<td nowrap=\"nowrap\" >变更前天数</td>\t\t\r\n<td nowrap=\"nowrap\">变更后天数</td>\r\n<td nowrap=\"nowrap\" >变更前点数</td>\r\n<td nowrap=\"nowrap\" >变更后点数</td>\r\n<td nowrap=\"nowrap\" >类型</td>\r\n<td nowrap=\"nowrap\" >备注</td>\r\n</tr>\r\n";
if ( empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
{
    echo "<tr nodata=1 class=trd><td colspan=9>没找到任何充值日志</td></tr>";
}
else
{
    foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        echo "<tr class='trd' id='trd'><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "</td><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        echo "</td><td nowrap='nowrap'>";
        echo _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['addtime'], "m-d H:i:s" );
        echo "</td><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['oldcday'];
        echo "</td><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['newcday'];
        echo "</td><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['oldtimes'];
        echo "</td><td nowrap='nowrap'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['newtimes'];
        echo "</td><td nowrap='nowrap'>";
        echo $_obf_iY6GioqOjomTiIiKh4mGkZE�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cztype']];
        echo "</td><td nowrap='nowrap'>";
        switch ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cztype'] )
        {
        case 0 :
        case 1 :
        case 7 :
            echo "卡号：".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'];
            break;
        case 2 :
            echo "管理手工操作";
            break;
        case 3 :
            echo "子帐号：".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['tzxguser'];
            break;
        case 4 :
            echo "父帐号：".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['tzxguser'];
            break;
        case 5 :
            echo "旧->新：".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'];
            break;
        case 10 :
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'];
            break;
        default :
            echo "&nbsp;";
        }
        echo "</td></tr>\r\n";
    }
}
echo "</table>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n";
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
echo "<div id=pageruntime>页面运行时间"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_i5GVjZWQj4ePkJKMjJSRipM� )."毫秒</div>";
echo "</body>\r\n</html>";
?>
