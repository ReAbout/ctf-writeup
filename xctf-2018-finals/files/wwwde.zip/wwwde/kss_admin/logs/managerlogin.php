<?php

function _obf_kYeIjo2OipCRkYyUjJCQko8�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 6 );
$_obf_k5KUlIyJio_Gj4_OlIiSjZA� = array( 1 => "正常登陆", 2 => "帐号过期", 3 => "帐号被锁定", 4 => "密码错误" );
$_obf_kYqTiZWUjZKLjZCVlImUi5A� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "managerid", "gp", "int", 0 );
$_obf_i4uIkYuKkJGQlJKOjoiMj4c� = array(
    "action" => $_obf_lZOThomRipOIi5SRhpWRjY4�
);
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 )
{
    $_obf_kYqTiZWUjZKLjZCVlImUi5A� = $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
}
else
{
    if ( $_obf_kYqTiZWUjZKLjZCVlImUi5A� == 0 )
    {
        $_obf_kYqTiZWUjZKLjZCVlImUi5A� = $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
    }
    $_obf_jIqTkJSOiYyIk5WJjIuJiYk� = 0;
    $_obf_kYmHlZCUhpSMkpCPiY6Shog� = array( );
    $_obf_kZCRjYuGiIuGi5WJlIaKiZM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `id`,`username`,`pid`,`isdel` from `kss_tb_manager` where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'] );
    foreach ( $_obf_kZCRjYuGiIuGi5WJlIaKiZM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] == $_obf_kYqTiZWUjZKLjZCVlImUi5A� )
        {
            $_obf_jIqTkJSOiYyIk5WJjIuJiYk� = 1;
            $_obf_kYmHlZCUhpSMkpCPiY6Shog�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        }
    }
    if ( $_obf_jIqTkJSOiYyIk5WJjIuJiYk� == 0 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你所查询的用户没找到，或你无权查询该用户的登陆日志！" );
    }
}
$_obf_k42Rh4mVlYqGi4mOiZWMjJA� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "page", "gp", "int", 1 );
$_obf_iYqPiJGIjoaVhoaQiI2Ti4w� = "SELECT `id` ";
$_obf_jpCQi4aKkYaIjpSUhpWNipM� = "SELECT * ";
$_obf_homTioySho6Vh5ORiYmUkok� = " where `id` in";
$_obf_kZCPiJCHiI_IlY2Ok4_JlIc� = "SELECT count(*) as tnum ";
$_obf_lJSNlZWKlYmGi4iSkIqHjpA� = "from `kss_tb_log_login` ";
$_obf_h4eJlYuIjpKNio6QkIuJlIY� = array( );
$_obf_h4eJlYuIjpKNio6QkIuJlIY�[] = " `managerid`='".$_obf_kYqTiZWUjZKLjZCVlImUi5A�."'";
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['managerid'] = $_obf_kYqTiZWUjZKLjZCVlImUi5A�;
$_obf_j4mJh4aKjZKHhpOSiJKSjJI� = "";
if ( !empty( $_obf_h4eJlYuIjpKNio6QkIuJlIY� ) )
{
    $_obf_j4mJh4aKjZKHhpOSiJKSjJI� = " where".implode( " and ", $_obf_h4eJlYuIjpKNio6QkIuJlIY� )." order by logintime desc";
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_lI_KipSOk4iQkI_MjIuVkpQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "recordnum", "gp", "int", 0 );
if ( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� == 1 )
{
    $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( $_obf_kZCPiJCHiI_IlY2Ok4_JlIc�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI� );
    $_obf_lI_KipSOk4iQkI_MjIuVkpQ� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
}
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['recordnum'] = $_obf_lI_KipSOk4iQkI_MjIuVkpQ�;
$_obf_jIiNjZCPkoeUjI2LipCQk5Q� = abs( floor( $_obf_lI_KipSOk4iQkI_MjIuVkpQ� / ZPAGESIZE * -1 ) );
$_obf_iZWHjpGQkoqPlYmJjYmIhpU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
echo "<!-- ";
echo $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE;
echo " -->";
$_obf_iIiHi4aTkoySkpCNio_UjYo� = "";
if ( !empty( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� ) )
{
    foreach ( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� as $_obf_kYqOi5CTjoySj4mIkYmIlY4� )
    {
        $_obf_iIiHi4aTkoySkpCNio_UjYo� .= $_obf_kYqOi5CTjoySj4mIkYmIlY4�['id'].",";
    }
    $_obf_iIiHi4aTkoySkpCNio_UjYo� = substr( $_obf_iIiHi4aTkoySkpCNio_UjYo�, 0, strlen( $_obf_iIiHi4aTkoySkpCNio_UjYo� ) - 1 );
}
$_obf_iYeIjIaVlYaIj4yTiJWHk40� = FALSE;
if ( $_obf_iIiHi4aTkoySkpCNio_UjYo� != "" )
{
    $_obf_homTioySho6Vh5ORiYmUkok� .= "(".$_obf_iIiHi4aTkoySkpCNio_UjYo�.")";
    $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok�." order by id desc" );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_k4yVk4iOipWPioqJlIuVkpE� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iouHh42RkIeKkYaSipWKiog�( $_obf_k42Rh4mVlYqGi4mOiZWMjJA�, $_obf_jIiNjZCPkoeUjI2LipCQk5Q�, $_obf_i4uIkYuKkJGQlJKOjoiMj4c� )."<span class=page_nav_a>".$_obf_lI_KipSOk4iQkI_MjIuVkpQ�."行  耗时"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_lJKOiJSHjo_Sj4yKk4aIh5I� )."毫秒</span>";
echo "<script type=\"text/javascript\">\r\n\$(document).ready(function() { \r\n\$(\".vieworder\").live(\"click\",function(){\r\n\$(\".malertboxclosebtn\").click();\r\nmalert('./admin_order.php?action=vieworder&isajax=1&ordernum='+\$(this).text(),'订单'+\$(this).text()+'的注册卡号',600,300);\t\r\n});\r\n});\r\n</script>\r\n";
if ( 7 < $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] )
{
    echo "<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr class=trd>\r\n<td valign=middle><form action=\"?action=managerlogin\" method=\"post\" id=\"agentrmbf\" name=\"agentrmbf\">\r\n用户<select id='managerid' name='managerid'>";
    foreach ( $_obf_kZCRjYuGiIuGi5WJlIaKiZM� as $_obf_ipWMj4mQkZSRi5KKkJOQlY8� )
    {
        if ( $_obf_ipWMj4mQkZSRi5KKkJOQlY8�['isdel'] == 0 )
        {
            echo "<option value=".$_obf_ipWMj4mQkZSRi5KKkJOQlY8�['id'];
            if ( $_obf_kYqTiZWUjZKLjZCVlImUi5A� == $_obf_ipWMj4mQkZSRi5KKkJOQlY8�['id'] )
            {
                echo " selected";
            }
            echo ">".$_obf_ipWMj4mQkZSRi5KKkJOQlY8�['username']."</option>";
        }
    }
    echo "</select><input type=submit class=submitbtn value=\"查询\">\r\n</form></td>\r\n</tr>\r\n</table>\r\n";
}
echo "\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr class=\"trhead\">\r\n<td >ID</td>\r\n<td >日期</td>\r\n<td >IP</td>\r\n<td >用户名</td>\r\n<td >备注</td>\r\n</tr>\r\n";
if ( empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
{
    echo "<tr class=trd><td colspan=5>没有登陆记录</td></tr>";
}
else
{
    foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        echo "<tr class=\"trd\">\r\n<td>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "</td>\r\n<td>";
        echo _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['logintime'] );
        echo "</td>\r\n<td class=isip>";
        echo long2ip( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['loginip'] );
        echo "</td>\r\n<td>";
        echo isset( $_obf_kYmHlZCUhpSMkpCPiY6Shog�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['managerid']] ) ? $_obf_kYmHlZCUhpSMkpCPiY6Shog�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['managerid']] : "&nbsp;";
        echo "</td>\r\n<td>";
        echo $_obf_k5KUlIyJio_Gj4_OlIiSjZA�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['logintype']];
        echo "</td>\r\n</tr>\r\n";
    }
}
echo "</table>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n";
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
echo "<div id=pageruntime>页面运行时间"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_i5GVjZWQj4ePkJKMjJSRipM� )."毫秒</div>";
echo "</body>\r\n</html>";
?>
