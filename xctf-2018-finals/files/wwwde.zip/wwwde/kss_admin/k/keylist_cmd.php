<?php

function _obf_kpGTjo6Gj46KlYeIkI6GjZU�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function my_sort( $_obf_iJSNjIuPjoqSjYyUiIyIi5A�, $_obf_j4qUhoiVipWQj4iNh5CJj4w� )
{
    if ( $_obf_iJSNjIuPjoqSjYyUiIyIi5A�['username'] == $_obf_j4qUhoiVipWQj4iNh5CJj4w�['username'] )
    {
        if ( $_obf_j4qUhoiVipWQj4iNh5CJj4w�['endtime'] < $_obf_iJSNjIuPjoqSjYyUiIyIi5A�['endtime'] )
        {
            return 0;
        }
        if ( $_obf_j4qUhoiVipWQj4iNh5CJj4w�['endtime'] < $_obf_iJSNjIuPjoqSjYyUiIyIi5A�['endtime'] )
        {
            return -1;
        }
        return 1;
    }
    if ( $_obf_j4qUhoiVipWQj4iNh5CJj4w�['username'] < $_obf_iJSNjIuPjoqSjYyUiIyIi5A�['username'] )
    {
        return -1;
    }
    return 1;
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
switch ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� )
{
case "锁定" :
case "解锁" :
    if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你真聪明，绕到这来了" );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = "";
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
    {
        $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = " and `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."'";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."')";
    }
    $_obf_jJOHiIqRiYmTkJKPhpWTipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select A.`keys`,A.`islock`,A.`keyfix`,B.`pmid` from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." as A left join kss_tb_manager as B on A.`managerid`=B.`id` where A.`keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�.$_obf_jYaSi46HjY6Jj4qKi5WPlIo�." and A.`cztime`=0 and A.`islock`<".( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] - 4 ) );
    if ( empty( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您没有权限对选择的注册卡执行锁定或解锁操作！<br>1、可能是你选择的注册卡已被高于你级别的用户锁定。<br>2、该注册卡已使用过，锁定或解锁没有任何意义。" );
    }
    if ( count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) != count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) )
    {
        $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "你提交".$_obf_k4mViI2Nj4mJkIuUj42JiIY�.count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."个注册卡号的操作请求，只有".count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� )."条被处理";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = "";
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 7 && $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pmid'] != $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'] )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你试图操作不属于你管理的卡号".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyfix'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'] );
        }
        $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys']."',";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = substr( $_obf_kYqNjZWRkI6OhomJjoqHjoY�, 0, strlen( $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) - 1 );
    $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in (".$_obf_kYqNjZWRkI6OhomJjoqHjoY�.")";
    $_obf_k5KIjYeHhoyOkoiKiJSOh5I� = $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] - 5;
    $_obf_k5KIjYeHhoyOkoiKiJSOh5I� = 3 < $_obf_k5KIjYeHhoyOkoiKiJSOh5I� ? 3 : $_obf_k5KIjYeHhoyOkoiKiJSOh5I�;
    if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == "锁定" )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `islock`=".$_obf_k5KIjYeHhoyOkoiKiJSOh5I�." where `keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok1,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    else
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `islock`=0 where `keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok0,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    break;
case "删除" :
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你真聪明，绕到这来了" );
    }
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'], "52" ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您无权限执行删除操作！", 1 );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."'";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."')";
    }
    $_obf_jJOHiIqRiYmTkJKPhpWTipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `keys`,`islock` from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok� );
    if ( empty( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你选择的卡好像都不存在！" );
    }
    if ( count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) != count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) )
    {
        $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "你提交".$_obf_k4mViI2Nj4mJkIuUj42JiIY�.count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."个注册卡号的操作请求，只找到".count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� )."张卡";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = "";
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys']."',";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = substr( $_obf_kYqNjZWRkI6OhomJjoqHjoY�, 0, strlen( $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) - 1 );
    $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in (".$_obf_kYqNjZWRkI6OhomJjoqHjoY�.")";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "replace into kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle (`managerid`, `keyfix`,`keys`, `keyspassword`, `addtime`, `ordernum`, `cday`, `linknum`, `points`, `keyextattr`, `tag`, `islock`, `isback`, `cztime`, `czusername`,`deltime`,`delmid`) select `managerid`,`keyfix`,`keys`, `keyspassword`, `addtime`, `ordernum`, `cday`, `linknum`, `points`, `keyextattr`, `tag`, `islock`, `isback`, `cztime`, `czusername`,".time( ).",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id']." from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� == $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where  `keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE && $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok3,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), 1 );
    break;
case "savetags" :
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = "";
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_lYqOkIyVi5WGhoqLhouThoo� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "tags", "gp", "sqljs", "" );
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
    {
        $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = " and `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�.$_obf_iZOQkZCMkZGGjZCIlZSQi40�." set `tag`='".$_obf_lYqOkIyVi5WGhoqLhouThoo�."' where `keys`='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."'".$_obf_jYaSi46HjY6Jj4qKi5WPlIo�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok" );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
case "设置标签" :
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你真聪明，绕到这来了" );
    }
    $_obf_ipCVkZKKi4eSjIuTlZSVho8� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "newtag", "gp", "sqljs", "" );
    if ( 50 < _obf_ioqHi5WHiJKIkoeIhouHjYw�( $_obf_ipCVkZKKi4eSjIuTlZSVho8� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "标签最大长度50个字符！", 1 );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = "";
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
    {
        $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = " and `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."'";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."')";
    }
    $_obf_jJOHiIqRiYmTkJKPhpWTipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `keys`,`islock` from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�.$_obf_jYaSi46HjY6Jj4qKi5WPlIo� );
    if ( empty( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你选择的卡好像都不存在或是您没有权限对选择的注册卡执行操作！" );
    }
    if ( count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) != count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) )
    {
        $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "你提交".count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."个注册卡号的设置标签操作的请求，只有".count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� )."条被处理";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = "";
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys']."',";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = substr( $_obf_kYqNjZWRkI6OhomJjoqHjoY�, 0, strlen( $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) - 1 );
    $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in (".$_obf_kYqNjZWRkI6OhomJjoqHjoY�.")";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `tag`='".$_obf_ipCVkZKKi4eSjIuTlZSVho8�."' where `keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok4,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), 1 );
    break;
case "还原" :
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "只有作者级别的才可以还原数据" );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."'";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."')";
    }
    $_obf_jJOHiIqRiYmTkJKPhpWTipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `keys`,`islock` from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle where `keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok� );
    if ( empty( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你选择的卡好像都不存在！" );
    }
    if ( count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) != count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) )
    {
        $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "你提交".$_obf_k4mViI2Nj4mJkIuUj42JiIY�.count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."个注册卡号的操作请求，只找到".count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� )."张卡";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = "";
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys']."',";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = substr( $_obf_kYqNjZWRkI6OhomJjoqHjoY�, 0, strlen( $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) - 1 );
    $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in (".$_obf_kYqNjZWRkI6OhomJjoqHjoY�.")";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "replace into kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." (`managerid`, `keyfix`, `keys`, `keyspassword`, `addtime`, `ordernum`, `cday`, `linknum`, `points`, `keyextattr`, `tag`, `islock`, `isback`, `cztime`, `czusername`) select `managerid`, `keyfix`, `keys`, `keyspassword`, `addtime`, `ordernum`, `cday`, `linknum`, `points`, `keyextattr`, `tag`, `islock`, `isback`, `cztime`, `czusername` from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle where `keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� == $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle where  `keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE && $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok5,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), 1 );
    break;
case "退卡" :
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "只有作者级才可能需要退卡操作！" );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."' and A.`isback`=0 ";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."') and A.`isback`=0 ";
    }
    $_obf_jJOHiIqRiYmTkJKPhpWTipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select A.`ordernum`, A.`managerid`,A.`keyfix`,A.`keys`,A.`keyspassword`,A.`cday` as cdaya, A.`cztime`,A.`czusername`, A.`ordernum`,B.`username`,B.`cday` as cdayb, B.`starttime`,B.`endtime`,B.`activetimes`,C.`level`,C.`rmb` from (kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." as A left join kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." as B on A.`czusername`=B.`username`) left join kss_tb_manager as C on A.`managerid`=C.`id`  where A.`keys`".$_obf_k4iLiZOSjJWRlIqLiYaPiok� );
    if ( empty( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你选择的卡好像都不符合退卡规则或不存在！" );
    }
    if ( 20 < count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "每次最多退20张卡号！" );
    }
    $_obf_h46IjY6UkomKi4yRh4iJiZM� = 0;
    $_obf_jYiMkoyVi5GOkY_NiIyKioc� = "";
    $_obf_h4iHi4mJkpGOjpWMjoiSk4c� = array( );
    $_obf_jJCMlYaJk4yKkI2QhpWLho4� = 0;
    $_obf_h4qJk4_TkJWGhomKio2Ui5E� = 0;
    $_obf_h4yViImPipSNiY6MiZWIkZQ� = array( );
    $_obf_ho6VlZOPiZCUjZCLiY_TlJM� = 0;
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = "";
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys']."',";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = substr( $_obf_kYqNjZWRkI6OhomJjoqHjoY�, 0, strlen( $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) - 1 );
    $_obf_jY6JkY2LlY2PjIqGiJCJjoY� = array( );
    $_obf_joqPh4qMjIeMkYmPlZWTi5A� = array( );
    $_obf_joqTkpGSiIyKhoqIiJGJi4g� = array( );
    $_obf_lY2NjouTjo2JjoiVjpSKj5E� = array( );
    $_obf_lZOMh4uSkYmRj46MlY_Kh40� = array( );
    $_obf_iJGGlJCSjJGThomTh4mGiok� = 0;
    $_obf_i4iOj4iMjo2Jj5WKk5CVh48� = 0;
    ob_clean( );
    $_obf_kIeRlJCQk5CIjpOOh4uSiI4� = 0;
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        if ( $_obf_h46IjY6UkomKi4yRh4iJiZM� != 0 && $_obf_h46IjY6UkomKi4yRh4iJiZM� != $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['managerid'] )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "退卡操作无效<br>选择注册卡时请注意，只能同时对某一个代理的卡执行退款操作。<br>你选择了超出一个代理的卡号" );
        }
        $_obf_h46IjY6UkomKi4yRh4iJiZM� = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['managerid'];
        $_obf_kIeRlJCQk5CIjpOOh4uSiI4� = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['rmb'];
        if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level'] != 6 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "只能给代理的卡执行退卡操作" );
        }
        $_obf_jpWSkImSiIeHkY2TlY_JlIs� = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyspassword'];
        if ( !isset( $_obf_h4iHi4mJkpGOjpWMjoiSk4c�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum']] ) )
        {
            $_obf_h4iHi4mJkpGOjpWMjoiSk4c�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum']] = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select `keycount`,`agentamount7`, `agentamount`,`orderstatus` from kss_tb_order where ordernum='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum']."'" );
        }
        if ( empty( $_obf_h4iHi4mJkpGOjpWMjoiSk4c�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum']] ) )
        {
            $_obf_jY6JkY2LlY2PjIqGiJCJjoY�[] = array(
                "username" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['czusername'],
                "ok" => 0,
                "keys" => $_obf_jpWSkImSiIeHkY2TlY_JlIs�,
                "cday" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 1,
                "price" => "？",
                "price2" => 0,
                "price7" => 0,
                "ordernum" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum'],
                "isused" => 0 < $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cztime'] ? "是" : "否",
                "endtime" => empty( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] ) ? "" : $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] == 0 ? $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdayb'] : round( ( time( ) - $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] ) / 86400, 2 ),
                "intro" => "订单未找到，不能退卡"
            );
        }
        else
        {
            $_obf_j4qKjIaLi4iKjZKHjJGLjY0� = $_obf_h4iHi4mJkpGOjpWMjoiSk4c�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum']]['agentamount'] / $_obf_h4iHi4mJkpGOjpWMjoiSk4c�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum']]['keycount'];
            $_obf_komOio_SkZCSjoyKiJWJjo8� = $_obf_h4iHi4mJkpGOjpWMjoiSk4c�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum']]['agentamount7'] / $_obf_h4iHi4mJkpGOjpWMjoiSk4c�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum']]['keycount'];
            if ( $_obf_h4iHi4mJkpGOjpWMjoiSk4c�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum']]['orderstatus'] < 8 )
            {
                $_obf_jY6JkY2LlY2PjIqGiJCJjoY�[] = array(
                    "username" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['czusername'],
                    "ok" => 0,
                    "keys" => $_obf_jpWSkImSiIeHkY2TlY_JlIs�,
                    "cday" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 1,
                    "price" => $_obf_j4qKjIaLi4iKjZKHjJGLjY0�,
                    "price2" => 0,
                    "price7" => 0,
                    "ordernum" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum'],
                    "isused" => 0 < $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cztime'] ? "是" : "否",
                    "endtime" => empty( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] ) ? "" : $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] == 0 ? $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdayb'] : round( ( time( ) - $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] ) / 86400, 2 ),
                    "intro" => "订单未完成状态，不能退卡"
                );
            }
            else if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cztime'] != 0 )
            {
                if ( !isset( $_obf_joqPh4qMjIeMkYmPlZWTi5A�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] ) )
                {
                    $_obf_joqPh4qMjIeMkYmPlZWTi5A�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdayb'];
                    $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'];
                }
                is_null( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['activetimes'] );
                if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['activetimes'] == 0 )
                {
                    $_obf_jI_MjoiJj4yHh42Ok4_Mjo4� = $_obf_joqPh4qMjIeMkYmPlZWTi5A�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']];
                    $_obf_joqPh4qMjIeMkYmPlZWTi5A�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] = $_obf_joqPh4qMjIeMkYmPlZWTi5A�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] - $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'];
                    $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] = $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] - $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 86400;
                    $_obf_jJCMlYaJk4yKkI2QhpWLho4� += $_obf_j4qKjIaLi4iKjZKHjJGLjY0�;
                    $_obf_h4qJk4_TkJWGhomKio2Ui5E� += $_obf_komOio_SkZCSjoyKiJWJjo8�;
                    $_obf_lY2NjouTjo2JjoiVjpSKj5E�[] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'];
                    $_obf_lZOMh4uSkYmRj46MlY_Kh40�[] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyfix'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'];
                    $_obf_ho6VlZOPiZCUjZCLiY_TlJM� += 1;
                    $_obf_jY6JkY2LlY2PjIqGiJCJjoY�[] = array(
                        "username" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['czusername'],
                        "ok" => 1,
                        "keys" => $_obf_jpWSkImSiIeHkY2TlY_JlIs�,
                        "cday" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 1,
                        "price" => $_obf_j4qKjIaLi4iKjZKHjJGLjY0�,
                        "price2" => $_obf_j4qKjIaLi4iKjZKHjJGLjY0�,
                        "price7" => $_obf_komOio_SkZCSjoyKiJWJjo8�,
                        "ordernum" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum'],
                        "isused" => "是",
                        "endtime" => $_obf_jI_MjoiJj4yHh42Ok4_Mjo4�,
                        "intro" => "帐号从未登录，金额全退"
                    );
                }
                else if ( $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] <= time( ) )
                {
                    $_obf_jY6JkY2LlY2PjIqGiJCJjoY�[] = array(
                        "username" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['czusername'],
                        "ok" => 0,
                        "keys" => $_obf_jpWSkImSiIeHkY2TlY_JlIs�,
                        "cday" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 1,
                        "price" => $_obf_j4qKjIaLi4iKjZKHjJGLjY0�,
                        "price2" => 0,
                        "price7" => 0,
                        "ordernum" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum'],
                        "isused" => "是",
                        "endtime" => 0,
                        "intro" => "用户已过期，不退款"
                    );
                }
                else if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 86400 < $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] - time( ) )
                {
                    $_obf_jI_MjoiJj4yHh42Ok4_Mjo4� = round( ( $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] - time( ) ) / 86400, 2 );
                    $_obf_joqPh4qMjIeMkYmPlZWTi5A�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] = $_obf_joqPh4qMjIeMkYmPlZWTi5A�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] - $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'];
                    $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] = $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] - $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 86400;
                    $_obf_jJCMlYaJk4yKkI2QhpWLho4� += $_obf_j4qKjIaLi4iKjZKHjJGLjY0�;
                    $_obf_h4qJk4_TkJWGhomKio2Ui5E� += $_obf_komOio_SkZCSjoyKiJWJjo8�;
                    $_obf_lY2NjouTjo2JjoiVjpSKj5E�[] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'];
                    $_obf_lZOMh4uSkYmRj46MlY_Kh40�[] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyfix'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'];
                    $_obf_ho6VlZOPiZCUjZCLiY_TlJM� += 1;
                    $_obf_jY6JkY2LlY2PjIqGiJCJjoY�[] = array(
                        "username" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['czusername'],
                        "ok" => 1,
                        "keys" => $_obf_jpWSkImSiIeHkY2TlY_JlIs�,
                        "cday" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 1,
                        "price" => $_obf_j4qKjIaLi4iKjZKHjJGLjY0�,
                        "price2" => $_obf_j4qKjIaLi4iKjZKHjJGLjY0�,
                        "price7" => $_obf_komOio_SkZCSjoyKiJWJjo8�,
                        "ordernum" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum'],
                        "isused" => "是",
                        "endtime" => $_obf_jI_MjoiJj4yHh42Ok4_Mjo4�,
                        "intro" => "有效天数足够，全额退款"
                    );
                }
                else
                {
                    $_obf_kpGOi5OIj4_Nj4qQiI_SjpQ� = round( $_obf_j4qKjIaLi4iKjZKHjJGLjY0� * ( $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] - time( ) ) / ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 86400 ), 2 );
                    $_obf_iY_TjoaOkZOOhpOVhoqHj5U� = round( $_obf_komOio_SkZCSjoyKiJWJjo8� * ( $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] - time( ) ) / ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 86400 ), 2 );
                    $_obf_jI2Pi4_UkI2UjIaPlI2RkI8� = round( ( $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] - time( ) ) / 86400, 2 );
                    $_obf_joqPh4qMjIeMkYmPlZWTi5A�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] = 0;
                    $_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['starttime'];
                    $_obf_jJCMlYaJk4yKkI2QhpWLho4� += $_obf_kpGOi5OIj4_Nj4qQiI_SjpQ�;
                    $_obf_h4qJk4_TkJWGhomKio2Ui5E� += $_obf_iY_TjoaOkZOOhpOVhoqHj5U�;
                    $_obf_iJGGlJCSjJGThomTh4mGiok� = $_obf_iJGGlJCSjJGThomTh4mGiok� + $_obf_j4qKjIaLi4iKjZKHjJGLjY0� - $_obf_kpGOi5OIj4_Nj4qQiI_SjpQ�;
                    $_obf_j5WSiY6Oko6Lj4yMjo2Ti5U� = $_obf_iJGGlJCSjJGThomTh4mGiok� + $_obf_komOio_SkZCSjoyKiJWJjo8� - $_obf_iY_TjoaOkZOOhpOVhoqHj5U�;
                    $_obf_lY2NjouTjo2JjoiVjpSKj5E�[] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'];
                    $_obf_lZOMh4uSkYmRj46MlY_Kh40�[] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyfix'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'];
                    $_obf_ho6VlZOPiZCUjZCLiY_TlJM� += 1;
                    $_obf_jY6JkY2LlY2PjIqGiJCJjoY�[] = array(
                        "username" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['czusername'],
                        "ok" => 1,
                        "keys" => $_obf_jpWSkImSiIeHkY2TlY_JlIs�,
                        "cday" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 1,
                        "price" => $_obf_j4qKjIaLi4iKjZKHjJGLjY0�,
                        "price2" => $_obf_kpGOi5OIj4_Nj4qQiI_SjpQ�,
                        "price7" => $_obf_komOio_SkZCSjoyKiJWJjo8�,
                        "ordernum" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum'],
                        "isused" => "是",
                        "endtime" => $_obf_jI2Pi4_UkI2UjIaPlI2RkI8�,
                        "intro" => "有效天数不足，部份退款"
                    );
                }
            }
            else
            {
                $_obf_jJCMlYaJk4yKkI2QhpWLho4� += $_obf_j4qKjIaLi4iKjZKHjJGLjY0�;
                $_obf_h4qJk4_TkJWGhomKio2Ui5E� += $_obf_komOio_SkZCSjoyKiJWJjo8�;
                $_obf_lY2NjouTjo2JjoiVjpSKj5E�[] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'];
                $_obf_lZOMh4uSkYmRj46MlY_Kh40�[] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyfix'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'];
                $_obf_ho6VlZOPiZCUjZCLiY_TlJM� += 1;
                $_obf_jY6JkY2LlY2PjIqGiJCJjoY�[] = array(
                    "username" => "",
                    "ok" => 1,
                    "keys" => $_obf_jpWSkImSiIeHkY2TlY_JlIs�,
                    "cday" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cdaya'] * 1,
                    "price" => $_obf_j4qKjIaLi4iKjZKHjJGLjY0�,
                    "price2" => $_obf_j4qKjIaLi4iKjZKHjJGLjY0�,
                    "price7" => $_obf_komOio_SkZCSjoyKiJWJjo8�,
                    "ordernum" => $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ordernum'],
                    "isused" => "否",
                    "endtime" => "",
                    "intro" => "未充值的卡，全额退款"
                );
            }
        }
    }
    uasort( &$_obf_jY6JkY2LlY2PjIqGiJCJjoY�, "my_sort" );
    echo "ok6,<div style='width:100%; height:360px; overflow:auto; border:0;'><table class='listtable' border='0' cellspacing='1' cellpadding='0' align='center' width='100%'>";
    echo "<tr class='trhead'><td>共计".$_obf_ho6VlZOPiZCUjZCLiY_TlJM�."张卡</td><td>天数</td><td>已充值</td><td>单价</td><td>退款</td><td>用户名</td><td>剩余天</td><td>备注</td></tr>";
    foreach ( $_obf_jY6JkY2LlY2PjIqGiJCJjoY� as $_obf_jZOPjoiSjZOLiIaJkY2Ri4c� )
    {
        echo "<tr class=trd><td class=keynum>".$_obf_jZOPjoiSjZOLiIaJkY2Ri4c�['keys']."</td><td>".$_obf_jZOPjoiSjZOLiIaJkY2Ri4c�['cday']."</td><td>".$_obf_jZOPjoiSjZOLiIaJkY2Ri4c�['isused']."</td><td>".$_obf_jZOPjoiSjZOLiIaJkY2Ri4c�['price']."</td><td>".$_obf_jZOPjoiSjZOLiIaJkY2Ri4c�['price2']."</td><td>".$_obf_jZOPjoiSjZOLiIaJkY2Ri4c�['username']."</td><td>".$_obf_jZOPjoiSjZOLiIaJkY2Ri4c�['endtime']."</td><td>".$_obf_jZOPjoiSjZOLiIaJkY2Ri4c�['intro']."</td></tr>";
    }
    echo "</table></div>";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `isback`=1,`islock`=3 where `keys` in ('".implode( "','", $_obf_lY2NjouTjo2JjoiVjpSKj5E� )."')", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        echo "<p color=red>将注册卡设置为已退状态时出错，还未退款".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."</p>";
        exit( );
    }
    $_obf_iIyPhoqLjYuJioeIioyJk5A� = "";
    foreach ( $_obf_joqPh4qMjIeMkYmPlZWTi5A� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `cday`=".$_obf_lYeSkY6Th5SOlYuHjZGVio8�.",`endtime`=".$_obf_joqTkpGSiIyKhoqIiJGJi4g�[$_obf_koiIh4mRlJKGlIiGiJCUkI4�]." where `username`='".$_obf_koiIh4mRlJKGlIiGiJCUkI4�."'", "sync" );
        if ( !$_obf_lY6RhpOJh46VkJOGkoeRiIY� )
        {
            $_obf_iIyPhoqLjYuJioeIioyJk5A� .= "扣除用户".$_obf_koiIh4mRlJKGlIiGiJCUkI4�."的时间时出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."\r\n";
        }
    }
    if ( $_obf_iIyPhoqLjYuJioeIioyJk5A� != "" )
    {
        echo "<textarea style='width:600px;height:20px;color:#f00'>".$_obf_iIyPhoqLjYuJioeIioyJk5A�."</textarea>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `kss_tb_log_agentrmb` (`pid`,`softid`,`managerid`,`opmanagerid`,`addtime`,`oldrmb`,`changermb`,`optype`,`ordernum`,`intro`) VALUES (".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'].",".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�.",".$_obf_h46IjY6UkomKi4yRh4iJiZM�.",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'].",".time( ).",".$_obf_kIeRlJCQk5CIjpOOh4uSiI4�.",".$_obf_jJCMlYaJk4yKkI2QhpWLho4�.",6,'','<span class=ek ekey=".YH2.implode( ",", $_obf_lZOMh4uSkYmRj46MlY_Kh40� ).YH2.">退卡</span>')", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE `kss_tb_log_agentrmb`", "notsync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "记录日志失败，操作中断[未加款]。".$_obf_h4aUkomQiI6JlIaSkomSkok� );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set rmb=rmb+".$_obf_jJCMlYaJk4yKkI2QhpWLho4�.",`xfrmb`=`xfrmb`-".$_obf_jJCMlYaJk4yKkI2QhpWLho4�." where `id`=".$_obf_h46IjY6UkomKi4yRh4iJiZM�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        echo "<p color=red>注册卡已退，但退还款项".$_obf_jJCMlYaJk4yKkI2QhpWLho4�."到代理帐号时操作出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."</p>";
        exit( );
    }
    $_obf_lIiPjo6LjoqUjYiUjJKOhpA� = 1;
    $_obf_kpSQiI_Qk4mPjYeMk4uHhpA� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and id=".$_obf_h46IjY6UkomKi4yRh4iJiZM� );
    $_obf_koqGkI6TkpSOhpCQlY2UjJQ� = _obf_iY6RiYaNio6PiIyIiZWJkJQ�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'], $_obf_kpSQiI_Qk4mPjYeMk4uHhpA�['pmid'] );
    if ( !empty( $_obf_koqGkI6TkpSOhpCQlY2UjJQ� ) )
    {
        $_obf_lIiPjo6LjoqUjYiUjJKOhpA� = 0;
    }
    $_obf_jY6UkZSViY2Hj4aVi5SIjpM� = "";
    if ( $_obf_lIiPjo6LjoqUjYiUjJKOhpA� == 0 )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `kss_tb_log_agentrmb` (`pid`,`softid`,`managerid`,`opmanagerid`,`addtime`,`oldrmb`,`changermb`,`optype`,`ordernum`,`intro`) VALUES (".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'].",".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�.",".$_obf_koqGkI6TkpSOhpCQlY2UjJQ�['id'].",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'].",".time( ).",".$_obf_koqGkI6TkpSOhpCQlY2UjJQ�['rmb'].",".$_obf_h4qJk4_TkJWGhomKio2Ui5E�.",6,'','<span class=ek ekey=".YH2.implode( ",", $_obf_lZOMh4uSkYmRj46MlY_Kh40� ).YH2.">退卡</span>')", "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
        {
            $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE `kss_tb_log_agentrmb`", "notsync" );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "记录日志失败，操作中断[未加款]。".$_obf_h4aUkomQiI6JlIaSkomSkok� );
        }
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set rmb=rmb+".$_obf_h4qJk4_TkJWGhomKio2Ui5E�.",`xfrmb`=`xfrmb`-".$_obf_h4qJk4_TkJWGhomKio2Ui5E�." where `id`=".$_obf_koqGkI6TkpSOhpCQlY2UjJQ�['id'], "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
        {
            echo "<p color=red>注册卡已退，但退还款项".$_obf_jJCMlYaJk4yKkI2QhpWLho4�."到总代理帐号时操作出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."</p>";
            exit( );
        }
        $_obf_jY6UkZSViY2Hj4aVi5SIjpM� = "，退款".$_obf_h4qJk4_TkJWGhomKio2Ui5E�."元给总代，总代损耗".$_obf_i4iOj4iMjo2Jj5WKk5CVh48�."元";
    }
    echo "<p>退卡成功，共退款".$_obf_jJCMlYaJk4yKkI2QhpWLho4�."元给代理，代理损耗".$_obf_iJGGlJCSjJGThomTh4mGiok�."元".$_obf_jY6UkZSViY2Hj4aVi5SIjpM�."</p>";
    exit( );
}
?>
