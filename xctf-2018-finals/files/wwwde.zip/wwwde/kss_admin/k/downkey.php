<?php

function _obf_iYiLkZSRh5CGipCIj4_Ti4k�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 6 );
$_obf_iJWMjIiVi5OGjJOViY2Li48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "orderid", "gp", "sql", 0 );
$_obf_jJGViZKTi5GTjpWGjo6Rkow� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_order where ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'" );
if ( empty( $_obf_jJGViZKTi5GTjpWGjo6Rkow� ) )
{
    exit( "err ordernum." );
}
if ( $_obf_jJGViZKTi5GTjpWGjo6Rkow�['managerid'] != $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'] )
{
    exit( "err userid." );
}
$_obf_iJSMjYqGlZCOh42KiJOTk4o� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_keyset where id=".$_obf_jJGViZKTi5GTjpWGjo6Rkow�['keygroupid'] );
if ( empty( $_obf_iJSMjYqGlZCOh42KiJOTk4o� ) )
{
    exit( "err keygroupid." );
}
$_obf_h4yVkpKPlY_Tk4qVjZKOj4k� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_z_key_".$_obf_jJGViZKTi5GTjpWGjo6Rkow�['pid']."_".$_obf_jJGViZKTi5GTjpWGjo6Rkow�['softid']." where ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'" );
if ( empty( $_obf_h4yVkpKPlY_Tk4qVjZKOj4k� ) )
{
    exit( "err notkey" );
}
$_obf_jZGRipSRkIeUiIeQjoaUjJI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where id=".$_obf_jJGViZKTi5GTjpWGjo6Rkow�['softid'] );
$_obf_jZWKko2SlJWSjYiNjJSHkow� = "key_"._obf_iI6QhpSTiJCJiI_KlYePlZI�( 15 ).".txt";
$_obf_jouJi5CRlZWSlIqGio2MkZA� = "../kss_logs/".$_obf_jZWKko2SlJWSjYiNjJSHkow�;
file_put_contents( $_obf_jouJi5CRlZWSlIqGio2MkZA�, "卡名：".$_obf_iJSMjYqGlZCOh42KiJOTk4o�['keyname']."\r\n" );
file_put_contents( $_obf_jouJi5CRlZWSlIqGio2MkZA�, "天数：".$_obf_iJSMjYqGlZCOh42KiJOTk4o�['cday']."\r\n", FILE_APPEND );
if ( $_obf_iJSMjYqGlZCOh42KiJOTk4o�['points'] != 0 )
{
    file_put_contents( $_obf_jouJi5CRlZWSlIqGio2MkZA�, "点数：".$_obf_iJSMjYqGlZCOh42KiJOTk4o�['points']."\r\n", FILE_APPEND );
}
if ( $_obf_iJSMjYqGlZCOh42KiJOTk4o�['linknum'] != 1 )
{
    file_put_contents( $_obf_jouJi5CRlZWSlIqGio2MkZA�, "通道数：".$_obf_iJSMjYqGlZCOh42KiJOTk4o�['linknum']."\r\n", FILE_APPEND );
}
if ( $_obf_iJSMjYqGlZCOh42KiJOTk4o�['extattr1'] != "" )
{
    file_put_contents( $_obf_jouJi5CRlZWSlIqGio2MkZA�, "附属性：".$_obf_iJSMjYqGlZCOh42KiJOTk4o�['extattr1']."\r\n", FILE_APPEND );
}
$_obf_ioeRj4yHlYeNiouRkoiQj4w� = "\r\n\r\n\r\n";
foreach ( $_obf_h4yVkpKPlY_Tk4qVjZKOj4k� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
{
    $_obf_ioeRj4yHlYeNiouRkoiQj4w� .= $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyfix'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyspassword']."\r\n";
}
file_put_contents( $_obf_jouJi5CRlZWSlIqGio2MkZA�, $_obf_ioeRj4yHlYeNiouRkoiQj4w�, FILE_APPEND );
ob_clean( );
$_obf_k4eLh5CTj42Pjo6MkYyIipA� = file_get_contents( $_obf_jouJi5CRlZWSlIqGio2MkZA� );
$_obf_k46PjYaSioiHiY6OjoaLjpA� = filesize( $_obf_jouJi5CRlZWSlIqGio2MkZA� );
header( "Content-Type: text/plain" );
header( "Expires: ".gmdate( "D, d M Y H:i:s" )." GMT" );
header( "Content-Disposition: attachment; filename=".YH2.$_obf_jZGRipSRkIeUiIeQjoaUjJI�['softname']."_".$_obf_iJSMjYqGlZCOh42KiJOTk4o�['keyname']."_".$_obf_jJGViZKTi5GTjpWGjo6Rkow�['keycount']."张_".$_obf_iJWMjIiVi5OGjJOViY2Li48�.".txt".YH2 );
header( "Cache-Control: must-revalidate, post-check=0, pre-check=0" );
header( "Pragma: public" );
header( "Last-Modified: ".gmdate( "D, d M Y H:i:s" )." GMT" );
header( "Content-Length: ".$_obf_k46PjYaSioiHiY6OjoaLjpA� );
echo $_obf_k4eLh5CTj42Pjo6MkYyIipA�;
unlink( $_obf_jouJi5CRlZWSlIqGio2MkZA� );
exit( );
?>
