<?php

function _obf_homTi4qOh46PiZOPkIqJjog�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 6 );
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 9 )
{
    _obf_lI_NjpSLio_JjZCVh4qUjYc�( );
}
$_obf_k4mViI2Nj4mJkIuUj42JiIY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "op", "gp", "sql", "" );
$_obf_k42Rh4mVlYqGi4mOiZWMjJA� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "page", "gp", "int", 1 );
$_obf_jpKNh4aRh4aQkY2PlIuRhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softid", "gp", "int", 0 );
$_obf_iIyVlIiOhoiMhomQk5GLh5M� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "selcmd", "gp", "sql", "no" );
$_obf_lImLiIqUj5OSipGOko6RlJQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keywords", "gp", "sql", "" );
$_obf_iZOQkZCMkZGGjZCIlZSQi40� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "recycle", "gp", "sql", "" );
if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� != "" && $_obf_iZOQkZCMkZGGjZCIlZSQi40� != "_recycle" )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您传入的参数错误严重！" );
}
if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" && $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "14" ) )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你无权查看回收站！" );
}
$_obf_kYqTiZWUjZKLjZCVlImUi5A� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "managerid", "gp", "int", 0 );
$_obf_kJKTk5WSiI6NiYmHj4_Jkoc� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "morekeys", "gp", "sql", "" );
$_obf_i4uIkYuKkJGQlJKOjoiMj4c� = array(
    "action" => $_obf_lZOThomRipOIi5SRhpWRjY4�
);
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['softid'] = $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['recycle'] = $_obf_iZOQkZCMkZGGjZCIlZSQi40�;
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_ho2NhoaMhoqMlYuLiJSKjo4� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_agentprice where `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id']." and `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
    if ( empty( $_obf_ho2NhoaMhoqMlYuLiJSKjo4� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没有该软件的授权", 1 );
    }
}
$_obf_kIqPhpWOi4yQhpOJlJOUjY0� = array( "锁定", "解锁", "冻结", "解冻", "删除", "还原", "解绑", "下线", "清除", "savetags", "设置标签", "unline" );
$_obf_jZGRipSRkIeUiIeQjoaUjJI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where `id`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
if ( in_array( $_obf_k4mViI2Nj4mJkIuUj42JiIY�, $_obf_kIqPhpWOi4yQhpOJlJOUjY0� ) )
{
    include( dirname( __FILE__ ).DIRECTORY_SEPARATOR."userlist_cmd.php" );
}
$_obf_iI_VhpWIjpSPi4eQj4aTjZE� = $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'];
$_obf_iYqPiJGIjoaVhoaQiI2Ti4w� = "SELECT `id` ";
$_obf_jpCQi4aKkYaIjpSUhpWNipM� = "SELECT * ";
$_obf_homTioySho6Vh5ORiYmUkok� = " where `id` ";
$_obf_kZCPiJCHiI_IlY2Ok4_JlIc� = "SELECT count(*) as tnum ";
$_obf_lJSNlZWKlYmGi4iSkIqHjpA� = "from `kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�.$_obf_iZOQkZCMkZGGjZCIlZSQi40�."` ";
$_obf_h4eJlYuIjpKNio6QkIuJlIY� = array( );
$_obf_lImLiIqUj5OSipGOko6RlJQ� = trim( $_obf_lImLiIqUj5OSipGOko6RlJQ� );
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['selcmd'] = $_obf_iIyVlIiOhoiMhomQk5GLh5M�;
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['keywords'] = $_obf_lImLiIqUj5OSipGOko6RlJQ�;
switch ( $_obf_iIyVlIiOhoiMhomQk5GLh5M� )
{
case "morekeys" :
    $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� = preg_replace( "/(\\r)/", "", $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� );
    $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� = str_replace( "\n\n", "\n", $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� );
    if ( $_obf_iI_VhpWIjpSPi4eQj4aTjZE� == "USOFT" )
    {
        if ( strlen( $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� ) < 3 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没输入任何用户名", 1 );
        }
    }
    else if ( strlen( $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� ) < 32 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没输入任何卡号", 1 );
    }
    $_obf_h5OVi5KSi5OIhpCSk42KiI4� = explode( "\n", $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� );
    $_obf_joeNkJKLko2Hi4aNjomOj4s� = "";
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    $_obf_kYiQkJKGlI6JlZWRioaKlYg� = array( );
    foreach ( $_obf_h5OVi5KSi5OIhpCSk42KiI4� as $_obf_ko2HkJOUh5WSiZKSjomUk4w� )
    {
        if ( $_obf_iI_VhpWIjpSPi4eQj4aTjZE� == "KSOFT" && strlen( $_obf_ko2HkJOUh5WSiZKSjomUk4w� ) == 32 )
        {
            $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 1;
            if ( ZPAGESIZE < $_obf_jpKPlJSUiZOHkYaPlIeOiY4� )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "每次最多只能查询".ZPAGESIZE."条", 1 );
            }
            $_obf_joeNkJKLko2Hi4aNjomOj4s� .= "'".substr( $_obf_ko2HkJOUh5WSiZKSjomUk4w�, 0, 10 )."',";
            $_obf_kYiQkJKGlI6JlZWRioaKlYg�[substr( $_obf_ko2HkJOUh5WSiZKSjomUk4w�, 0, 10 )] = substr( $_obf_ko2HkJOUh5WSiZKSjomUk4w�, 10, 10 );
        }
        else if ( !( $_obf_iI_VhpWIjpSPi4eQj4aTjZE� == "USOFT" ) && !( 2 < _obf_ioqHi5WHiJKIkoeIhouHjYw�( $_obf_ko2HkJOUh5WSiZKSjomUk4w� ) ) )
        {
            $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 1;
            if ( ZPAGESIZE < $_obf_jpKPlJSUiZOHkYaPlIeOiY4� )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "每次最多只能查询".ZPAGESIZE."条", 1 );
            }
            $_obf_joeNkJKLko2Hi4aNjomOj4s� .= "'".$_obf_ko2HkJOUh5WSiZKSjomUk4w�."',";
            $_obf_kYiQkJKGlI6JlZWRioaKlYg�[$_obf_ko2HkJOUh5WSiZKSjomUk4w�] = "";
        }
    }
    if ( $_obf_joeNkJKLko2Hi4aNjomOj4s� == "" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没输入任何要查询的资料", 1 );
    }
    $_obf_joeNkJKLko2Hi4aNjomOj4s� = substr( $_obf_joeNkJKLko2Hi4aNjomOj4s�, 0, strlen( $_obf_joeNkJKLko2Hi4aNjomOj4s� ) - 1 );
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `username` in (".$_obf_joeNkJKLko2Hi4aNjomOj4s�.") ";
    break;
case "keys" :
    if ( $_obf_iI_VhpWIjpSPi4eQj4aTjZE� == "KSOFT" )
    {
        if ( strlen( $_obf_lImLiIqUj5OSipGOko6RlJQ� ) != 32 && strlen( $_obf_lImLiIqUj5OSipGOko6RlJQ� ) != 10 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "输入的注册卡号必须是32位 或 卡号前10位", 1 );
        }
        if ( strlen( $_obf_lImLiIqUj5OSipGOko6RlJQ� ) == 32 )
        {
            $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `username`='".substr( $_obf_lImLiIqUj5OSipGOko6RlJQ�, 0, 10 )."' and `password`='".substr( $_obf_lImLiIqUj5OSipGOko6RlJQ�, 10, 10 )."' ";
        }
        else
        {
            $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `username`='".substr( $_obf_lImLiIqUj5OSipGOko6RlJQ�, 0, 10 )."' ";
        }
    }
    else
    {
        if ( _obf_ioqHi5WHiJKIkoeIhouHjYw�( $_obf_lImLiIqUj5OSipGOko6RlJQ� ) < 2 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "输入的会员名少于2个字符", 1 );
        }
        $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `username` like '".$_obf_lImLiIqUj5OSipGOko6RlJQ�."%' ";
    }
    break;
case "islock" :
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `islock`>0 ";
    break;
case "isonline" :
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['chkonline'] != 1 )
    {
        $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `lasttime`>".( time( ) - 60 * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['connectpenli'] - 300 )."";
    }
    else
    {
        $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `isonline`=1 ";
    }
    break;
case "isend" :
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `endtime`<".time( )." ";
    break;
case "tags" :
    if ( strlen( $_obf_lImLiIqUj5OSipGOko6RlJQ� ) < 1 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "标签最少两位", 1 );
    }
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `tag` like '".$_obf_lImLiIqUj5OSipGOko6RlJQ�."%' ";
    break;
case "bdinfo" :
    if ( strlen( $_obf_lImLiIqUj5OSipGOko6RlJQ� ) < 1 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "绑定信息最少两位", 1 );
    }
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `bdinfo` like '".$_obf_lImLiIqUj5OSipGOko6RlJQ�."%' ";
    break;
case "pccode" :
    if ( strlen( $_obf_lImLiIqUj5OSipGOko6RlJQ� ) < 1 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "机器码最少两位", 1 );
    }
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `pccode` like '".$_obf_lImLiIqUj5OSipGOko6RlJQ�."%' ";
    break;
case "keyextattr" :
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['a'] = " `keyextattr`='".$_obf_lImLiIqUj5OSipGOko6RlJQ�."' ";
}
$_obf_j5OIiY_GkpCLh5CJh5SIlYc� = array( );
$_obf_kIiMk4_SkpOVho2SjoyMjZU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `id`,`username`,`level`,`isdel`,`pmid` from `kss_tb_manager` where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." order by id asc" );
$_obf_ioiKkImNk5KKlZSIjomPkow� = array( );
foreach ( $_obf_kIiMk4_SkpOVho2SjoyMjZU� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
{
    $_obf_j5OIiY_GkpCLh5CJh5SIlYc�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
    if ( 7 < $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level'] )
    {
        $_obf_jJSLkI_TkpSTh5WOiYaTj4g� = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
    }
    if ( !( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 7 ) && !( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'] == $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pmid'] ) )
    {
        $_obf_ioiKkImNk5KKlZSIjomPkow�[] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
    }
}
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_h4eJlYuIjpKNio6QkIuJlIY�['managerid'] = " `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id']." ";
}
else
{
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 7 )
    {
        if ( $_obf_kYqTiZWUjZKLjZCVlImUi5A� == 0 )
        {
            $_obf_kYqTiZWUjZKLjZCVlImUi5A� = -1;
        }
        if ( 0 < $_obf_kYqTiZWUjZKLjZCVlImUi5A� )
        {
            if ( !in_array( $_obf_kYqTiZWUjZKLjZCVlImUi5A�, $_obf_ioiKkImNk5KKlZSIjomPkow� ) )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你似乎越界了", 1 );
            }
            $_obf_h4eJlYuIjpKNio6QkIuJlIY�['managerid'] = " `managerid`=".$_obf_kYqTiZWUjZKLjZCVlImUi5A�." ";
        }
        if ( $_obf_kYqTiZWUjZKLjZCVlImUi5A� == -1 )
        {
            $_obf_i5KHlIeVi4mQlIaOioqTkpE� = implode( ",", $_obf_ioiKkImNk5KKlZSIjomPkow� );
            $_obf_h4eJlYuIjpKNio6QkIuJlIY�['managerid'] = " `managerid` in(".$_obf_i5KHlIeVi4mQlIaOioqTkpE�.") ";
        }
    }
    else
    {
        if ( $_obf_kYqTiZWUjZKLjZCVlImUi5A� == -1 )
        {
            $_obf_h4eJlYuIjpKNio6QkIuJlIY�['managerid'] = " `managerid` <> ".$_obf_jJSLkI_TkpSTh5WOiYaTj4g�." ";
        }
        if ( 0 < $_obf_kYqTiZWUjZKLjZCVlImUi5A� )
        {
            $_obf_h4eJlYuIjpKNio6QkIuJlIY�['managerid'] = " `managerid`=".$_obf_kYqTiZWUjZKLjZCVlImUi5A�." ";
        }
    }
}
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['managerid'] = $_obf_kYqTiZWUjZKLjZCVlImUi5A�;
$_obf_j4mJh4aKjZKHhpOSiJKSjJI� = "";
if ( !empty( $_obf_h4eJlYuIjpKNio6QkIuJlIY� ) )
{
    $_obf_j4mJh4aKjZKHhpOSiJKSjJI� = " where".implode( " and ", $_obf_h4eJlYuIjpKNio6QkIuJlIY� );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_lI_KipSOk4iQkI_MjIuVkpQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "recordnum", "gp", "int", 0 );
if ( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� == 1 )
{
    $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( $_obf_kZCPiJCHiI_IlY2Ok4_JlIc�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI� );
    $_obf_lI_KipSOk4iQkI_MjIuVkpQ� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
}
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['recordnum'] = $_obf_lI_KipSOk4iQkI_MjIuVkpQ�;
$_obf_jIiNjZCPkoeUjI2LipCQk5Q� = abs( floor( $_obf_lI_KipSOk4iQkI_MjIuVkpQ� / ZPAGESIZE * -1 ) );
$_obf_iZWHjpGQkoqPlYmJjYmIhpU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
echo "<textarea id=viewsql>";
echo htmlspecialchars( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
echo "\r\n";
$_obf_iIiHi4aTkoySkpCNio_UjYo� = "";
$_obf_j4aSkImMlYyRiY6Mho2VkZM� = "";
if ( !empty( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� ) )
{
    foreach ( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� as $_obf_kYqOi5CTjoySj4mIkYmIlY4� )
    {
        $_obf_iIiHi4aTkoySkpCNio_UjYo� .= $_obf_kYqOi5CTjoySj4mIkYmIlY4�['id'].",";
        $_obf_j4aSkImMlYyRiY6Mho2VkZM� = "=".$_obf_kYqOi5CTjoySj4mIkYmIlY4�['id'];
    }
    $_obf_iIiHi4aTkoySkpCNio_UjYo� = substr( $_obf_iIiHi4aTkoySkpCNio_UjYo�, 0, strlen( $_obf_iIiHi4aTkoySkpCNio_UjYo� ) - 1 );
}
$_obf_iYeIjIaVlYaIj4yTiJWHk40� = FALSE;
$_obf_koeUkImOlYeQiZSJkZWPiJU� = "";
if ( $_obf_iIiHi4aTkoySkpCNio_UjYo� != "" )
{
    $_obf_homTioySho6Vh5ORiYmUkok� .= 1 < count( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� ) ? " in (".$_obf_iIiHi4aTkoySkpCNio_UjYo�.")" : $_obf_j4aSkImMlYyRiY6Mho2VkZM�;
    if ( $_obf_iIyVlIiOhoiMhomQk5GLh5M� == "morekeys" && $_obf_iI_VhpWIjpSPi4eQj4aTjZE� == "KSOFT" )
    {
        $_obf_jY_UkIyPh4eOi4uNioaVkJQ� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "SELECT `id`,`username`,`password` ".$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
        echo htmlspecialchars( "SELECT `id`,`username`,`password` ".$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
        echo "\r\n";
        $_obf_iIiHi4aTkoySkpCNio_UjYo� = "";
        foreach ( $_obf_jY_UkIyPh4eOi4uNioaVkJQ� as $_obf_homIkYiRk5SSlImKk4_Jho8� )
        {
            if ( $_obf_kYiQkJKGlI6JlZWRioaKlYg�[$_obf_homIkYiRk5SSlImKk4_Jho8�['username']] != $_obf_homIkYiRk5SSlImKk4_Jho8�['password'] )
            {
                $_obf_koeUkImOlYeQiZSJkZWPiJU� .= $_obf_homIkYiRk5SSlImKk4_Jho8�['username'].$_obf_kYiQkJKGlI6JlZWRioaKlYg�[$_obf_homIkYiRk5SSlImKk4_Jho8�['username']]."\r\n";
                $_obf_lI_KipSOk4iQkI_MjIuVkpQ� -= 1;
            }
            else
            {
                $_obf_iIiHi4aTkoySkpCNio_UjYo� .= $_obf_homIkYiRk5SSlImKk4_Jho8�['id'].",";
                $_obf_j4aSkImMlYyRiY6Mho2VkZM� = "=".$_obf_homIkYiRk5SSlImKk4_Jho8�['id'];
            }
        }
        $_obf_iIiHi4aTkoySkpCNio_UjYo� = substr( $_obf_iIiHi4aTkoySkpCNio_UjYo�, 0, strlen( $_obf_iIiHi4aTkoySkpCNio_UjYo� ) - 1 );
        $_obf_homTioySho6Vh5ORiYmUkok� = " where `id` ".( 1 < $_obf_lI_KipSOk4iQkI_MjIuVkpQ� ? " in (".$_obf_iIiHi4aTkoySkpCNio_UjYo�.")" : $_obf_j4aSkImMlYyRiY6Mho2VkZM� );
    }
    $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
    echo htmlspecialchars( $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_k4yVk4iOipWPioqJlIuVkpE� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iouHh42RkIeKkYaSipWKiog�( $_obf_k42Rh4mVlYqGi4mOiZWMjJA�, $_obf_jIiNjZCPkoeUjI2LipCQk5Q�, $_obf_i4uIkYuKkJGQlJKOjoiMj4c� )."<span class=page_nav_a>".$_obf_lI_KipSOk4iQkI_MjIuVkpQ�."行  耗时"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_lJKOiJSHjo_Sj4yKk4aIh5I� )."毫秒</span>";
echo "</textarea><script type=\"text/javascript\">\r\nvar mylevel=";
echo $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'];
echo ";\r\nvar smode='";
echo $_obf_iI_VhpWIjpSPi4eQj4aTjZE�;
echo "';\r\nvar softid=";
echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
echo ";\r\n\r\n\r\n</script>\r\n\r\n<script type=\"text/javascript\" src=\"";
echo INSTALLPATH;
echo "kss_inc/js/k/userlist.js?20170102\" charset=\"utf-8\"></script>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<form id=\"find_key\" action=\"?action=userlist&softid=";
echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
echo "\" method=\"post\">\r\n<tr>\r\n<td class=\"findorpage\">\r\n";
if ( 7 < $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] || _obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "14" ) )
{
    echo "<input type='checkbox' name='recycle' value='_recycle' id='recycle' ".( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" ? " checked" : "" )." /><label for='recycle'>回收站</label> &nbsp;&nbsp;";
}
echo "<select id=\"selcmd\" name=\"selcmd\">\r\n";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    echo "<option value='no'>所有</option>";
}
else
{
    echo "<option value='no'>所属</option>";
}
echo "<option value='keys' ";
echo $_obf_iIyVlIiOhoiMhomQk5GLh5M� == "keys" ? " selected" : "";
echo ">";
echo $_obf_iI_VhpWIjpSPi4eQj4aTjZE� == "KSOFT" ? "注册卡号" : "用户名";
echo "</option>\t\t\t\r\n<option value='tags' ";
echo $_obf_iIyVlIiOhoiMhomQk5GLh5M� == "tags" ? " selected" : "";
echo ">标签</option>\r\n<option value='bdinfo' ";
echo $_obf_iIyVlIiOhoiMhomQk5GLh5M� == "bdinfo" ? " selected" : "";
echo ">绑定信息</option>\r\n<option value='keyextattr' ";
echo $_obf_iIyVlIiOhoiMhomQk5GLh5M� == "keyextattr" ? " selected" : "";
echo ">用户附属性</option>\r\n<option value='pccode' ";
echo $_obf_iIyVlIiOhoiMhomQk5GLh5M� == "pccode" ? " selected" : "";
echo ">机器码</option>\r\n<option value='isonline' ";
echo $_obf_iIyVlIiOhoiMhomQk5GLh5M� == "isonline" ? " selected" : "";
echo ">在线的用户</option>\r\n<option value='islock' style=\"background:#F6D892\"";
echo $_obf_iIyVlIiOhoiMhomQk5GLh5M� == "islock" ? " selected" : "";
echo ">被锁定的用户</option>\r\n<option value='isend' style='background:#FAD4CB' ";
echo $_obf_iIyVlIiOhoiMhomQk5GLh5M� == "isend" ? " selected" : "";
echo ">过期的用户</option>\r\n<option value='morekeys' ";
echo $_obf_iIyVlIiOhoiMhomQk5GLh5M� == "morekeys" ? " selected" : "";
echo ">";
echo $_obf_iI_VhpWIjpSPi4eQj4aTjZE� == "USOFT" ? "批量查询用户" : "批量查询注册卡";
echo "</option>\r\n</select>\r\n<input style=\"display:none\" type=text id=\"keywords\" name=\"keywords\" value=\"";
echo $_obf_lImLiIqUj5OSipGOko6RlJQ�;
echo "\">\r\n";
if ( 6 < $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] )
{
    echo "\t\t<select id='managerid' name='managerid'>";
    if ( 7 < $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] )
    {
        echo "\t\t\t<option value=0>所有后台用户</option>\r\n";
    }
    echo "\t\t\t<option value=-1 ";
    echo $_obf_kYqTiZWUjZKLjZCVlImUi5A� == -1 ? " selected" : "";
    echo ">所有代理</option>\r\n";
    foreach ( $_obf_kIiMk4_SkpOVho2SjoyMjZU� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['isdel'] != 1 )
        {
            if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 7 )
            {
                if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'] == $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pmid'] )
                {
                    echo "\t\t\t<option value='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."' ";
                    echo $_obf_kYqTiZWUjZKLjZCVlImUi5A� == $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] ? " selected" : "";
                    echo ">".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."[".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level']]."]</option>";
                }
            }
            else
            {
                echo "\t\t\t<option value='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."' ";
                echo $_obf_kYqTiZWUjZKLjZCVlImUi5A� == $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] ? " selected" : "";
                echo ">".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."[".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level']]."]</option>";
            }
        }
    }
    echo "\t\t</select>";
}
if ( $_obf_iI_VhpWIjpSPi4eQj4aTjZE� == "USOFT" )
{
    $_obf_kI2Ri4iLjoaMioyTiIaPjJA� = "用户名";
}
else
{
    $_obf_kI2Ri4iLjoaMioyTiIaPjJA� = "注册卡号";
}
echo "<input type=\"submit\" name=\"submit\" class=\"submitbtn\" value=\"搜索\" />\r\n<div id=\"morekeys\">每行一个";
echo $_obf_kI2Ri4iLjoaMioyTiIaPjJA�;
echo "，每次最多只允许查询";
echo ZPAGESIZE;
echo "行<br><textarea id=\"morekeystextarea\" style=\"display:block;width:500px;height:100px;margin:5px 0 0 0;font-family:Fixedsys,Arial,Verdana;color:#333\" name=\"morekeys\">";
echo htmlspecialchars( $_obf_kJKTk5WSiI6NiYmHj4_Jkoc� );
echo "</textarea>";
if ( $_obf_koeUkImOlYeQiZSJkZWPiJU� != "" )
{
    echo "未找到的注册卡<br><textarea  style='display:block;width:500px;height:50px;margin:5px 0 0 0;font-family:Fixedsys,Arial,Verdana;color:#333'>".$_obf_koeUkImOlYeQiZSJkZWPiJU�."</textarea>";
}
echo "</div>\r\n</td>\r\n</tr>\r\n</form>\r\n</table>\r\n\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n\r\n";
if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� != "_recycle" || 7 < $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] )
{
    echo "<form id=\"userlist\" action=\"?action=userlist&softid=";
    echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
    echo "&isajax=1\" method=\"post\">\r\n";
}
echo "<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr class=\"trhead\">\r\n<td malt=\"ID号\">ID</td>\r\n<td nowrap=\"nowrap\" malt=\"";
echo $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" ? "执行删除操作的管理用户" : "可以查看修改用户信息、查看用户使用日志、锁定与解锁用户、作者还可删除用户";
echo "\">操作</td>\r\n<td nowrap=\"nowrap\" malt=\"红色表示在线，如果软件参数设置勾选了登陆标识，用户被卡在线上可以点击红色小方块强制在线为离线状态\">状</td>\r\n";
if ( $_obf_iI_VhpWIjpSPi4eQj4aTjZE� == "USOFT" )
{
    echo "<td nowrap='nowrap' malt='用户名'>用户名</td><td nowrap='nowrap' malt='用户充值的卡号数量'>卡数</td>";
}
else
{
    echo "<td nowrap='nowrap' malt='注册卡号'>注册卡号</td>";
}
echo "<td nowrap='nowrap' malt='用户连接服务器验证的次数'>验证</td>\t\t\r\n<td nowrap=\"nowrap\" malt=\"可修改，主要是方便用户管理注册卡，给用户备注一些信息\">标签</td>\t\t\r\n<td nowrap=\"nowrap\" malt=\"用户自激活日期算起的可使用天数\">天数</td>\r\n<td nowrap=\"nowrap\" malt=\"在某些软件里，你可能要按点计费，该点数是按点扣费的基础功能\">点数</td>\r\n<td nowrap=\"nowrap\" malt=\"通道数大于1的，客户可用同一注册卡/帐号和不同的通道号，同时在不同的电脑上登陆\">通道</td>\r\n<td nowrap=\"nowrap\" malt=\"绑定信息可修改，你可以通过软件参数来控制客户能否在客户端通过API来修改该信息\">绑定信息</td>\r\n<td nowrap=\"nowrap\" malt=\"附属性不可以修改，客户登陆后可以取得该属性，你可以利用该属性来实现不同属性可使用不同的客户端软件功能<br>为防止附属性太长破坏界面，附属性放在文本框中显示\">附属性</td>\r\n<td nowrap=\"nowrap\" malt=\"该注册卡是属于哪一个后台帐号的\">所属</td>\r\n<td nowrap=\"nowrap\" malt=\"用户到期日期\">到期日期</td>\r\n";
if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
{
    echo "<td malt='该用户被删除的日期'>删除日期</td>";
}
else
{
    echo "<td malt='该用户激活的日期'>激活日期</td>";
}
echo "\t\t\r\n</tr>\r\n";
if ( empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
{
    echo "<tr nodata=1 class=trd><td colspan=15>无任何信息</td></tr>";
}
else
{
    foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['bdinfo'] = _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['bdinfo'] );
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pccode'] = _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pccode'] );
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'] = _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'] );
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyextattr'] = _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyextattr'] );
        echo "<tr class='".( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] < time( ) ? "trdisend" : 0 < $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['islock'] ? "trdislock" : $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] == PETIME ? "trdpubuser" : "trd" )."' id='trd";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        echo "' malt='[table][tr][td class=vth]会员名[/td][td class=vtd]".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."[/td][td class=vth]密码[/td][td class=vtd]";
        if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "18" ) )
        {
            echo "******";
        }
        else
        {
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['password'];
        }
        echo "[/td][td class=vth]安全密码[/td][td class=vtd]";
        if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "13" ) )
        {
            echo "******";
        }
        else
        {
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['password2'];
        }
        echo "[/td][td class=vth]冻结日期[/td][td class=vtd]".( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pausetime'] != 0 ? date( "Y-m-d H:i", $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pausetime'] ) : "-" )."[/td][td class=vth]备注[/td][td class=vtd]".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['intro']."[/td][td class=vth]使用过体验卡[/td][td class=vtd]".( 0 < $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['isusetestkey'] ? "是" : "否" )."[/td][td class=vth]私有数据[/td][td class=vtd]".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['updata']."[/td][/tr][tr][td class=vth]机器码[/td][td class=vtd]".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pccode']."[/td][td class=vth]绑定信息[/td][td class=vtd]".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['bdinfo']."[/td][td class=vth]上次验证日期[/td][td class=vtd]"._obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['lasttime'] )."[/td][td class=vth]上次验证IP[/td][td class=vtd]".long2ip( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['lastip'] )."[/td][td class=vth]推广帐号[/td][td class=vtd]".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['parentuser']."[/td][td class=vth]解绑次数[/td][td class=vtd]";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unlockday'] == date( "d" ) ? $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['unlocktimes'] : 0;
        echo "[/td][td class=vth]-[/td][td class=vtd]-[/td][/tr][/table]'><td nowrap='nowrap' style='cursor:pointer'><input type='checkbox' name='keys[]' value='";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        echo "' id='check";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        echo "'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "</td><td nowrap='nowrap'><img class=edituser malt='编辑用户信息' src=";
        echo INSTALLPATH;
        echo "kss_inc/images/b_edit.png>&nbsp;&nbsp;<img class=viewlog malt='查看用户使用日志' src=";
        echo INSTALLPATH;
        echo "kss_inc/images/b_calendar.png>";
        if ( $_obf_iI_VhpWIjpSPi4eQj4aTjZE� == "USOFT" )
        {
            echo "&nbsp;&nbsp;<img class=viewczlog malt='查看用户充值日志' src=";
            echo INSTALLPATH;
            echo "kss_inc/images/b_rmb.png>";
        }
        if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
        {
            echo isset( $_obf_j5OIiY_GkpCLh5CJh5SIlYc�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['delmid']] ) ? $_obf_j5OIiY_GkpCLh5CJh5SIlYc�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['delmid']] : "";
        }
        else
        {
            echo "&nbsp;&nbsp;<img class='hand' malt='锁级别：".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['islock'].",  点击此按钮锁定或解锁用户或注册卡'  op='".( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['islock'] == 0 ? "锁定" : "解锁" )."' lock='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['islock']."' src='".INSTALLPATH."kss_inc/images/".( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['islock'] == 0 ? "b_usrcheck.png" : "b_uncheck.png" )."'>";
            echo "&nbsp;&nbsp;<img class='hand' malt='冰结级别：".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ispause'].",  点击此按钮冻结或解冻用户或注册卡，冻结后不计时'  op='".( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ispause'] == 0 ? "冻结" : "解冻" )."' pause='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ispause']."' src='".INSTALLPATH."kss_inc/images/".( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ispause'] == 0 ? "b_pause.png" : "b_unpause.png" )."'>";
            if ( 7 < $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] )
            {
                echo "&nbsp;&nbsp;<img class='hand' malt='点击将该注册卡放入回收站'  op='删除' src='".INSTALLPATH."kss_inc/images/b_empty.png'>";
            }
        }
        echo "</td>";
        if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['chkonline'] == 0 )
        {
            $_obf_jpKIj4yRlZGKjYmOioqHjpQ� = time( ) < $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['lasttime'] + 60 * ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['connectpenli'] + 1 ) ? "'online1' title='在线'" : "'online0' title='不在线'";
        }
        else if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['isonline'] == 1 )
        {
            if ( time( ) < $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['lasttime'] + 60 * $_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinetime'] )
            {
                $_obf_jpKIj4yRlZGKjYmOioqHjpQ� = "'online2' title='在线，单击可强制设置为离线'";
            }
            else
            {
                $_obf_jpKIj4yRlZGKjYmOioqHjpQ� = "'online3' title='在线，已经".$_obf_jZGRipSRkIeUiIeQjoaUjJI�['outlinetime']."分钟没有连接服务器验证，单击可强制设置为离线'";
            }
        }
        else
        {
            $_obf_jpKIj4yRlZGKjYmOioqHjpQ� = "'online0' title='不在线'";
        }
        echo "<td><span class=".$_obf_jpKIj4yRlZGKjYmOioqHjpQ�.">◆</span></td>";
        if ( $_obf_iI_VhpWIjpSPi4eQj4aTjZE� == "USOFT" )
        {
            echo "<td nowrap='nowrap' id='copy_"._obf_iI6QhpSTiJCJiI_KlYePlZI�( 16 )."' class='keynum' copyt='";
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
            echo "'>";
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
            echo "</td><td nowrap='nowrap'><a href='javascript:void(0)'  onclick=";
            echo YH2;
            echo "dwin('user_key1_";
            echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
            echo "','";
            echo $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softname'];
            echo "注册卡列表','admin_key.php?action=keylist&softid=";
            echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
            echo "&selcmd=czusername&keywords='+encodeURIComponent('".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."'))";
            echo YH2;
            echo ">";
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cztimes'];
            echo "</td>";
        }
        else
        {
            echo "<td nowrap='nowrap' id='copy_"._obf_iI6QhpSTiJCJiI_KlYePlZI�( 16 )."' class='keynum' copyt='";
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['password'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['password2'];
            echo "'>";
            echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'].substr( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['password'], 18 );
            echo "</td>";
        }
        echo "<td>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['activetimes'];
        echo "</td><td nowrap='nowrap'><input type=text class=viewinput  maxlength='50' oldval='";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['tag'];
        echo "'";
        echo $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" ? " Readonly" : "";
        echo " value='";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['tag'];
        echo "'>";
        echo $_obf_iZOQkZCMkZGGjZCIlZSQi40� != "_recycle" ? "<input type='button' class='savetag' value=''>" : "";
        echo "</td><td nowrap='nowrap' aj='cday";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        echo "'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cday'] * 1;
        echo "</td><td aj='points";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        echo "'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['points'];
        echo "</td><td><img aj='imglinknum";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        echo "' ";
        echo 1 < $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linknum'] ? "class=viewipc malt='查看各通道信息' " : "malt='单通道' ";
        echo "src=";
        echo INSTALLPATH;
        echo "kss_inc/images/b_view2.png><span aj='linknum";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        echo "'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linknum'];
        echo "</span></td><td><input type=text class=viewinput Readonly aj='bdinfo";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        echo "'  value='";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['bdinfo'];
        echo "'></td><td><input type=text class=viewinput Readonly aj='keyextattr";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        echo "' value='";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyextattr'];
        echo "'></td><td nowrap='nowrap'>";
        echo $_obf_j5OIiY_GkpCLh5CJh5SIlYc�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['managerid']];
        echo "</td><td aj='endtime";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        echo "'>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] == PETIME ? "无限期" : _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'], "Y-m-d H:i" );
        echo "</td><td nowrap='nowrap'>";
        echo _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" ? $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['deltime'] : $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['starttime'], "Y-m-d H:i" );
        echo "</td></tr>\r\n";
    }
}
echo "</table>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr>\r\n<td class=\"findorpage\">\r\n<input type=\"hidden\" alt=\"ajax提交必须添加此项\" name=\"isajax\" value=\"1\" />\r\n<img  src=\"";
echo INSTALLPATH;
echo "kss_inc/images/arrow_ltr.png\" style=\"vertical-align:middle\"><input type=\"button\" name=\"chkall\" id=\"chkall\" value=\"全选/反选\" class=\"submitbtn\"> ━▶\r\n";
if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
{
    if ( 7 < $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] )
    {
        echo "&nbsp;&nbsp;<input type='submit' name='op' id='recoverykey' malt='将选中的卡号从回收站表还原到注册卡表中去' value='还原' class='submitbtn'>";
    }
}
else
{
    echo "&nbsp;&nbsp;<input type='submit' name='op' id='lockkey' malt='将选中的用户锁定，锁定后用户不能登陆' value='锁定' class='submitbtn'>&nbsp;&nbsp;<input type='submit' name='op' id='unlockkey' malt='将选中的用户解锁' value='解锁' class='submitbtn'>&nbsp;&nbsp;<input type='submit' name='op' id='pausekey' malt='将选中的用户冻结，冻结后用户不能登陆' value='冻结' class='submitbtn'>&nbsp;&nbsp;<input type='submit' name='op' id='unpausekey' malt='将选中的用户解冻' value='解冻' class='submitbtn'>&nbsp;&nbsp;<input type='submit' name='op' id='unbindkey' malt='将选中的用户解绑，即清空用户机器码' value='解绑' class='submitbtn'>";
    if ( 7 < $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] || _obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], 52 ) )
    {
        echo "&nbsp;&nbsp;<input type='submit' name='op' id='delkey' malt='将选中的卡号移动到回收站中去' value='删除' class='submitbtn'>";
    }
    echo "&nbsp;&nbsp;<input type='submit' name='op' id='setalltag' malt='将选中的卡号标签都设置为指定值' value='设置标签' class='submitbtn'>━▶<input maxlength='50' type=text id='newtag' name='newtag' class=viewinput value=''>";
}
echo "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style=\"color:red;font-weight:700\">友情提示：锁定后用户还在计时，冻结后不计时。如若想冻结所有用户时间，请到软件参数设置的基本页设置软件状态为冻结的相关状态。软件由冻结状态转为非冻结状态（也就是软件解冻操作)时，单独冻结的用户不会解冻）</span>\t\t\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n";
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
echo "<div id=pageruntime>页面运行时间"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_i5GVjZWQj4ePkJKMjJSRipM� )."毫秒</div>";
echo "<div id=\"altmsg001\" style=\"position:absolute;top:30px;left:80px;\"><img src=\"../kss_inc/images/altmsg001.gif\"></div>\r\n<script>\r\n\$(document).ready(function(){ \r\n\$('#altmsg001').bind(\"mouseover\",function(){\$(this).hide();})\r\n});\r\n</script>\r\n</body>\r\n</html>";
?>
