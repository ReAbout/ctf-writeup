<?php

function _obf_iJWLj5SHi4_NlImIlYeGkYg�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
switch ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� )
{
case "unline" :
    if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你真聪明，绕到这来了" );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_jImKk4yQkouLiZKUiJCGkIw� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "clientid", "gp", "int", 0 );
    $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = "";
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
    {
        $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = " and `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."'";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."')";
    }
    $_obf_iZGMi5SQk5SIjZWUj4uHj5Q� = "user";
    if ( $_obf_jImKk4yQkouLiZKUiJCGkIw� != 0 )
    {
        $_obf_iZGMi5SQk5SIjZWUj4uHj5Q� = "client";
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� .= " and clientid=".$_obf_jImKk4yQkouLiZKUiJCGkIw�;
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_".$_obf_iZGMi5SQk5SIjZWUj4uHj5Q�."_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `isonline`=0 where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�.$_obf_jYaSi46HjY6Jj4qKi5WPlIo�, "sync" );
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok" );
case "锁定" :
case "解锁" :
    if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你真聪明，绕到这来了" );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = "";
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
    {
        $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = " and `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."'";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."')";
    }
    $_obf_jJOHiIqRiYmTkJKPhpWTipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `username`,`islock` from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�.$_obf_jYaSi46HjY6Jj4qKi5WPlIo�." and `islock`<".( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] - 4 ) );
    if ( empty( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您没有权限对选择的用户执行锁定或解锁操作！<br>可能是你选择的会员已被高于你级别的管理锁定。" );
    }
    if ( count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) != count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) )
    {
        $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "你提交".$_obf_k4mViI2Nj4mJkIuUj42JiIY�.count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."个用户的操作请求，只有".count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� )."条被处理";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = "";
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."',";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = substr( $_obf_kYqNjZWRkI6OhomJjoqHjoY�, 0, strlen( $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) - 1 );
    $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in (".$_obf_kYqNjZWRkI6OhomJjoqHjoY�.")";
    $_obf_k5KIjYeHhoyOkoiKiJSOh5I� = $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] - 5;
    $_obf_k5KIjYeHhoyOkoiKiJSOh5I� = 3 < $_obf_k5KIjYeHhoyOkoiKiJSOh5I� ? 3 : $_obf_k5KIjYeHhoyOkoiKiJSOh5I�;
    if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == "锁定" )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `islock`=".$_obf_k5KIjYeHhoyOkoiKiJSOh5I�." where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok1,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    else
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `islock`=0 where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok0,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    break;
case "冻结" :
case "解冻" :
    if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你真聪明，绕到这来了" );
    }
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "22" ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没有".$_obf_k4mViI2Nj4mJkIuUj42JiIY�."权限" );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 6 || $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softstatus'] == 5 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "软件冻结期间，禁止单独对用户进行冻结与解冻操作！" );
    }
    $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = "";
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
    {
        $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = " and `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."'";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."')";
    }
    $_obf_jJOHiIqRiYmTkJKPhpWTipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `username`,`ispause`,`endtime`,`pausetime`,`starttime` from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�.$_obf_jYaSi46HjY6Jj4qKi5WPlIo�." and `ispause`<".( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] - 4 ) );
    if ( empty( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您没有权限对选择的用户执行冻结或解冻操作！<br>可能是你选择的会员已被高于你级别的管理冻结。" );
    }
    if ( count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) != count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) )
    {
        $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "你提交".$_obf_k4mViI2Nj4mJkIuUj42JiIY�.count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."个用户的操作请求，只有".count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� )."条被处理";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = "";
    $_obf_hoyOlIqVio2RkIiMlI_VhpQ� = "";
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] != PETIME )
        {
            if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == "冻结" )
            {
                if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['ispause'] == 0 )
                {
                    $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."',";
                }
            }
            else if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['starttime'] < $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pausetime'] )
            {
                $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."',";
            }
        }
        else
        {
            $_obf_hoyOlIqVio2RkIiMlI_VhpQ� = "公用帐号不允许".$_obf_k4mViI2Nj4mJkIuUj42JiIY�;
        }
    }
    if ( $_obf_kYqNjZWRkI6OhomJjoqHjoY� == "" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "没有找到能操作的数据。".$_obf_hoyOlIqVio2RkIiMlI_VhpQ� );
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = substr( $_obf_kYqNjZWRkI6OhomJjoqHjoY�, 0, strlen( $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) - 1 );
    $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in (".$_obf_kYqNjZWRkI6OhomJjoqHjoY�.")";
    $_obf_k5KIjYeHhoyOkoiKiJSOh5I� = $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] - 5;
    $_obf_k5KIjYeHhoyOkoiKiJSOh5I� = 3 < $_obf_k5KIjYeHhoyOkoiKiJSOh5I� ? 3 : $_obf_k5KIjYeHhoyOkoiKiJSOh5I�;
    if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == "冻结" )
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `ispause`=".$_obf_k5KIjYeHhoyOkoiKiJSOh5I�.",`pausetime`='".time( )."' where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�;
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok6,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    else
    {
        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `ispause`=0,starttime=starttime+".time( )."-pausetime,endtime=endtime+".time( )."-pausetime,pausetime=0 where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�;
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "sync" );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok7,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    break;
case "解绑" :
    if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你真聪明，绕到这来了" );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = "";
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "17" ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没有解绑权限" );
    }
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
    {
        $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = " and `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."'";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."')";
    }
    $_obf_jJOHiIqRiYmTkJKPhpWTipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `username`,`islock` from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�.$_obf_jYaSi46HjY6Jj4qKi5WPlIo� );
    if ( empty( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你选择的用户好像都不存在或是您没有权限对选择的用户执行操作！" );
    }
    if ( count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) != count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) )
    {
        $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "你提交".count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."个会员的设置标签操作的请求，只有".count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� )."个被处理";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = "";
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."',";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = substr( $_obf_kYqNjZWRkI6OhomJjoqHjoY�, 0, strlen( $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) - 1 );
    $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in (".$_obf_kYqNjZWRkI6OhomJjoqHjoY�.")";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `pccode`='' where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_client_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set id=1 where id=0", "notsync" );
        if ( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lI6Gio6PjomOj4mRjoaUjoY�( ) == 1146 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok9,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
        }
        else
        {
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_client_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `pccode`='' where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok9,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
            }
        }
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), 1 );
    break;
case "删除" :
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你真聪明，绕到这来了" );
    }
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'], "52" ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您无权限执行删除操作！", 1 );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."'";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."')";
    }
    $_obf_jJOHiIqRiYmTkJKPhpWTipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `username`,`islock`,`endtime` from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok� );
    if ( empty( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你选择的用户好像都不存在！" );
    }
    if ( count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) != count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) )
    {
        $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "你提交".$_obf_k4mViI2Nj4mJkIuUj42JiIY�.count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."个用户的操作请求，只找到".count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� )."个用户";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = "";
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."',";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = substr( $_obf_kYqNjZWRkI6OhomJjoqHjoY�, 0, strlen( $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) - 1 );
    $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in (".$_obf_kYqNjZWRkI6OhomJjoqHjoY�.")";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "replace into kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle (`istempuser`,`managerid`,`username`,`password`,`password2`,`cday`,`linknum`,`points`,`keyextattr`,`islock`,`tag`,`bdinfo`,`linecode`,`pccode`,`addtime`,`starttime`,`endtime`,`lasttime`,`isonline`,`lastip`,`activetimes`,`unlocktimes`,`unlockday`,`cztimes`,`isusetestkey`,`parentuser`,`intro`,`updata`,`deltime`,`delmid`) select `istempuser`,`managerid`,`username`,`password`,`password2`,`cday`,`linknum`,`points`,`keyextattr`,`islock`,`tag`,`bdinfo`,`linecode`,`pccode`,`addtime`,`starttime`,`endtime`,`lasttime`,`isonline`,`lastip`,`activetimes`,`unlocktimes`,`unlockday`,`cztimes`,`isusetestkey`,`parentuser`,`intro`,`updata`,".time( ).",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id']." from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� == $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where  `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE && $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok3,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), 1 );
    break;
case "savetags" :
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = "";
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_lYqOkIyVi5WGhoqLhouThoo� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "tags", "gp", "sqljs", "" );
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
    {
        $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = " and `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�.$_obf_iZOQkZCMkZGGjZCIlZSQi40�." set `tag`='".$_obf_lYqOkIyVi5WGhoqLhouThoo�."' where `username`='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."'".$_obf_jYaSi46HjY6Jj4qKi5WPlIo�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok" );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
case "设置标签" :
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    if ( $_obf_iZOQkZCMkZGGjZCIlZSQi40� == "_recycle" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你真聪明，绕到这来了" );
    }
    $_obf_ipCVkZKKi4eSjIuTlZSVho8� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "newtag", "gp", "sqljs", "" );
    if ( 50 < _obf_ioqHi5WHiJKIkoeIhouHjYw�( $_obf_ipCVkZKKi4eSjIuTlZSVho8� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "标签最大长度50个字符！", 1 );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = "";
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
    {
        $_obf_jYaSi46HjY6Jj4qKi5WPlIo� = " and `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."'";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."')";
    }
    $_obf_jJOHiIqRiYmTkJKPhpWTipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `username`,`islock` from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�.$_obf_jYaSi46HjY6Jj4qKi5WPlIo� );
    if ( empty( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你选择的卡好像都不存在或是您没有权限对选择的注册卡执行操作！" );
    }
    if ( count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) != count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) )
    {
        $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "你提交".count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."个会员的设置标签操作的请求，只有".count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� )."个被处理";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = "";
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."',";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = substr( $_obf_kYqNjZWRkI6OhomJjoqHjoY�, 0, strlen( $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) - 1 );
    $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in (".$_obf_kYqNjZWRkI6OhomJjoqHjoY�.")";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set `tag`='".$_obf_ipCVkZKKi4eSjIuTlZSVho8�."' where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok4,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), 1 );
    break;
case "还原" :
    _obf_kY6LiJGJiIiRiIuRjomOiZA�( );
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "只有作者级别的才可以还原数据" );
    }
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
    $_obf_j5WKlJOMkIyQjoePlYuSjJE� = explode( ",", $_obf_j5WKlJOMkIyQjoePlYuSjJE� );
    $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "";
    if ( count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) == 1 )
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = "='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�[0]."'";
    }
    else
    {
        $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in ('".implode( "','", $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."')";
    }
    $_obf_jJOHiIqRiYmTkJKPhpWTipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `username`,`islock` from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok� );
    if ( empty( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你选择的会员好像都不存在！" );
    }
    if ( count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� ) != count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� ) )
    {
        $_obf_iJKJjIuNk4mIjZKVjYmIhpQ� = "你提交".$_obf_k4mViI2Nj4mJkIuUj42JiIY�.count( $_obf_j5WKlJOMkIyQjoePlYuSjJE� )."个会员的操作请求，只找到".count( $_obf_jJOHiIqRiYmTkJKPhpWTipM� )."个会员";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = "";
    foreach ( $_obf_jJOHiIqRiYmTkJKPhpWTipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_kYqNjZWRkI6OhomJjoqHjoY� .= "'".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."',";
    }
    $_obf_kYqNjZWRkI6OhomJjoqHjoY� = substr( $_obf_kYqNjZWRkI6OhomJjoqHjoY�, 0, strlen( $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) - 1 );
    $_obf_k4iLiZOSjJWRlIqLiYaPiok� = " in (".$_obf_kYqNjZWRkI6OhomJjoqHjoY�.")";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "replace into kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." (`managerid`,`username`,`password`,`password2`,`cday`,`linknum`,`points`,`keyextattr`,`islock`,`tag`,`bdinfo`,`linecode`,`pccode`,`addtime`,`starttime`,`endtime`,`lasttime`,`isonline`,`lastip`,`activetimes`,`unlocktimes`,`unlockday`,`cztimes`,`isusetestkey`,`parentuser`,`intro`,`updata`) select `managerid`,`username`,`password`,`password2`,`cday`,`linknum`,`points`,`keyextattr`,`islock`,`tag`,`bdinfo`,`linecode`,`pccode`,`addtime`,`starttime`,`endtime`,`lasttime`,`isonline`,`lastip`,`activetimes`,`unlocktimes`,`unlockday`,`cztimes`,`isusetestkey`,`parentuser`,`intro`,`updata` from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle where `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� == $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle where  `username`".$_obf_k4iLiZOSjJWRlIqLiYaPiok�, "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE && $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok5,".$_obf_iJKJjIuNk4mIjZKVjYmIhpQ�.",".str_replace( "'", "", $_obf_kYqNjZWRkI6OhomJjoqHjoY� ) );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), 1 );
}
?>
