<?php

function _obf_io_Oi5OHi5CHlYuOk4iMiI8�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
_obf_kY6LiJGJiIiRiIuRjomOiZA�( );
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 6 );
$_obf_jpKNh4aRh4aQkY2PlIuRhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softid", "gp", "int", 0 );
$_obf_j5WKlJOMkIyQjoePlYuSjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keys", "gp", "sql", "" );
$_obf_k4mViI2Nj4mJkIuUj42JiIY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "opsubmit", "gp", "sql", "" );
$_obf_jZGRipSRkIeUiIeQjoaUjJI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_soft where `id`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
if ( empty( $_obf_jZGRipSRkIeUiIeQjoaUjJI� ) )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "软件未找到" );
}
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_ho2NhoaMhoqMlYuLiJSKjo4� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_agentprice where `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id']." and `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
    if ( empty( $_obf_ho2NhoaMhoqMlYuLiJSKjo4� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没有该软件的授权", 1 );
    }
}
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `username`='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."' and managerid=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'] );
}
else
{
    $_obf_jZGSiIyHlYaPjpWPjI_QiYg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where `username`='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."'" );
}
if ( empty( $_obf_jZGSiIyHlYaPjpWPjI_QiYg� ) )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "用户未找到" );
}
if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == "保存" )
{
    $_obf_jZOIiIiJkJOGiY_KjoaGh4c� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "password", "gp", "sqljs", "" );
    $_obf_iY_Hk5KMh4uRkpKGkoeQkZI� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "password2", "gp", "sqljs", "" );
    $_obf_k4_Gk5CUhoaJlZGNj42PiIs� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "bdinfo", "gp", "sqljs", "" );
    $_obf_i4eIipGJiZWSlIeIh4uJj5Q� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "keyextattr", "gp", "sqljs", "" );
    $_obf_iYmHlIeIio2Ni5CRjIeJkYk� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "cday", "gp", "num", 0 );
    $_obf_ko6Hj46GiZWKiYeQho6Oj5I� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "cday_add", "gp", "num", 0 );
    $_obf_iI_TiI_HjoiGj4eIkZSIjog� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "points", "gp", "int", 0 );
    $_obf_kJCVjoaIiYeKiI6UiYuIjYo� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "linknum", "gp", "int", 1 );
    $_obf_io6KiIyHkouMlY6LlImMiIc� = array( );
    $_obf_iYmHlIeIio2Ni5CRjIeJkYk� += $_obf_ko6Hj46GiZWKiYeQho6Oj5I�;
    $_obf_iYmHlIeIio2Ni5CRjIeJkYk� = number_format( $_obf_iYmHlIeIio2Ni5CRjIeJkYk�, 2, ".", "" );
    if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "USOFT" && ( !( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 ) && _obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "18" ) ) )
    {
        if ( strlen( $_obf_jZOIiIiJkJOGiY_KjoaGh4c� ) < 5 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "用户密码最少5位" );
        }
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['password'] = $_obf_jZOIiIiJkJOGiY_KjoaGh4c�;
    }
    $_obf_kpSQh42Tk4mRi4yRiZCGipI� = "<script>";
    if ( !( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 ) && _obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "13" ) )
    {
        if ( strlen( $_obf_iY_Hk5KMh4uRkpKGkoeQkZI� ) < 5 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "安全密码最少5位" );
        }
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['password2'] = $_obf_iY_Hk5KMh4uRkpKGkoeQkZI�;
    }
    if ( !( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 ) && _obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "15" ) )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['bdinfo'] = $_obf_k4_Gk5CUhoaJlZGNj42PiIs�;
        $_obf_kpSQh42Tk4mRi4yRiZCGipI� .= "\$(".YH2."[aj='bdinfo".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."']".YH2.").val('".htmlspecialchars( $_obf_k4_Gk5CUhoaJlZGNj42PiIs� )."');";
    }
    if ( !( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 ) && _obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "16" ) )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] = $_obf_i4eIipGJiZWSlIeIh4uJj5Q�;
        $_obf_kpSQh42Tk4mRi4yRiZCGipI� .= "\$(".YH2."[aj='keyextattr".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."']".YH2.").val('".$_obf_i4eIipGJiZWSlIeIh4uJj5Q�."');";
    }
    if ( $_obf_iYmHlIeIio2Ni5CRjIeJkYk� < 0 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "天数不能小于0" );
    }
    if ( PETIME <= $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_iYmHlIeIio2Ni5CRjIeJkYk� * 86400 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "该用户最大天数可设置为".round( ( PETIME - $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] - 86400 ) / 86400, 2 ) );
    }
    if ( $_obf_iI_TiI_HjoiGj4eIkZSIjog� < 0 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "点数不能小于0" );
    }
    if ( $_obf_kJCVjoaIiYeKiI6UiYuIjYo� < 1 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "通道数不能小于1" );
    }
    if ( ( !( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 ) && _obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "12" ) ) && $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['endtime'] != PETIME )
    {
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_iYmHlIeIio2Ni5CRjIeJkYk�;
        $_obf_kpSQh42Tk4mRi4yRiZCGipI� .= "\$(".YH2."[aj='cday".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."']".YH2.").text('".$_obf_iYmHlIeIio2Ni5CRjIeJkYk�."');";
        $_obf_kJSSjJKSkIyJiZCViI2TlJQ� = $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['starttime'] + $_obf_iYmHlIeIio2Ni5CRjIeJkYk� * 86400;
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_kJSSjJKSkIyJiZCViI2TlJQ�;
        $_obf_kImSkYuTk4qHkJWTiZCRio8� = _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_kJSSjJKSkIyJiZCViI2TlJQ�, "y-m-d H:i" );
        $_obf_kpSQh42Tk4mRi4yRiZCGipI� .= "\$(".YH2."[aj='endtime".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."']".YH2.").text('".$_obf_kImSkYuTk4qHkJWTiZCRio8�."');";
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_iI_TiI_HjoiGj4eIkZSIjog�;
        $_obf_kpSQh42Tk4mRi4yRiZCGipI� .= "\$(".YH2."[aj='points".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."']".YH2.").text('".$_obf_iI_TiI_HjoiGj4eIkZSIjog�."');";
        $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] = $_obf_kJCVjoaIiYeKiI6UiYuIjYo�;
        $_obf_kpSQh42Tk4mRi4yRiZCGipI� .= "\$(".YH2."[aj='linknum".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."']".YH2.").text('".$_obf_kJCVjoaIiYeKiI6UiYuIjYo�."');";
    }
    $_obf_j42HkJGSkI6UhoaJlYuVk4k� = array_diff_assoc( $_obf_j42HkJGSkI6UhoaJlYuVk4k�, $_obf_jZGSiIyHlYaPjpWPjI_QiYg� );
    if ( empty( $_obf_j42HkJGSkI6UhoaJlYuVk4k� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你未做任何修改！" );
    }
    if ( stripos( $_SERVER['SERVER_NAME'], "v9.hphu.com" ) !== FALSE && isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "禁止修改通道数！" );
    }
    if ( isset( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] ) )
    {
        if ( stripos( $_SERVER['SERVER_NAME'], "v9.hphu.com" ) !== FALSE && $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "禁止修改天数！" );
        }
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `kss_tb_log_addcday` (`pid`,`managerid`,`softid`,`addtime`,`cday`,`username`,`intro`) VALUES (".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'].",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'].",".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�.",".time( ).",".( $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] - $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'] ).",'".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."','".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username']."加时前天数：".$_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday']."')", "notsync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE `kss_tb_log_addcday`", "notsync" );
        }
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iJOJipCPk4yQlJOMlIeTjYs�( "kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "`username`='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."'", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "保存时出错[执行update语句]".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
    }
    $_obf_kpSQh42Tk4mRi4yRiZCGipI� .= "</script>";
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok".$_obf_kpSQh42Tk4mRi4yRiZCGipI� );
}
else if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == "setpub" )
{
    if ( stripos( $_SERVER['SERVER_NAME'], "v9.hphu.com" ) !== FALSE && $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "服务器禁止使用公用帐号功能！" );
    }
    $_obf_kJWKkYuPko2SkZORiI6UiZM� = round( ( PETIME - time( ) ) / 86400 + 0.5 );
    $_obf_hpWPi5KTh4qKh4qUkYePlJQ� = PETIME - $_obf_kJWKkYuPko2SkZORiI6UiZM� * 86400;
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." set starttime=".$_obf_hpWPi5KTh4qKh4qUkYePlJQ�.",cday=".$_obf_kJWKkYuPko2SkZORiI6UiZM�.",endtime=".PETIME.",linknum=1,points=0,keyextattr='' where `username`='".$_obf_j5WKlJOMkIyQjoePlYuSjJE�."'", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "ok" );
}
echo "<script>\r\nfunction closeat(){\r\n\$(\".malertboxclosebtn\").click();\r\n}\r\n\$(document).ready(function() {\t\r\n\r\n\$('#setpubuser').bind(\"click\",function(){\r\nif(!confirm(\"注意：此操作不可逆！\\r\\n是否真的要将此帐号设为公用帐号?\"))return false; \r\nvar cdurl='./admin_key.php?action=edituser&opsubmit=setpub&isajax=1&softid=";
echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
echo "&keys='+encodeURIComponent('";
echo $_obf_j5WKlJOMkIyQjoePlYuSjJE�;
echo "');\r\n\$.ajax({\r\nurl: cdurl,\r\ncache: false,\r\nsuccess: function(html){\r\nif(html=='ok'){\r\nwindow.setTimeout(\"closeat()\", 1);\r\n}else{\r\nmalert(html);\r\n}\r\n},\r\nerror:function(XMLHttpRequest, textStatus, errorThrown) {\r\nalert(ourl)\r\n} \r\n});\t\t\r\n});\r\n\r\n\$('#saveuser').ajaxForm({\r\nbeforeSubmit:function (arr, \$form, options) {\r\nreturn true;\r\n},\r\nsuccess:function (responseText, statusText, xhr, \$form) {\r\nif(responseText.substr(0,2)!='ok'){\r\nmalert(responseText);\r\n}else{\r\n\$(\"#load__script\").append(responseText.substr(2)); \r\nwindow.setTimeout(\"closeat()\", 1);\r\n}\r\n},\r\nerror:function(){isclickadd=0;alert(\"error!\");}\r\n});\r\n});\r\n</script>\r\n<div id='load__script'></div>\r\n<form id=\"saveuser\" action=\"?action=edituser&isajax=1&softid=";
echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
echo "\" method=\"post\">\r\n<table border=0  cellpadding=\"0\" cellspacing=\"0\" width='100%'>\r\n<tr><td valitn=top>\r\n<table border=0  cellpadding=\"5\" cellspacing=\"5\" >\r\n<tr>\r\n<td align=right>用户名</td>\r\n<td align=left><input class=\"longinput\" type=\"hidden\" name=\"keys\" value=\"";
echo _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username'] );
echo "\" />";
echo _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['username'] );
echo "</td>\r\n</tr>\r\n<tr>\r\n<td align=right>用户密码</td>\r\n<td align=left><input class=\"longinput\" type=\"text\" maxlength=\"32\"  name=\"password\" value=";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "18" ) )
{
    echo YH2."无权查看和修改".YH2." readOnly";
    echo YH2.htmlspecialchars( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['password'] ).YH2;
}
else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    echo " readOnly";
}
echo " /></td>\r\n</tr>\r\n<tr>\r\n<td align=right>安全密码</td>\r\n<td align=left><input class=\"longinput\" type=\"text\" maxlength=\"32\" name=\"password2\" value=";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "13" ) )
{
    echo YH2."无权查看和修改".YH2." readOnly";
    echo YH2.htmlspecialchars( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['password2'] ).YH2;
}
else if ( $_obf_jZGRipSRkIeUiIeQjoaUjJI�['softmode'] == "KSOFT" )
{
    echo " readOnly";
}
echo " ></td>\r\n</tr>\r\n<tr>\r\n<td align=right>绑定信息</td>\r\n<td align=left><input class=\"longinput\" type=\"text\"  name=\"bdinfo\"";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "15" ) )
{
    echo " disabled";
}
echo " value=\"";
echo htmlspecialchars( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['bdinfo'], ENT_QUOTES, "UTF-8" );
echo "\" /></td>\r\n</tr>\r\n</table></td><td valign=top>\r\n<table border=0  cellpadding=\"5\" cellspacing=\"5\" >\r\n<tr>\r\n<td align=right>天数</td>\r\n<td align=left><input class=\"midinput\" type=\"text\" maxlength=\"6\" name=\"cday\"";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "12" ) )
{
    echo " disabled";
}
echo " value=\"";
echo $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['cday'];
echo "\" />\r\n+\r\n<input style=\"width:76px\" type=\"text\" maxlength=\"6\" name=\"cday_add\"";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "12" ) )
{
    echo " disabled";
}
echo " value=\"0\" /></td>\r\n</tr>\r\n<tr>\r\n<td align=right>点数</td>\r\n<td align=left><input class=\"longinput\" type=\"text\" maxlength=\"6\" name=\"points\"";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "12" ) )
{
    echo " disabled";
}
echo " value=\"";
echo $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['points'];
echo "\" /></td>\r\n</tr>\r\n<tr>\r\n<td align=right>通道</td>\r\n<td align=left><input class=\"longinput\" type=\"text\" maxlength=\"4\" name=\"linknum\"";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "12" ) )
{
    echo " disabled";
}
echo " value=\"";
echo $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['linknum'];
echo "\" /></td>\r\n</tr>\r\n<tr>\r\n<td align=right>附属性</td>\r\n<td align=left><input class=\"longinput\" type=\"text\" maxlength=\"100\" name=\"keyextattr\"";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 && !_obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'], "16" ) )
{
    echo " disabled";
}
echo " value=\"";
echo htmlspecialchars( $_obf_jZGSiIyHlYaPjpWPjI_QiYg�['keyextattr'], ENT_QUOTES, "UTF-8" );
echo "\" /></td>\r\n</tr>\r\n</table></td></tr>\r\n<tr><td colspan=2 align=center>";
if ( 7 < $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] )
{
    echo "<input type=button id=setpubuser class=submitbtn value=设为公用 title='点此按钮会将此帐号设为公用帐号'>&nbsp;&nbsp;";
}
echo "<input type=submit name=opsubmit class=submitbtn value=保存>&nbsp;&nbsp;<span style=\"color:#0000ff\">操作成功无提示，窗口会自动关闭</span></td></tr>\r\n</table>\r\n</form>";
?>
