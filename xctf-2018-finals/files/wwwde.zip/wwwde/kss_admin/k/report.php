<?php

function _obf_lYeNkoeMlY2Ph5KGjY6VkIk�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 6 );
$_obf_jpKNh4aRh4aQkY2PlIuRhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "softid", "gp", "int", 0 );
$_obf_kYqTiZWUjZKLjZCVlImUi5A� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "managerid", "gp", "int", 0 );
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_kYqTiZWUjZKLjZCVlImUi5A� = $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
}
$_obf_kYmQkIuQkpOLjo6RlY6LkJU� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "cztime1", "gp", "time", "2012-01-01 00:00:00" );
$_obf_kJSJjYyPlYyKj5GPiYyKjY4� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "cztime2", "gp", "time", _obf_jZGJkpOSkY_HiY2HjY2JlIg�( ) );
$_obf_iYeTlYuQiIuTlIqQi5KOkoo� = strtotime( $_obf_kYmQkIuQkpOLjo6RlY6LkJU� );
$_obf_h42Vi5OUi5OGlJCOjYmPlJE� = strtotime( $_obf_kJSJjYyPlYyKj5GPiYyKjY4� );
if ( $_obf_h42Vi5OUi5OGlJCOjYmPlJE� < $_obf_iYeTlYuQiIuTlIqQi5KOkoo� )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你选择的充值日期时间段错误，前边的应该要比后边的小" );
}
$_obf_jJWJi46Gi4yJjYqRiY6TjYk� = "";
if ( $_obf_kYqTiZWUjZKLjZCVlImUi5A� != 0 )
{
    $_obf_jJWJi46Gi4yJjYqRiY6TjYk� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and `id`=".$_obf_kYqTiZWUjZKLjZCVlImUi5A� );
    if ( empty( $_obf_jJWJi46Gi4yJjYqRiY6TjYk� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你要统计的用户未找到" );
    }
}
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_kYqTiZWUjZKLjZCVlImUi5A� = $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
    $_obf_ho2NhoaMhoqMlYuLiJSKjo4� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_agentprice where `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id']." and `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE� );
    if ( empty( $_obf_ho2NhoaMhoqMlYuLiJSKjo4� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你没有该软件的授权", 1 );
    }
}
else
{
    $_obf_j5OIiY_GkpCLh5CJh5SIlYc� = array( );
    $_obf_ioiKkImNk5KKlZSIjomPkow� = array( );
    $_obf_kIiMk4_SkpOVho2SjoyMjZU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `id`,`username`,`level`,`pmid` from `kss_tb_manager` where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and isdel=0 order by id asc" );
    foreach ( $_obf_kIiMk4_SkpOVho2SjoyMjZU� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_j5OIiY_GkpCLh5CJh5SIlYc�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'];
        if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 7 && $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'] == $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pmid'] )
        {
            $_obf_ioiKkImNk5KKlZSIjomPkow�[] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        }
        if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'] == $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] )
        {
            $_obf_ioiKkImNk5KKlZSIjomPkow�[] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        }
    }
}
$_obf_kIyNj4uPjZGOiouLiYiQlZQ� = "";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_kIyNj4uPjZGOiouLiYiQlZQ� = " and `id` in (select distinct `keygroupid` from kss_tb_agentprice where managerid=".$_obf_kYqTiZWUjZKLjZCVlImUi5A�." and `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�.") ";
}
$_obf_hoqKho2Mh4iNkpOTiZONio4� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_keyset where `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." and islock=0".$_obf_kIyNj4uPjZGOiouLiYiQlZQ� );
echo "<script type=\"text/javascript\">\t\r\n\$(document).ready(function() {\r\n\$(\"#cztime1,#cztime2\").date_input({addhss: \"00:00:00\"});\r\n});\r\n\r\n\r\n</script>\r\n\r\n\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<form id=\"find_key\" action=\"?action=report&softid=";
echo $_obf_jpKNh4aRh4aQkY2PlIuRhpE�;
echo "\" method=\"post\">\r\n<tr>\r\n<td class=\"findorpage\">\r\n";
if ( 6 < $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] )
{
    echo "\t\t<select id='managerid' name='managerid'>\t\t\t<option value=0>所有后台用户</option>\r\n";
    foreach ( $_obf_kIiMk4_SkpOVho2SjoyMjZU� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 7 )
        {
            if ( in_array( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'], $_obf_ioiKkImNk5KKlZSIjomPkow� ) )
            {
                echo "<option value=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
                if ( $_obf_kYqTiZWUjZKLjZCVlImUi5A� == $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] )
                {
                    echo " selected";
                }
                echo ">".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."[".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level']]."]</option>";
            }
        }
        else
        {
            echo "<option value=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
            if ( $_obf_kYqTiZWUjZKLjZCVlImUi5A� == $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] )
            {
                echo " selected";
            }
            echo ">".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username']."[".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level']]."]</option>";
        }
    }
    echo "\t\t</select>";
}
echo "\r\n<input name=\"cztime1\" id=\"cztime1\" class=\"my_date_input\" type=\"text\" value=\"";
echo $_obf_kYmQkIuQkpOLjo6RlY6LkJU�;
echo "\" /><span style=\"font-family: 宋体\">＜充值日期≤</span><input name=\"cztime2\" id=\"cztime2\" class=\"my_date_input\" type=\"text\" value=\"";
echo $_obf_kJSJjYyPlYyKj5GPiYyKjY4�;
echo "\" />\r\n<input type=\"submit\" name=\"submit\" class=\"submitbtn\" value=\"统计\" />\r\n</td>\r\n</tr>\r\n</form>\r\n</table>\r\n";
$_obf_i4iJk4iJjI_JkJKUi4iMiYY� = "";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
{
    $_obf_i4iJk4iJjI_JkJKUi4iMiYY� = " `managerid`=".$_obf_kYqTiZWUjZKLjZCVlImUi5A�." and ";
}
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 7 )
{
    if ( $_obf_kYqTiZWUjZKLjZCVlImUi5A� == 0 )
    {
        $_obf_lIaKh5WUhpSOiJCNiYmGjZA� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_manager where pmid=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'] );
        $_obf_ipSOh4yIjomLjoqVkJOKk5A� = $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'];
        if ( !empty( $_obf_lIaKh5WUhpSOiJCNiYmGjZA� ) )
        {
            foreach ( $_obf_lIaKh5WUhpSOiJCNiYmGjZA� as $_obf_jomUjIaRjIaQj5GNiIqUiow� )
            {
                $_obf_ipSOh4yIjomLjoqVkJOKk5A� .= ",".$_obf_jomUjIaRjIaQj5GNiIqUiow�['id'];
            }
        }
        $_obf_i4iJk4iJjI_JkJKUi4iMiYY� = " `managerid` in (".$_obf_ipSOh4yIjomLjoqVkJOKk5A�.") and ";
    }
    else
    {
        $_obf_i4iJk4iJjI_JkJKUi4iMiYY� = " `managerid`=".$_obf_kYqTiZWUjZKLjZCVlImUi5A�." and ";
    }
}
if ( 7 < $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] )
{
    if ( $_obf_kYqTiZWUjZKLjZCVlImUi5A� == 0 )
    {
        $_obf_i4iJk4iJjI_JkJKUi4iMiYY� = " `managerid`>0 and ";
    }
    else if ( $_obf_jJWJi46Gi4yJjYqRiY6TjYk�['level'] == 7 )
    {
        $_obf_lIaKh5WUhpSOiJCNiYmGjZA� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_manager where pmid=".$_obf_jJWJi46Gi4yJjYqRiY6TjYk�['id'] );
        $_obf_ipSOh4yIjomLjoqVkJOKk5A� = $_obf_jJWJi46Gi4yJjYqRiY6TjYk�['id'];
        if ( !empty( $_obf_lIaKh5WUhpSOiJCNiYmGjZA� ) )
        {
            foreach ( $_obf_lIaKh5WUhpSOiJCNiYmGjZA� as $_obf_jomUjIaRjIaQj5GNiIqUiow� )
            {
                $_obf_ipSOh4yIjomLjoqVkJOKk5A� .= ",".$_obf_jomUjIaRjIaQj5GNiIqUiow�['id'];
            }
        }
        $_obf_i4iJk4iJjI_JkJKUi4iMiYY� = " `managerid` in (".$_obf_ipSOh4yIjomLjoqVkJOKk5A�.") and ";
    }
    else
    {
        $_obf_i4iJk4iJjI_JkJKUi4iMiYY� = " `managerid`=".$_obf_kYqTiZWUjZKLjZCVlImUi5A�." and ";
    }
}
echo "\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"99%\">\r\n<tr class=\"trhead\">\r\n<td>注册卡类</td>\r\n<td>已充值注册卡数量</td>\r\n<td>未充值注册卡数量</td>\r\n<td>退卡数量</td>\r\n</tr>\r\n";
$_obf_k5CIjpGIlZOGk5WJi4eTkZQ� = 0;
foreach ( $_obf_hoqKho2Mh4iNkpOTiZONio4� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
{
    $_obf_lIeHjpGOi5WTlIeGj4_Jj48� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT count(*) as tnum from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where ".$_obf_i4iJk4iJjI_JkJKUi4iMiYY�." `keyfix`='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['prefix']."' and cztime between ".$_obf_iYeTlYuQiIuTlIqQi5KOkoo�." and ".$_obf_h42Vi5OUi5OGlJCOjYmPlJE�." and isback=0" );
    $_obf_iYyPi4uTk46UkYyNjY6Rj44� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT count(*) as tnum from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where ".$_obf_i4iJk4iJjI_JkJKUi4iMiYY�." `keyfix`='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['prefix']."' and cztime=0 and isback=0" );
    $_obf_iYqNh4yVi4mMkZCHh4mUkoY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "SELECT count(*) as tnum from kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." where  isback=1 and ".$_obf_i4iJk4iJjI_JkJKUi4iMiYY�."  `keyfix`='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['prefix']."'" );
    $_obf_k5CIjpGIlZOGk5WJi4eTkZQ� = $_obf_k5CIjpGIlZOGk5WJi4eTkZQ� + $_obf_lIeHjpGOi5WTlIeGj4_Jj48�['tnum'] + $_obf_iYyPi4uTk46UkYyNjY6Rj44�['tnum'] + $_obf_iYqNh4yVi4mMkZCHh4mUkoY�['tnum'];
    echo "<tr class=trd><td>"._obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyname'] )."</td><td>".$_obf_lIeHjpGOi5WTlIeGj4_Jj48�['tnum']."</td><td>".$_obf_iYyPi4uTk46UkYyNjY6Rj44�['tnum']."</td><td>".$_obf_iYqNh4yVi4mMkZCHh4mUkoY�['tnum']."</td></tr>";
}
echo "<tr class=trd><td>注册卡总数</td><td colspan=3 align=center>".$_obf_k5CIjpGIlZOGk5WJi4eTkZQ�."</td></tr>";
echo "</table>";
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
echo "<div id=pageruntime>页面运行时间"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_i5GVjZWQj4ePkJKMjJSRipM� )."毫秒</div>";
echo "</body>\r\n</html>";
?>
