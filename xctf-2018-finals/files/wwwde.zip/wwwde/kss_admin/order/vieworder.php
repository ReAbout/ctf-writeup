<?php

function _obf_joeHkIiGkIuHi4eNh5WNkY8�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "KSSROOTDIR" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 6 );
$_obf_iJWMjIiVi5OGjJOViY2Li48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "ordernum", "gp", "sql", "" );
$_obf_k4eGjIaPjoaPlJWMlJSLhoc� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select A.*, B.`level`, B.`pmid` from kss_tb_order as A left join kss_tb_manager as B on A.`managerid`=B.`id` where A.`ordernum`='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'" );
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'] != $_obf_k4eGjIaPjoaPlJWMlJSLhoc�['pid'] )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "未找到订单号，订单可能已被清理掉了，或者该订单是代理自助充值订单" );
}
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 && $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'] != $_obf_k4eGjIaPjoaPlJWMlJSLhoc�['managerid'] )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "该订单不是你的，你无权查看" );
}
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 7 && $_obf_k4eGjIaPjoaPlJWMlJSLhoc�['pmid'] != $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'] )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "该订单你无权查看" );
}
$_obf_lZCJkIySjI6TipKIio6Ojos� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `keyfix`,`keys`,`keyspassword` from `kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_k4eGjIaPjoaPlJWMlJSLhoc�['softid']."` where `ordernum`='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."' limit 0,".$_obf_k4eGjIaPjoaPlJWMlJSLhoc�['keycount'] );
if ( empty( $_obf_lZCJkIySjI6TipKIio6Ojos� ) )
{
    $_obf_lImOiY6UiYaUlZKQh4qKiok� = "卡号还未生成";
}
else
{
    $_obf_lImOiY6UiYaUlZKQh4qKiok� = "";
    foreach ( $_obf_lZCJkIySjI6TipKIio6Ojos� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_lImOiY6UiYaUlZKQh4qKiok� .= $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyfix'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keys'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyspassword']."\r\n";
    }
}
$_obf_kpCGkYyIlJWKk42KjIuNi5M� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_keyset where `id`=".$_obf_k4eGjIaPjoaPlJWMlJSLhoc�['keygroupid'] );
if ( empty( $_obf_kpCGkYyIlJWKk42KjIuNi5M� ) )
{
    $_obf_kIuPkIeUjoiTlZKLipWIiog� = "卡类未找到";
}
else
{
    $_obf_kIuPkIeUjoiTlZKLipWIiog� = $_obf_kpCGkYyIlJWKk42KjIuNi5M�['keyname']." 天数".$_obf_kpCGkYyIlJWKk42KjIuNi5M�['cday'] * 1." 点数".$_obf_kpCGkYyIlJWKk42KjIuNi5M�['points']." 通道".$_obf_kpCGkYyIlJWKk42KjIuNi5M�['linknum']."<br>附属性：".$_obf_kpCGkYyIlJWKk42KjIuNi5M�['extattr1'];
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
echo "<table border=0  cellpadding=\"5\" cellspacing=\"5\" class=\"orderkey\">\r\n<tr>\r\n<td align=right>订单号</td>\r\n<td align=left>";
echo $_obf_iJWMjIiVi5OGjJOViY2Li48�;
echo "</td>\r\n<td align=right>下单时间</td>\r\n<td align=left>";
echo _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_k4eGjIaPjoaPlJWMlJSLhoc�['addtime'] );
echo "</td>\r\n</tr>\r\n<tr>\r\n<td align=right valign=top>注册卡类</td>\r\n<td align=left>";
echo $_obf_kIuPkIeUjoiTlZKLipWIiog�;
echo "</td>\r\n<td colspan=2><input type='button' class=submitbtn value='复制' id='copykey'><span id=copyed></span></td>\r\n\r\n</tr>\r\n<tr>\r\n<td align=right valign=top>注册卡号</td>\r\n<td align=left colspan=3><textarea id=\"orderkeynum\" style=\"width:450px;height:150px;font-family:Fixedsys,Verdana;color:#666;\">";
echo $_obf_lImOiY6UiYaUlZKQh4qKiok�;
echo "</textarea></td>\r\n</tr>\r\n</table>\r\n";
echo "<div class=pageruntime>查询用时"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_i5GVjZWQj4ePkJKMjJSRipM� )."毫秒</div>";
?>
