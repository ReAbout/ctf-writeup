<?php

function _obf_jo2GipGPkY6GkY2Rk5WOi5I�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

require( "../kss_inc/inc.php" );
$_obf_lZOThomRipOIi5SRhpWRjY4� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "action", "gp", "sql", "softlist" );
$_obf_jIuNj5GTho_UjIiMjYyOh4k� = "�����������������";
$_obf_iIaLiY_UiIaNi4uLlI6Vj4g� = "�����������������";
$$_obf_iIaLiY_UiIaNi4uLlI6Vj4g� = array( "mysqldatayh" => "数据库优化", "mysqldatabak" => "数据库备份", "mysqlquery" => "执行SQL" );
$$_obf_jIuNj5GTho_UjIiMjYyOh4k� = array( "mysqldatayh" => "数据库优化", "mysqldatabak" => "数据库备份", "mysqldatabak_down" => "数据库备份下载", "mysqlquery" => "执行SQL" );
if ( array_key_exists( $_obf_lZOThomRipOIi5SRhpWRjY4�, $_obf_koqUi4mUkpWSj4_Kj4eVhoY� ) )
{
    $_obf_kouLj4_JkJWKkJCQkIaMjZE� = $_obf_koqUi4mUkpWSj4_Kj4eVhoY�[$_obf_lZOThomRipOIi5SRhpWRjY4�];
    include( dirname( __FILE__ ).DIRECTORY_SEPARATOR."c_head.php" );
}
if ( array_key_exists( $_obf_lZOThomRipOIi5SRhpWRjY4�, $_obf_kpWHh5SPio2Gk4qIi4_Ri4k� ) )
{
    $_obf_lI_HiJGJlI2GkI2Ri4qOj40� = explode( "_", $_obf_lZOThomRipOIi5SRhpWRjY4� );
    include( dirname( __FILE__ ).DIRECTORY_SEPARATOR."data".DIRECTORY_SEPARATOR.$_obf_lI_HiJGJlI2GkI2Ri4qOj40�[0].".php" );
}
else
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "未知的action请求！" );
}
?>
