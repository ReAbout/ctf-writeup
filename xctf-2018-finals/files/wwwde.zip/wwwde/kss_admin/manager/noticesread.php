<?php

function _obf_iZGRlJGUk4qShpWUlZKGkoo�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 6 );
$_obf_komRjo6Qi4_Rh5KHi5SLhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "id", "gp", "int", 0 );
$_obf_k4mViI2Nj4mJkIuUj42JiIY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "op", "gp", "int", 0 );
if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == 3 )
{
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_notices where id=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE� );
    if ( empty( $_obf_lY6RhpOJh46VkJOGkoeRiIY� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "未找到公告" );
    }
    $_obf_ipGGjY6TjImLko_IkJKUiZI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `kss_tb_noticesread` (`noticesid`,`managerid`,`isread`,`readtime`) VALUES (".$_obf_komRjo6Qi4_Rh5KHi5SLhpE�.",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'].",1,".time( ).")", "notsync" );
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "<textarea name=\"softnotice\" class=\"softtextarea\">".htmlspecialchars( $_obf_lY6RhpOJh46VkJOGkoeRiIY�['content'] == "" ? "" : base64_decode( $_obf_lY6RhpOJh46VkJOGkoeRiIY�['content'] ) )."</textarea>" );
}
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 8 )
{
    $_obf_lZWLio_SiZGJko_PkZWMipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_notices where pid=10000 and level=8 order by id desc limit 0,10" );
}
else
{
    $_obf_lZWLio_SiZGJko_PkZWMipM� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_notices where pid=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and level<=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level']." order by id desc limit 0,10" );
}
$_obf_lI2HjIqUkYqTho2HiJWUk5I� = "";
$_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "<ul id=sysnotice>";
$_obf_lYmJiomHhouOkI6Qko_Pkow� = TRUE;
foreach ( $_obf_lZWLio_SiZGJko_PkZWMipM� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
{
    $_obf_ipSKiZCJj5OQi5GVj5OMlZQ� = "";
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 9 )
    {
        $_obf_ipSKiZCJj5OQi5GVj5OMlZQ� = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid'];
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_noticesread where managerid=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id']." and noticesid=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] );
    if ( empty( $_obf_lY6RhpOJh46VkJOGkoeRiIY� ) )
    {
        $_obf_lYmJiomHhouOkI6Qko_Pkow� = FALSE;
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "<li><a class=noticesli1 herf=# noticeid=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']." >[".$_obf_ipSKiZCJj5OQi5GVj5OMlZQ�." "._obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['addtime'], "y-m-d" )."]&nbsp;&nbsp;"._obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['title'] )."</a></li>";
    }
    else
    {
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "<li><a class=noticesli2 herf=# noticeid=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']." >[".$_obf_ipSKiZCJj5OQi5GVj5OMlZQ�." "._obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['addtime'], "y-m-d" )."]&nbsp;&nbsp;"._obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['title'] )."</a></li>";
    }
}
$_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "</ul>";
if ( $_obf_k4mViI2Nj4mJkIuUj42JiIY� == 0 )
{
    if ( $_obf_lYmJiomHhouOkI6Qko_Pkow� )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "allread".$_obf_lI2HjIqUkYqTho2HiJWUk5I� );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "notread".$_obf_lI2HjIqUkYqTho2HiJWUk5I� );
}
else
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_lI2HjIqUkYqTho2HiJWUk5I� );
}
?>
