<?php

function _obf_iZGRlJGUk4qShpWUlZKGkoo�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 8 );
$_obf_komRjo6Qi4_Rh5KHi5SLhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "id", "gp", "int", 0 );
if ( $_obf_lZOThomRipOIi5SRhpWRjY4� == "notices_view" )
{
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_notices where id=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE� );
    if ( empty( $_obf_lY6RhpOJh46VkJOGkoeRiIY� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "未找到公告" );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "<textarea name=\"softnotice\" class=\"softtextarea\">".htmlspecialchars( $_obf_lY6RhpOJh46VkJOGkoeRiIY�['content'] == "" ? "" : base64_decode( $_obf_lY6RhpOJh46VkJOGkoeRiIY�['content'] ) )."</textarea>" );
}
if ( $_obf_lZOThomRipOIi5SRhpWRjY4� == "notices_add" )
{
    $_obf_jYeUjIaQh4_Gh46KjoeQipA� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "level", "gp", "int", 7 );
    $_obf_jIuMi42QkYqVkpOMjYaLiYY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "title", "gp", "sql", 7 );
    $_obf_kpGHjIyRkZOGiYaLipKIiYg� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "content", "gp", "sql", 7 );
    $_obf_kpGHjIyRkZOGiYaLipKIiYg� = base64_encode( $_obf_kpGHjIyRkZOGiYaLipKIiYg� );
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] <= $_obf_jYeUjIaQh4_Gh46KjoeQipA� )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "无权限发布该级别公告！" );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `kss_tb_notices` (`pid`,`managerid`,`level`,`addtime`,`title`,`content`) VALUES (".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'].",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'].",".$_obf_jYeUjIaQh4_Gh46KjoeQipA�.",".time( ).",'".$_obf_jIuMi42QkYqVkpOMjYaLiYY�."','".$_obf_kpGHjIyRkZOGiYaLipKIiYg�."')", "notsync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "发布公告成功,请刷新页面查看！" );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "发布公告时出错：".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
}
if ( $_obf_lZOThomRipOIi5SRhpWRjY4� == "notices_del" )
{
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_notices where pid=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and id=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE� );
    if ( empty( $_obf_lY6RhpOJh46VkJOGkoeRiIY� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "未找到公告" );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_notices` where id=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE�, "notsync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_noticesread` where noticesid=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE�, "notsync" );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "delok删除公告成功！" );
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "删除公告时出错：".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
}
$_obf_lJKGipSShoyHi4aRkoyKjo0� = array( );
$_obf_lJKGipSShoyHi4aRkoyKjo0�[0] = "无";
$_obf_jo_Mh4iRkIuRjYyUh5CVj4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select id,username from kss_tb_manager where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'] );
foreach ( $_obf_jo_Mh4iRkIuRjYyUh5CVj4g� as $_obf_ko2TkI6OjY_GiI2IjZKOlIo� )
{
    $_obf_lJKGipSShoyHi4aRkoyKjo0�[$_obf_ko2TkI6OjY_GiI2IjZKOlIo�['id']] = $_obf_ko2TkI6OjY_GiI2IjZKOlIo�['username'];
}
unset( $_obf_jo_Mh4iRkIuRjYyUh5CVj4g� );
$_obf_i4uIkYuKkJGQlJKOjoiMj4c� = array(
    "action" => $_obf_lZOThomRipOIi5SRhpWRjY4�
);
$_obf_k42Rh4mVlYqGi4mOiZWMjJA� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "page", "gp", "int", 1 );
$_obf_iYqPiJGIjoaVhoaQiI2Ti4w� = "SELECT `id` ";
$_obf_jpCQi4aKkYaIjpSUhpWNipM� = "SELECT * ";
$_obf_homTioySho6Vh5ORiYmUkok� = " where `id` in";
$_obf_kZCPiJCHiI_IlY2Ok4_JlIc� = "SELECT count(*) as tnum ";
$_obf_lJSNlZWKlYmGi4iSkIqHjpA� = "from `kss_tb_notices`  ";
$_obf_h4eJlYuIjpKNio6QkIuJlIY� = array( );
$_obf_j4aLlZCQhoyUh5GSjoeSh4c� = "username";
if ( stripos( $_SERVER['HTTP_HOST'], ".hphu.com" ) )
{
    $_obf_j4aLlZCQhoyUh5GSjoeSh4c� = "qq";
}
$_obf_h4eJlYuIjpKNio6QkIuJlIY�[] = " `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'];
$_obf_j4mJh4aKjZKHhpOSiJKSjJI� = "";
if ( !empty( $_obf_h4eJlYuIjpKNio6QkIuJlIY� ) )
{
    $_obf_j4mJh4aKjZKHhpOSiJKSjJI� = " where".implode( " and ", $_obf_h4eJlYuIjpKNio6QkIuJlIY� );
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_lI_KipSOk4iQkI_MjIuVkpQ� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "recordnum", "gp", "int", 0 );
if ( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� == 1 )
{
    $_obf_k46Gk4qOjJGGiYqMiouGh4g� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( $_obf_kZCPiJCHiI_IlY2Ok4_JlIc�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI� );
    $_obf_lI_KipSOk4iQkI_MjIuVkpQ� = $_obf_k46Gk4qOjJGGiYqMiouGh4g�['tnum'];
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_i4uIkYuKkJGQlJKOjoiMj4c�['recordnum'] = $_obf_lI_KipSOk4iQkI_MjIuVkpQ�;
$_obf_jIiNjZCPkoeUjI2LipCQk5Q� = abs( floor( $_obf_lI_KipSOk4iQkI_MjIuVkpQ� / ZPAGESIZE * -1 ) );
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
echo "<textarea id=viewsql>";
echo htmlspecialchars( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
echo "\r\n";
$_obf_iZWHjpGQkoqPlYmJjYmIhpU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_iYqPiJGIjoaVhoaQiI2Ti4w�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_j4mJh4aKjZKHhpOSiJKSjJI�." LIMIT ".( $_obf_k42Rh4mVlYqGi4mOiZWMjJA� - 1 ) * ZPAGESIZE.",".ZPAGESIZE );
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_iIiHi4aTkoySkpCNio_UjYo� = "";
if ( !empty( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� ) )
{
    foreach ( $_obf_iZWHjpGQkoqPlYmJjYmIhpU� as $_obf_kYqOi5CTjoySj4mIkYmIlY4� )
    {
        $_obf_iIiHi4aTkoySkpCNio_UjYo� .= $_obf_kYqOi5CTjoySj4mIkYmIlY4�['id'].",";
    }
    $_obf_iIiHi4aTkoySkpCNio_UjYo� = substr( $_obf_iIiHi4aTkoySkpCNio_UjYo�, 0, strlen( $_obf_iIiHi4aTkoySkpCNio_UjYo� ) - 1 );
}
$_obf_iYeIjIaVlYaIj4yTiJWHk40� = FALSE;
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
if ( $_obf_iIiHi4aTkoySkpCNio_UjYo� != "" )
{
    $_obf_homTioySho6Vh5ORiYmUkok� .= "(".$_obf_iIiHi4aTkoySkpCNio_UjYo�.") order by id asc";
    $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok� );
    echo $_obf_jpCQi4aKkYaIjpSUhpWNipM�.$_obf_lJSNlZWKlYmGi4iSkIqHjpA�.$_obf_homTioySho6Vh5ORiYmUkok�;
    echo "\r\n";
}
$_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_k4yVk4iOipWPioqJlIuVkpE� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iouHh42RkIeKkYaSipWKiog�( $_obf_k42Rh4mVlYqGi4mOiZWMjJA�, $_obf_jIiNjZCPkoeUjI2LipCQk5Q�, $_obf_i4uIkYuKkJGQlJKOjoiMj4c� )."<span class=page_nav_a>".$_obf_lI_KipSOk4iQkI_MjIuVkpQ�."行  耗时"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_lJKOiJSHjo_Sj4yKk4aIh5I� )."毫秒</span>";
echo "</textarea><script type=\"text/javascript\">\r\n\$(document).ready(function() { \r\n\$(\".viewnotices\").bind(\"click\",function(){\r\nvar tid=\$(this).attr(\"nid\");\r\nvar ttext=\$(this).text();\r\nvar ourl=\"./admin_manager.php?action=notices_view&isajax=1&id=\"+tid;\r\nmalert(ourl,ttext,700,200);\r\n});\r\n\r\n\$(\"#submitadd\").click(function () {\r\nvar options = {\r\nurl: \$(\"#addnotices\").attr(\"action\"),\r\ntype: 'post',\r\ndataType: 'text',\r\ndata: \$(\"#addnotices\").serialize(),\r\nsuccess: function (responseText) {\r\nmalert(responseText);\r\n}\r\n};\r\n\$.ajax(options);            \r\n\r\nreturn false;\r\n});\r\n\r\n\$(\"[delnoticeid]\").bind('click',function(){\r\nvar othis=\$(this);\r\ndid=othis.attr(\"delnoticeid\");\r\nvar ourl=\"./admin_manager.php?action=notices_del&isajax=1&id=\"+did;\r\n\$.ajax({\r\nurl: ourl,\r\ncache: false,\r\nsuccess: function(html){\r\nif(html.substr(0,5)=='delok'){\r\n\$(\"#trnid\"+did).remove();\t\r\nmalert(html.substr(5));\t\t\r\n}else{\r\nmalert(html);\r\n}\r\n},\r\nerror:function(XMLHttpRequest, textStatus, errorThrown) {\r\nalert(ourl)\r\n} \r\n});\t\r\n});\r\n\r\n});\r\n</script>\r\n\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr>\r\n<td class=\"findorpage\"><form id=\"addnotices\" action=\"?action=notices_add&isajax=1\" method=\"post\"> \r\n公告标题：<input type=\"text\" class=\"longinput\" maxlength=\"20\" name=\"title\" value=\"\"/>&nbsp;\r\n公告发送给<select name=\"level\" style=\"width:200px;height:22px\">\r\n";
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 9 && 1 < LICTYPE )
{
    echo "<option value=8>所有作者</option>\r\n";
}
echo "<option value=7>所有总代</option>\r\n<option value=6>所有总代和代理</option>\r\n</select>\r\n&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" id=\"submitadd\" name=\"submitadd\" class=\"submitbtn\" value=\"添加公告\" /></td></tr>\r\n<tr><td class=\"findorpage\">\r\n公告内容：<textarea name=\"content\" class=\"softtextarea\"></textarea>\r\n\r\n</form></td>\r\n</tr>\r\n</table>\r\n\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr class=\"trhead\">\r\n<td malt=\"公告ID\">ID</td>\r\n<td>发布人ID</td>\r\n<td>发布时间</td>\r\n<td>标题</td>\r\n<td>发布对像</td>\r\n<td colspan=4>操作</td>\r\n</tr>\r\n\r\n";
if ( empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
{
    echo "<tr class=trd><td colspan=6>无任何数据</td></tr>";
}
else
{
    foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        echo "<tr class=\"trd\" id=\"trnid";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\">\r\n<td>";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "</td>\t\t\r\n";
        echo "<td>".$_obf_lJKGipSShoyHi4aRkoyKjo0�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['managerid']]."</td>";
        echo "<td>"._obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['addtime'], "y-m-d H:i" )."</td>";
        echo "<td><a class=\"viewnotices\" nid=";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo ">";
        echo _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['title'] );
        echo "</a></td>\r\n<td>";
        echo $_obf_jJCMjYyHjpSTiJCNiYiIkpE�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level']];
        echo "</td>\r\n<td width=\"20\"><img delnoticeid=\"";
        echo $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
        echo "\" malt=\"删除该公告\" src=\"";
        echo INSTALLPATH;
        echo "kss_inc/images/bd_drop.png\"></td>\r\n</tr>\r\n";
    }
}
echo "</table>\t\t\t\t\r\n<table class=\"listtable\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" align=\"center\" width=\"97%\">\r\n<tr>\r\n<td class=\"findorpage\">";
echo $_obf_k4yVk4iOipWPioqJlIuVkpE�;
echo "</td>\r\n</tr>\r\n</table>\r\n";
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
echo "<div id=pageruntime>页面运行时间"._obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_i5GVjZWQj4ePkJKMjJSRipM� )."毫秒</div>";
echo "</body>\r\n</html>";
?>
