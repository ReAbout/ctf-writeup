<?php

function _obf_iYqKh42Kj5GLjYeNlIqOlZM�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
$_obf_i5GVjZWQj4ePkJKMjJSRipM�[] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 8 );
if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] != 9 )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "只有管理员可以无密登入其它帐号" );
}
ob_clean( );
$_obf_komRjo6Qi4_Rh5KHi5SLhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "id", "gp", "int", 0 );
$_obf_kY_OlYeUlIiVjo6Hio_MkpI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where `id`=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE� );
if ( empty( $_obf_kY_OlYeUlIiVjo6Hio_MkpI� ) )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "没找到该用户" );
}
if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level'] < 8 )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "目标帐号不是作者帐号，不能登入查看！" );
}
$_obf_kI6PjYmLhpGMk4qGjZSHlIg� = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linecode'];
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set linecode='".$_obf_kI6PjYmLhpGMk4qGjZSHlIg�."' where id=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE�, "notsync" );
_obf_jZKVlY6HkYmKkIyRj4qSjIc�( "kss_manager", $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'].",".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['username'].",".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['password'].",".$_obf_kI6PjYmLhpGMk4qGjZSHlIg� );
if ( !isset( $_COOKIE['kss_mmlogin'] ) )
{
    _obf_jZKVlY6HkYmKkIyRj4qSjIc�( "kss_mmlogin", md5( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['username'].$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['password'] ) );
}
echo "<script>alert('login ok!');window.top.location=window.top.location+'1';</script>";
exit( );
?>
