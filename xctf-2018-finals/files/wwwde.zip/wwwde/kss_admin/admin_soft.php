<?php

function _obf_jpCSk46VlJWJjJKNiIyKlZA�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

require( "../kss_inc/inc.php" );
$_obf_lZOThomRipOIi5SRhpWRjY4� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "action", "gp", "sql", "softlist" );
$_obf_jIuNj5GTho_UjIiMjYyOh4k� = "�����������������";
$_obf_iIaLiY_UiIaNi4uLlI6Vj4g� = "�����������������";
$$_obf_iIaLiY_UiIaNi4uLlI6Vj4g� = array( "softlist" => "软件列表", "addsoft" => "添加或编辑软件", "keygroup" => "软件卡类设置" );
$$_obf_jIuNj5GTho_UjIiMjYyOh4k� = array( "softlist" => "软件列表", "addsoft" => "添加或编辑软件", "addsoft_save" => "保存软件", "addsoft_rsatest" => "RSA测试", "delsoft" => "删除软件", "softlistbar" => "小软件列表", "keygroup" => "软件卡类设置", "radvapi" => "更新advapi", "signdata" => "取签名数据" );
if ( array_key_exists( $_obf_lZOThomRipOIi5SRhpWRjY4�, $_obf_koqUi4mUkpWSj4_Kj4eVhoY� ) )
{
    $_obf_kouLj4_JkJWKkJCQkIaMjZE� = $_obf_koqUi4mUkpWSj4_Kj4eVhoY�[$_obf_lZOThomRipOIi5SRhpWRjY4�];
    include( dirname( __FILE__ ).DIRECTORY_SEPARATOR."c_head.php" );
}
if ( array_key_exists( $_obf_lZOThomRipOIi5SRhpWRjY4�, $_obf_kpWHh5SPio2Gk4qIi4_Ri4k� ) )
{
    $_obf_lI_HiJGJlI2GkI2Ri4qOj40� = explode( "_", $_obf_lZOThomRipOIi5SRhpWRjY4� );
    include( dirname( __FILE__ ).DIRECTORY_SEPARATOR."soft".DIRECTORY_SEPARATOR.$_obf_lI_HiJGJlI2GkI2Ri4qOj40�[0].".php" );
}
else
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "未知的action请求！" );
}
?>
