<?php

function _obf_i4mNio2QjpWNiJKNiZWQjoo�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

require( "../kss_inc/inc.php" );
$_obf_lZOThomRipOIi5SRhpWRjY4� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "action", "gp", "sql", "" );
$_obf_jIuNj5GTho_UjIiMjYyOh4k� = "�����������������";
$_obf_iIaLiY_UiIaNi4uLlI6Vj4g� = "�����������������";
$$_obf_iIaLiY_UiIaNi4uLlI6Vj4g� = array( "managerlogin" => "管理登录日志", "agentrmb" => "财务日志", "user_log" => "会员登陆日志", "userczlog" => "会员充值日志", "pubuser_log" => "公用帐号记录", "witesyncdata" => "待同步数据", "synclogs" => "数据同步日志", "outline" => "强制下线日志", "addcday" => "加时操作日志", "v8data" => "V8卡->新卡" );
$$_obf_jIuNj5GTho_UjIiMjYyOh4k� = array( "managerlogin" => "管理登录日志", "agentrmb" => "财务日志", "user_log" => "会员登陆日志", "userczlog" => "会员充值日志", "pubuser_log" => "公用帐号记录", "witesyncdata" => "待同步数据", "synclogs" => "数据同步日志", "outline" => "强制下线日志", "addcday" => "加时操作日志", "v8data" => "V8卡->新卡" );
if ( array_key_exists( $_obf_lZOThomRipOIi5SRhpWRjY4�, $_obf_koqUi4mUkpWSj4_Kj4eVhoY� ) )
{
    $_obf_kouLj4_JkJWKkJCQkIaMjZE� = $_obf_koqUi4mUkpWSj4_Kj4eVhoY�[$_obf_lZOThomRipOIi5SRhpWRjY4�];
    include( dirname( __FILE__ ).DIRECTORY_SEPARATOR."c_head.php" );
}
if ( array_key_exists( $_obf_lZOThomRipOIi5SRhpWRjY4�, $_obf_kpWHh5SPio2Gk4qIi4_Ri4k� ) )
{
    include( dirname( __FILE__ ).DIRECTORY_SEPARATOR."logs".DIRECTORY_SEPARATOR.$_obf_lZOThomRipOIi5SRhpWRjY4�.".php" );
}
else
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "未知的action请求！" );
}
?>
