<?php

function _obf_jYiPioeJi5OSiY_RlIeIjYw�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_jYuKk4uOiYmSkpOTj5GUlZA�( $_obf_kImKk4aUjIeVk4yHkomKjYg�, $_obf_lJOQiIqSlJGMiYaOiZOSi4c� = 0 )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( "kss_tb_log_login", $_obf_kImKk4aUjIeVk4yHkomKjYg�, "notsync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
    {
        return TRUE;
    }
    if ( $_obf_lJOQiIqSlJGMiYaOiZOSi4c� == 1 )
    {
        return FALSE;
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "repair table kss_tb_log_login", "notsync" );
    return _obf_jYuKk4uOiYmSkpOTj5GUlZA�( $_obf_kImKk4aUjIeVk4yHkomKjYg�, 1 );
}

function _obf_hpCMiIaTkoeLho6Tk4uRlY8�( )
{
    $_obf_kZORiZWPjouKjpOQh4iJkZE� = array( "这", "是", "一", "个", "密", "码", "字", "符", "集", "那", "基", "础", "训", "练", "的", "项", "目", "着", "实", "给", "了", "广", "大", "宇", "战", "爱", "好", "者", "一", "个", "全", "新", "的", "观", "点", "九", "级", "和", "十", "级", "跟", "一", "般", "等", "级", "不", "同", "学", "在", "做", "这", "个", "测", "试", "的", "时", "候", "由", "于", "难", "度", "过", "高", "所", "以", "观", "看", "者", "可", "以", "清", "楚", "地", "观", "看", "到", "其", "中", "的", "难", "度" );
    $_obf_hoqTiYaOlJONkZOSk42ViZE� = "";
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 8; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
    {
        $_obf_hoqTiYaOlJONkZOSk42ViZE� .= $_obf_kZORiZWPjouKjpOQh4iJkZE�[mt_rand( 0, 80 )];
    }
    return $_obf_hoqTiYaOlJONkZOSk42ViZE�;
}

function _obf_lZWPjZSUjI6VkImViIySko8�( $_obf_jZWKko2SlJWSjYiNjJSHkow� )
{
    $_obf_kJWSj4iSjI2PlYuMiYuSiYc� = file_get_contents( $_obf_jZWKko2SlJWSjYiNjJSHkow� );
    $_obf_j4eIlJWSkpCViZCIk4iVk44�[1] = ord( substr( $_obf_kJWSj4iSjI2PlYuMiYuSiYc�, 0, 1 ) );
    $_obf_j4eIlJWSkpCViZCIk4iVk44�[2] = ord( substr( $_obf_kJWSj4iSjI2PlYuMiYuSiYc�, 1, 1 ) );
    $_obf_j4eIlJWSkpCViZCIk4iVk44�[3] = ord( substr( $_obf_kJWSj4iSjI2PlYuMiYuSiYc�, 2, 1 ) );
    if ( $_obf_j4eIlJWSkpCViZCIk4iVk44�[1] == 239 && $_obf_j4eIlJWSkpCViZCIk4iVk44�[2] == 187 && $_obf_j4eIlJWSkpCViZCIk4iVk44�[3] == 191 )
    {
        $_obf_iY2Vi5WJi4qMjpOKiIyVlZA� = substr( $_obf_kJWSj4iSjI2PlYuMiYuSiYc�, 3 );
        file_put_contents( $_obf_jZWKko2SlJWSjYiNjJSHkow�, $_obf_iY2Vi5WJi4qMjpOKiIyVlZA� );
    }
}

require( "../kss_inc/inc.php" );
if ( is_file( "../install/index.php" ) )
{
    header( "location:../install/index.php" );
    exit( );
}
$_obf_lZOThomRipOIi5SRhpWRjY4� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "action", "g", "sql", "main" );
if ( $_obf_lZOThomRipOIi5SRhpWRjY4� == "exit" )
{
    $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    $_obf_komRjo6Qi4_Rh5KHi5SLhpE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "id", "g", "int", 0 );
    $_obf_kI6PjYmLhpGMk4qGjZSHlIg� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "linecode", "g", "sql", 0 );
    _obf_jZKVlY6HkYmKkIyRj4qSjIc�( "kss_manager", "" );
    _obf_jZKVlY6HkYmKkIyRj4qSjIc�( "kss_safe", "" );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set `linecode`='"._obf_iI6QhpSTiJCJiI_KlYePlZI�( 48 )."' where `id`=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE�." and  `linecode`='".$_obf_kI6PjYmLhpGMk4qGjZSHlIg�."'", "notsyne" );
}
if ( $_obf_lZOThomRipOIi5SRhpWRjY4� == "chklogin" )
{
    $_obf_hpGNiJKJlYuRkI2IlIaNlYk� = $_SESSION['loginimg'];
    $_obf_koyOkJKSj4eRjIyQjY2Lk4g� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "loginimg", "p", "sql", "" );
    $_obf_h4eSk4uGiZCKhoyNkIiTlI8� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "username", "p", "sql", "" );
    $_obf_jZOIiIiJkJOGiY_KjoaGh4c� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "password", "p", "sql", "" );
    $_obf_i4mRjZCJlZCGk4_UioyHk4k� = array( );
    $_obf_i4mRjZCJlZCGk4_UioyHk4k�['pid'] = 0;
    $_obf_i4mRjZCJlZCGk4_UioyHk4k�['managerid'] = 0;
    $_obf_i4mRjZCJlZCGk4_UioyHk4k�['logintime'] = time( );
    $_obf_i4mRjZCJlZCGk4_UioyHk4k�['loginip'] = $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    if ( strlen( $_obf_h4eSk4uGiZCKhoyNkIiTlI8� ) < 5 || strlen( $_obf_jZOIiIiJkJOGiY_KjoaGh4c� ) < 5 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "用户名或密码长度小于5个字符", 1 );
    }
    if ( strlen( $_obf_koyOkJKSj4eRjIyQjY2Lk4g� ) != 4 && strlen( $_obf_koyOkJKSj4eRjIyQjY2Lk4g� ) != 6 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "验证码长度不符", 1 );
    }
    if ( $_obf_h4eSk4uGiZCKhoyNkIiTlI8� != "test01" && $_obf_hpGNiJKJlYuRkI2IlIaNlYk� != strtoupper( $_obf_koyOkJKSj4eRjIyQjY2Lk4g� ) )
    {
        $GLOBALS['_SESSION']['loginimg'] = NULL;
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "验证码错误", 1 );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    $_obf_kY_OlYeUlIiVjo6Hio_MkpI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where `username`='".$_obf_h4eSk4uGiZCKhoyNkIiTlI8�."' and isdel=0" );
    if ( empty( $_obf_kY_OlYeUlIiVjo6Hio_MkpI� ) )
    {
        $GLOBALS['_SESSION']['loginimg'] = NULL;
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "用户名或密码错误！", 1 );
    }
    $_obf_houUi42Ki5SHiY_RiImQlZA� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_log_login where `managerid`=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']." order by id desc limit 0,5" );
    if ( !empty( $_obf_houUi42Ki5SHiY_RiImQlZA� ) )
    {
        $_obf_iZSViY2KjJSNjoePh4yOjI4� = FALSE;
        $_obf_iYaQk4iUlYqRk46Kio_TiI8� = array( );
        foreach ( $_obf_houUi42Ki5SHiY_RiImQlZA� as $_obf_lJCSkoeMho2PlJOLiouJj4Y� )
        {
            if ( $_obf_lJCSkoeMho2PlJOLiouJj4Y�['logintype'] == 1 )
            {
                $_obf_iZSViY2KjJSNjoePh4yOjI4� = TRUE;
            }
            else
            {
                $_obf_iYaQk4iUlYqRk46Kio_TiI8�[] = $_obf_lJCSkoeMho2PlJOLiouJj4Y�['loginip'];
            }
        }
        if ( !$_obf_iZSViY2KjJSNjoePh4yOjI4� || count( $_obf_houUi42Ki5SHiY_RiImQlZA� ) == 5 && in_array( $_obf_kYmJjZOIiZKJioqMkoaGiYk�, $_obf_iYaQk4iUlYqRk46Kio_TiI8� ) )
        {
            $GLOBALS['_SESSION']['loginimg'] = NULL;
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "该帐号连续五次登陆失败，您的IP已被锁定，如果你是合法用户请更换IP重试！" );
        }
    }
    $_obf_i4mRjZCJlZCGk4_UioyHk4k�['pid'] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid'];
    $_obf_i4mRjZCJlZCGk4_UioyHk4k�['managerid'] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
    if ( md5( $_obf_jZOIiIiJkJOGiY_KjoaGh4c� ) != $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['password'] )
    {
        $GLOBALS['_SESSION']['loginimg'] = NULL;
        $_obf_i4mRjZCJlZCGk4_UioyHk4k�['logintype'] = 4;
        _obf_jYuKk4uOiYmSkpOTj5GUlZA�( $_obf_i4mRjZCJlZCGk4_UioyHk4k� );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "用户名或密码错误！", 1 );
    }
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level'] < 8 )
    {
        if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level'] == 6 )
        {
            $_obf_kImIi4uNioeSlIiMjJOTipI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where id=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pmid'] );
            if ( $_obf_kImIi4uNioeSlIiMjJOTipI�['endtime'] < _obf_jZGJkpOSkY_HiY2HjY2JlIg�( ) )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "上级".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[$_obf_kImIi4uNioeSlIiMjJOTipI�['level']]."帐号已过期".$_obf_kImIi4uNioeSlIiMjJOTipI�['endtime'] );
            }
            if ( $_obf_kImIi4uNioeSlIiMjJOTipI�['islock'] == 1 )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "上级".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[$_obf_kImIi4uNioeSlIiMjJOTipI�['level']]."帐号被锁定! [锁定原因：".$_obf_kImIi4uNioeSlIiMjJOTipI�['lockedinter']."]" );
            }
        }
        $_obf_kImIi4uNioeSlIiMjJOTipI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where pid=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']." and level>7" );
        if ( $_obf_kImIi4uNioeSlIiMjJOTipI�['endtime'] < _obf_jZGJkpOSkY_HiY2HjY2JlIg�( ) )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "上级".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[8]."帐号已过期".$_obf_kImIi4uNioeSlIiMjJOTipI�['endtime'] );
        }
        if ( $_obf_kImIi4uNioeSlIiMjJOTipI�['islock'] == 1 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "上级".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[8]."帐号被锁定! [锁定原因：".$_obf_kImIi4uNioeSlIiMjJOTipI�['lockedinter']."]" );
        }
    }
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['islock'] == "1" )
    {
        $_obf_i4mRjZCJlZCGk4_UioyHk4k�['logintype'] = 3;
        _obf_jYuKk4uOiYmSkpOTj5GUlZA�( $_obf_i4mRjZCJlZCGk4_UioyHk4k� );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您的帐号被锁定，".( empty( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['lockedinter'] ) ? "锁定原因不明" : $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['lockedinter'] )."！", 1 );
    }
    if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] < _obf_jZGJkpOSkY_HiY2HjY2JlIg�( ) )
    {
        $_obf_i4mRjZCJlZCGk4_UioyHk4k�['logintype'] = 2;
        _obf_jYuKk4uOiYmSkpOTj5GUlZA�( $_obf_i4mRjZCJlZCGk4_UioyHk4k� );
        $_obf_lZONiYiNkJCNkZWUjY_JkYw� = "";
        if ( stripos( $_SERVER['SERVER_NAME'], "v9.hphu.com" ) !== FALSE && $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level'] == 8 )
        {
            $_obf_lZONiYiNkJCNkZWUjY_JkYw� = "，现在就去<a href=http://www.hphu.com/free.html>延长帐号有效期</a>";
        }
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您的帐号已过期，过期日期".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'].$_obf_lZONiYiNkJCNkZWUjY_JkYw�, 1 );
    }
    $_obf_kI6PjYmLhpGMk4qGjZSHlIg� = _obf_iI6QhpSTiJCJiI_KlYePlZI�( 48 );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set `linecode`='".$_obf_kI6PjYmLhpGMk4qGjZSHlIg�."',`lastlogintime`='"._obf_jZGJkpOSkY_HiY2HjY2JlIg�( )."',`lastloginip`=".$_obf_kYmJjZOIiZKJioqMkoaGiYk�." where `id`=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'], "notsync" );
    $_obf_i4mRjZCJlZCGk4_UioyHk4k�['logintype'] = 1;
    _obf_jYuKk4uOiYmSkpOTj5GUlZA�( $_obf_i4mRjZCJlZCGk4_UioyHk4k� );
    $_obf_i4qGi5WLhoqPkoyGkoiMhpU� = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'].",".$_obf_h4eSk4uGiZCKhoyNkIiTlI8�.",".md5( $_obf_jZOIiIiJkJOGiY_KjoaGh4c� ).",".$_obf_kI6PjYmLhpGMk4qGjZSHlIg�;
    _obf_jZKVlY6HkYmKkIyRj4qSjIc�( "kss_manager", $_obf_i4qGi5WLhoqPkoyGkoiMhpU� );
    $_obf_lZSUiIeMi5SPjpCGh4yVios� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "jz", "p", "int", 0 );
    if ( $_obf_lZSUiIeMi5SPjpCGh4yVios� == 1 )
    {
        _obf_lI2NjoyHh4mLlYqJjJSQlYg�( "cook_jz", "1" );
        _obf_lI2NjoyHh4mLlYqJjJSQlYg�( "cook_u", $_obf_h4eSk4uGiZCKhoyNkIiTlI8� );
        _obf_lI2NjoyHh4mLlYqJjJSQlYg�( "cook_p", $_obf_jZOIiIiJkJOGiY_KjoaGh4c� );
    }
    if ( stripos( $_SERVER['SERVER_NAME'], "v9.hphu.com" ) !== FALSE && $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['level'] == 8 && substr( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'], 0, 4 ) < 2038 && strtotime( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'] ) - time( ) < 604800 )
    {
        echo "<html><head><meta HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=utf-8'><title>登陆成功--友情提示</title><style>*{font-size:12px}</style></head><body>";
        echo "你帐号可用时间不足一星期(".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['endtime'].")，";
        echo "请及时<a href=http://www.hphu.com/free.html target=_blank style='color:red'>延期</a>以免影响正常使用。<br><br>";
        echo "<a href='admin.php?nc=".time( )."' style='color:red'>进入后台</a>";
        echo "<body></html>";
        exit( );
    }
    echo "<html><head><meta HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=utf-8'>";
    echo "<meta http-equiv='refresh' content='0.1;url=admin.php?nc=".time( )."'>";
    echo "<title>登陆成功--跳转中</title><style>*{font-size:12px}</style></head><body><script>location.href='admin.php?nc=".time( )."';</script>";
    echo "<a href='admin.php?nc=".time( )."'>正在转向中，如果长时间没跳转请单击这里</a>";
    echo "<body></html>";
    exit( );
}
$_obf_jYuMjo_JjZGOj4uNlIeTh4s� = "";
$_obf_jZCUkIiLjYaTjpOSlYmJjIo� = "";
if ( isset( $_GET['demo'] ) )
{
    $_obf_jYuMjo_JjZGOj4uNlIeTh4s� = "test01";
    $_obf_jZCUkIiLjYaTjpOSlYmJjIo� = "可可网络验证";
}
$_obf_ioeUkIqVhpSTk5GTj4yJj5E� = 0;
if ( _obf_k5OSjY_Rh4_HkYiOko6QhpM�( "cook_jz" ) == 1 )
{
    $_obf_ioeUkIqVhpSTk5GTj4yJj5E� = 1;
}
if ( $_obf_ioeUkIqVhpSTk5GTj4yJj5E� == 1 )
{
    $_obf_jYuMjo_JjZGOj4uNlIeTh4s� = _obf_k5OSjY_Rh4_HkYiOko6QhpM�( "cook_u" );
    $_obf_jZCUkIiLjYaTjpOSlYmJjIo� = _obf_k5OSjY_Rh4_HkYiOko6QhpM�( "cook_p" );
}
_obf_lZWPjZSUjI6VkImViIySko8�( KSSINCDIR."_config.php" );
_obf_lZWPjZSUjI6VkImViIySko8�( KSSINCDIR."inc.php" );
_obf_lZWPjZSUjI6VkImViIySko8�( KSSROOTDIR."kss_api".DIRECTORY_SEPARATOR."BIG5.php" );
_obf_lZWPjZSUjI6VkImViIySko8�( KSSROOTDIR."kss_api".DIRECTORY_SEPARATOR."GBK.php" );
_obf_lZWPjZSUjI6VkImViIySko8�( KSSROOTDIR."kss_api".DIRECTORY_SEPARATOR."io_ext.php" );
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\r\n<head>\r\n<title>";
echo ADMINWEBNAME;
echo "--";
echo KSSVERSION;
echo "  </title>\r\n<meta HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=utf-8\" />\r\n<meta name=\"服务端版本\" content=\"Version ";
echo KSSVERSION;
echo "\" />\r\n<meta name=\"开发商\" content=\"火云网络工作室  http://www.hphu.com  QQ188372002\" />\r\n<script type=\"text/javascript\" src=\"";
echo INSTALLPATH;
echo "kss_inc/js/jquery.1.3.2.pack.js\" charset=\"utf-8\"></script>\r\n<link rel=\"shortcut icon\" href=\"/favicon.ico\" />\r\n<style>\r\na{font-size:12px;color:#666;text-decoration:none;}\r\nbody{background:#ffffff url(../kss_inc/images/login_01.png) repeat-x;}\r\nform{margin:0;padding:0}\r\ninput{font-size:12px}\r\n#username{background:url(../kss_inc/images/user1.png) no-repeat;border:1px solid #ccc;width:200px;height:28px;padding:0 0 0 40px;margin:0;line-height:28px;}\r\n\r\n#password{font-size:12px;font-family: Fixedsys;line-height:24px;background:url(../kss_inc/images/passwordt.png) no-repeat;border:1px solid #ccc;color:#fff;width:200px;height:28px;padding:0 0 0 40px;margin:0;line-height:28px;}\r\n#input3{background:url(../kss_inc/images/password2.png) no-repeat;ime-mode:disabled;border:1px solid #ccc;width:200px!important;height:28px;padding:0 0 0 40px;margin:0;line-height:28px;}\r\n#chkimg{display:block;position:absolute;top:-26px;left:187px}\r\n#psssdiv{position:absolute;top:-100px;left:0px;width:200px;height:22px;line-height:22px;background-color:#fff;margin:0;font-size:12px;font-family: Fixedsys;color:#ccc;}\r\n</style>\r\n</head>\r\n<body  leftmargin=\"0\" topmargin=\"0\" marginwidth=\"0\" marginheight=\"0\">\r\n\r\n<script type=\"text/javascript\">\r\nvar imgtime=0;\r\nfunction t2p(s){\r\nvar e='';\r\nfor(var i = 0; i < s.length; i++){\r\nif(s.charCodeAt(i) < 256 ) {\r\ne=e+\"#\";\r\n}else{\r\ne=e+\"╳\";  \n}\r\n}\r\nreturn e;\r\n}\r\n\r\nfunction sTime(){var d,s;d = new Date();s=d.getTime();return(s);}\r\n\$(document).ready(function(){\r\nimgtime=sTime();\r\n\$(\"#input3\").bind(\"focus\",function(){\r\nif(sTime()-imgtime>50*1000){\r\n\$(\"#chkimg\").attr(\"src\",\"./loginimg.php?rndid=\"+sTime());\r\nimgtime=sTime();\r\n}\r\n});\r\n\$(\"#chkimg\").bind(\"click\",function(){\r\n\$(\"#chkimg\").attr(\"src\",\"./loginimg.php?rndid=\"+sTime());\r\n});\r\n\r\n\$(\"#password\").bind(\"click\",function(){\r\nvar c1=\$(this).offset();\r\n\$(\"#psssdiv\").css({top:c1.top+5,left:c1.left+40});\r\n\$(this).val(\"\");\r\n\$(\"#psssdiv\").text(\"\");\r\n});\r\n\r\n\$(\"#password\").bind(\"keyup\",function(){\r\nvar e1=\$(this).val();\r\n\$(\"#psssdiv\").text(t2p(e1));\r\n});\r\n\r\n\$(\"#psssdiv\").bind(\"click\",function(){\r\n\$(\"#password\").click().focus();\r\n}).bind(\"dblclick\",function(){\r\n\$(\"#password\").dblclick().focus();\r\n});\r\nwindow.setInterval(loadps, 200);\r\n\$(\"#username\").focus();\r\n";
if ( $_obf_ioeUkIqVhpSTk5GTj4yJj5E� == 1 )
{
    echo "\$(\"#psssdiv\").text(t2p(\$(\"#password\").val()));\r\n\$(\"#input3\").focus();\r\n";
}
if ( isset( $_GET['demo'] ) )
{
    echo "\$(\"#input3\").val(\"8888\");\r\n\$(\"#find_manager\").submit();\r\n";
}
echo "});\r\nfunction loadps(){\r\nvar c3=\$(\"#password\").offset();\r\n\$(\"#psssdiv\").css({top:c3.top+5,left:c3.left+40});\r\n}\r\n</script>\r\n<table id=\"__login\" width=\"940\" height=\"560\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=center>\r\n<form id=\"find_manager\" action=\"index.php?action=chklogin\" method=\"post\"> \r\n<tr>\r\n<td rowspan=\"3\" style=\"background:url(../kss_inc/images/login_02.png);\"  width=\"208\" height=\"560\">&nbsp;</td>\r\n<td style=\"background:url(../kss_inc/images/login_03.png);\"  width=\"517\" height=\"239\">&nbsp;</td>\r\n<td rowspan=\"3\" style=\"background:url(../kss_inc/images/login_04.png);\" width=\"215\" height=\"560\">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td style=\"background:url(../kss_inc/images/login_05.png);\" width=\"517\" height=\"190\" align=center>\r\n<table width=\"230\" height=100\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=center>\r\n<tr>\r\n<td colspan=2><input type=\"text\" value=\"";
echo $_obf_jYuMjo_JjZGOj4uNlIeTh4s�;
echo "\" name=\"username\" id=\"username\" maxlength=\"15\" AUTOCOMPLETE=\"off\"><br><br></td>\r\n</tr>\r\n<tr>\r\n<td colspan=2><input type=\"text\" value=\"";
echo $_obf_jZCUkIiLjYaTjpOSlYmJjIo�;
echo "\" id=\"password\" name=\"password\"  maxlength=\"15\" AUTOCOMPLETE=\"off\"><br><br></td>\r\n</tr>\r\n<tr>\r\n<td colspan=2 align=left><input type=\"text\" name=\"loginimg\" maxlength=\"6\" AUTOCOMPLETE=\"off\" id=\"input3\"><div style=\"position:relative;\"><img id=\"chkimg\" src=\"./loginimg.php?rndid=";
echo time( );
echo "\"></div></td>\r\n</tr>\r\n<tr>\r\n<td width=120 nowarp><input type=checkbox ";
if ( $_obf_ioeUkIqVhpSTk5GTj4yJj5E� == 1 )
{
    echo "checked ";
}
echo " value=1 name=jz id=jz ><label style=\"font-size:11px\" for=jz>记住密码</label></td><td><input style=\"margin-top:3px\" type=\"image\" src=\"../kss_inc/images/login_.png\"></td>\r\n</tr>\r\n</table>\t\t\r\n</td>\r\n</tr>\r\n<tr>\r\n<td style=\"background:url(../kss_inc/images/login_06.png);\" width=\"517\" height=\"131\" align=center>";
if ( ICPNUM != "" )
{
    echo "<a href=http://www.miibeian.gov.cn/ target=_blank>".ICPNUM."</a>";
}
echo "&nbsp;Ver: ";
echo KSSVERSION;
echo "</td>\r\n</tr>\r\n</table>\r\n<div id='psssdiv'>请输入密码，支持中文</div><div id=\"psssdiv2\"></div>\r\n<script>\r\n\r\n\r\n</script>\r\n</body>\r\n</html>";
?>
