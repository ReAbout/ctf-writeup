<?php

function _obf_iYeSi5SNlZSUhoiMjImQi4Y�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_kJCTi4yGi4aMjomOjYmJlYo�( $_obf_koiKkIiPjI6UkYeRlIqNhoc�, $_obf_hpSVjpOKhouRkpOLjY6MkYY�, $_obf_io6UjZWThpOSjYeOj46Qkow� )
{
    return preg_replace( "/define\\('".$_obf_hpSVjpOKhouRkpOLjY6MkYY�."','[^']*'\\)/i", "define('".$_obf_hpSVjpOKhouRkpOLjY6MkYY�."','".$_obf_io6UjZWThpOSjYeOj46Qkow�."')", $_obf_koiKkIiPjI6UkYeRlIqNhoc� );
}

function _obf_jI6Jh5SLiY_Pko6PkYaRk44�( $_obf_koiKkIiPjI6UkYeRlIqNhoc�, $_obf_hpSVjpOKhouRkpOLjY6MkYY�, $_obf_io6UjZWThpOSjYeOj46Qkow� )
{
    return preg_replace( "/define\\('".$_obf_hpSVjpOKhouRkpOLjY6MkYY�."',[^\\)]*\\)/i", "define('".$_obf_hpSVjpOKhouRkpOLjY6MkYY�."',".$_obf_io6UjZWThpOSjYeOj46Qkow�.")", $_obf_koiKkIiPjI6UkYeRlIqNhoc� );
}

require( "../kss_inc/inc.php" );
$_obf_lZOThomRipOIi5SRhpWRjY4� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "action", "gp", "sql", "" );
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_iY2KjYiVj4aUkpSKkYaPlZM� = 0;
if ( isset( $_GET['t'], $_GET['t'] ) )
{
    if ( md5( $_GET['t']."urlkeyIjjeruik987" ) != $_GET['m'] )
    {
        exit( "<script>alert('err:url md5');</script>" );
    }
    if ( time( ) < $_GET['t'] || 20 < time( ) - $_GET['t'] )
    {
        exit( "<script>alert('err:url time');</script>" );
    }
    $_obf_iY2KjYiVj4aUkpSKkYaPlZM� = 1;
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
}
if ( $_obf_iY2KjYiVj4aUkpSKkYaPlZM� == 0 )
{
    $_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iZSVk4mLkY_LlIeHh5WKlZA�( 9 );
}
$_obf_ioyNhoyGk5GGlY6UjomGhoo� = file_get_contents( "../kss_inc/_config.php" );
$_obf_lZGTiYqOjI_SlJGPkYeNjIg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_config where id=1" );
$_obf_ioyNhoyGk5GGlY6UjomGhoo� = _obf_jI6Jh5SLiY_Pko6PkYaRk44�( $_obf_ioyNhoyGk5GGlY6UjomGhoo�, "RSACRYPT", $_obf_lZGTiYqOjI_SlJGPkYeNjIg�['s_rsamode'] );
$_obf_ioyNhoyGk5GGlY6UjomGhoo� = _obf_kJCTi4yGi4aMjomOjYmJlYo�( $_obf_ioyNhoyGk5GGlY6UjomGhoo�, "RSA_PRVKEY", $_obf_lZGTiYqOjI_SlJGPkYeNjIg�['s_rsaekey'] );
$_obf_ioyNhoyGk5GGlY6UjomGhoo� = _obf_kJCTi4yGi4aMjomOjYmJlYo�( $_obf_ioyNhoyGk5GGlY6UjomGhoo�, "RSA_MODULES", $_obf_lZGTiYqOjI_SlJGPkYeNjIg�['s_rsankey'] );
$_obf_ioyNhoyGk5GGlY6UjomGhoo� = file_put_contents( "../kss_inc/_config.php", $_obf_ioyNhoyGk5GGlY6UjomGhoo� );
_obf_k42GhouUh5SVj4uSlYqRlYg�( );
if ( $_obf_iY2KjYiVj4aUkpSKkYaPlZM� == 0 )
{
    exit( "全局RSA、软件私有RSA、软件ADVAPI、软件数组数据缓存更新完毕！" );
}
exit( "<script>alert('重建缓存OK');</script>" );
?>
