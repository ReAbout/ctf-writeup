<?php

function _obf_jpCLkIyHhoqPjYmSkY2PlIc�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_io_Mio_Ii5SPiIeKjoaGkos�( $_obf_lIyUkIaVk46LiZCNipOIkJA�, &$_obf_lJWGkouIj4uGlIaVhpWUko4� )
{
    if ( trim( $_obf_lIyUkIaVk46LiZCNipOIkJA� ) == "" )
    {
        return "";
    }
    $_obf_hoaPhoqTiIiHi4qSjI_OipM� = strrev( "dUGJS00JAk6r" );
    switch ( CLVersion )
    {
    case 10 :
    case 11 :
        $_obf_kpSNh4_SjIiNi4mGjIiHkJA� = "F47yP63RgcDjCs|phQTI21UdO9AoXeL_BmMvx58ZJGnEYlbKatkqzwSfu0WHVirN";
        break;
    case 12 :
        $_obf_kpSNh4_SjIiNi4mGjIiHkJA� = "N3RgcD2uOUo8ZnEYqhG9AWHViX_BmMvx5QTI7eLyP6r0dKatkzwSfjCs|p4lb1JF";
        break;
    default :
        $_obf_kpSNh4_SjIiNi4mGjIiHkJA� = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_|";
    }
    $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� = strlen( $_obf_lIyUkIaVk46LiZCNipOIkJA� );
    if ( $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� % 3 != 0 )
    {
        $_obf_ipSMkIiVkpKJjY6Kj4iJiZU� = 3 - $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� % 3;
        $_obf_lIyUkIaVk46LiZCNipOIkJA� .= str_repeat( "0", $_obf_ipSMkIiVkpKJjY6Kj4iJiZU� );
        $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� += $_obf_ipSMkIiVkpKJjY6Kj4iJiZU�;
    }
    else
    {
        $_obf_ipSMkIiVkpKJjY6Kj4iJiZU� = 0;
    }
    if ( $_obf_lJWGkouIj4uGlIaVhpWUko4� == 0 )
    {
        $_obf_lJWGkouIj4uGlIaVhpWUko4� = rand( 26, 254 );
    }
    $_obf_kpSNh4_SjIiNi4mGjIiHkJA� = substr( $_obf_kpSNh4_SjIiNi4mGjIiHkJA�, $_obf_lJWGkouIj4uGlIaVhpWUko4� % 60 + 1, 63 - $_obf_lJWGkouIj4uGlIaVhpWUko4� % 60 ).substr( $_obf_kpSNh4_SjIiNi4mGjIiHkJA�, 0, $_obf_lJWGkouIj4uGlIaVhpWUko4� % 60 + 1 );
    $_obf_lJKJioqQjIeJhoaPlYuNlJE� = unpack( "C*", $_obf_kpSNh4_SjIiNi4mGjIiHkJA� );
    $_obf_kpSPkpGUk46IlIaHlIyGjJM� = unpack( "C*", $_obf_hoaPhoqTiIiHi4qSjI_OipM� );
    $_obf_k46QlJSQkIiJh42Jj4uNkpU� = unpack( "C*", HTTPKEY );
    $_obf_k4aVhpSHkoqGj5WGhoqQjYo� = unpack( "C*", $_obf_lIyUkIaVk46LiZCNipOIkJA� );
    $_obf_ho2Gh4_Jh5GQh4mGjZWPkJQ� = strtoupper( dechex( intval( $_obf_lJWGkouIj4uGlIaVhpWUko4�.$_obf_ipSMkIiVkpKJjY6Kj4iJiZU� ) ) );
    $_obf_hoaUk4qViJWIi5KTj4yOkZE� = strlen( $_obf_hoaPhoqTiIiHi4qSjI_OipM� );
    $_obf_jI_SipWLkImHkYqSjo2JkYk� = intval( $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� * 4 / 3 );
    $_obf_hpCGjIqVko2PiIqPiJKOlIY� = unpack( "C*", str_repeat( chr( 0 ), $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� ) );
    $_obf_hpCGjIqVko2PiIqPiJKOlIY�[0] = 0;
    $_obf_lYeVipCSko6IhouTk4qOk4Y� = $_obf_lJWGkouIj4uGlIaVhpWUko4� % 249;
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� + 1; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
    {
        $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] = $_obf_k4aVhpSHkoqGj5WGhoqQjYo�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] ^ $_obf_kpSPkpGUk46IlIaHlIyGjJM�[( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� - 1 ) % $_obf_hoaUk4qViJWIi5KTj4yOkZE� + 1];
        $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = 1;
        for ( ; $_obf_jIiLiYiQj5CSk5KRjJSGjYw� < 6; ++$_obf_jIiLiYiQj5CSk5KRjJSGjYw�, )
        {
            $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] = $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] ^ $_obf_lYeVipCSko6IhouTk4qOk4Y� + $_obf_jIiLiYiQj5CSk5KRjJSGjYw�;
        }
    }
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� + 1; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
    {
        $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] = $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] ^ $_obf_k46QlJSQkIiJh42Jj4uNkpU�[( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� - 1 ) % 64 + 1];
    }
    $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = 1;
    for ( ; $_obf_jIiLiYiQj5CSk5KRjJSGjYw� < 6; ++$_obf_jIiLiYiQj5CSk5KRjJSGjYw�, )
    {
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1;
        for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� + 1; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
        {
            $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] = $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] ^ $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� - 1];
        }
    }
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1;
    do
    {
        $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = intval( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� / 3 ) * 4;
        $_obf_kImKho_MjZKSjIqSiYuNj4s� = ( $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_koeLkIyUiZKQjpCHlJGLiYs� = ( ( $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] & 15 ) << 8 ) + $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 2];
        $_obf_ho2Gh4_Jh5GQh4mGjZWPkJQ� .= chr( $_obf_lJKJioqQjIeJhoaPlYuNlJE�[intval( $_obf_kImKho_MjZKSjIqSiYuNj4s� / 64 ) + 1] ).chr( $_obf_lJKJioqQjIeJhoaPlYuNlJE�[$_obf_kImKho_MjZKSjIqSiYuNj4s� % 64 + 1] ).chr( $_obf_lJKJioqQjIeJhoaPlYuNlJE�[intval( $_obf_koeLkIyUiZKQjpCHlJGLiYs� / 64 ) + 1] ).chr( $_obf_lJKJioqQjIeJhoaPlYuNlJE�[$_obf_koeLkIyUiZKQjpCHlJGLiYs� % 64 + 1] );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 3;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� + 1 );
    return $_obf_ho2Gh4_Jh5GQh4mGjZWPkJQ�;
}

function _obf_ipSSlJORlJGNkYaKlYyHjYw�( $_obf_lIyUkIaVk46LiZCNipOIkJA�, &$_obf_lJWGkouIj4uGlIaVhpWUko4� )
{
    if ( trim( $_obf_lIyUkIaVk46LiZCNipOIkJA� ) == "" )
    {
        return "";
    }
    $_obf_hoaPhoqTiIiHi4qSjI_OipM� = strrev( "dUGJS00JAk6r" );
    switch ( CLVersion )
    {
    case 10 :
    case 11 :
        $_obf_kpSNh4_SjIiNi4mGjIiHkJA� = "F47yP63RgcDjCs|phQTI21UdO9AoXeL_BmMvx58ZJGnEYlbKatkqzwSfu0WHVirN";
        break;
    case 12 :
        $_obf_kpSNh4_SjIiNi4mGjIiHkJA� = "N3RgcD2uOUo8ZnEYqhG9AWHViX_BmMvx5QTI7eLyP6r0dKatkzwSfjCs|p4lb1JF";
        break;
    default :
        $_obf_kpSNh4_SjIiNi4mGjIiHkJA� = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_|";
    }
    $_obf_kY2Gho6Li5OOko6IkoePj4k� = hexdec( substr( $_obf_lIyUkIaVk46LiZCNipOIkJA�, 0, 3 ) );
    if ( $_obf_lJWGkouIj4uGlIaVhpWUko4� == 0 )
    {
        $_obf_lJWGkouIj4uGlIaVhpWUko4� = intval( substr( $_obf_kY2Gho6Li5OOko6IkoePj4k�, 0, strlen( $_obf_kY2Gho6Li5OOko6IkoePj4k� ) - 1 ) );
    }
    $_obf_ipSMkIiVkpKJjY6Kj4iJiZU� = intval( substr( $_obf_kY2Gho6Li5OOko6IkoePj4k�, strlen( $_obf_kY2Gho6Li5OOko6IkoePj4k� ) - 1, 1 ) );
    $_obf_kpSNh4_SjIiNi4mGjIiHkJA� = substr( $_obf_kpSNh4_SjIiNi4mGjIiHkJA�, $_obf_lJWGkouIj4uGlIaVhpWUko4� % 60 + 1, 63 - $_obf_lJWGkouIj4uGlIaVhpWUko4� % 60 ).substr( $_obf_kpSNh4_SjIiNi4mGjIiHkJA�, 0, $_obf_lJWGkouIj4uGlIaVhpWUko4� % 60 + 1 );
    $_obf_lJKJioqQjIeJhoaPlYuNlJE� = unpack( "C*", $_obf_kpSNh4_SjIiNi4mGjIiHkJA� );
    $_obf_kpSPkpGUk46IlIaHlIyGjJM� = unpack( "C*", $_obf_hoaPhoqTiIiHi4qSjI_OipM� );
    $_obf_k46QlJSQkIiJh42Jj4uNkpU� = unpack( "C*", HTTPKEY );
    $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� = strlen( $_obf_lIyUkIaVk46LiZCNipOIkJA� ) - 3;
    $_obf_hoaUk4qViJWIi5KTj4yOkZE� = strlen( $_obf_hoaPhoqTiIiHi4qSjI_OipM� );
    $_obf_lIyUkIaVk46LiZCNipOIkJA� = substr( $_obf_lIyUkIaVk46LiZCNipOIkJA�, 3, $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� );
    $_obf_iJCOlJGVlZOThouHjI2Sj4o� = intval( $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� * 3 / 4 );
    $_obf_k4aVhpSHkoqGj5WGhoqQjYo� = unpack( "C*", $_obf_lIyUkIaVk46LiZCNipOIkJA� );
    $_obf_hpCGjIqVko2PiIqPiJKOlIY� = unpack( "C*", str_repeat( chr( 0 ), $_obf_iJCOlJGVlZOThouHjI2Sj4o� ) );
    $_obf_hpCGjIqVko2PiIqPiJKOlIY�[0] = 0;
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1;
    do
    {
        $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = intval( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� / 4 ) * 3;
        $_obf_h4mIkpOMkYyOjY_Nh4uLk4g� = strpos( $_obf_kpSNh4_SjIiNi4mGjIiHkJA�, $_obf_k4aVhpSHkoqGj5WGhoqQjYo�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] ) * 64 + strpos( $_obf_kpSNh4_SjIiNi4mGjIiHkJA�, $_obf_k4aVhpSHkoqGj5WGhoqQjYo�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] );
        $_obf_k5GUjY_Hio6GiZSRkZKRjok� = strpos( $_obf_kpSNh4_SjIiNi4mGjIiHkJA�, $_obf_k4aVhpSHkoqGj5WGhoqQjYo�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 2] ) * 64 + strpos( $_obf_kpSNh4_SjIiNi4mGjIiHkJA�, $_obf_k4aVhpSHkoqGj5WGhoqQjYo�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 3] );
        $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw� + 1] = $_obf_h4mIkpOMkYyOjY_Nh4uLk4g� >> 4;
        $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw� + 2] = ( ( $_obf_h4mIkpOMkYyOjY_Nh4uLk4g� & 15 ) << 4 ) + ( $_obf_k5GUjY_Hio6GiZSRkZKRjok� >> 8 );
        $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw� + 3] = $_obf_k5GUjY_Hio6GiZSRkZKRjok� & 255;
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 4;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_kJWQiJOMi5GNj5CLkIiKiJQ� );
    $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = 1;
    for ( ; $_obf_jIiLiYiQj5CSk5KRjJSGjYw� < 6; ++$_obf_jIiLiYiQj5CSk5KRjJSGjYw�, )
    {
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1;
        for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_iJCOlJGVlZOThouHjI2Sj4o� + 1; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
        {
            $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_iJCOlJGVlZOThouHjI2Sj4o� - $_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] = $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_iJCOlJGVlZOThouHjI2Sj4o� - $_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] ^ $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_iJCOlJGVlZOThouHjI2Sj4o� - $_obf_jpKPlJSUiZOHkYaPlIeOiY4�];
        }
    }
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_iJCOlJGVlZOThouHjI2Sj4o� + 1; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
    {
        $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] = $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] ^ $_obf_k46QlJSQkIiJh42Jj4uNkpU�[( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� - 1 ) % 64 + 1];
    }
    $_obf_ho2Gh4_Jh5GQh4mGjZWPkJQ� = "";
    $_obf_lYeVipCSko6IhouTk4qOk4Y� = $_obf_lJWGkouIj4uGlIaVhpWUko4� % 249;
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_iJCOlJGVlZOThouHjI2Sj4o� + 1; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
    {
        $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = 0;
        for ( ; $_obf_jIiLiYiQj5CSk5KRjJSGjYw� < 5; ++$_obf_jIiLiYiQj5CSk5KRjJSGjYw�, )
        {
            $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] = $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] ^ $_obf_lYeVipCSko6IhouTk4qOk4Y� + 5 - $_obf_jIiLiYiQj5CSk5KRjJSGjYw�;
        }
        $_obf_ho2Gh4_Jh5GQh4mGjZWPkJQ� .= chr( $_obf_hpCGjIqVko2PiIqPiJKOlIY�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] ^ $_obf_kpSPkpGUk46IlIaHlIyGjJM�[( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� - 1 ) % $_obf_hoaUk4qViJWIi5KTj4yOkZE� + 1] );
    }
    $_obf_ho2Gh4_Jh5GQh4mGjZWPkJQ� = substr( $_obf_ho2Gh4_Jh5GQh4mGjZWPkJQ�, 0, strlen( $_obf_ho2Gh4_Jh5GQh4mGjZWPkJQ� ) - $_obf_ipSMkIiVkpKJjY6Kj4iJiZU� );
    return $_obf_ho2Gh4_Jh5GQh4mGjZWPkJQ�;
}

?>
