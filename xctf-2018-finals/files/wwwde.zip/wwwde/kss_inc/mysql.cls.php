<?php

class mysql_cls
{

    public $����������������� = NULL;
    public $����������������� = NULL;

    public function _obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_h42JipKTjZKOk4mUjZWVjok�, $_obf_h5WKkImSkIiTjIqHi5KUjpM� = 1 )
    {
        global $_obf_mGKRY4dMuU6bZZJfh1_TX5k�;
        $this->����������������� = mysql_connect( $_obf_h42JipKTjZKOk4mUjZWVjok�['dbhost'], $_obf_h42JipKTjZKOk4mUjZWVjok�['dbuser'], $_obf_h42JipKTjZKOk4mUjZWVjok�['dbpass'], $_obf_h42JipKTjZKOk4mUjZWVjok�['newlink'] );
        if ( !$this->����������������� )
        {
            $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� = mysql_error( );
            $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� = preg_replace( "/\\[.*\\]/", "", $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� );
            $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� = preg_replace( "/\\'[^\\']*\\'/", "'***'", $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� );
            if ( $_obf_h5WKkImSkIiTjIqHi5KUjpM� == 1 )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� );
            }
            else
            {
                return $_obf_kZONjI2Kk5SOlY2Gj5CSj4o�;
            }
        }
        if ( !mysql_select_db( $_obf_h42JipKTjZKOk4mUjZWVjok�['dbname'], $this->����������������� ) )
        {
            $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� = mysql_error( );
            $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� = preg_replace( "/\\[.*\\]/", "", $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� );
            $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� = preg_replace( "/\\'[^\\']*\\'/", "'***'", $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� );
            if ( $_obf_h5WKkImSkIiTjIqHi5KUjpM� == 1 )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� );
            }
            else
            {
                return $_obf_kZONjI2Kk5SOlY2Gj5CSj4o�;
            }
        }
        if ( !mysql_query( "set names 'utf8'" ) )
        {
            $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� = mysql_error( );
            $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� = preg_replace( "/\\[.*\\]/", "", $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� );
            $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� = preg_replace( "/\\'[^\\']*\\'/", "'***'", $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� );
            if ( $_obf_h5WKkImSkIiTjIqHi5KUjpM� == 1 )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_kZONjI2Kk5SOlY2Gj5CSj4o� );
                return "success";
            }
            return $_obf_kZONjI2Kk5SOlY2Gj5CSj4o�;
        }
        return "success";
    }

    public function api__query( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_k4yHk5KGiImKlIeNkYuRlJQ� = "not_sync", $_obf_kJWQk46KjIuKlImOjJWHjpA� = 0 )
    {
        return $this->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_k4yHk5KGiImKlIeNkYuRlJQ�, $_obf_kJWQk46KjIuKlImOjJWHjpA� );
    }

    public function _obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_k4yHk5KGiImKlIeNkYuRlJQ� = "not_sync", $_obf_kJWQk46KjIuKlImOjJWHjpA� = 0 )
    {
        if ( $_obf_kJWQk46KjIuKlImOjJWHjpA� == 0 )
        {
            $_obf_kpSOj5KVio2Hj4uKj4_KjIY� = mysql_query( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $this->����������������� );
        }
        else
        {
            $_obf_kpSOj5KVio2Hj4uKj4_KjIY� = mysql_unbuffered_query( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $this->����������������� );
        }
        if ( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� === FALSE )
        {
            $this->_obf_k4mUj5OViI6HjY2JiYiLjJA�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� );
            return $_obf_kpSOj5KVio2Hj4uKj4_KjIY�;
        }
        if ( substr( strtolower( trim( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� ) ), 0, 24 ) != "insert into `kss_tb_sql`" && in_array( substr( strtolower( trim( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� ) ), 0, 6 ), array( "update", "delete", "insert", "replac" ) ) )
        {
            $this->����������������� = mysql_affected_rows( );
        }
        if ( IS2SVR == 1 && $_obf_k4yHk5KGiImKlIeNkYuRlJQ� == "sync" && substr( strtolower( trim( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� ) ), 0, 6 ) !== "select" )
        {
            $_obf_lYyJjIePlZOGk4_RkYeSjo0� = $this->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `kss_tb_sql` (`addtime`,`sqltext`) VALUES (".time( ).",'".mysql_real_escape_string( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� )."')", "notsync" );
        }
        return $_obf_kpSOj5KVio2Hj4uKj4_KjIY�;
    }

    public function _obf_ho_Ljo6NjpOOhpGHj5KHiYs�( $_obf_h5ORhoePi4iTjI2HiYaGho4� = "defult", $_obf_jo2Sh4uNh4aViomIioqGlI4� = 0, $_obf_jJONioiJjpGMiJSOi4aGk4Y� = 0 )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = TRUE;
        if ( $_obf_jJONioiJjpGMiJSOi4aGk4Y� == 0 )
        {
            $_obf_jJONioiJjpGMiJSOi4aGk4Y� = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
        }
        $_obf_iYaNkZKGlIqVjoySiJKLi4c� = $this->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `kss_tb_lock` (`lockname`,`locktime`) values ('".$_obf_h5ORhoePi4iTjI2HiYaGho4�."',".time( ).")", "notsync" );
        if ( $_obf_iYaNkZKGlIqVjoySiJKLi4c� === FALSE )
        {
            $_obf_j4aUioiHlYmIi4iNi5GQiY8� = $this->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select locktime from kss_tb_lock where `lockname`='".$_obf_h5ORhoePi4iTjI2HiYaGho4�."'" );
            if ( AUTODELLOCK < abs( time( ) - $_obf_j4aUioiHlYmIi4iNi5GQiY8�['locktime'] ) )
            {
                $this->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_lock where `lockname`='".$_obf_h5ORhoePi4iTjI2HiYaGho4�."'", "notsync" );
                return $this->_obf_ho_Ljo6NjpOOhpGHj5KHiYs�( $_obf_h5ORhoePi4iTjI2HiYaGho4�, $_obf_jo2Sh4uNh4aViomIioqGlI4�, $_obf_jJONioiJjpGMiJSOi4aGk4Y� );
            }
            $_obf_kImMk5OViomJlYeIk4mVh40� = $this->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
            if ( substr( $_obf_kImMk5OViomJlYeIk4mVh40�, 0, 15 ) == "Duplicate entry" )
            {
                $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_h5ORhoePi4iTjI2HiYaGho4�."锁被占用中";
            }
            else
            {
                $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_h5ORhoePi4iTjI2HiYaGho4�."[".$_obf_kImMk5OViomJlYeIk4mVh40�."]";
            }
        }
        if ( $_obf_j4eSkIiSiZCRh4_NiYaQkYk� === TRUE )
        {
            return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
        }
        if ( $_obf_jo2Sh4uNh4aViomIioqGlI4� == 1 && _obf_hpCTj4mKj5WSkpWPjouJkoc�( ) - $_obf_jJONioiJjpGMiJSOi4aGk4Y� < 2 )
        {
            _obf_lYyMjpSLiZSVkpSLjJGMkYw�( 1000 );
            return $this->_obf_ho_Ljo6NjpOOhpGHj5KHiYs�( $_obf_h5ORhoePi4iTjI2HiYaGho4�, $_obf_jo2Sh4uNh4aViomIioqGlI4�, $_obf_jJONioiJjpGMiJSOi4aGk4Y� );
        }
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    }

    public function _obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_h5ORhoePi4iTjI2HiYaGho4� = "defult" )
    {
        $this->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_lock` where `lockname`='".$_obf_h5ORhoePi4iTjI2HiYaGho4�."'", "notsync" );
    }

    public function api__getrow( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_i5SUlYiJjY2Kk4iNkIaMjY0� = 1, $_obf_kJWQk46KjIuKlImOjJWHjpA� = 0 )
    {
        return $this->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_i5SUlYiJjY2Kk4iNkIaMjY0�, $_obf_kJWQk46KjIuKlImOjJWHjpA� );
    }

    public function _obf_iY6OkJCRkY2PjpCPk5CRkJA�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_i5SUlYiJjY2Kk4iNkIaMjY0� = 1, $_obf_kJWQk46KjIuKlImOjJWHjpA� = 0 )
    {
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI� = $this->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync", $_obf_kJWQk46KjIuKlImOjJWHjpA� );
        if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI� !== FALSE )
        {
            return $this->_obf_lJWJh4mKhpCLkJKUjZWSi5M�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, $_obf_i5SUlYiJjY2Kk4iNkIaMjY0� );
        }
        return FALSE;
    }

    public function api__getrows( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_i5SUlYiJjY2Kk4iNkIaMjY0� = 1 )
    {
        return $this->_obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_i5SUlYiJjY2Kk4iNkIaMjY0� );
    }

    public function _obf_lZGTiIiKhouKiZGLi5KUkI8�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_i5SUlYiJjY2Kk4iNkIaMjY0� = 1, $_obf_kJWQk46KjIuKlImOjJWHjpA� = 0 )
    {
        $_obf_kY_OlYeUlIiVjo6Hio_MkpI� = $this->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "not_sync", $_obf_kJWQk46KjIuKlImOjJWHjpA� );
        if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI� !== FALSE )
        {
            $_obf_jo6SjIuHj46LjIyTlIyQk4s� = array( );
            while ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $this->_obf_lJWJh4mKhpCLkJKUjZWSi5M�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�, $_obf_i5SUlYiJjY2Kk4iNkIaMjY0� ) )
            {
                $_obf_jo6SjIuHj46LjIyTlIyQk4s�[] = $_obf_iYeIjIaVlYaIj4yTiJWHk40�;
            }
            $this->_obf_lYuPlIeUlYuMiJGJiI2LiZE�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI� );
            return $_obf_jo6SjIuHj46LjIyTlIyQk4s�;
        }
        return FALSE;
    }

    public function _obf_kpSVjoiHkoeTlJSRiJGHiI0�( $_obf_k5WOjYqNj4mOiJGGipOQiIY�, $_obf_jo_Ti5WSkZSGjZSOi5OKlI8�, $_obf_k4yHk5KGiImKlIeNkYuRlJQ� = "not_sync", $_obf_j4qMj4eMk5CLkIuSkY2GkIc� = 0 )
    {
        $_obf_hpGGi42SjZWKjI2QkYqIk40� = $this->_obf_koaRi4aHjIiPiYmJh5SKh4k�( "DESC ".$_obf_k5WOjYqNj4mOiJGGipOQiIY� );
        $_obf_iYeIk42Sjo_GhpWOiZCOi5E� = array( );
        $_obf_k4ySiImVj5GGlIaNjYmLiog� = array( );
        if ( $_obf_hpGGi42SjZWKjI2QkYqIk40� === FALSE )
        {
            if ( $_obf_j4qMj4eMk5CLkIuSkY2GkIc� == 1 )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_k5WOjYqNj4mOiJGGipOQiIY�."表异常，需要修复（可能是C盘空间已满）！" );
                return FALSE;
            }
            $_obf_j4qMj4eMk5CLkIuSkY2GkIc� = 1;
            return $this->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( $_obf_k5WOjYqNj4mOiJGGipOQiIY�, $_obf_jo_Ti5WSkZSGjZSOi5OKlI8�, $_obf_k4yHk5KGiImKlIeNkYuRlJQ�, $_obf_j4qMj4eMk5CLkIuSkY2GkIc� );
        }
        foreach ( $_obf_hpGGi42SjZWKjI2QkYqIk40� as $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
        {
            if ( array_key_exists( $_obf_lYeSkY6Th5SOlYuHjZGVio8�, $_obf_jo_Ti5WSkZSGjZSOi5OKlI8� ) )
            {
                $_obf_iYeIk42Sjo_GhpWOiZCOi5E�[] = "`".$_obf_lYeSkY6Th5SOlYuHjZGVio8�."`";
                $_obf_k4ySiImVj5GGlIaNjYmLiog�[] = "'".mysql_real_escape_string( $_obf_jo_Ti5WSkZSGjZSOi5OKlI8�[$_obf_lYeSkY6Th5SOlYuHjZGVio8�] )."'";
            }
        }
        if ( !empty( $_obf_iYeIk42Sjo_GhpWOiZCOi5E� ) )
        {
            if ( $_obf_k4yHk5KGiImKlIeNkYuRlJQ� == "sql" )
            {
                return "insert into `".$_obf_k5WOjYqNj4mOiJGGipOQiIY�."` (".implode( ",", $_obf_iYeIk42Sjo_GhpWOiZCOi5E� ).") VALUES (".implode( ",", $_obf_k4ySiImVj5GGlIaNjYmLiog� ).")";
            }
            return $this->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `".$_obf_k5WOjYqNj4mOiJGGipOQiIY�."` (".implode( ",", $_obf_iYeIk42Sjo_GhpWOiZCOi5E� ).") VALUES (".implode( ",", $_obf_k4ySiImVj5GGlIaNjYmLiog� ).")", $_obf_k4yHk5KGiImKlIeNkYuRlJQ� );
        }
        return FALSE;
    }

    public function _obf_iJOJipCPk4yQlJOMlIeTjYs�( $_obf_k5WOjYqNj4mOiJGGipOQiIY�, $_obf_jo_Ti5WSkZSGjZSOi5OKlI8�, $_obf_h42QlImNjZSLj4qLkoqIlIg� = "", $_obf_k4yHk5KGiImKlIeNkYuRlJQ� = "not_sync", $_obf_j4qMj4eMk5CLkIuSkY2GkIc� = 0 )
    {
        $_obf_hpGGi42SjZWKjI2QkYqIk40� = $this->_obf_koaRi4aHjIiPiYmJh5SKh4k�( "DESC ".$_obf_k5WOjYqNj4mOiJGGipOQiIY� );
        $_obf_lY2SjIuNiouMkI2Kk4qMlYc� = array( );
        if ( $_obf_hpGGi42SjZWKjI2QkYqIk40� === FALSE )
        {
            if ( $_obf_j4qMj4eMk5CLkIuSkY2GkIc� == 1 )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_k5WOjYqNj4mOiJGGipOQiIY�."表异常，需要深度修复！" );
                return FALSE;
            }
            $_obf_j4qMj4eMk5CLkIuSkY2GkIc� = 1;
            return $this->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( $_obf_k5WOjYqNj4mOiJGGipOQiIY�, $_obf_jo_Ti5WSkZSGjZSOi5OKlI8�, $_obf_h42QlImNjZSLj4qLkoqIlIg�, $_obf_k4yHk5KGiImKlIeNkYuRlJQ�, $_obf_j4qMj4eMk5CLkIuSkY2GkIc� );
        }
        foreach ( $_obf_hpGGi42SjZWKjI2QkYqIk40� as $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
        {
            if ( array_key_exists( $_obf_lYeSkY6Th5SOlYuHjZGVio8�, $_obf_jo_Ti5WSkZSGjZSOi5OKlI8� ) )
            {
                $_obf_lY2SjIuNiouMkI2Kk4qMlYc�[] = "`".$_obf_lYeSkY6Th5SOlYuHjZGVio8�."`='".mysql_real_escape_string( $_obf_jo_Ti5WSkZSGjZSOi5OKlI8�[$_obf_lYeSkY6Th5SOlYuHjZGVio8�] )."'";
            }
        }
        if ( !empty( $_obf_lY2SjIuNiouMkI2Kk4qMlYc� ) )
        {
            if ( $_obf_k4yHk5KGiImKlIeNkYuRlJQ� == "sql" )
            {
                return "update ".$_obf_k5WOjYqNj4mOiJGGipOQiIY�." set ".implode( ", ", $_obf_lY2SjIuNiouMkI2Kk4qMlYc� )." where ".$_obf_h42QlImNjZSLj4qLkoqIlIg�;
            }
            return $this->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update ".$_obf_k5WOjYqNj4mOiJGGipOQiIY�." set ".implode( ", ", $_obf_lY2SjIuNiouMkI2Kk4qMlYc� )." where ".$_obf_h42QlImNjZSLj4qLkoqIlIg�, $_obf_k4yHk5KGiImKlIeNkYuRlJQ� );
        }
        return FALSE;
    }

    public function _obf_komUlJONiIqQk42JjYmOioY�( $_obf_k5WOjYqNj4mOiJGGipOQiIY� )
    {
        $_obf_kpSOj5KVio2Hj4uKj4_KjIY� = $this->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select max(`id`) from `".$_obf_k5WOjYqNj4mOiJGGipOQiIY�."`", 2 );
        if ( empty( $_obf_kpSOj5KVio2Hj4uKj4_KjIY�[0] ) )
        {
            return 0;
        }
        return $_obf_kpSOj5KVio2Hj4uKj4_KjIY�[0];
    }

    public function _obf_ioeOiIuTiJGQi42VkY_Vios�( $_obf_k5WOjYqNj4mOiJGGipOQiIY� )
    {
        $_obf_kpSOj5KVio2Hj4uKj4_KjIY� = mysql_query( "show table status where Name ='".$_obf_k5WOjYqNj4mOiJGGipOQiIY�."'", $this->����������������� );
        if ( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� === FALSE )
        {
            $_obf_lYeHjJWPkJKTiY6HkpCMiZQ� = $this->_obf_komUlJONiIqQk42JjYmOioY�( $_obf_k5WOjYqNj4mOiJGGipOQiIY� ) + 1;
            mysql_query( "ALTER TABLE `".$_obf_k5WOjYqNj4mOiJGGipOQiIY�."` AUTO_INCREMENT =".$_obf_lYeHjJWPkJKTiY6HkpCMiZQ�, $this->����������������� );
            return $_obf_lYeHjJWPkJKTiY6HkpCMiZQ�;
        }
        $_obf_iYeIjIaVlYaIj4yTiJWHk40� = mysql_fetch_array( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� );
        return $_obf_iYeIjIaVlYaIj4yTiJWHk40�['Auto_increment'];
    }

    public function _obf_h4uSk4qJiZGVkoqQkYqIiYs�( $_obf_lY6SiYuVjZKOkpGUh4qOiYc� = 0, $_obf_k42JhoyGiY6Ti4qRiIaPlZI� = -1 )
    {
        return " limit ".$_obf_lY6SiYuVjZKOkpGUh4qOiYc�.",".$_obf_k42JhoyGiY6Ti4qRiIaPlZI�;
    }

    public function _obf_h4yIho_UiouJiYeJko6Sko8�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� )
    {
        $_obf_kpSOj5KVio2Hj4uKj4_KjIY� = $this->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� );
        if ( empty( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� ) )
        {
            return FALSE;
        }
        return mysql_num_rows( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� );
    }

    public function _obf_iouHh42RkIeKkYaSipWKiog�( $_obf_lYuIio2HjIyVh4_JiY6Ij5E�, $_obf_kI_Tk4uTh5KOh42RhpOJjZM�, $_obf_ipSSiYeJlZGIj4mSjI6Gh5M� )
    {
        $_obf_jJSOi4eRkIyPho6Jh4mHlJQ� = "<img src=".INSTALLPATH."kss_inc/images/b_firstpage.png align=absmiddle style='display:inline-block; *display:inline; *zoom:1; vertical-align:middle'>";
        $_obf_jpWViIiUkJGQjouPkoaPk4w� = "<img src=".INSTALLPATH."kss_inc/images/b_prevpage.png align=absmiddle style='display:inline-block; *display:inline; *zoom:1; vertical-align:middle'>";
        $_obf_kIaNhpSNlJCQiZWHh4qSios� = "<img src=".INSTALLPATH."kss_inc/images/b_nextpage.png align=absmiddle style='display:inline-block; *display:inline; *zoom:1; vertical-align:middle'>";
        $_obf_kY6OlZWSkIqIlZOJh4mGi5I� = "<img src=".INSTALLPATH."kss_inc/images/b_lastpage.png align=absmiddle style='display:inline-block; *display:inline; *zoom:1; vertical-align:middle'>";
        $_obf_kpKOiYmNj4eMjYmOkImMjoc� = $this->_obf_joeRk5WMj4_LiZCPkJSTkZA�( $_obf_ipSSiYeJlZGIj4mSjI6Gh5M� );
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� = "";
        if ( $_obf_lYuIio2HjIyVh4_JiY6Ij5E� <= 1 )
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "<a href='javascript:void(0);'>".$_obf_jJSOi4eRkIyPho6Jh4mHlJQ�."</a>&nbsp;&nbsp;";
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "<a href='javascript:void(0);'>".$_obf_jpWViIiUkJGQjouPkoaPk4w�."</a>&nbsp;";
        }
        else
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "<a href='?page=1".$_obf_kpKOiYmNj4eMjYmOkImMjoc�."'>".$_obf_jJSOi4eRkIyPho6Jh4mHlJQ�."</a>&nbsp;";
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "<a href='?page=".( $_obf_lYuIio2HjIyVh4_JiY6Ij5E� - 1 ).$_obf_kpKOiYmNj4eMjYmOkImMjoc�."'>".$_obf_jpWViIiUkJGQjouPkoaPk4w�."</a>&nbsp;";
        }
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = -3;
        for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� <= 3; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
        {
            $_obf_kJGGh5GOjJGTkpSGkZCKiY4� = $_obf_jpKPlJSUiZOHkYaPlIeOiY4� + $_obf_lYuIio2HjIyVh4_JiY6Ij5E�;
            if ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� == 0 )
            {
                $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "&nbsp;<a class=nowpage href='javascript:void(0);'>".$_obf_lYuIio2HjIyVh4_JiY6Ij5E�."</a>&nbsp;";
            }
            else if ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 0 )
            {
                if ( 1 <= $_obf_kJGGh5GOjJGTkpSGkZCKiY4� )
                {
                    $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "&nbsp;<a class='page_nav_a' href='?page=".$_obf_kJGGh5GOjJGTkpSGkZCKiY4�.$_obf_kpKOiYmNj4eMjYmOkImMjoc�."'>".$_obf_kJGGh5GOjJGTkpSGkZCKiY4�."</a>&nbsp;";
                }
            }
            else if ( !( 0 < $_obf_jpKPlJSUiZOHkYaPlIeOiY4� ) && !( $_obf_kJGGh5GOjJGTkpSGkZCKiY4� <= $_obf_kI_Tk4uTh5KOh42RhpOJjZM� ) )
            {
                $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "&nbsp;<a class='page_nav_a' href='?page=".$_obf_kJGGh5GOjJGTkpSGkZCKiY4�.$_obf_kpKOiYmNj4eMjYmOkImMjoc�."'>".$_obf_kJGGh5GOjJGTkpSGkZCKiY4�."</a>&nbsp;";
            }
        }
        if ( $_obf_kI_Tk4uTh5KOh42RhpOJjZM� <= $_obf_lYuIio2HjIyVh4_JiY6Ij5E� )
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "&nbsp;<a href='javascript:void(0);'>".$_obf_kIaNhpSNlJCQiZWHh4qSios�."</a>&nbsp;";
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "&nbsp;<a href='javascript:void(0);'>".$_obf_kY6OlZWSkIqIlZOJh4mGi5I�."</a>&nbsp;";
        }
        else
        {
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "&nbsp;<a href='?page=".( $_obf_lYuIio2HjIyVh4_JiY6Ij5E� + 1 ).$_obf_kpKOiYmNj4eMjYmOkImMjoc�."'>".$_obf_kIaNhpSNlJCQiZWHh4qSios�."</a>";
            $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "&nbsp;&nbsp;<a href='?page=".$_obf_kI_Tk4uTh5KOh42RhpOJjZM�.$_obf_kpKOiYmNj4eMjYmOkImMjoc�."'>".$_obf_kY6OlZWSkIqIlZOJh4mGi5I�."</a>";
        }
        $_obf_lJWIlIeQlJOSiJGLkI6LjJE� = $_obf_kI_Tk4uTh5KOh42RhpOJjZM�;
        if ( $_obf_kI_Tk4uTh5KOh42RhpOJjZM� == 250000 )
        {
            $_obf_lJWIlIeQlJOSiJGLkI6LjJE� = "?";
        }
        $_obf_lI2HjIqUkYqTho2HiJWUk5I� .= "&nbsp;共".$_obf_lJWIlIeQlJOSiJGLkI6LjJE�."页";
        return "<span id='page___nav'>".$_obf_lI2HjIqUkYqTho2HiJWUk5I�."</span>";
    }

    public function _obf_joeRk5WMj4_LiZCPkJSTkZA�( $_obf_ipSSiYeJlZGIj4mSjI6Gh5M� )
    {
        $_obf_i4aLkIePi42Oh5GVjIeMioY� = "";
        if ( is_array( $_obf_ipSSiYeJlZGIj4mSjI6Gh5M� ) )
        {
            foreach ( $_obf_ipSSiYeJlZGIj4mSjI6Gh5M� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
            {
                $_obf_i4aLkIePi42Oh5GVjIeMioY� .= "&amp;".$_obf_lIeHkoeKkpOSiomPi4mQk5E�."=".urlencode( $_obf_io6UjZWThpOSjYeOj46Qkow� );
            }
        }
        return $_obf_i4aLkIePi42Oh5GVjIeMioY�;
    }

    public function _obf_koaRi4aHjIiPiYmJh5SKh4k�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� )
    {
        $_obf_k5WUj4aRi5SIkpGTjImUiZI� = mysql_query( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� );
        if ( $_obf_k5WUj4aRi5SIkpGTjImUiZI� !== FALSE )
        {
            $_obf_jo6SjIuHj46LjIyTlIyQk4s� = array( );
            while ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� = mysql_fetch_row( $_obf_k5WUj4aRi5SIkpGTjImUiZI� ) )
            {
                $_obf_jo6SjIuHj46LjIyTlIyQk4s�[] = $_obf_iYeIjIaVlYaIj4yTiJWHk40�[0];
            }
            return $_obf_jo6SjIuHj46LjIyTlIyQk4s�;
        }
        return FALSE;
    }

    public function _obf_lJWJh4mKhpCLkJKUjZWSi5M�( $_obf_kpSOj5KVio2Hj4uKj4_KjIY�, $_obf_i5SUlYiJjY2Kk4iNkIaMjY0� = 1 )
    {
        return mysql_fetch_array( $_obf_kpSOj5KVio2Hj4uKj4_KjIY�, $_obf_i5SUlYiJjY2Kk4iNkIaMjY0� );
    }

    public function _obf_iYmHkJSKj5OJhoiRiY2Rio4�( )
    {
        if ( $this->����������������� )
        {
            return mysql_error( $this->����������������� );
        }
        return mysql_error( );
    }

    public function _obf_lI6Gio6PjomOj4mRjoaUjoY�( )
    {
        return intval( $this->����������������� ? mysql_errno( $this->����������������� ) : mysql_errno( ) );
    }

    public function _obf_j4eSkIiSiZCRh4_NiYaQkYk�( $_obf_kpSOj5KVio2Hj4uKj4_KjIY�, $_obf_iYeIjIaVlYaIj4yTiJWHk40� )
    {
        $_obf_kpSOj5KVio2Hj4uKj4_KjIY� = @mysql_result( $_obf_kpSOj5KVio2Hj4uKj4_KjIY�, $_obf_iYeIjIaVlYaIj4yTiJWHk40� );
        return $_obf_kpSOj5KVio2Hj4uKj4_KjIY�;
    }

    public function _obf_k5WGh4yNj5ORhpKIjJGPi5M�( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� )
    {
        $_obf_kpSOj5KVio2Hj4uKj4_KjIY� = mysql_num_rows( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� );
        return $_obf_kpSOj5KVio2Hj4uKj4_KjIY�;
    }

    public function _obf_jJGUj5WRioqViZWHjo2KhpE�( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� )
    {
        return mysql_num_fields( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� );
    }

    public function _obf_lYuPlIeUlYuMiJGJiI2LiZE�( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� )
    {
        return mysql_free_result( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� );
    }

    public function _obf_kJOTjpKUiJWSjY_LjYyQj5M�( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� )
    {
        $_obf_kpSOj5KVio2Hj4uKj4_KjIY� = mysql_fetch_row( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� );
        return $_obf_kpSOj5KVio2Hj4uKj4_KjIY�;
    }

    public function _obf_j46SkIuVk4qLkoqRj46Gkow�( )
    {
        $_obf_kpSOj5KVio2Hj4uKj4_KjIY� = $this->�����������������;
        return $_obf_kpSOj5KVio2Hj4uKj4_KjIY�;
    }

    public function _obf_j5KJlI2NiJKNlIqPk4iGj5U�( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� )
    {
        return mysql_fetch_field( $_obf_kpSOj5KVio2Hj4uKj4_KjIY� );
    }

    public function _obf_iImVjYePiJSMiZOKjZWGlZQ�( )
    {
        return mysql_get_server_info( $this->����������������� );
    }

    public function _obf_kJCHlYiNjJCQlJKQkZKSko0�( )
    {
        return mysql_close( $this->����������������� );
    }

    public function _obf_k4mUj5OViI6HjY2JiYiLjJA�( $_obf_kImMk5OViomJlYeIk4mVh40� = "" )
    {
    }

}

function _obf_jo_LiZSIjZGTjYqNhomOkIY�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

?>
