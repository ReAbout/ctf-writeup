<?php

function _obf_jZOUipGMiJKKjZKJkZCIkYk�( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�, $_obf_i5GGjZGNi42Hk4qIioiKk44� )
{
    $_obf_kpWJhoqKj4eIiIeJkIaJkIk� = strtoupper( md5( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['rmb']."CNY".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['ordernum'].$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['partner'].$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['return_url'].$_obf_i5GGjZGNi42Hk4qIioiKk44� ) );
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� = "";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<form method='post' name='E_FORM' target='_blank' action='https://Pay3.chinabank.com.cn/PayGate'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='v_mid'         value='".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['partner']."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='v_oid'         value='".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['ordernum']."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='v_amount'      value='".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['rmb']."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='v_moneytype'   value='CNY'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='v_url'         value='".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['return_url']."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='v_md5info'     value='".$_obf_kpWJhoqKj4eIiIeJkIaJkIk�."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='remark1'       value='".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['cz']."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='remark2'       value='remark2'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type=submit class=submitbtn value='点击支付'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "</form>";
    return $_obf_kpKOiYmNj4eMjYmOkImMjoc�;
}

?>
