<?php

function _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_hoyMkoeOj42QioaSioaKi4g�, $_obf_i5OJk5CSj4iKhpOJkJKTjpU� = 1 )
{
    if ( defined( "SAE_MYSQL_USER" ) == TRUE || DEBUGPAYWG == 0 )
    {
        return FALSE;
    }
    $_obf_jpKUipCPlZSHlYuJjYaUlZE� = KSSLOGDIR."saledebug2_log.php";
    if ( $_obf_i5OJk5CSj4iKhpOJkJKTjpU� == 1 )
    {
        @file_put_contents( $_obf_jpKUipCPlZSHlYuJjYaUlZE�, $_obf_hoyMkoeOj42QioaSioaKi4g�."\r\n", FILE_APPEND );
    }
    else if ( !is_file( $_obf_jpKUipCPlZSHlYuJjYaUlZE� ) || 262144 < filesize( $_obf_jpKUipCPlZSHlYuJjYaUlZE� ) )
    {
        $_obf_ipWMho2NlI2MiI_MioeTlZI� = "?";
        $_obf_ipCIiZCRiYmKhpOSi4eSjZI� = "<".$_obf_ipWMho2NlI2MiI_MioeTlZI�."php exit('Access denied to view this page!');".$_obf_ipWMho2NlI2MiI_MioeTlZI�.">\r\n";
        @file_put_contents( $_obf_jpKUipCPlZSHlYuJjYaUlZE�, $_obf_ipCIiZCRiYmKhpOSi4eSjZI�."\r\n\r\n\r\n时间:".@date( "Y-m-d H:i:s" )."\r\n订单号:".$_obf_iJWMjIiVi5OGjJOViY2Li48�."\r\n状态:".$_obf_hoyMkoeOj42QioaSioaKi4g�."\r\n" );
    }
    else
    {
        @file_put_contents( $_obf_jpKUipCPlZSHlYuJjYaUlZE�, "\r\n\r\n\r\n时间:".@date( "Y-m-d H:i:s" )."\r\n订单号:".$_obf_iJWMjIiVi5OGjJOViY2Li48�."\r\n状态:".$_obf_hoyMkoeOj42QioaSioaKi4g�."\r\n", FILE_APPEND );
    }
}

require( "inc.php" );
$_obf_jo_MipCRkYuSk4mSko2RkIg� = array( "ali" => "支付宝", "ten" => "财付通", "chinabank" => "网银在线", "e138" => "易付通" );
$_obf_iZSViY2KjJSNjoePh4yOjI4� = array( "ali" => "success", "ten" => "success", "chinabank" => "ok", "e138" => "2" );
$_obf_k5OQh4iJjoyPjJSMjpSOlZA� = array( "WAIT_BUYER_PAY", "WAIT_SELLER_SEND_GOODS", "WAIT_BUYER_CONFIRM_GOODS", "TRADE_FINISHED", "TRADE_SUCCESS" );
$_obf_kYyPkY_PkJKVh4qGjJGIio4� = "ali";
if ( isset( $_GET['transaction_id'] ) )
{
    $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "ten";
}
if ( isset( $_POST['v_oid'] ) )
{
    $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "chinabank";
}
if ( isset( $_POST['AttachString'] ) && $_POST['AttachString'] == "e138" )
{
    $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "e138";
}
include( $_obf_kYyPkY_PkJKVh4qGjJGIio4�."pay_function.php" );
if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ali" )
{
    $_obf_iJWMjIiVi5OGjJOViY2Li48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "out_trade_no", "pg", "sql", "" );
    $_obf_kpGPh4mNh46SkZONh4eLlJU� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_no", "pg", "sql", "" );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "total_fee", "pg", "sql", "" );
    $_obf_i5CMioaGiI6ShomNiIuKjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_status", "pg", "sql", "" );
    $_obf_j4mLiYmUj4aJiI6IjY6TjI0� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "buyer_email", "pg", "sql", "" );
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ten" )
{
    $_obf_hpKNkIaShoaKkY6Lk4qVk5U� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_mode", "gp", "int", 0 );
    $_obf_iJWMjIiVi5OGjJOViY2Li48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "out_trade_no", "gp", "sql", "" );
    $_obf_kpGPh4mNh46SkZONh4eLlJU� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "transaction_id", "gp", "sql", "" );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "total_fee", "gp", "sql", "" );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� /= 100;
    $_obf_i5CMioaGiI6ShomNiIuKjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_state", "gp", "sql", "" );
    if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "0" )
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "TRADE_FINISHED";
    }
    else
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "WAIT_BUYER_PAY";
    }
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "chinabank" )
{
    $_obf_kpGPh4mNh46SkZONh4eLlJU� = "";
    $_obf_k42NkY2RkoiNjJCKlZSKiIg� = trim( $_POST['v_oid'] );
    $_obf_iJWMjIiVi5OGjJOViY2Li48� = $_obf_k42NkY2RkoiNjJCKlZSKiIg�;
    $_obf_iIuQkYaUioqGlI6IjIuMiI8� = trim( $_POST['v_pstatus'] );
    $_obf_jpGJk5SSkJOIk4iQiI_OhpU� = trim( $_POST['v_amount'] );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = $_obf_jpGJk5SSkJOIk4iQiI_OhpU�;
    $_obf_hpCRlJCSjI6Ki5WSipCLkpQ� = trim( $_POST['v_moneytype'] );
    $_obf_lJSPjJCOi5CIiJSSkZWNh4Y� = trim( $_POST['remark1'] );
    $_obf_iImJjYmQjYyOjIuVkIuMjIs� = trim( $_POST['v_md5str'] );
    if ( $_obf_iIuQkYaUioqGlI6IjIuMiI8� == "20" )
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "TRADE_FINISHED";
    }
    else
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "WAIT_BUYER_PAY";
    }
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "e138" )
{
    $_obf_kpGPh4mNh46SkZONh4eLlJU� = "";
    $_obf_k42NkY2RkoiNjJCKlZSKiIg� = trim( $_POST['SerialNo'] );
    $_obf_iJWMjIiVi5OGjJOViY2Li48� = $_obf_k42NkY2RkoiNjJCKlZSKiIg�;
    $_obf_iIuQkYaUioqGlI6IjIuMiI8� = trim( $_POST['Status'] );
    $_obf_jpGJk5SSkJOIk4iQiI_OhpU� = trim( $_POST['Money'] );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = $_obf_jpGJk5SSkJOIk4iQiI_OhpU�;
    $_obf_iImJjYmQjYyOjIuVkIuMjIs� = trim( $_POST['VerifyString'] );
    if ( $_obf_iIuQkYaUioqGlI6IjIuMiI8� == "2" )
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "TRADE_FINISHED";
    }
    else
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "WAIT_BUYER_PAY";
    }
}
else
{
    exit( "errwg" );
}
_obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_i5CMioaGiI6ShomNiIuKjJE�, 0 );
$_obf_k42GiI_RiIqKjIaUio6IiIw� = "POSTDATA:";
foreach ( $_POST as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
{
    $_obf_k42GiI_RiIqKjIaUio6IiIw� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".urlencode( $_obf_lYeSkY6Th5SOlYuHjZGVio8� )."&";
}
_obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_k42GiI_RiIqKjIaUio6IiIw� );
$_obf_lYuTjYmGkJWKk5WOjoeGlYw� = "GETDATA:";
foreach ( $_GET as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
{
    $_obf_lYuTjYmGkJWKk5WOjoeGlYw� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".urlencode( $_obf_lYeSkY6Th5SOlYuHjZGVio8� )."&";
}
_obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_lYuTjYmGkJWKk5WOjoeGlYw� );
if ( !in_array( $_obf_i5CMioaGiI6ShomNiIuKjJE�, $_obf_k5OQh4iJjoyPjJSMjpSOlZA� ) )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."返回的状态码异常！" );
}
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
$_obf_lZGQj4iOj4mTlZGNjZGUj5E� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_order where ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'" );
if ( empty( $_obf_lZGQj4iOj4mTlZGNjZGUj5E� ) )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "订单未找到！" );
}
if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['orderamount'] != $_obf_lIuQk5OGjpKVjY6UiI_QjJM� )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "订单金额不符！" );
}
$_obf_jI2JlY_QkoeQj5OLjouLlYo� = _obf_iY6RiYaNio6PiIyIiZWJkJQ�( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['pid'] );
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iIeMkYyJiZKTjI2UjImPi4Y�( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['managerid'] );
$_obf_kJCGiI6Nk4_RkYuGiZWSi5M� = explode( ",", $_obf_jI2JlY_QkoeQj5OLjouLlYo�['alipayset'] );
if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ali" )
{
    $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = _obf_i4iVlY2UkouLj5KGlI2Uhoc�( $_obf_kJCGiI6Nk4_RkYuGiZWSi5M�[1], $_obf_jI2JlY_QkoeQj5OLjouLlYo�['alikey'], 1 );
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ten" )
{
    if ( $_obf_hpKNkIaShoaKkY6Lk4qVk5U� != 1 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "不支持即时到帐以外的".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."接口！" );
    }
    $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = _obf_jY6OlY_RlYqPjZSQh4uPkJQ�( $_obf_jI2JlY_QkoeQj5OLjouLlYo�['tenkey'] );
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "chinabank" )
{
    $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = TRUE;
    if ( $_obf_iImJjYmQjYyOjIuVkIuMjIs� != strtoupper( md5( $_obf_k42NkY2RkoiNjJCKlZSKiIg�.$_obf_iIuQkYaUioqGlI6IjIuMiI8�.$_obf_jpGJk5SSkJOIk4iQiI_OhpU�.$_obf_hpCRlJCSjI6Ki5WSipCLkpQ�.$_obf_jI2JlY_QkoeQj5OLjouLlYo�['chinabankkey'] ) ) )
    {
        $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = FALSE;
    }
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "e138" )
{
    $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = TRUE;
    if ( $_obf_iImJjYmQjYyOjIuVkIuMjIs� != strtolower( md5( "SerialNo=".$_obf_k42NkY2RkoiNjJCKlZSKiIg�."&UserID=".$_obf_jI2JlY_QkoeQj5OLjouLlYo�['e138set']."&Money=".$_obf_jpGJk5SSkJOIk4iQiI_OhpU�."&Status=".$_obf_iIuQkYaUioqGlI6IjIuMiI8�."&AttachString=e138&MerchantKey=".$_obf_jI2JlY_QkoeQj5OLjouLlYo�['e138key'] ) ) )
    {
        $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = FALSE;
    }
}
if ( $_obf_k4mJh5SPkY6Vh4qHjIaJh44� !== TRUE )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."URL签名不正确！curl:".$_obf_k4mJh5SPkY6Vh4qHjIaJh44� );
}
$_obf_iIeHlZWKipOJlIyVk42UjJM� = 0;
if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "WAIT_BUYER_PAY" )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "订单已确定但还未付款，也可能是数据同步问题，如果你支付成功，请等五分钟再查询订单号！" );
}
else if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "WAIT_SELLER_SEND_GOODS" )
{
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "订单已付款，系统在五分钟内会自动发货！" );
}
else if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "WAIT_BUYER_CONFIRM_GOODS" )
{
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ali" )
    {
        $_obf_jpSRjpKGhpOOiIuHiI_UjYo� = explode( ",", $_obf_jI2JlY_QkoeQj5OLjouLlYo�['alipayset'] );
        if ( $_obf_jpSRjpKGhpOOiIuHiI_UjYo�[0] == "create_partner_trade_by_buyer" && $_obf_jpSRjpKGhpOOiIuHiI_UjYo�[2] == $_obf_j4mLiYmUj4aJiI6IjY6TjI0� )
        {
            $_obf_iIeHlZWKipOJlIyVk42UjJM� = 1;
        }
        else
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "订单已发货，<a href=https://lab.alipay.com/consume/queryTradeDetail.htm?tradeNo=".$_obf_kpGPh4mNh46SkZONh4eLlJU�.">请登陆支付宝确认收货</a>！" );
        }
    }
    else
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "订单已发货！" );
    }
}
if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "TRADE_FINISHED" || $_obf_i5CMioaGiI6ShomNiIuKjJE� == "TRADE_SUCCESS" || $_obf_iIeHlZWKipOJlIyVk42UjJM� == 1 )
{
    $_obf_lImOiY6UiYaUlZKQh4qKiok� = "";
    $_obf_lZCJkIySjI6TipKIio6Ojos� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select `keyfix`,`keys`,`keyspassword` from `kss_z_key_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid']."` where `ordernum`='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."' limit 0,".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['keycount'] );
    if ( empty( $_obf_lZCJkIySjI6TipKIio6Ojos� ) )
    {
        $_obf_lImOiY6UiYaUlZKQh4qKiok� = "订单已完成，但由于未知的原因注册卡号未找到<br>请记下订单号".$_obf_iJWMjIiVi5OGjJOViY2Li48�."五分钟后偿试重新查询，如还是无卡请联系销售方！";
    }
    else
    {
        $_obf_lImOiY6UiYaUlZKQh4qKiok� = "<textarea style='width:300px;height:100px'>";
        if ( count( $_obf_lZCJkIySjI6TipKIio6Ojos� ) != $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['keycount'] )
        {
            $_obf_lImOiY6UiYaUlZKQh4qKiok� .= "注册卡号数量不符，请记下订单号".$_obf_iJWMjIiVi5OGjJOViY2Li48�."并联系销售方\r\n\r\n";
        }
        else
        {
            $_obf_lImOiY6UiYaUlZKQh4qKiok� .= "你购买到的注册卡：\r\n";
        }
        foreach ( $_obf_lZCJkIySjI6TipKIio6Ojos� as $_obf_jpSNkYeQi5CGjIeTipSTkYY� )
        {
            $_obf_lImOiY6UiYaUlZKQh4qKiok� .= $_obf_jpSNkYeQi5CGjIeTipSTkYY�['keyfix'].$_obf_jpSNkYeQi5CGjIeTipSTkYY�['keys'].$_obf_jpSNkYeQi5CGjIeTipSTkYY�['keyspassword']."\r\n";
        }
        $_obf_lImOiY6UiYaUlZKQh4qKiok� .= "</textarea>";
    }
    _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_lImOiY6UiYaUlZKQh4qKiok� );
}
_obf_kYyOhouLjo2Gh4eNj4iQlIg�( "未知的订单状态码：".$_obf_i5CMioaGiI6ShomNiIuKjJE� );
?>
