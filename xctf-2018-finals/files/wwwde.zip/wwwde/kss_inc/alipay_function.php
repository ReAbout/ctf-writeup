<?php

function _obf_lZWKi4mVio2IjYyHjZKQiI0�( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� )
{
    $_obf_k5CTkIyHk5CKkY6Pk5KQjJM� = array( );
    foreach ( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_jJCNh42NjpGQkIaPk4qLkok� )
    {
        if ( $_obf_koiIh4mRlJKGlIiGiJCUkI4� == "sign" || $_obf_koiIh4mRlJKGlIiGiJCUkI4� == "sign_type" || $_obf_jJCNh42NjpGQkIaPk4qLkok� == "" )
        {
            continue;
        }
        else
        {
            $_obf_k5CTkIyHk5CKkY6Pk5KQjJM�[$_obf_koiIh4mRlJKGlIiGiJCUkI4�] = $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[$_obf_koiIh4mRlJKGlIiGiJCUkI4�];
        }
    }
    return $_obf_k5CTkIyHk5CKkY6Pk5KQjJM�;
}

function _obf_koiJjZKKlIqLjZORiYaGjog�( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�, $_obf_i5GGjZGNi42Hk4qIioiKk44� )
{
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� = "https://mapi.alipay.com/gateway.do?";
    $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['_input_charset'] = "utf-8";
    $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� = _obf_lZWKi4mVio2IjYyHjZKQiI0�( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    ksort( &$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    reset( &$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    $_obf_jpCKkoaHhoiJlZSViIqSiIo� = "";
    foreach ( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_jJCNh42NjpGQkIaPk4qLkok� )
    {
        $_obf_jpCKkoaHhoiJlZSViIqSiIo� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".$_obf_jJCNh42NjpGQkIaPk4qLkok�."&";
    }
    $_obf_k46Hj5KSjJGUjYqLiJKIho4� = substr( $_obf_jpCKkoaHhoiJlZSViIqSiIo�, 0, count( $_obf_jpCKkoaHhoiJlZSViIqSiIo� ) - 2 );
    $_obf_lIyTho_IkJKLjJWHipOUlIw� = md5( $_obf_k46Hj5KSjJGUjYqLiJKIho4�.$_obf_i5GGjZGNi42Hk4qIioiKk44� );
    $_obf_jpCKkoaHhoiJlZSViIqSiIo� = "";
    reset( &$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    foreach ( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_jJCNh42NjpGQkIaPk4qLkok� )
    {
        $_obf_jpCKkoaHhoiJlZSViIqSiIo� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".urlencode( $_obf_jJCNh42NjpGQkIaPk4qLkok� )."&";
    }
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= $_obf_jpCKkoaHhoiJlZSViIqSiIo�."sign=".$_obf_lIyTho_IkJKLjJWHipOUlIw�."&sign_type=MD5";
    return $_obf_kpKOiYmNj4eMjYmOkImMjoc�;
}

function _obf_i4iVlY2UkouLj5KGlI2Uhoc�( $_obf_hpWMiIaMiZCSlJSSj42MjpU�, $_obf_i5GGjZGNi42Hk4qIioiKk44�, $_obf_jI6NlI6HiJWPiYeKipCNk4g� = 0 )
{
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = FALSE;
    if ( $_obf_jI6NlI6HiJWPiYeKipCNk4g� == 0 )
    {
        $_obf_lZWPiZCQiomLi4qSiImUhos� = $_POST['notify_id'];
        $_obf_kpWNiY2Kk5KUi4eTi5KKipE� = $_POST;
        $_obf_ho6Hh4mLj4iLi5GMkYuPh5U� = $_POST['sign'];
    }
    else
    {
        $_obf_lZWPiZCQiomLi4qSiImUhos� = $_GET['notify_id'];
        $_obf_kpWNiY2Kk5KUi4eTi5KKipE� = $_GET;
        $_obf_ho6Hh4mLj4iLi5GMkYuPh5U� = $_GET['sign'];
    }
    $_obf_jJWQj4iTioeTjo_Ujo_Jk4k� = "https://mapi.alipay.com/gateway.do?service=notify_verify&partner=".$_obf_hpWMiIaMiZCSlJSSj42MjpU�."&notify_id=".$_obf_lZWPiZCQiomLi4qSiImUhos�;
    if ( _obf_iYqMjJCPipKLjpSRioeUlYc�( $_obf_jJWQj4iTioeTjo_Ujo_Jk4k� ) != "true" )
    {
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    }
    $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� = _obf_lZWKi4mVio2IjYyHjZKQiI0�( $_obf_kpWNiY2Kk5KUi4eTi5KKipE� );
    ksort( &$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    reset( &$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    $_obf_jpCKkoaHhoiJlZSViIqSiIo� = "";
    foreach ( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_jJCNh42NjpGQkIaPk4qLkok� )
    {
        $_obf_jpCKkoaHhoiJlZSViIqSiIo� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".$_obf_jJCNh42NjpGQkIaPk4qLkok�."&";
    }
    $_obf_k46Hj5KSjJGUjYqLiJKIho4� = substr( $_obf_jpCKkoaHhoiJlZSViIqSiIo�, 0, count( $_obf_jpCKkoaHhoiJlZSViIqSiIo� ) - 2 );
    $_obf_lIyTho_IkJKLjJWHipOUlIw� = md5( $_obf_k46Hj5KSjJGUjYqLiJKIho4�.$_obf_i5GGjZGNi42Hk4qIioiKk44� );
    if ( $_obf_lIyTho_IkJKLjJWHipOUlIw� == $_obf_ho6Hh4mLj4iLi5GMkYuPh5U� )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = TRUE;
    }
    return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
}

function _obf_iYqMjJCPipKLjpSRioeUlYc�( $_obf_kpKOiYmNj4eMjYmOkImMjoc� )
{
    $_obf_h42OlYmRjY2VhoyUho6SkIw� = "true";
    if ( defined( "AliPay_No_Safe" ) && AliPay_No_Safe == 1 )
    {
        return $_obf_h42OlYmRjY2VhoyUho6SkIw�;
    }
    if ( _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_init" ) && _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_exec" ) )
    {
        $_obf_i5WJjY_SkpKUjIiQiJGRjpA� = parse_url( $_obf_kpKOiYmNj4eMjYmOkImMjoc� );
        $_obf_jYyIkpCKlIiLlI6NipSUj4w� = curl_init( );
        curl_setopt( $_obf_jYyIkpCKlIiLlI6NipSUj4w�, CURLOPT_URL, $_obf_kpKOiYmNj4eMjYmOkImMjoc� );
        curl_setopt( $_obf_jYyIkpCKlIiLlI6NipSUj4w�, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $_obf_jYyIkpCKlIiLlI6NipSUj4w�, CURLOPT_SSL_VERIFYHOST, FALSE );
        curl_setopt( $_obf_jYyIkpCKlIiLlI6NipSUj4w�, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT'] );
        curl_setopt( $_obf_jYyIkpCKlIiLlI6NipSUj4w�, CURLOPT_POST, 1 );
        curl_setopt( $_obf_jYyIkpCKlIiLlI6NipSUj4w�, CURLOPT_POSTFIELDS, $_obf_i5WJjY_SkpKUjIiQiJGRjpA�['query'] );
        curl_setopt( $_obf_jYyIkpCKlIiLlI6NipSUj4w�, CURLOPT_HEADER, 0 );
        curl_setopt( $_obf_jYyIkpCKlIiLlI6NipSUj4w�, CURLOPT_RETURNTRANSFER, 1 );
        $_obf_h42OlYmRjY2VhoyUho6SkIw� = curl_exec( $_obf_jYyIkpCKlIiLlI6NipSUj4w� );
        if ( curl_errno( $_obf_jYyIkpCKlIiLlI6NipSUj4w� ) )
        {
            $_obf_h42OlYmRjY2VhoyUho6SkIw� = "true";
            @file_put_contents( KSSLOGDIR."err_log.php", "连接alipay服务器效验订单时出错:".@curl_error( $_obf_jYyIkpCKlIiLlI6NipSUj4w� )."\r\n", FILE_APPEND );
        }
        curl_close( $_obf_jYyIkpCKlIiLlI6NipSUj4w� );
    }
    return $_obf_h42OlYmRjY2VhoyUho6SkIw�;
}

function _obf_koyJjYuOjZOSiZOUkYmKi40�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_koeTkZCTiIiGlYuOioqJiog�, $_obf_jZOVj4mKjI2Oi5WKhpCIho8�, $_obf_i5GGjZGNi42Hk4qIioiKk44� )
{
    $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� = array(
        "service" => "send_goods_confirm_by_platform",
        "partner" => $_obf_jZOVj4mKjI2Oi5WKhpCIho8�,
        "trade_no" => $_obf_koeTkZCTiIiGlYuOioqJiog�,
        "logistics_name" => "KSPAY",
        "invoice_no" => $_obf_iJWMjIiVi5OGjJOViY2Li48�,
        "transport_type" => "EXPRESS"
    );
    return _obf_koiJjZKKlIqLjZORiYaGjog�( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�, $_obf_i5GGjZGNi42Hk4qIioiKk44� );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
?>
