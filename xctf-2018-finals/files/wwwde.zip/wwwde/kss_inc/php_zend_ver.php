<?php

ob_start( );
phpinfo( );
$_obf_kpSKi5GKh5COio2GkpWPlYw� = ob_get_contents( );
ob_end_clean( );
$_obf_i4aPkYqIiZORjpSSkZOTj4Y� = stripos( $_obf_kpSKi5GKh5COio2GkpWPlYw�, "</table>" );
$_obf_kouLi4qLiZCRj4yPjJSMlYw� = substr( $_obf_kpSKi5GKh5COio2GkpWPlYw�, 0, $_obf_i4aPkYqIiZORjpSSkZOTj4Y� + 8 );
$_obf_jo2ThomRhpCTjY2ViIaLj4Y� = substr( $_obf_kpSKi5GKh5COio2GkpWPlYw�, $_obf_i4aPkYqIiZORjpSSkZOTj4Y� + 100 );
$_obf_iI2OkIaGi5SPjJKIlZSHjog� = stripos( $_obf_jo2ThomRhpCTjY2ViIaLj4Y�, "<table" );
$_obf_i4eTi4qMjIyJjYuIho_Qh4k� = substr( $_obf_jo2ThomRhpCTjY2ViIaLj4Y�, $_obf_iI2OkIaGi5SPjJKIlZSHjog� );
$_obf_iI2OkIaGi5SPjJKIlZSHjog� = stripos( $_obf_i4eTi4qMjIyJjYuIho_Qh4k�, "</table>" );
$_obf_i4aTkZWNkZSNjo_Ri46Mj4o� = substr( $_obf_i4eTi4qMjIyJjYuIho_Qh4k�, 0, $_obf_iI2OkIaGi5SPjJKIlZSHjog� + 8 );
echo $_obf_kouLi4qLiZCRj4yPjJSMlYw�;
echo "<br><br>";
echo $_obf_i4aTkZWNkZSNjo_Ri46Mj4o�;
?>
