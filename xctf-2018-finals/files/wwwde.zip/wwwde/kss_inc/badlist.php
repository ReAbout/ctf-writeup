<?php

function _obf_i5KUj5SIk4iOj42RlJCIk48�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_h5KVhouQjZGLk4uGi4mKjo4�( )
{
    define( "SVRENDTIME", 123123123 );
    $_obf_lYaHjI_QkY2MkIuNkZONkpQ� = array( "123", "234", "456" );
    $_obf_j4_Mio6RkpCMi4_Kk42SkI4� = serialize( $_obf_lYaHjI_QkY2MkIuNkZONkpQ� );
    define( "SVRBADSTR", $_obf_j4_Mio6RkpCMi4_Kk42SkI4� );
}

_obf_h5KVhouQjZGLk4uGi4mKjo4�( );
?>
