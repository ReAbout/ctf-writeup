<?php

function _obf_kYmLh4qIipGMjJCSiIuTiJU�( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� )
{
    $_obf_k5CTkIyHk5CKkY6Pk5KQjJM� = array( );
    while ( list( $_obf_koiIh4mRlJKGlIiGiJCUkI4�, $_obf_jJCNh42NjpGQkIaPk4qLkok� ) = each( &$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� ) )
    {
        if ( $_obf_koiIh4mRlJKGlIiGiJCUkI4� == "sign" || $_obf_jJCNh42NjpGQkIaPk4qLkok� == "" )
        {
            continue;
        }
        else
        {
            $_obf_k5CTkIyHk5CKkY6Pk5KQjJM�[$_obf_koiIh4mRlJKGlIiGiJCUkI4�] = $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[$_obf_koiIh4mRlJKGlIiGiJCUkI4�];
        }
    }
    return $_obf_k5CTkIyHk5CKkY6Pk5KQjJM�;
}

function _obf_lZWKjpCLjomHkoyKlZWQi5M�( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�, $_obf_i5GGjZGNi42Hk4qIioiKk44� )
{
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� = "https://gw.tenpay.com/gateway/pay.htm?";
    $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['input_charset'] = "UTF-8";
    $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� = _obf_kYmLh4qIipGMjJCSiIuTiJU�( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    ksort( &$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    reset( &$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    $_obf_k46Hj5KSjJGUjYqLiJKIho4� = "";
    foreach ( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_jJCNh42NjpGQkIaPk4qLkok� )
    {
        $_obf_k46Hj5KSjJGUjYqLiJKIho4� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".$_obf_jJCNh42NjpGQkIaPk4qLkok�."&";
    }
    $_obf_lIyTho_IkJKLjJWHipOUlIw� = strtolower( md5( $_obf_k46Hj5KSjJGUjYqLiJKIho4�."key=".$_obf_i5GGjZGNi42Hk4qIioiKk44� ) );
    $_obf_jpCKkoaHhoiJlZSViIqSiIo� = "";
    reset( &$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    foreach ( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_jJCNh42NjpGQkIaPk4qLkok� )
    {
        $_obf_jpCKkoaHhoiJlZSViIqSiIo� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".urlencode( $_obf_jJCNh42NjpGQkIaPk4qLkok� )."&";
    }
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= $_obf_jpCKkoaHhoiJlZSViIqSiIo�."sign=".$_obf_lIyTho_IkJKLjJWHipOUlIw�;
    return $_obf_kpKOiYmNj4eMjYmOkImMjoc�;
}

function _obf_jY6OlY_RlYqPjZSQh4uPkJQ�( $_obf_i5GGjZGNi42Hk4qIioiKk44� )
{
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = FALSE;
    $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� = array( );
    foreach ( $_GET as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_jJCNh42NjpGQkIaPk4qLkok� )
    {
        $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[$_obf_koiIh4mRlJKGlIiGiJCUkI4�] = $_obf_jJCNh42NjpGQkIaPk4qLkok�;
    }
    foreach ( $_POST as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_jJCNh42NjpGQkIaPk4qLkok� )
    {
        $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�[$_obf_koiIh4mRlJKGlIiGiJCUkI4�] = $_obf_jJCNh42NjpGQkIaPk4qLkok�;
    }
    $_obf_iY2VhoaTh5SUh4mIiY6Hi5M� = $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['sign'];
    $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� = _obf_kYmLh4qIipGMjJCSiIuTiJU�( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    ksort( &$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    reset( &$_obf_k42Uko6Qk5CLiYqIjI_Ih5U� );
    $_obf_k46Hj5KSjJGUjYqLiJKIho4� = "";
    foreach ( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_jJCNh42NjpGQkIaPk4qLkok� )
    {
        $_obf_k46Hj5KSjJGUjYqLiJKIho4� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".$_obf_jJCNh42NjpGQkIaPk4qLkok�."&";
    }
    $_obf_lIyTho_IkJKLjJWHipOUlIw� = md5( $_obf_k46Hj5KSjJGUjYqLiJKIho4�."key=".$_obf_i5GGjZGNi42Hk4qIioiKk44� );
    return strtoupper( $_obf_lIyTho_IkJKLjJWHipOUlIw� ) == strtoupper( $_obf_iY2VhoaTh5SUh4mIiY6Hi5M� );
}

?>
