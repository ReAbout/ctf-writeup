<?php

function user_ext_getip( )
{
    return "0.0.0.0";
}

?>
