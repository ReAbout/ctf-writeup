<?php

function _obf_kpWLkoyMhouPipCQiImKjZA�( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8�, $_obf_hoyNlY_HiJOGjoiNiImOkIw� )
{
    libxml_disable_entity_loader( TRUE );
    $_obf_i5SPhouVkYmIio2Pj4aHho8� = json_decode( json_encode( simplexml_load_string( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8�, "SimpleXMLElement", LIBXML_NOCDATA ) ), TRUE );
    ksort( &$_obf_i5SPhouVkYmIio2Pj4aHho8� );
    $_obf_io_NlZONi4mIkZSOlZWPlIw� = "";
    foreach ( $_obf_i5SPhouVkYmIio2Pj4aHho8� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
    {
        if ( $_obf_lIeHkoeKkpOSiomPi4mQk5E� != "sign" )
        {
            $_obf_io_NlZONi4mIkZSOlZWPlIw� .= $_obf_lIeHkoeKkpOSiomPi4mQk5E�."=".$_obf_io6UjZWThpOSjYeOj46Qkow�."&";
        }
    }
    $_obf_io_NlZONi4mIkZSOlZWPlIw� .= "key=".$_obf_hoyNlY_HiJOGjoiNiImOkIw�;
    if ( !empty( $_obf_i5SPhouVkYmIio2Pj4aHho8�['return_code'] ) && $_obf_i5SPhouVkYmIio2Pj4aHho8�['return_code'] == "FAIL" )
    {
        return $_obf_i5SPhouVkYmIio2Pj4aHho8�['return_msg'];
    }
    if ( $_obf_i5SPhouVkYmIio2Pj4aHho8�['sign'] != strtoupper( md5( $_obf_io_NlZONi4mIkZSOlZWPlIw� ) ) )
    {
        return "签名错误";
    }
    return TRUE;
}

function _obf_komQkZGUhomRk4eLipOSkJM�( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8� )
{
    libxml_disable_entity_loader( TRUE );
    $_obf_i5SPhouVkYmIio2Pj4aHho8� = json_decode( json_encode( simplexml_load_string( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8�, "SimpleXMLElement", LIBXML_NOCDATA ) ), TRUE );
    ksort( &$_obf_i5SPhouVkYmIio2Pj4aHho8� );
    return $_obf_i5SPhouVkYmIio2Pj4aHho8�;
}

function _obf_h4yJjZWLkYyMjIqNlYaSjpM�( $_obf_jomMjoiOjomMlI_Mj42NlZA�, $_obf_hoyNlY_HiJOGjoiNiImOkIw� )
{
    $_obf_io_NlZONi4mIkZSOlZWPlIw� = "";
    $_obf_jY2KkYuVh5WHkZGKlI2QkYc� = "<xml>";
    foreach ( $_obf_jomMjoiOjomMlI_Mj42NlZA� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
    {
        $_obf_io_NlZONi4mIkZSOlZWPlIw� .= $_obf_lIeHkoeKkpOSiomPi4mQk5E�."=".$_obf_io6UjZWThpOSjYeOj46Qkow�."&";
        $_obf_jY2KkYuVh5WHkZGKlI2QkYc� .= "<".$_obf_lIeHkoeKkpOSiomPi4mQk5E�.">".$_obf_io6UjZWThpOSjYeOj46Qkow�."</".$_obf_lIeHkoeKkpOSiomPi4mQk5E�.">";
    }
    $_obf_io_NlZONi4mIkZSOlZWPlIw� .= "key=".$_obf_hoyNlY_HiJOGjoiNiImOkIw�;
    $_obf_jY2KkYuVh5WHkZGKlI2QkYc� .= "<sign>".strtoupper( md5( $_obf_io_NlZONi4mIkZSOlZWPlIw� ) )."</sign></xml>";
    return $_obf_jY2KkYuVh5WHkZGKlI2QkYc�;
}

function _obf_lZCGk4mUkY6GhoeIkZWMk5Q�( $_obf_i5CNjI2Tk4eJlJSUk4eKkI8�, $_obf_kpKOiYmNj4eMjYmOkImMjoc�, $_obf_kZCUipKHlZKGj4iOipGTjYw� = FALSE, $_obf_kZCUhpOUioaJipSJjJOGh4o� = 30 )
{
    $_obf_joiNh4aIhouViZGQho_JiI4� = curl_init( );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_TIMEOUT, $_obf_kZCUhpOUioaJipSJjJOGh4o� );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_URL, $_obf_kpKOiYmNj4eMjYmOkImMjoc� );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_SSL_VERIFYPEER, FALSE );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_SSL_VERIFYHOST, FALSE );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_HEADER, FALSE );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_RETURNTRANSFER, TRUE );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_POST, TRUE );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_POSTFIELDS, $_obf_i5CNjI2Tk4eJlJSUk4eKkI8� );
    $_obf_lIyUkIaVk46LiZCNipOIkJA� = curl_exec( $_obf_joiNh4aIhouViZGQho_JiI4� );
    if ( $_obf_lIyUkIaVk46LiZCNipOIkJA� )
    {
        curl_close( $_obf_joiNh4aIhouViZGQho_JiI4� );
        return $_obf_lIyUkIaVk46LiZCNipOIkJA�;
    }
    else
    {
        $_obf_iYmHkJSKj5OJhoiRiY2Rio4� = curl_errno( $_obf_joiNh4aIhouViZGQho_JiI4� );
        curl_close( $_obf_joiNh4aIhouViZGQho_JiI4� );
        exit( "curl出错，错误码:{$error}" );
    }
}

?>
