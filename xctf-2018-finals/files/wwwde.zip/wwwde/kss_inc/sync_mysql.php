<?php

function _obf_iYuRlIaRioySiZKTj4mPkY0�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_j42OiJORiY6OjYuMkY2Lj4k�;
    global $_obf_h5KGh42MlI2Ij5WRjI6Nh48�;
    $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = $_GET['notifyid'];
    $_obf_h4iLlI2KlI_QjoqNkoyRh4c� = isset( $_GET['trytimes'] ) ? $_GET['trytimes'] : 0;
    if ( !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_ioqNlY6GjpCVjY2Ph5WVioc� ) )
    {
        exit( "notifyid invalid!" );
    }
    if ( 3 < $_obf_h4iLlI2KlI_QjoqNkoyRh4c� )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "取备服数据失败，".( $_obf_h4iLlI2KlI_QjoqNkoyRh4c� - 1 )."次重试均失败，同步结束！" );
        exit( );
    }
    if ( $_obf_h4iLlI2KlI_QjoqNkoyRh4c� == 0 )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "CURL模式，同步开始！" );
    }
    else
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "取备服数据失败，开始第".$_obf_h4iLlI2KlI_QjoqNkoyRh4c�."次重试！" );
    }
    $_obf_lY6IiZSRk5OMk42Hi4eMkoY� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC2URL."?step=b1&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&pwd=".MYSQLBAKPASSWORD, FALSE, $_obf_h5KGh42MlI2Ij5WRjI6Nh48� / 1000 - 5 );
    if ( substr( $_obf_lY6IiZSRk5OMk42Hi4eMkoY�, 0, 6 ) != "dataok" )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "错误信息：".$_obf_lY6IiZSRk5OMk42Hi4eMkoY� );
        $_obf_koqTiIuHiY6NlJWOiYqRkZE� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC1URL."?step=a1&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&trytimes=".( $_obf_h4iLlI2KlI_QjoqNkoyRh4c� + 1 )."&pwd=".MYSQLBAKPASSWORD, FALSE, 1 );
        exit( );
    }
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "取备服数据成功！" );
    $_obf_kJCUiZKMhomPkZSVkYmUio8� = explode( "|", $_obf_lY6IiZSRk5OMk42Hi4eMkoY� );
    unset( $_obf_lY6IiZSRk5OMk42Hi4eMkoY� );
    $_obf_hoqLk5OLlIuMkIuRk5CNlJA� = "";
    $_obf_iYqQh5CQkpGIkI6JjpWRk4w� = "";
    if ( $_obf_kJCUiZKMhomPkZSVkYmUio8�[1] != "" )
    {
        $_obf_hoqLk5OLlIuMkIuRk5CNlJA� = _obf_lYuLkpWKjJOKk4eLiZWHi4g�( $_obf_kJCUiZKMhomPkZSVkYmUio8�[1] );
    }
    if ( $_obf_kJCUiZKMhomPkZSVkYmUio8�[2] != "" )
    {
        $_obf_iYqQh5CQkpGIkI6JjpWRk4w� = _obf_lYuLkpWKjJOKk4eLiZWHi4g�( $_obf_kJCUiZKMhomPkZSVkYmUio8�[2] );
    }
    if ( !empty( $_obf_hoqLk5OLlIuMkIuRk5CNlJA� ) )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "备服有激活记录，开始处理激活记录" );
        foreach ( $_obf_hoqLk5OLlIuMkIuRk5CNlJA� as $_obf_lJCSkoeMho2PlJOLiouJj4Y� )
        {
            _obf_kZWOkouLho6Uko2OjIqMjI0�( );
            $_obf_kpWKiI2Jj5SGipKVkI_OjY8� = $_obf_lJCSkoeMho2PlJOLiouJj4Y�['id'];
            $_obf_j5KIipONlJSQiYmTiYeVlYk� = "kss_z_user_".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['tbname'];
            $_obf_jo6SlY_VkouJhoqGio2IiZI� = "kss_z_key_".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['tbname'];
            $_obf_i4yKj4eSi4mRkIqSkY6Piok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from ".$_obf_j5KIipONlJSQiYmTiYeVlYk�." where `username`='".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."'" );
            if ( empty( $_obf_i4yKj4eSi4mRkIqSkY6Piok� ) )
            {
                $_obf_joaVlZWPkYeKi5WTiZWVkYw� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from ".$_obf_jo6SlY_VkouJhoqGio2IiZI�." where `keys`='".substr( $_obf_lJCSkoeMho2PlJOLiouJj4Y�['username'], 4, 6 )."' and `keyfix`='".substr( $_obf_lJCSkoeMho2PlJOLiouJj4Y�['username'], 0, 4 )."'" );
                if ( empty( $_obf_joaVlZWPkYeKi5WTiZWVkYw� ) )
                {
                    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "delete from ".$_obf_j5KIipONlJSQiYmTiYeVlYk�." where `username`='".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."'";
                    $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                        2
                    );
                    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "主服未找到注册卡".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."，删除备服用户" );
                    continue;
                }
                else
                {
                    if ( $_obf_joaVlZWPkYeKi5WTiZWVkYw�['islock'] != 0 )
                    {
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update ".$_obf_j5KIipONlJSQiYmTiYeVlYk�." set islock=".$_obf_joaVlZWPkYeKi5WTiZWVkYw�['islock']." where `username`='".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."'";
                        $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                            2
                        );
                        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "主服注册卡用户被锁定".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."，锁定备服注册卡用户" );
                        continue;
                    }
                    if ( $_obf_joaVlZWPkYeKi5WTiZWVkYw�['isback'] != 0 )
                    {
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "delete from ".$_obf_j5KIipONlJSQiYmTiYeVlYk�." where `username`='".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."'";
                        $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                            2
                        );
                        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "主服注册卡退款".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."，删除备服注册卡用户" );
                        continue;
                    }
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k� = array( );
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['username'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['keyfix'].$_obf_joaVlZWPkYeKi5WTiZWVkYw�['keys'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['password'] = substr( $_obf_joaVlZWPkYeKi5WTiZWVkYw�['keyspassword'], 0, 10 );
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['password2'] = substr( $_obf_joaVlZWPkYeKi5WTiZWVkYw�['keyspassword'], 10 );
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['addtime'] = $_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['starttime'] = $_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['managerid'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['managerid'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['cday'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['points'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['tag'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['tag'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['linknum'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['keyextattr'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'] + $_obf_joaVlZWPkYeKi5WTiZWVkYw�['cday'] * 86400;
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] = 1;
                    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( $_obf_j5KIipONlJSQiYmTiYeVlYk�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "sql" );
                    $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                        1
                    );
                    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update `".$_obf_jo6SlY_VkouJhoqGio2IiZI�."` set cztime=".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'].",czusername='".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."' where `keys`='".$_obf_joaVlZWPkYeKi5WTiZWVkYw�['keys']."'";
                    $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                        1
                    );
                }
            }
            else
            {
                if ( $_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'] < $_obf_i4yKj4eSi4mRkIqSkY6Piok�['starttime'] )
                {
                    $_obf_kZGIi4yVio2Nh5CNkJOHiY8� = $_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'];
                    $_obf_ipKHlZGViZOSkZOMho2ViZM� = 1;
                    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "备服先激活".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username'] );
                }
                else
                {
                    $_obf_kZGIi4yVio2Nh5CNkJOHiY8� = $_obf_i4yKj4eSi4mRkIqSkY6Piok�['starttime'];
                    $_obf_ipKHlZGViZOSkZOMho2ViZM� = 2;
                    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "主服先激活".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username'] );
                }
                $_obf_kY_HiJOShpCTioiIiJWLho4� = $_obf_kZGIi4yVio2Nh5CNkJOHiY8� + $_obf_i4yKj4eSi4mRkIqSkY6Piok�['cday'] * 86400;
                $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update `".$_obf_j5KIipONlJSQiYmTiYeVlYk�."` set cday='".$_obf_i4yKj4eSi4mRkIqSkY6Piok�['cday']."', starttime=".$_obf_kZGIi4yVio2Nh5CNkJOHiY8�.", endtime=".$_obf_kY_HiJOShpCTioiIiJWLho4�." where `username`='".$_obf_i4yKj4eSi4mRkIqSkY6Piok�['username']."'";
                $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                    $_obf_ipKHlZGViZOSkZOMho2ViZM�
                );
            }
        }
        $_obf_k5OTjZSSlY6PiY6LhoyUh5M� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_komUlJONiIqQk42JjYmOioY�( "kss_tb_sql" );
        foreach ( $_obf_iouNho2VkZGNi4qGhoiLiJA� as $_obf_jYqGj4aRj4_TiY_Mk4qUipA� )
        {
            $_obf_kI6TlIiSlYaMjpKQi4eHj5A� = "insert into `kss_tb_sql` (`addtime`,`sqltext`,`isact`,`notifyid`) VALUES(".time( ).",'".mysql_real_escape_string( $_obf_jYqGj4aRj4_TiY_Mk4qUipA�[0] )."',".$_obf_jYqGj4aRj4_TiY_Mk4qUipA�[1].",'".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."')";
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kI6TlIiSlYaMjpKQi4eHj5A�, "notsync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "repair table kss_tb_sql", "notsync" );
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kI6TlIiSlYaMjpKQi4eHj5A�, "notsync" );
                if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
                {
                    $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."'", "notsync" );
                    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "录入临时数据时出错".$_obf_jYqGj4aRj4_TiY_Mk4qUipA�[0] );
                    exit( );
                }
            }
        }
        unset( $_obf_hoqLk5OLlIuMkIuRk5CNlJA� );
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "激活记录处理完毕！" );
    }
    if ( !empty( $_obf_iYqQh5CQkpGIkI6JjpWRk4w� ) )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "备服有扣点记录，开始处理扣点记录" );
        $_obf_kpWKiI2Jj5SGipKVkI_OjY8� = 0;
        $_obf_hpWVj5COj5KSh5GHkoqIk4g� = array( );
        foreach ( $_obf_iYqQh5CQkpGIkI6JjpWRk4w� as $_obf_jZWHko2GjY6MkI2QlYqJiIc� )
        {
            _obf_kZWOkouLho6Uko2OjIqMjI0�( );
            $_obf_kpWKiI2Jj5SGipKVkI_OjY8� = $_obf_jZWHko2GjY6MkI2QlYqJiIc�['id'];
            if ( isset( $_obf_hpWVj5COj5KSh5GHkoqIk4g�[$_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'].$_obf_jZWHko2GjY6MkI2QlYqJiIc�['username']] ) )
            {
                $_obf_hpWVj5COj5KSh5GHkoqIk4g�[$_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'].$_obf_jZWHko2GjY6MkI2QlYqJiIc�['username']] = array(
                    $_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'],
                    $_obf_jZWHko2GjY6MkI2QlYqJiIc�['username'],
                    $_obf_hpWVj5COj5KSh5GHkoqIk4g�[$_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'].$_obf_jZWHko2GjY6MkI2QlYqJiIc�['username']][2] + $_obf_jZWHko2GjY6MkI2QlYqJiIc�['points']
                );
            }
            else
            {
                $_obf_hpWVj5COj5KSh5GHkoqIk4g�[$_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'].$_obf_jZWHko2GjY6MkI2QlYqJiIc�['username']] = array(
                    $_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'],
                    $_obf_jZWHko2GjY6MkI2QlYqJiIc�['username'],
                    $_obf_jZWHko2GjY6MkI2QlYqJiIc�['points']
                );
            }
        }
        unset( $_obf_iYqQh5CQkpGIkI6JjpWRk4w� );
        foreach ( $_obf_hpWVj5COj5KSh5GHkoqIk4g� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_tb_sql_points (`addtime`,`tbname`,`username`,`points`,`svrid`) values (".time( ).",'".$_obf_lYeSkY6Th5SOlYuHjZGVio8�[0]."','".$_obf_lYeSkY6Th5SOlYuHjZGVio8�[1]."',".$_obf_lYeSkY6Th5SOlYuHjZGVio8�[2].",2)", "notsync" );
        }
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "扣点记录处理完毕" );
    }
    if ( !empty( $_obf_iYqQh5CQkpGIkI6JjpWRk4w� ) || !empty( $_obf_hoqLk5OLlIuMkIuRk5CNlJA� ) )
    {
        file_put_contents( KSSROOTDIR."kss_logs".DIRECTORY_SEPARATOR."notifyid.txt", "11112" );
        $_obf_koqTiIuHiY6NlJWOiYqRkZE� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC1URL."?step=a2&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&trytimes=0&pwd=".MYSQLBAKPASSWORD, FALSE, 1 );
    }
    else
    {
        $_obf_koqTiIuHiY6NlJWOiYqRkZE� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC1URL."?step=a3&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&trytimes=0&pwd=".MYSQLBAKPASSWORD, FALSE, 1 );
    }
    exit( );
}

function _obf_ipWRkoaJjZONiYyPlJKIkoY�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_j42OiJORiY6OjYuMkY2Lj4k�;
    global $_obf_h5KGh42MlI2Ij5WRjI6Nh48�;
    $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = $_GET['notifyid'];
    $_obf_h4iLlI2KlI_QjoqNkoyRh4c� = $_GET['trytimes'];
    if ( !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_ioqNlY6GjpCVjY2Ph5WVioc� ) )
    {
        exit( "notifyid invalid!" );
    }
    if ( 2 < $_obf_h4iLlI2KlI_QjoqNkoyRh4c� )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "删除备服已处理数据2次重试均失败，同步结束！" );
        exit( );
    }
    if ( $_obf_h4iLlI2KlI_QjoqNkoyRh4c� == 0 )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "向备服发送删除已处理数据的命令！" );
    }
    else
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "删除备服已处理数据命令失败，开始第".$_obf_h4iLlI2KlI_QjoqNkoyRh4c�."次重试！" );
    }
    $_obf_jYyRlJOMh4uPh5KUlZSRiZE� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC2URL."?step=b2&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&trytimes=".$_obf_h4iLlI2KlI_QjoqNkoyRh4c�."&pwd=".MYSQLBAKPASSWORD, FALSE, $_obf_h5KGh42MlI2Ij5WRjI6Nh48� / 1000 - 5 );
    if ( substr( $_obf_jYyRlJOMh4uPh5KUlZSRiZE�, 0, 6 ) != "dataok" )
    {
        $_obf_koqTiIuHiY6NlJWOiYqRkZE� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC1URL."?step=a2&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&trytimes=".( $_obf_h4iLlI2KlI_QjoqNkoyRh4c� + 1 )."&pwd=".MYSQLBAKPASSWORD, FALSE, 1 );
        exit( );
    }
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "备服已处理数据删除成功，开始处理主服数据变更到备服！" );
    $_obf_koqTiIuHiY6NlJWOiYqRkZE� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC1URL."?step=a3&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&trytimes=0&limit=0&pwd=".MYSQLBAKPASSWORD, FALSE, 1 );
    exit( );
}

function _obf_kIiQjY_Uh5OLhpKOkZOLkpU�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_j42OiJORiY6OjYuMkY2Lj4k�;
    global $_obf_h5KGh42MlI2Ij5WRjI6Nh48�;
    $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = $_GET['notifyid'];
    if ( !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_ioqNlY6GjpCVjY2Ph5WVioc� ) )
    {
        exit( "notifyid invalid!" );
    }
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "开始处理主服数据" );
    $_obf_k5OTjZSSlY6PiY6LhoyUh5M� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_komUlJONiIqQk42JjYmOioY�( "kss_tb_sql" );
    if ( $_obf_k5OTjZSSlY6PiY6LhoyUh5M� == 0 )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "未发现待同步数据" );
        exit( );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_sql set notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."' where notifyid='' ", "notsync" );
    $_obf_iouGh4aRkYmSioiOlImUio4� = array( "sqldata" => "" );
    $_obf_hoiVk4iHiIaLlIySi4qVkZM� = 0;
    $_obf_i4mIjpWGkJSLkZWJjYeGlJI� = 0;
    $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql` where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."' order by id asc limit 0,300 ", 1, 1 );
    while ( !empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
    {
        foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
        {
            if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['isact'] == 1 )
            {
                $_obf_i4mIjpWGkJSLkZWJjYeGlJI� = 1;
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['sqltext'] );
                if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
                {
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_sql` where `id`=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'], "notsync" );
                }
                else
                {
                    $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_config SET `sync_state`=`sync_state`+1 where id=1", "notsync" );
                    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "↑↑↑↑↑↑↑↑↑↑↑同步到日志ID=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."时出错！".$_obf_h4aUkomQiI6JlIaSkomSkok�."\t".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['sqltext'] );
                    exit( );
                }
            }
            else
            {
                $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'] .= $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['sqltext'].chr( 1 );
            }
        }
        unset( $_obf_iYeIjIaVlYaIj4yTiJWHk40� );
        $_obf_hoiVk4iHiIaLlIySi4qVkZM� += 300;
        $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql` where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."' order by id asc limit ".$_obf_hoiVk4iHiIaLlIySi4qVkZM�.",300", 1, 1 );
    }
    if ( $_obf_i4mIjpWGkJSLkZWJjYeGlJI� == 1 )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "注册卡激活记录主服相关变更完成！" );
    }
    $_obf_hoiVk4iHiIaLlIySi4qVkZM� = 0;
    $_obf_jI2Ri4eIiIqNjZKSiY_HkZI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql_points` where `svrid`=2 order by id asc limit 0,300 ", 1, 1 );
    while ( !empty( $_obf_jI2Ri4eIiIqNjZKSiY_HkZI� ) )
    {
        foreach ( $_obf_jI2Ri4eIiIqNjZKSiY_HkZI� as $_obf_jZWPiZWJlIeHkZWIhouRlZA� )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_jZWPiZWJlIeHkZWIhouRlZA�['tbname']." SET `points`=`points`-".$_obf_jZWPiZWJlIeHkZWIhouRlZA�['points']." where `username`='".$_obf_jZWPiZWJlIeHkZWIhouRlZA�['username']."'", "notsync" );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_sql_points` where `id`=".$_obf_jZWPiZWJlIeHkZWIhouRlZA�['id'], "notsync" );
        }
        unset( $_obf_jI2Ri4eIiIqNjZKSiY_HkZI� );
        $_obf_hoiVk4iHiIaLlIySi4qVkZM� += 300;
        $_obf_jI2Ri4eIiIqNjZKSiY_HkZI� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql_points` where `svrid`=2 order by id asc limit ".$_obf_hoiVk4iHiIaLlIySi4qVkZM�.",300", 1, 1 );
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "点数处理".$_obf_hoiVk4iHiIaLlIySi4qVkZM� );
    }
    if ( empty( $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'] ) )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "无需同步数据取备服" );
        file_put_contents( KSSLOGDIR."sendsqldata.php", "<?php exit('x');?>" );
        exit( );
    }
    $_obf_lI2Vh4qTjpKPlZSVjo_JhpE� = strlen( $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'] );
    $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'] = substr( $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'], 0, strlen( $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'] ) - 1 );
    $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'] = base64_encode( gzcompress( $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'] ) );
    $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'] = strtr( $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'], "+/=", "*_-" );
    file_put_contents( KSSLOGDIR."sendsqldata.php", "<?php exit('x');?>".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�.$_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'] );
    $_obf_kIqHiYqIko2Qk4eOjIaOj4s� = strlen( $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'] );
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "主服数据处理完毕，开始发送数据到备服！".round( $_obf_kIqHiYqIko2Qk4eOjIaOj4s� / 1024, 2 )."KB数据压缩率".round( $_obf_kIqHiYqIko2Qk4eOjIaOj4s� * 100 / $_obf_lI2Vh4qTjpKPlZSVjo_JhpE� )."%" );
    $_obf_koqTiIuHiY6NlJWOiYqRkZE� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC2URL."?step=b3&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&trytimes=0&randid=".time( )."&limit=0&pwd=".MYSQLBAKPASSWORD, $_obf_iouGh4aRkYmSioiOlImUio4�, intval( $_obf_h5KGh42MlI2Ij5WRjI6Nh48� / 1000 - 10 ) );
    if ( substr( $_obf_koqTiIuHiY6NlJWOiYqRkZE�, 0, 6 ) != "dataok" )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( $_obf_koqTiIuHiY6NlJWOiYqRkZE� );
        $_obf_koqTiIuHiY6NlJWOiYqRkZE� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC2URL."?step=a4&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&trytimes=1&limit=0&pwd=".MYSQLBAKPASSWORD, $_obf_iouGh4aRkYmSioiOlImUio4�, 1 );
        exit( );
    }
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "备服处理主服数据结果：".substr( $_obf_koqTiIuHiY6NlJWOiYqRkZE�, 6 ) );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."' ", "notsync" );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_config SET `sync_state`=0 where id=1", "notsync" );
    file_put_contents( KSSLOGDIR."sendsqldata.php", "<?php exit('x');?>" );
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "本次同步完成" );
    exit( );
}

function _obf_i5SNipCHjImPkoeRlZGTjo0�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_j42OiJORiY6OjYuMkY2Lj4k�;
    global $_obf_h5KGh42MlI2Ij5WRjI6Nh48�;
    $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = $_GET['notifyid'];
    $_obf_h4iLlI2KlI_QjoqNkoyRh4c� = $_GET['trytimes'];
    if ( !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_ioqNlY6GjpCVjY2Ph5WVioc� ) )
    {
        exit( "notifyid invalid!" );
    }
    if ( 3 < $_obf_h4iLlI2KlI_QjoqNkoyRh4c� )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "发送数据到备服".( $_obf_h4iLlI2KlI_QjoqNkoyRh4c� - 1 )."次重试均失败，同步结束！" );
        exit( );
    }
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "发送数据到备服，开始第".$_obf_h4iLlI2KlI_QjoqNkoyRh4c�."次重试！" );
    $_obf_jZWRiYeJlI2Pj4mGioiKkpM� = file_get_contents( KSSLOGDIR."sendsqldata.php" );
    if ( substr( $_obf_jZWRiYeJlI2Pj4mGioiKkpM�, 18, 20 ) != $_obf_ioqNlY6GjpCVjY2Ph5WVioc� )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_config SET `sync_state`=10 where id=1", "notsync" );
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "同步结束sendsqldata内容被改变，建议手工同步一次数据库！" );
        exit( );
    }
    $_obf_iouGh4aRkYmSioiOlImUio4� = array( );
    $_obf_iouGh4aRkYmSioiOlImUio4�['sqldata'] = substr( $_obf_jZWRiYeJlI2Pj4mGioiKkpM�, 38 );
    $_obf_koqTiIuHiY6NlJWOiYqRkZE� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC2URL."?step=b3&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&trytimes=0&pwd=".MYSQLBAKPASSWORD, $_obf_iouGh4aRkYmSioiOlImUio4�, $_obf_h5KGh42MlI2Ij5WRjI6Nh48� / 1000 - 5 );
    if ( substr( $_obf_koqTiIuHiY6NlJWOiYqRkZE�, 0, 6 ) != "dataok" )
    {
        $_obf_koqTiIuHiY6NlJWOiYqRkZE� = _obf_j5SMi5KSiouIj4iIipWIkIs�( SYNC2URL."?step=a4&notifyid=".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."&trytimes=".( $_obf_h4iLlI2KlI_QjoqNkoyRh4c� + 1 )."&limit=0&pwd=".MYSQLBAKPASSWORD, $_obf_iouGh4aRkYmSioiOlImUio4�, 1 );
        exit( );
    }
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "备服处理主服数据结果：".substr( $_obf_koqTiIuHiY6NlJWOiYqRkZE�, 6 ) );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."' ", "notsync" );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_config SET `sync_state`=0 where id=1", "notsync" );
    file_put_contents( KSSLOGDIR."sendsqldata.php", "<?php exit('x');?>" );
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "本次同步完成" );
    exit( );
}

function _obf_hpCLjoyMjJSSiY6Qjo6VjZQ�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_j42OiJORiY6OjYuMkY2Lj4k�;
    global $_obf_h5KGh42MlI2Ij5WRjI6Nh48�;
    $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = $_GET['notifyid'];
    if ( !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_ioqNlY6GjpCVjY2Ph5WVioc� ) )
    {
        exit( "notifyid invalid!" );
    }
    $_obf_iIyIjoeKjYuOj46JkYqVkoY� = "";
    $_obf_iYeViIuKjpWHhoaMio6GjIY� = "";
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql_active where notifyid not in('".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."','')", "notsync" );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql_points where notifyid not in('".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."','')", "notsync" );
    $_obf_jY2Kh4aJkJCJlIaSlY_Nj5I� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql_points` where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."' order by id asc" );
    if ( !empty( $_obf_jY2Kh4aJkJCJlIaSlY_Nj5I� ) )
    {
        $_obf_iIyIjoeKjYuOj46JkYqVkoY� = _obf_i5KKjpOTlJGTiYeMkZCTk4g�( $_obf_jY2Kh4aJkJCJlIaSlY_Nj5I� );
    }
    else
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_sql_points set notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."'", "notsync" );
        $_obf_jY2Kh4aJkJCJlIaSlY_Nj5I� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql_points` where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."' order by id asc" );
        if ( !empty( $_obf_jY2Kh4aJkJCJlIaSlY_Nj5I� ) )
        {
            $_obf_iIyIjoeKjYuOj46JkYqVkoY� = _obf_i5KKjpOTlJGTiYeMkZCTk4g�( $_obf_jY2Kh4aJkJCJlIaSlY_Nj5I� );
        }
    }
    $_obf_i5WNkIiOkoqUkYeGk4uTjIc� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql_active` where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."' order by id asc" );
    if ( !empty( $_obf_i5WNkIiOkoqUkYeGk4uTjIc� ) )
    {
        $_obf_iYeViIuKjpWHhoaMio6GjIY� = _obf_i5KKjpOTlJGTiYeMkZCTk4g�( $_obf_i5WNkIiOkoqUkYeGk4uTjIc� );
    }
    else
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_sql_active set notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."'", "notsync" );
        $_obf_i5WNkIiOkoqUkYeGk4uTjIc� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql_active` where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."' order by id asc" );
        if ( !empty( $_obf_i5WNkIiOkoqUkYeGk4uTjIc� ) )
        {
            $_obf_iYeViIuKjpWHhoaMio6GjIY� = _obf_i5KKjpOTlJGTiYeMkZCTk4g�( $_obf_i5WNkIiOkoqUkYeGk4uTjIc� );
        }
    }
    exit( "dataok|".$_obf_iYeViIuKjpWHhoaMio6GjIY�."|".$_obf_iIyIjoeKjYuOj46JkYqVkoY� );
}

function _obf_kYmVhpKGj5OSj5CPho_UlJA�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_j42OiJORiY6OjYuMkY2Lj4k�;
    global $_obf_h5KGh42MlI2Ij5WRjI6Nh48�;
    $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = $_GET['notifyid'];
    if ( !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_ioqNlY6GjpCVjY2Ph5WVioc� ) )
    {
        exit( "notifyid invalid!" );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql_active where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."'", "notsync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE kss_tb_sql_active", "notsync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql_active where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."'", "notsync" );
    }
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql_points where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."'", "notsync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE kss_tb_sql_points", "notsync" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql_points where notifyid='".$_obf_ioqNlY6GjpCVjY2Ph5WVioc�."'", "notsync" );
    }
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( $_obf_ioqNlY6GjpCVjY2Ph5WVioc�."激活与点数数据成功发送到主服" );
    exit( );
}

function _obf_iYqMlY_Vi5WIjoyGkI2Hko0�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_j42OiJORiY6OjYuMkY2Lj4k�;
    global $_obf_h5KGh42MlI2Ij5WRjI6Nh48�;
    _obf_hpCHkYaMkYuNko2Gio2KjJQ�( );
    $_obf_ioqNlY6GjpCVjY2Ph5WVioc� = $_GET['notifyid'];
    $_obf_hoeUiJCLjYyGjIaKkZKOk4c� = $_POST['sqldata'];
    $_obf_hoeUiJCLjYyGjIaKkZKOk4c� = strtr( $_obf_hoeUiJCLjYyGjIaKkZKOk4c�, "*_-", "+/=" );
    if ( !_obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_ioqNlY6GjpCVjY2Ph5WVioc� ) )
    {
        exit( "notifyid invalid!" );
    }
    $_obf_hoeUiJCLjYyGjIaKkZKOk4c� = gzuncompress( base64_decode( $_obf_hoeUiJCLjYyGjIaKkZKOk4c� ) );
    $_obf_h4yViImPipSNiY6MiZWIkZQ� = explode( chr( 1 ), $_obf_hoeUiJCLjYyGjIaKkZKOk4c� );
    if ( is_file( KSSLOGDIR."notifyid".DIRECTORY_SEPARATOR.$_obf_ioqNlY6GjpCVjY2Ph5WVioc�.".txt" ) )
    {
        $_obf_jY2OjpWVjpGNi4yNiIeIjIg� = file_get_contents( KSSLOGDIR."notifyid".DIRECTORY_SEPARATOR.$_obf_ioqNlY6GjpCVjY2Ph5WVioc�.".txt" );
    }
    else
    {
        $_obf_jY2OjpWVjpGNi4yNiIeIjIg� = 0;
        file_put_contents( KSSLOGDIR."notifyid".DIRECTORY_SEPARATOR.$_obf_ioqNlY6GjpCVjY2Ph5WVioc�.".txt", "0" );
    }
    if ( !empty( $_obf_h4yViImPipSNiY6MiZWIkZQ� ) )
    {
        if ( $_obf_jY2OjpWVjpGNi4yNiIeIjIg� < count( $_obf_h4yViImPipSNiY6MiZWIkZQ� ) )
        {
            $_obf_h4yViImPipSNiY6MiZWIkZQ� = array_slice( $_obf_h4yViImPipSNiY6MiZWIkZQ�, $_obf_jY2OjpWVjpGNi4yNiIeIjIg� );
            $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
            foreach ( $_obf_h4yViImPipSNiY6MiZWIkZQ� as $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� )
            {
                $_obf_j42OiJORiY6OjYuMkY2Lj4k�[1] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
                if ( $_obf_h5KGh42MlI2Ij5WRjI6Nh48� < _obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_j42OiJORiY6OjYuMkY2Lj4k� ) + 5000 )
                {
                    exit( "try主服发送".count( $_obf_h4yViImPipSNiY6MiZWIkZQ� )."条，备服已执行".( $_obf_jY2OjpWVjpGNi4yNiIeIjIg� + $_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1 )."条，主服需重试发送" );
                }
                $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 1;
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "notsync" );
                if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === TRUE )
                {
                    file_put_contents( KSSLOGDIR."notifyid".DIRECTORY_SEPARATOR.$_obf_ioqNlY6GjpCVjY2Ph5WVioc�.".txt", $_obf_jpKPlJSUiZOHkYaPlIeOiY4� + $_obf_jY2OjpWVjpGNi4yNiIeIjIg� );
                }
                else
                {
                    exit( "try备服执行到第".( $_obf_jY2OjpWVjpGNi4yNiIeIjIg� + $_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1 )."条语句【".$_obf_i4qPjo_Oj5GJiIyIi4qKh5U�."】时出错【".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( )."】" );
                }
            }
            exit( "dataok数据处理完毕1！" );
        }
        else
        {
            exit( "dataok数据处理完毕2！" );
        }
    }
    else
    {
        exit( "dataok接收到的数据是空的！" );
    }
}

function _obf_i4iHjpWLlY2SjI2RlJSMk4c�( )
{
    $_obf_kouViYyOlJWMkpSKkpGSlJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "fname", "g", "int", 0 );
    $_obf_lJOVj5WVkI2PjI6QjZWJjoY� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "scode", "p", "int", 0 );
    if ( strlen( $_obf_kouViYyOlJWMkpSKkpGSlJE� ) < 6 || strlen( $_obf_lJOVj5WVkI2PjI6QjZWJjoY� ) != 7 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "，同步advapi代码到备服时出错：软件标识错误".$_obf_kouViYyOlJWMkpSKkpGSlJE� );
    }
    $_obf_h5WSh5WPkoaVjJWVkoiQjoc� = $_POST['advapicode'];
    $_obf_h5WSh5WPkoaVjJWVkoiQjoc� = _obf_kIuUko_Mh42UkZSHjZSQiZI�( $_obf_h5WSh5WPkoaVjJWVkoiQjoc� );
    $_obf_hoaVjJGTj4uNioeOjpSVh4Y� = $_POST['rsacode'];
    $_obf_hoaVjJGTj4uNioeOjpSVh4Y� = _obf_kIuUko_Mh42UkZSHjZSQiZI�( $_obf_hoaVjJGTj4uNioeOjpSVh4Y� );
    file_put_contents( "./advapi/".$_obf_kouViYyOlJWMkpSKkpGSlJE�.".php", $_obf_h5WSh5WPkoaVjJWVkoiQjoc� );
    file_put_contents( "./advapi/rsa".$_obf_lJOVj5WVkI2PjI6QjZWJjoY�.".php", $_obf_hoaVjJGTj4uNioeOjpSVh4Y� );
    exit( "，advapi和rsa缓存代码已更新到备服" );
}

function _obf_hpCHkYaMkYuNko2Gio2KjJQ�( )
{
    clearstatcache( );
    $_obf_j4uTjpCNho6Kh4qGh4eLi40� = KSSLOGDIR."notifyid".DIRECTORY_SEPARATOR;
    $_obf_jZCHlIqNkJSSiYaQk4eVko0� = @dir( $_obf_j4uTjpCNho6Kh4qGh4eLi40� );
    while ( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� = $_obf_jZCHlIqNkJSSiYaQk4eVko0�->read( ) )
    {
        if ( pathinfo( $_obf_kY_Ki4_NiIqMj5CSiIiRk48�, PATHINFO_EXTENSION ) == "txt" && is_file( $_obf_j4uTjpCNho6Kh4qGh4eLi40�.$_obf_kY_Ki4_NiIqMj5CSiIiRk48� ) && filemtime( $_obf_j4uTjpCNho6Kh4qGh4eLi40�.$_obf_kY_Ki4_NiIqMj5CSiIiRk48� ) < time( ) - 36000 )
        {
            @unlink( $_obf_j4uTjpCNho6Kh4qGh4eLi40�.$_obf_kY_Ki4_NiIqMj5CSiIiRk48� );
        }
    }
    $_obf_jZCHlIqNkJSSiYaQk4eVko0�->close( );
}

function _obf_lJSMlYuJk5SMkI_KiI_RiIk�( $_obf_jIqLjIyJk5WTh5CHiZSVh5E� )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "insert into `kss_tb_log_task` (`addtime`, `intro`) values (".time( ).", '".mysql_real_escape_string( $_obf_jIqLjIyJk5WTh5CHiZSVh5E� )."')";
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, "nosync" );
    if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== TRUE )
    {
        _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ), __FILE__, 528 );
    }
}

function _obf_kZWOkouLho6Uko2OjIqMjI0�( )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�;
    global $_obf_h5KGh42MlI2Ij5WRjI6Nh48�;
    global $_obf_j42OiJORiY6OjYuMkY2Lj4k�;
    $_obf_j42OiJORiY6OjYuMkY2Lj4k�[1] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
    if ( $_obf_h5KGh42MlI2Ij5WRjI6Nh48� < _obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_j42OiJORiY6OjYuMkY2Lj4k� ) + 2000 )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "↑↑↑↑↑↑↑↑↑↑↑".$_obf_h5KGh42MlI2Ij5WRjI6Nh48�."秒" );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kJCHlYiNjJCQlJKQkZKSko0�( );
        $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_kJCHlYiNjJCQlJKQkZKSko0�( );
        exit( );
    }
}

function _obf_i5KKjpOTlJGTiYeMkZCTk4g�( $_obf_iY2TjIyPlIeMkYeQiJKVjI8� )
{
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = "";
    foreach ( $_obf_iY2TjIyPlIeMkYeQiJKVjI8� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
    {
        $_obf_jIiIiJSJiYyGiIaPiZWJjZI� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�.chr( 1 );
        foreach ( $_obf_lYeSkY6Th5SOlYuHjZGVio8� as $_obf_jIiJhoaRhpWMh5WSlI2JkpI� => $_obf_hoeShoiJj4qSkZCKh4_Pj5A� )
        {
            $_obf_jIiIiJSJiYyGiIaPiZWJjZI� .= $_obf_jIiJhoaRhpWMh5WSlI2JkpI�.chr( 2 ).$_obf_hoeShoiJj4qSkZCKh4_Pj5A�.chr( 2 );
        }
        $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = substr( $_obf_jIiIiJSJiYyGiIaPiZWJjZI�, 0, strlen( $_obf_jIiIiJSJiYyGiIaPiZWJjZI� ) - 1 ).chr( 1 );
    }
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = substr( $_obf_jIiIiJSJiYyGiIaPiZWJjZI�, 0, strlen( $_obf_jIiIiJSJiYyGiIaPiZWJjZI� ) - 1 );
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = base64_encode( gzcompress( $_obf_jIiIiJSJiYyGiIaPiZWJjZI� ) );
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = strtr( $_obf_jIiIiJSJiYyGiIaPiZWJjZI�, "+/=", "*_-" );
    return $_obf_jIiIiJSJiYyGiIaPiZWJjZI�;
}

function _obf_lYuLkpWKjJOKk4eLiZWHi4g�( $_obf_jIiIiJSJiYyGiIaPiZWJjZI� )
{
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = strtr( $_obf_jIiIiJSJiYyGiIaPiZWJjZI�, "*_-", "+/=" );
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = gzuncompress( base64_decode( $_obf_jIiIiJSJiYyGiIaPiZWJjZI� ) );
    $_obf_iY_KkZKTjJOQjZGLiZSUiIw� = explode( chr( 1 ), $_obf_jIiIiJSJiYyGiIaPiZWJjZI� );
    $_obf_jomViI6KkJOPh4eNiYeGi48� = count( $_obf_iY_KkZKTjJOQjZGLiZSUiIw� );
    $_obf_lIePko6OkoePiJCJkpOSjIo� = array( );
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_jomViI6KkJOPh4eNiYeGi48�; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2, )
    {
        $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = intval( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� / 2 );
        $_obf_i4yLjY6PhoqJkJOUj4uTjJM� = explode( chr( 2 ), $_obf_iY_KkZKTjJOQjZGLiZSUiIw�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw� * 2 + 1] );
        $_obf_koyIh5KTkJWMipWQjpGJh4s� = count( $_obf_i4yLjY6PhoqJkJOUj4uTjJM� );
        $_obf_jJWUlZWTjJWKjY2NkZSHjIk� = array( );
        $_obf_iI2OkIaGi5SPjJKIlZSHjog� = 0;
        for ( ; $_obf_iI2OkIaGi5SPjJKIlZSHjog� < $_obf_koyIh5KTkJWMipWQjpGJh4s�; $_obf_iI2OkIaGi5SPjJKIlZSHjog� += 2, )
        {
            $_obf_jJWUlZWTjJWKjY2NkZSHjIk�[$_obf_i4yLjY6PhoqJkJOUj4uTjJM�[$_obf_iI2OkIaGi5SPjJKIlZSHjog�]] = $_obf_i4yLjY6PhoqJkJOUj4uTjJM�[$_obf_iI2OkIaGi5SPjJKIlZSHjog� + 1];
        }
        $_obf_lIePko6OkoePiJCJkpOSjIo�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw�] = $_obf_jJWUlZWTjJWKjY2NkZSHjIk�;
        unset( $_obf_jJWUlZWTjJWKjY2NkZSHjIk� );
    }
    return $_obf_lIePko6OkoePiJCJkpOSjIo�;
}

function _obf_iIqLh42UipSHk46SlY_ViY0�( $_obf_iY2TjIyPlIeMkYeQiJKVjI8� )
{
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = "";
    foreach ( $_obf_iY2TjIyPlIeMkYeQiJKVjI8� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
    {
        $_obf_jIiIiJSJiYyGiIaPiZWJjZI� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�.chr( 1 ).$_obf_lYeSkY6Th5SOlYuHjZGVio8�.chr( 1 );
    }
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = substr( $_obf_jIiIiJSJiYyGiIaPiZWJjZI�, 0, strlen( $_obf_jIiIiJSJiYyGiIaPiZWJjZI� ) - 1 );
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = base64_encode( gzcompress( $_obf_jIiIiJSJiYyGiIaPiZWJjZI� ) );
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = strtr( $_obf_jIiIiJSJiYyGiIaPiZWJjZI�, "+/=", "*_-" );
    return $_obf_jIiIiJSJiYyGiIaPiZWJjZI�;
}

function _obf_h4qTkJOHjpCGh4uMk4eJh44�( $_obf_jIiIiJSJiYyGiIaPiZWJjZI� )
{
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = strtr( $_obf_jIiIiJSJiYyGiIaPiZWJjZI�, "*_-", "+/=" );
    $_obf_jIiIiJSJiYyGiIaPiZWJjZI� = gzuncompress( base64_decode( $_obf_jIiIiJSJiYyGiIaPiZWJjZI� ) );
    $_obf_iY_KkZKTjJOQjZGLiZSUiIw� = explode( chr( 1 ), $_obf_jIiIiJSJiYyGiIaPiZWJjZI� );
    $_obf_jomViI6KkJOPh4eNiYeGi48� = count( $_obf_iY_KkZKTjJOQjZGLiZSUiIw� );
    $_obf_lIePko6OkoePiJCJkpOSjIo� = array( );
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_jomViI6KkJOPh4eNiYeGi48�; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2, )
    {
        $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = intval( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� / 2 );
        $_obf_lIePko6OkoePiJCJkpOSjIo�[$_obf_iY_KkZKTjJOQjZGLiZSUiIw�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw�]] = $_obf_iY_KkZKTjJOQjZGLiZSUiIw�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw� * 2 + 1];
    }
    return $_obf_lIePko6OkoePiJCJkpOSjIo�;
}

require( "./inc.php" );
$_obf_j42OiJORiY6OjYuMkY2Lj4k� = array( );
$_obf_j42OiJORiY6OjYuMkY2Lj4k�[0] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
$_obf_h5KGh42MlI2Ij5WRjI6Nh48� = ini_get( "max_execution_time" );
if ( ini_get( "safe_mode" ) == FALSE )
{
    ini_set( "max_execution_time", 90 );
    $_obf_h5KGh42MlI2Ij5WRjI6Nh48� = 90;
}
$_obf_h5KGh42MlI2Ij5WRjI6Nh48� *= 1000;
if ( SVRID == 2 && MYSQLBAKPASSWORD == $_GET['pwd'] && isset( $_GET['step'] ) && $_GET['step'] == "bsaveapicode" )
{
    _obf_i4iHjpWLlY2SjI2RlJSMk4c�( );
}
if ( SVRID == 1 && MYSQLSYNCMODE == 1 )
{
    $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
    $_obf_ho_Ik5KOh5KVh4eGlJCNjpM� = new mysql_cls( );
    include( "./sqlmode.php" );
    _obf_k4qTkYmKjpWRh42TlIeVlIo�( );
}
else
{
    $_obf_lI_ViZOTiIiSko2QjJCTipM� = $_GET['step'];
    if ( $_obf_lI_ViZOTiIiSko2QjJCTipM� == "b1" && ( SVRID != 2 || IS2SVR != 1 ) )
    {
        exit( "备服_config.php配置不正确，SVRID应该为2  IS2SVR应该为1" );
    }
    if ( MYSQLBAKPASSWORD != $_GET['pwd'] )
    {
        exit( "主服和备服【系统参数设置】里的【备份数据库的接口密码】不相同，请修改。" );
    }
    if ( IS2SVR == 1 )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
        if ( SVRID == 1 )
        {
            switch ( $_obf_lI_ViZOTiIiSko2QjJCTipM� )
            {
            case "a1" :
                _obf_iYuRlIaRioySiZKTj4mPkY0�( );
                break;
            case "a2" :
                _obf_ipWRkoaJjZONiYyPlJKIkoY�( );
                break;
            case "a3" :
                _obf_kIiQjY_Uh5OLhpKOkZOLkpU�( );
                break;
            case "a4" :
                _obf_i5SNipCHjImPkoeRlZGTjo0�( );
                break;
            default :
                break;
            }
            switch ( $_obf_lI_ViZOTiIiSko2QjJCTipM� )
            {
            }
            else
            {
            case "b1" :
                _obf_hpCLjoyMjJSSiY6Qjo6VjZQ�( );
                break;
            case "b2" :
                _obf_kYmVhpKGj5OSj5CPho_UlJA�( );
                break;
            case "b3" :
                _obf_iYqMlY_Vi5WIjoyGkI2Hko0�( );
                break;
            default :
                break;
            }
        }
        exit( );
    }
}
?>
