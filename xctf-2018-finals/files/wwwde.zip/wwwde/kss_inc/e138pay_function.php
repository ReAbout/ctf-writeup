<?php

function _obf_lYuMlYiPko_OkYqUk4qRlJE�( $_obf_k42Uko6Qk5CLiYqIjI_Ih5U�, $_obf_i5GGjZGNi42Hk4qIioiKk44� )
{
    $_obf_kouShpCQlYeOk4aPkomKh5M� = "SerialNo=".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['ordernum']."&UserID=".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['partner']."&ChannelID=".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['bkid']."&Money=".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['rmb']."&AttachString=e138&ReturnUrl=".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['return_url']."&NotifyUrl=".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['notify_url']."&MerchantKey=".$_obf_i5GGjZGNi42Hk4qIioiKk44�;
    $_obf_kpWJhoqKj4eIiIeJkIaJkIk� = strtolower( md5( $_obf_kouShpCQlYeOk4aPkomKh5M� ) );
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� = "";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<form method='post' name='E138_FORM' target='_blank' action='http://pay.e138.com/GateWay/Bank/Default.aspx'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='UserID'         value='".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['partner']."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='SerialNo'         value='".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['ordernum']."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='Money'      value='".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['rmb']."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='ReturnUrl'         value='".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['return_url']."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='NotifyUrl'     value='".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['notify_url']."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='VerifyString'       value='".$_obf_kpWJhoqKj4eIiIeJkIaJkIk�."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name='AttachString'       value='e138'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type='hidden' name=ChannelID value='".$_obf_k42Uko6Qk5CLiYqIjI_Ih5U�['bkid']."'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "<input type=submit class=submitbtn value='点击支付'>";
    $_obf_kpKOiYmNj4eMjYmOkImMjoc� .= "</form>";
    return $_obf_kpKOiYmNj4eMjYmOkImMjoc�;
}

?>
