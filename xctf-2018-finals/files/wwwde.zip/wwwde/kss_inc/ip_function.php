<?php

function _obf_j5SHjI6IhpKIh4_Hh4iMjIs�( $_obf_jY6MkIuIioqTk4eIiIiNj5U� )
{
    if ( !preg_match( "/^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\$/", $_obf_jY6MkIuIioqTk4eIiIiNj5U� ) )
    {
        return "";
    }
    if ( is_file( KSSROOTDIR."ip.dat" ) && ( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A� = @fopen( KSSROOTDIR."ip.dat", "rb" ) ) )
    {
        $_obf_jY6MkIuIioqTk4eIiIiNj5U� = explode( ".", $_obf_jY6MkIuIioqTk4eIiIiNj5U� );
        $_obf_kYmOjoiLkpCKiZGRiY2Mh5U� = $_obf_jY6MkIuIioqTk4eIiIiNj5U�[0] * 16777216 + $_obf_jY6MkIuIioqTk4eIiIiNj5U�[1] * 65536 + $_obf_jY6MkIuIioqTk4eIiIiNj5U�[2] * 256 + $_obf_jY6MkIuIioqTk4eIiIiNj5U�[3];
        $_obf_kY2HiIaKlI2Gi4_HiIaVipI� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 4 );
        $_obf_iJWLk4yQiY6MlZOOhpCIkI8� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 4 );
        $_obf_iJKJjpGSi5OPiYiTk5KGhpM� = implode( "", unpack( "L", $_obf_kY2HiIaKlI2Gi4_HiIaVipI� ) );
        if ( $_obf_iJKJjpGSi5OPiYiTk5KGhpM� < 0 )
        {
            $_obf_iJKJjpGSi5OPiYiTk5KGhpM� += pow( 2, 32 );
        }
        $_obf_homJkYmKkZSUi42PiYqVh5M� = implode( "", unpack( "L", $_obf_iJWLk4yQiY6MlZOOhpCIkI8� ) );
        if ( $_obf_homJkYmKkZSUi42PiYqVh5M� < 0 )
        {
            $_obf_homJkYmKkZSUi42PiYqVh5M� += pow( 2, 32 );
        }
        $_obf_i4aLjImMi5GNlY_IhpWTipU� = ( $_obf_homJkYmKkZSUi42PiYqVh5M� - $_obf_iJKJjpGSi5OPiYiTk5KGhpM� ) / 7 + 1;
        $_obf_lYaUjZWQhpSNj5OKlIyRi4w� = 0;
        $_obf_iJSUiYiSkI_OjomQk5SNi5Q� = $_obf_i4aLjImMi5GNlY_IhpWTipU�;
        $_obf_k42NkoqPk5ORj4mSipSRkYY� = 0;
        $_obf_j4uMjoaUjYaNh5WUh4eGlIc� = 0;
        $_obf_iZCKh4qVkZCJjI2PkYuQjYk� = "";
        $_obf_jJCKipSPlY6PiZOKjIaJiog� = "";
        while ( $_obf_kYmOjoiLkpCKiZGRiY2Mh5U� < $_obf_k42NkoqPk5ORj4mSipSRkYY� || $_obf_j4uMjoaUjYaNh5WUh4eGlIc� < $_obf_kYmOjoiLkpCKiZGRiY2Mh5U� )
        {
            $_obf_jo2Vjo2IiIyJlYiGlZCLkIg� = intval( ( $_obf_iJSUiYiSkI_OjomQk5SNi5Q� + $_obf_lYaUjZWQhpSNj5OKlIyRi4w� ) / 2 );
            fseek( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, $_obf_iJKJjpGSi5OPiYiTk5KGhpM� + 7 * $_obf_jo2Vjo2IiIyJlYiGlZCLkIg� );
            $_obf_kZCGh5GVkZCHkYeLio_QiY4� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 4 );
            if ( strlen( $_obf_kZCGh5GVkZCHkYeLio_QiY4� ) < 4 )
            {
                fclose( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A� );
                return "System Error";
            }
            $_obf_k42NkoqPk5ORj4mSipSRkYY� = implode( "", unpack( "L", $_obf_kZCGh5GVkZCHkYeLio_QiY4� ) );
            if ( $_obf_k42NkoqPk5ORj4mSipSRkYY� < 0 )
            {
                $_obf_k42NkoqPk5ORj4mSipSRkYY� += pow( 2, 32 );
            }
            if ( $_obf_kYmOjoiLkpCKiZGRiY2Mh5U� < $_obf_k42NkoqPk5ORj4mSipSRkYY� )
            {
                $_obf_iJSUiYiSkI_OjomQk5SNi5Q� = $_obf_jo2Vjo2IiIyJlYiGlZCLkIg�;
                continue;
            }
            $_obf_i4uRko2KkIyPkoiTlYqLjYc� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 3 );
            if ( strlen( $_obf_i4uRko2KkIyPkoiTlYqLjYc� ) < 3 )
            {
                fclose( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A� );
                return "System Error";
            }
            $_obf_i4uRko2KkIyPkoiTlYqLjYc� = implode( "", unpack( "L", $_obf_i4uRko2KkIyPkoiTlYqLjYc�.chr( 0 ) ) );
            fseek( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, $_obf_i4uRko2KkIyPkoiTlYqLjYc� );
            $_obf_joeJj4eJkpWJh5GUi4yTj5I� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 4 );
            if ( strlen( $_obf_joeJj4eJkpWJh5GUi4yTj5I� ) < 4 )
            {
                fclose( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A� );
                return "System Error";
            }
            $_obf_j4uMjoaUjYaNh5WUh4eGlIc� = implode( "", unpack( "L", $_obf_joeJj4eJkpWJh5GUi4yTj5I� ) );
            if ( $_obf_j4uMjoaUjYaNh5WUh4eGlIc� < 0 )
            {
                $_obf_j4uMjoaUjYaNh5WUh4eGlIc� += pow( 2, 32 );
            }
            if ( $_obf_j4uMjoaUjYaNh5WUh4eGlIc� < $_obf_kYmOjoiLkpCKiZGRiY2Mh5U� )
            {
                if ( $_obf_jo2Vjo2IiIyJlYiGlZCLkIg� == $_obf_lYaUjZWQhpSNj5OKlIyRi4w� )
                {
                    fclose( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A� );
                    return "Unknown";
                }
                $_obf_lYaUjZWQhpSNj5OKlIyRi4w� = $_obf_jo2Vjo2IiIyJlYiGlZCLkIg�;
            }
        }
        $_obf_io6Sj4aOkI2Tk4uOjJGGjpU� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 1 );
        if ( $_obf_io6Sj4aOkI2Tk4uOjJGGjpU� == chr( 1 ) )
        {
            $_obf_kpWRj5CRi4mHk4uKhoaSiI0� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 3 );
            if ( strlen( $_obf_kpWRj5CRi4mHk4uKhoaSiI0� ) < 3 )
            {
                fclose( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A� );
                return "System Error";
            }
            $_obf_kpWRj5CRi4mHk4uKhoaSiI0� = implode( "", unpack( "L", $_obf_kpWRj5CRi4mHk4uKhoaSiI0�.chr( 0 ) ) );
            fseek( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, $_obf_kpWRj5CRi4mHk4uKhoaSiI0� );
            $_obf_io6Sj4aOkI2Tk4uOjJGGjpU� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 1 );
        }
        if ( $_obf_io6Sj4aOkI2Tk4uOjJGGjpU� == chr( 2 ) )
        {
            $_obf_jIiHlIiLkIeMjIuRhoiNk4c� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 3 );
            if ( strlen( $_obf_jIiHlIiLkIeMjIuRhoiNk4c� ) < 3 )
            {
                fclose( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A� );
                return "System Error";
            }
            $_obf_io6Sj4aOkI2Tk4uOjJGGjpU� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 1 );
            if ( $_obf_io6Sj4aOkI2Tk4uOjJGGjpU� == chr( 2 ) )
            {
                $_obf_ioyLjY2SlZCSkoqGj5CUiow� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 3 );
                if ( strlen( $_obf_ioyLjY2SlZCSkoqGj5CUiow� ) < 3 )
                {
                    fclose( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A� );
                    return "System Error";
                }
                $_obf_ioyLjY2SlZCSkoqGj5CUiow� = implode( "", unpack( "L", $_obf_ioyLjY2SlZCSkoqGj5CUiow�.chr( 0 ) ) );
                fseek( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, $_obf_ioyLjY2SlZCSkoqGj5CUiow� );
            }
            else
            {
                fseek( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, -1, SEEK_CUR );
            }
            while ( ( $_obf_iY_HjI2IjIuOhpCIkoeVkIw� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 1 ) ) != chr( 0 ) )
            {
                $_obf_jJCKipSPlY6PiZOKjIaJiog� .= $_obf_iY_HjI2IjIuOhpCIkoeVkIw�;
            }
            $_obf_jIiHlIiLkIeMjIuRhoiNk4c� = implode( "", unpack( "L", $_obf_jIiHlIiLkIeMjIuRhoiNk4c�.chr( 0 ) ) );
            fseek( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, $_obf_jIiHlIiLkIeMjIuRhoiNk4c� );
            while ( ( $_obf_iY_HjI2IjIuOhpCIkoeVkIw� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 1 ) ) != chr( 0 ) )
            {
                $_obf_iZCKh4qVkZCJjI2PkYuQjYk� .= $_obf_iY_HjI2IjIuOhpCIkoeVkIw�;
            }
        }
        else
        {
            fseek( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, -1, SEEK_CUR );
            while ( ( $_obf_iY_HjI2IjIuOhpCIkoeVkIw� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 1 ) ) != chr( 0 ) )
            {
                $_obf_iZCKh4qVkZCJjI2PkYuQjYk� .= $_obf_iY_HjI2IjIuOhpCIkoeVkIw�;
            }
            $_obf_io6Sj4aOkI2Tk4uOjJGGjpU� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 1 );
            if ( $_obf_io6Sj4aOkI2Tk4uOjJGGjpU� == chr( 2 ) )
            {
                $_obf_ioyLjY2SlZCSkoqGj5CUiow� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 3 );
                if ( strlen( $_obf_ioyLjY2SlZCSkoqGj5CUiow� ) < 3 )
                {
                    fclose( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A� );
                    return "System Error";
                }
                $_obf_ioyLjY2SlZCSkoqGj5CUiow� = implode( "", unpack( "L", $_obf_ioyLjY2SlZCSkoqGj5CUiow�.chr( 0 ) ) );
                fseek( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, $_obf_ioyLjY2SlZCSkoqGj5CUiow� );
            }
            else
            {
                fseek( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, -1, SEEK_CUR );
            }
            while ( ( $_obf_iY_HjI2IjIuOhpCIkoeVkIw� = fread( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A�, 1 ) ) != chr( 0 ) )
            {
                $_obf_jJCKipSPlY6PiZOKjIaJiog� .= $_obf_iY_HjI2IjIuOhpCIkoeVkIw�;
            }
        }
        fclose( $_obf_kJWHjIaOiY6Gh5GTi42Oh5A� );
        if ( preg_match( "/http/i", $_obf_jJCKipSPlY6PiZOKjIaJiog� ) )
        {
            $_obf_jJCKipSPlY6PiZOKjIaJiog� = "";
        }
        $_obf_ko2JlJGPk4iPlIiIlYqKio8� = $_obf_iZCKh4qVkZCJjI2PkYuQjYk�." ".$_obf_jJCKipSPlY6PiZOKjIaJiog�;
        $_obf_ko2JlJGPk4iPlIiIlYqKio8� = preg_replace( "/CZ88\\.NET/is", "", $_obf_ko2JlJGPk4iPlIiIlYqKio8� );
        $_obf_ko2JlJGPk4iPlIiIlYqKio8� = preg_replace( "/^\\s*/is", "", $_obf_ko2JlJGPk4iPlIiIlYqKio8� );
        $_obf_ko2JlJGPk4iPlIiIlYqKio8� = preg_replace( "/\\s*\$/is", "", $_obf_ko2JlJGPk4iPlIiIlYqKio8� );
        if ( preg_match( "/http/i", $_obf_ko2JlJGPk4iPlIiIlYqKio8� ) || $_obf_ko2JlJGPk4iPlIiIlYqKio8� == "" )
        {
            $_obf_ko2JlJGPk4iPlIiIlYqKio8� = "Unknown";
        }
        return _obf_hpSOjImTiIuPiJKUjoaKjpA�( $_obf_ko2JlJGPk4iPlIiIlYqKio8�, "GBK", "UTF-8" );
    }
    else if ( _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_init" ) )
    {
        if ( $_obf_jY6MkIuIioqTk4eIiIiNj5U� == "255.255.255.255" )
        {
            return "当前使用IP138接口<br>建议使用纯真ip库：下载<a href=http://www.onlinedown.net/soft/19051.htm target=_blank>QQWry.Dat</a>改名为ip.dat上传到KSS根目录！";
        }
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = _obf_j5SMi5KSiouIj4iIipWIkIs�( "http://www.ip138.com/ips1388.asp?ip=".$_obf_jY6MkIuIioqTk4eIiIiNj5U�."&action=2", FALSE, 10 );
        if ( substr( $_obf_j4eSkIiSiZCRh4_NiYaQkYk�, 0, 7 ) == "curlerr" )
        {
            return substr( $_obf_j4eSkIiSiZCRh4_NiYaQkYk�, 8 );
        }
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = _obf_hpSOjImTiIuPiJKUjoaKjpA�( $_obf_j4eSkIiSiZCRh4_NiYaQkYk�, "GBK", "UTF-8" );
        $_obf_lY2VlYyLioeLlIyNiYqJkI4� = stripos( $_obf_j4eSkIiSiZCRh4_NiYaQkYk�, "<ul class=".YH2."ul1".YH2.">" );
        $_obf_iouUlJKTj5SIhoaUj4qVkYw� = stripos( $_obf_j4eSkIiSiZCRh4_NiYaQkYk�, "</ul>", $_obf_lY2VlYyLioeLlIyNiYqJkI4� + 5 );
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = substr( $_obf_j4eSkIiSiZCRh4_NiYaQkYk�, $_obf_lY2VlYyLioeLlIyNiYqJkI4� + 20, $_obf_iouUlJKTj5SIhoaUj4qVkYw� - $_obf_lY2VlYyLioeLlIyNiYqJkI4� - 20 );
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = str_replace( "</li><li>", "<br>", $_obf_j4eSkIiSiZCRh4_NiYaQkYk� );
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = str_replace( "本站", "", $_obf_j4eSkIiSiZCRh4_NiYaQkYk� );
        return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
    }
    else
    {
        return "请将传纯真ip库<a href=http://www.onlinedown.net/soft/19051.htm target=_blank>QQWry.Dat</a>改名为ip.dat上传到根目录（favicon.ico所在目录）！";
    }
}

?>
