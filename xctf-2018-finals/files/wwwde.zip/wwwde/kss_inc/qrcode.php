<?php

error_reporting( E_ERROR );
require( "class_qrcode.php" );
$url = urldecode( $_GET['data'] );
QRcode::png( $url );
?>
