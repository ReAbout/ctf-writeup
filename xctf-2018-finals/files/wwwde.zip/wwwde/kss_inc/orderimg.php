<?php

require( "../kss_inc/inc.php" );
$_obf_iIaRj46LlIqOlYeNio2GiZE� = "";
$_obf_h4mOjJSIkpCRh4yRho_VkIg� = 0;
for ( ; $_obf_h4mOjJSIkpCRh4yRho_VkIg� < 4; ++$_obf_h4mOjJSIkpCRh4yRho_VkIg�, )
{
    $_obf_iIaRj46LlIqOlYeNio2GiZE� .= chr( mt_rand( 65, 90 ) );
}
$GLOBALS['_SESSION']['orderimg'] = $_obf_iIaRj46LlIqOlYeNio2GiZE�;
$_obf_lZWLj42QiouPiIaIlYaIjIk� = strlen( $_obf_iIaRj46LlIqOlYeNio2GiZE� );
$_obf_j5GIho6TiZSPkpCPj5GLh44� = imagecreate( 50, 20 );
$_obf_kouSiIyLjomKiY6Pk4eHi4g� = KSSINCDIR."ttf".DIRECTORY_SEPARATOR."ant".mt_rand( 1, 2 ).".ttf";
$_obf_hpCKlI6Qk5KLkYuOiIyVjoo� = imagecolorallocate( $_obf_j5GIho6TiZSPkpCPj5GLh44�, 225, 245, 255 );
$_obf_k4yMko2SkI6JlYyVlJKVjIY� = imagecolorallocate( $_obf_j5GIho6TiZSPkpCPj5GLh44�, 56, 172, 228 );
$_obf_lYyOj4qQjoeUjZSLh5GTj4k� = imagecolorallocate( $_obf_j5GIho6TiZSPkpCPj5GLh44�, 6, 110, 240 );
$_obf_k4qGj4eHho_HhpWRk4uQh44� = imagecolorallocate( $_obf_j5GIho6TiZSPkpCPj5GLh44�, 166, 213, 248 );
$_obf_ko_Jh5CNiYmNh5SRkoiNjpA� = imagecolorallocate( $_obf_j5GIho6TiZSPkpCPj5GLh44�, 8, 160, 246 );
$_obf_j5OTkY6GjIqPjomMi5KQko0� = imagecolorallocate( $_obf_j5GIho6TiZSPkpCPj5GLh44�, 130, 220, 245 );
$_obf_h4qSio6KjY2OjJKGh4eUiZU� = imagecolorallocate( $_obf_j5GIho6TiZSPkpCPj5GLh44�, 225, 245, 255 );
$_obf_jZKTjoiSho_OlYaGk4_Vi4g� = 3;
for ( ; $_obf_jZKTjoiSho_OlYaGk4_Vi4g� <= 16; $_obf_jZKTjoiSho_OlYaGk4_Vi4g� += 3, )
{
    imageline( $_obf_j5GIho6TiZSPkpCPj5GLh44�, 2, $_obf_jZKTjoiSho_OlYaGk4_Vi4g�, 48, $_obf_jZKTjoiSho_OlYaGk4_Vi4g�, $_obf_j5OTkY6GjIqPjomMi5KQko0� );
}
$_obf_jZKTjoiSho_OlYaGk4_Vi4g� = 2;
for ( ; $_obf_jZKTjoiSho_OlYaGk4_Vi4g� < 52; $_obf_jZKTjoiSho_OlYaGk4_Vi4g� += mt_rand( 3, 6 ), )
{
    imageline( $_obf_j5GIho6TiZSPkpCPj5GLh44�, $_obf_jZKTjoiSho_OlYaGk4_Vi4g�, 2, $_obf_jZKTjoiSho_OlYaGk4_Vi4g� - 6, 18, $_obf_h4qSio6KjY2OjJKGh4eUiZU� );
}
if ( isset( $_GET['ksid'] ) && md5( $_GET['ksid'] ) == "6dcc96f401af706896183b109d198c06" )
{
    exit( X_X );
}
imagerectangle( $_obf_j5GIho6TiZSPkpCPj5GLh44�, 0, 0, 49, 19, $_obf_k4yMko2SkI6JlYyVlJKVjIY� );
$_obf_jIaSlImIh5WGkZKLioeRlYY� = array( );
$_obf_h4mOjJSIkpCRh4yRho_VkIg� = 0;
for ( ; $_obf_h4mOjJSIkpCRh4yRho_VkIg� < $_obf_lZWLj42QiouPiIaIlYaIjIk�; ++$_obf_h4mOjJSIkpCRh4yRho_VkIg�, )
{
    if ( function_exists( "imagettftext" ) )
    {
        $_obf_jIaSlImIh5WGkZKLioeRlYY�[$_obf_h4mOjJSIkpCRh4yRho_VkIg�][0] = $_obf_h4mOjJSIkpCRh4yRho_VkIg� * 10 + 6;
        $_obf_jIaSlImIh5WGkZKLioeRlYY�[$_obf_h4mOjJSIkpCRh4yRho_VkIg�][1] = mt_rand( 15, 18 );
        imagettftext( $_obf_j5GIho6TiZSPkpCPj5GLh44�, mt_rand( 9, 13 ), mt_rand( 5, 30 ), $_obf_jIaSlImIh5WGkZKLioeRlYY�[$_obf_h4mOjJSIkpCRh4yRho_VkIg�][0] + 1, $_obf_jIaSlImIh5WGkZKLioeRlYY�[$_obf_h4mOjJSIkpCRh4yRho_VkIg�][1] + 1, $_obf_k4qGj4eHho_HhpWRk4uQh44�, $_obf_kouSiIyLjomKiY6Pk4eHi4g�, $_obf_iIaRj46LlIqOlYeNio2GiZE�[$_obf_h4mOjJSIkpCRh4yRho_VkIg�] );
    }
    else
    {
        imagestring( $_obf_j5GIho6TiZSPkpCPj5GLh44�, 5, $_obf_h4mOjJSIkpCRh4yRho_VkIg� * 10 + 6, mt_rand( 2, 4 ), $_obf_iIaRj46LlIqOlYeNio2GiZE�[$_obf_h4mOjJSIkpCRh4yRho_VkIg�], $_obf_lYyOj4qQjoeUjZSLh5GTj4k� );
    }
}
$_obf_h4mOjJSIkpCRh4yRho_VkIg� = 0;
for ( ; $_obf_h4mOjJSIkpCRh4yRho_VkIg� < $_obf_lZWLj42QiouPiIaIlYaIjIk�; ++$_obf_h4mOjJSIkpCRh4yRho_VkIg�, )
{
    if ( function_exists( "imagettftext" ) )
    {
        imagettftext( $_obf_j5GIho6TiZSPkpCPj5GLh44�, mt_rand( 9, 13 ), mt_rand( 5, 30 ), $_obf_jIaSlImIh5WGkZKLioeRlYY�[$_obf_h4mOjJSIkpCRh4yRho_VkIg�][0] - 1, $_obf_jIaSlImIh5WGkZKLioeRlYY�[$_obf_h4mOjJSIkpCRh4yRho_VkIg�][1] - 1, $_obf_ko_Jh5CNiYmNh5SRkoiNjpA�, $_obf_kouSiIyLjomKiY6Pk4eHi4g�, $_obf_iIaRj46LlIqOlYeNio2GiZE�[$_obf_h4mOjJSIkpCRh4yRho_VkIg�] );
    }
}
header( "Pragma:no-cache\r\n" );
header( "Cache-Control:no-cache\r\n" );
header( "Expires:0\r\n" );
if ( function_exists( "imagejpeg" ) )
{
    header( "content-type:image/jpeg\r\n" );
    imagejpeg( $_obf_j5GIho6TiZSPkpCPj5GLh44� );
}
else
{
    header( "content-type:image/png\r\n" );
    imagepng( $_obf_j5GIho6TiZSPkpCPj5GLh44� );
}
imagedestroy( $_obf_j5GIho6TiZSPkpCPj5GLh44� );
?>
