<?php

function _obf_k4qTkYmKjpWRh42TlIeVlIo�( )
{
    global $_obf_mGKRY4dMuU6bZZJfh1_TX5k�;
    global $_obf_kJCSj4qIjZCUjZSQlYuKi4s�;
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    global $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�;
    global $_obf_j42OiJORiY6OjYuMkY2Lj4k�;
    global $_obf_h5KGh42MlI2Ij5WRjI6Nh48�;
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k�, 1 );
    $_obf_joyJlIaJkoePkYqNk4iVjIY� = $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_kJCSj4qIjZCUjZSQlYuKi4s�, 0 );
    echo "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890";
    if ( $_obf_joyJlIaJkoePkYqNk4iVjIY� == "success" )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "↓↓↓↓↓↓↓↓↓↓↓连接备用服务器".$_obf_kJCSj4qIjZCUjZSQlYuKi4s�['dbhost']."数据库".$_obf_kJCSj4qIjZCUjZSQlYuKi4s�['dbname']."成功" );
    }
    else
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "↑↑↑↑↑↑↑↑↑↑↑连接备用数据库".$_obf_kJCSj4qIjZCUjZSQlYuKi4s�['dbhost']."数据库".$_obf_kJCSj4qIjZCUjZSQlYuKi4s�['dbname']."失败,".SYNCTIME."秒后自动重试" );
        exit( );
    }
    $_obf_iouNho2VkZGNi4qGhoiLiJA� = array( );
    $_obf_hoqLk5OLlIuMkIuRk5CNlJA� = $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql_active` order by id asc" );
    if ( !empty( $_obf_hoqLk5OLlIuMkIuRk5CNlJA� ) )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "开始处理kss_tb_sql_active表" );
        $_obf_kpWKiI2Jj5SGipKVkI_OjY8� = 0;
        foreach ( $_obf_hoqLk5OLlIuMkIuRk5CNlJA� as $_obf_lJCSkoeMho2PlJOLiouJj4Y� )
        {
            _obf_kZWOkouLho6Uko2OjIqMjI0�( );
            $_obf_kpWKiI2Jj5SGipKVkI_OjY8� = $_obf_lJCSkoeMho2PlJOLiouJj4Y�['id'];
            $_obf_j5KIipONlJSQiYmTiYeVlYk� = "kss_z_user_".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['tbname'];
            $_obf_jo6SlY_VkouJhoqGio2IiZI� = "kss_z_key_".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['tbname'];
            $_obf_i4yKj4eSi4mRkIqSkY6Piok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from ".$_obf_j5KIipONlJSQiYmTiYeVlYk�." where `username`='".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."'" );
            if ( empty( $_obf_i4yKj4eSi4mRkIqSkY6Piok� ) )
            {
                $_obf_joaVlZWPkYeKi5WTiZWVkYw� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from ".$_obf_jo6SlY_VkouJhoqGio2IiZI�." where `keys`='".substr( $_obf_lJCSkoeMho2PlJOLiouJj4Y�['username'], 4, 6 )."' and `keyfix`='".substr( $_obf_lJCSkoeMho2PlJOLiouJj4Y�['username'], 0, 4 )."'" );
                if ( empty( $_obf_joaVlZWPkYeKi5WTiZWVkYw� ) )
                {
                    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "delete from ".$_obf_j5KIipONlJSQiYmTiYeVlYk�." where `username`='".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."'";
                    $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                        2
                    );
                    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "主服未找到注册卡".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."，删除备服用户" );
                    continue;
                }
                else
                {
                    if ( $_obf_joaVlZWPkYeKi5WTiZWVkYw�['islock'] != 0 )
                    {
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update ".$_obf_j5KIipONlJSQiYmTiYeVlYk�." set islock=".$_obf_joaVlZWPkYeKi5WTiZWVkYw�['islock']." where `username`='".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."'";
                        $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                            2
                        );
                        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "主服注册卡用户被锁定".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."，锁定备服注册卡用户" );
                        continue;
                    }
                    if ( $_obf_joaVlZWPkYeKi5WTiZWVkYw�['isback'] != 0 )
                    {
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "delete from ".$_obf_j5KIipONlJSQiYmTiYeVlYk�." where `username`='".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."'";
                        $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                            $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                            2
                        );
                        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "主服注册卡退款".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."，删除备服注册卡用户" );
                        continue;
                    }
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k� = array( );
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['username'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['keyfix'].$_obf_joaVlZWPkYeKi5WTiZWVkYw�['keys'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['password'] = substr( $_obf_joaVlZWPkYeKi5WTiZWVkYw�['keyspassword'], 0, 10 );
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['password2'] = substr( $_obf_joaVlZWPkYeKi5WTiZWVkYw�['keyspassword'], 10 );
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['addtime'] = $_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['starttime'] = $_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['managerid'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['managerid'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cday'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['cday'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['points'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['points'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['tag'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['tag'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['linknum'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['linknum'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['keyextattr'] = $_obf_joaVlZWPkYeKi5WTiZWVkYw�['keyextattr'];
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['endtime'] = $_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'] + $_obf_joaVlZWPkYeKi5WTiZWVkYw�['cday'] * 86400;
                    $_obf_j42HkJGSkI6UhoaJlYuVk4k�['cztimes'] = 1;
                    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSVjoiHkoeTlJSRiJGHiI0�( $_obf_j5KIipONlJSQiYmTiYeVlYk�, $_obf_j42HkJGSkI6UhoaJlYuVk4k�, "sql" );
                    $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                        1
                    );
                    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update `".$_obf_jo6SlY_VkouJhoqGio2IiZI�."` set cztime=".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'].",czusername='".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username']."' where `keys`='".$_obf_joaVlZWPkYeKi5WTiZWVkYw�['keys']."'";
                    $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                        $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                        1
                    );
                }
            }
            else
            {
                if ( $_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'] < $_obf_i4yKj4eSi4mRkIqSkY6Piok�['starttime'] )
                {
                    $_obf_kZGIi4yVio2Nh5CNkJOHiY8� = $_obf_lJCSkoeMho2PlJOLiouJj4Y�['starttime'];
                    $_obf_ipKHlZGViZOSkZOMho2ViZM� = 1;
                    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "备服先激活".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username'] );
                }
                else
                {
                    $_obf_kZGIi4yVio2Nh5CNkJOHiY8� = $_obf_i4yKj4eSi4mRkIqSkY6Piok�['starttime'];
                    $_obf_ipKHlZGViZOSkZOMho2ViZM� = 2;
                    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "主服先激活".$_obf_lJCSkoeMho2PlJOLiouJj4Y�['username'] );
                }
                $_obf_kY_HiJOShpCTioiIiJWLho4� = $_obf_kZGIi4yVio2Nh5CNkJOHiY8� + $_obf_i4yKj4eSi4mRkIqSkY6Piok�['cday'] * 86400;
                $_obf_i4qPjo_Oj5GJiIyIi4qKh5U� = "update `".$_obf_j5KIipONlJSQiYmTiYeVlYk�."` set cday='".$_obf_i4yKj4eSi4mRkIqSkY6Piok�['cday']."', starttime=".$_obf_kZGIi4yVio2Nh5CNkJOHiY8�.", endtime=".$_obf_kY_HiJOShpCTioiIiJWLho4�." where `username`='".$_obf_i4yKj4eSi4mRkIqSkY6Piok�['username']."'";
                $_obf_iouNho2VkZGNi4qGhoiLiJA�[] = array(
                    $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�,
                    $_obf_ipKHlZGViZOSkZOMho2ViZM�
                );
            }
        }
        $_obf_k5OTjZSSlY6PiY6LhoyUh5M� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_komUlJONiIqQk42JjYmOioY�( "kss_tb_sql" );
        foreach ( $_obf_iouNho2VkZGNi4qGhoiLiJA� as $_obf_jYqGj4aRj4_TiY_Mk4qUipA� )
        {
            $_obf_kI6TlIiSlYaMjpKQi4eHj5A� = "insert into `kss_tb_sql` (`addtime`,`sqltext`,`isact`) VALUES(".time( ).",'".mysql_real_escape_string( $_obf_jYqGj4aRj4_TiY_Mk4qUipA�[0] )."',".$_obf_jYqGj4aRj4_TiY_Mk4qUipA�[1].")";
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kI6TlIiSlYaMjpKQi4eHj5A�, "notsync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "repair table kss_tb_sql", "notsync" );
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kI6TlIiSlYaMjpKQi4eHj5A�, "notsync" );
                if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
                {
                    $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql where id>".$_obf_k5OTjZSSlY6PiY6LhoyUh5M�." and isact>0", "notsync" );
                    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "录入临时数据时出错".$_obf_jYqGj4aRj4_TiY_Mk4qUipA�[0] );
                    exit( );
                }
            }
        }
        $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_sql_active` where id<".( $_obf_kpWKiI2Jj5SGipKVkI_OjY8� + 1 ), "notsync" );
        unset( $_obf_hoqLk5OLlIuMkIuRk5CNlJA� );
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "kss_tb_sql_active表处理完成" );
    }
    else
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "备服kss_tb_sql_active表无数据" );
    }
    $_obf_kpOIlIaOkoiHiZCOkpWUlZM� = "";
    $_obf_iYqQh5CQkpGIkI6JjpWRk4w� = $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql_points` order by id asc" );
    if ( !empty( $_obf_iYqQh5CQkpGIkI6JjpWRk4w� ) )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "开始处理kss_tb_sql_points表" );
        $_obf_kpWKiI2Jj5SGipKVkI_OjY8� = 0;
        $_obf_hpWVj5COj5KSh5GHkoqIk4g� = array( );
        foreach ( $_obf_iYqQh5CQkpGIkI6JjpWRk4w� as $_obf_jZWHko2GjY6MkI2QlYqJiIc� )
        {
            _obf_kZWOkouLho6Uko2OjIqMjI0�( );
            $_obf_kpWKiI2Jj5SGipKVkI_OjY8� = $_obf_jZWHko2GjY6MkI2QlYqJiIc�['id'];
            if ( isset( $_obf_hpWVj5COj5KSh5GHkoqIk4g�[$_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'].$_obf_jZWHko2GjY6MkI2QlYqJiIc�['username']] ) )
            {
                $_obf_hpWVj5COj5KSh5GHkoqIk4g�[$_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'].$_obf_jZWHko2GjY6MkI2QlYqJiIc�['username']] = array(
                    $_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'],
                    $_obf_jZWHko2GjY6MkI2QlYqJiIc�['username'],
                    $_obf_hpWVj5COj5KSh5GHkoqIk4g�[$_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'].$_obf_jZWHko2GjY6MkI2QlYqJiIc�['username']][2] + $_obf_jZWHko2GjY6MkI2QlYqJiIc�['points']
                );
            }
            else
            {
                $_obf_hpWVj5COj5KSh5GHkoqIk4g�[$_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'].$_obf_jZWHko2GjY6MkI2QlYqJiIc�['username']] = array(
                    $_obf_jZWHko2GjY6MkI2QlYqJiIc�['tbname'],
                    $_obf_jZWHko2GjY6MkI2QlYqJiIc�['username'],
                    $_obf_jZWHko2GjY6MkI2QlYqJiIc�['points']
                );
            }
        }
        unset( $_obf_iYqQh5CQkpGIkI6JjpWRk4w� );
        $_obf_kpOIlIaOkoiHiZCOkpWUlZM� = _obf_iI6QhpSTiJCJiI_KlYePlZI�( 24 );
        foreach ( $_obf_hpWVj5COj5KSh5GHkoqIk4g� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
        {
            $_obf_j42OiJORiY6OjYuMkY2Lj4k�[1] = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
            if ( $_obf_h5KGh42MlI2Ij5WRjI6Nh48� < _obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_j42OiJORiY6OjYuMkY2Lj4k� ) + 2000 )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql_points where guid='".$_obf_kpOIlIaOkoiHiZCOkpWUlZM�."'", "notsync" );
                _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "↑↑↑↑↑↑↑↑↑↑↑".$_obf_h5KGh42MlI2Ij5WRjI6Nh48�."秒[points]" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kJCHlYiNjJCQlJKQkZKSko0�( );
                $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_kJCHlYiNjJCQlJKQkZKSko0�( );
                exit( );
            }
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into kss_tb_sql_points (`addtime`,`tbname`,`username`,`points`,`guid`,`svrid`) values (".time( ).",'".$_obf_lYeSkY6Th5SOlYuHjZGVio8�[0]."','".$_obf_lYeSkY6Th5SOlYuHjZGVio8�[1]."',".$_obf_lYeSkY6Th5SOlYuHjZGVio8�[2].",'".$_obf_kpOIlIaOkoiHiZCOkpWUlZM�."',2)", "notsync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE kss_tb_sql_points", "notsync" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql_points where guid='".$_obf_kpOIlIaOkoiHiZCOkpWUlZM�."'", "notsync" );
                _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "录入kss_tb_sql_points临时数据时出错".$_obf_h4aUkomQiI6JlIaSkomSkok� );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kJCHlYiNjJCQlJKQkZKSko0�( );
                $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_kJCHlYiNjJCQlJKQkZKSko0�( );
                exit( );
            }
        }
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_sql_points` where id<".( $_obf_kpWKiI2Jj5SGipKVkI_OjY8� + 1 ), "notsync" );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
        {
            $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
            $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE kss_tb_sql_points", "notsync" );
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql_points where guid='".$_obf_kpOIlIaOkoiHiZCOkpWUlZM�."'", "notsync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE kss_tb_sql_points", "notsync" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql_points where guid='".$_obf_kpOIlIaOkoiHiZCOkpWUlZM�."'", "notsync" );
            }
            _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "删除备服已获取的点数记录时发生错误".$_obf_h4aUkomQiI6JlIaSkomSkok� );
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kJCHlYiNjJCQlJKQkZKSko0�( );
            $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_kJCHlYiNjJCQlJKQkZKSko0�( );
            exit( );
        }
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "kss_tb_sql_points表处理完成" );
    }
    else
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "kss_tb_sql_points表无数据" );
    }
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "开始同步kss_tb_sql表" );
    $_obf_k5WGko2Ik5CIjpOGkY6Oj5I� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select count(*) as tnum from `kss_tb_sql` " );
    if ( $_obf_k5WGko2Ik5CIjpOGkY6Oj5I�['tnum'] == 0 )
    {
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "↑↑↑↑↑↑↑↑↑↑↑未发现待同步数据" );
        exit( );
    }
    $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql` order by id asc limit 0,500 ", 1, 1 );
    while ( !empty( $_obf_iYeIjIaVlYaIj4yTiJWHk40� ) )
    {
        foreach ( $_obf_iYeIjIaVlYaIj4yTiJWHk40� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
        {
            _obf_kZWOkouLho6Uko2OjIqMjI0�( );
            if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['isact'] == 1 )
            {
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['sqltext'] );
            }
            else
            {
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['sqltext'] );
            }
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� !== FALSE )
            {
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from `kss_tb_sql` where `id`=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'], "notsync" );
            }
            else
            {
                if ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['isact'] == 1 )
                {
                    $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                }
                else
                {
                    $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                }
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_config SET `sync_state`=`sync_state`+1 where id=1", "notsync" );
                _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "↑↑↑↑↑↑↑↑↑↑↑同步到日志ID=".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']."时出错！".$_obf_h4aUkomQiI6JlIaSkomSkok�."\t".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['sqltext'] );
                exit( );
            }
        }
        unset( $_obf_iYeIjIaVlYaIj4yTiJWHk40� );
        $_obf_iYeIjIaVlYaIj4yTiJWHk40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from `kss_tb_sql` order by id asc limit 0,500", 1, 1 );
    }
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "kss_tb_sql表同步完成" );
    if ( $_obf_kpOIlIaOkoiHiZCOkpWUlZM� != "" )
    {
        $_obf_lImGjo2PjY2JipKKjZWRhoo� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "select * from kss_tb_sql_points where guid='".$_obf_kpOIlIaOkoiHiZCOkpWUlZM�."' " );
        foreach ( $_obf_lImGjo2PjY2JipKKjZWRhoo� as $_obf_h42JlZWMkJGTiZOQj4qOkoc� )
        {
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_h42JlZWMkJGTiZOQj4qOkoc�['tbname']." set points=points-".$_obf_h42JlZWMkJGTiZOQj4qOkoc�['points']." where `username`='".$_obf_h42JlZWMkJGTiZOQj4qOkoc�['username']."'", "notsync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "更新主服点数时出错".$_obf_h4aUkomQiI6JlIaSkomSkok� );
                exit( );
            }
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "delete from kss_tb_sql_points where id=".$_obf_h42JlZWMkJGTiZOQj4qOkoc�['id'], "notsync" );
        }
        _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "点数处理完成" );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_config SET `sync_state`=0 where id=1", "notsync" );
    _obf_lJSMlYuJk5SMkI_KiI_RiIk�( "↑↑↑↑↑↑↑↑↑↑↑所有待同步数据同步完成，本次共同步".$_obf_k5WGko2Ik5CIjpOGkY6Oj5I�['tnum']."条SQL语句" );
    $_obf_ho_Ik5KOh5KVh4eGlJCNjpM�->_obf_kJCHlYiNjJCQlJKQkZKSko0�( );
    exit( );
}

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
?>
