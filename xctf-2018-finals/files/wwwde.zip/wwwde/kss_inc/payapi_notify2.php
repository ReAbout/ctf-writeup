<?php

function _obf_io_HhpSGjI6IlZKJioqUhpI�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_hoyMkoeOj42QioaSioaKi4g�, $_obf_i5OJk5CSj4iKhpOJkJKTjpU� = 1 )
{
    if ( defined( "SAE_MYSQL_USER" ) || DEBUGPAYWG == 0 )
    {
        return FALSE;
    }
    $_obf_jpKUipCPlZSHlYuJjYaUlZE� = KSSLOGDIR."saledebug1_log.php";
    if ( $_obf_i5OJk5CSj4iKhpOJkJKTjpU� == 1 )
    {
        @file_put_contents( $_obf_jpKUipCPlZSHlYuJjYaUlZE�, $_obf_hoyMkoeOj42QioaSioaKi4g�."\r\n", FILE_APPEND );
    }
    else if ( !is_file( $_obf_jpKUipCPlZSHlYuJjYaUlZE� ) && 262144 < filesize( $_obf_jpKUipCPlZSHlYuJjYaUlZE� ) )
    {
        $_obf_ipWMho2NlI2MiI_MioeTlZI� = "?";
        $_obf_ipCIiZCRiYmKhpOSi4eSjZI� = "<".$_obf_ipWMho2NlI2MiI_MioeTlZI�."php exit('Access denied to view this page!');".$_obf_ipWMho2NlI2MiI_MioeTlZI�.">\r\n";
        @file_put_contents( $_obf_jpKUipCPlZSHlYuJjYaUlZE�, $_obf_ipCIiZCRiYmKhpOSi4eSjZI�."\r\n\r\n\r\n时间:".@date( "Y-m-d H:i:s" )."\r\n订单号:".$_obf_iJWMjIiVi5OGjJOViY2Li48�."\r\n状态:".$_obf_hoyMkoeOj42QioaSioaKi4g�."\r\n" );
    }
    else
    {
        @file_put_contents( $_obf_jpKUipCPlZSHlYuJjYaUlZE�, "\r\n\r\n\r\n时间:".@date( "Y-m-d H:i:s" )."\r\n订单号:".$_obf_iJWMjIiVi5OGjJOViY2Li48�."\r\n状态:".$_obf_hoyMkoeOj42QioaSioaKi4g�."\r\n", FILE_APPEND );
    }
}

if ( isset( $_POST['wxtest'] ) )
{
    $GLOBALS['GLOBALS']['HTTP_RAW_POST_DATA'] = $_POST['wxtest'];
}
if ( !isset( $_obf_k5OUk5WOk5KVlIaLlYmRh5I� ) )
{
    include( "inc.php" );
}
$_obf_jo_MipCRkYuSk4mSko2RkIg� = array( "ali" => "支付宝", "ten" => "财付通", "chinabank" => "网银在线", "e138" => "易付通", "jqr" => "支付宝机器人", "wx" => "微信扫描" );
$_obf_iZSViY2KjJSNjoePh4yOjI4� = array( "ali" => "success", "ten" => "success", "chinabank" => "ok", "e138" => "success", "jqr" => "success", "wx" => "success" );
$_obf_k4iNkYmOkpOVjJCHkIqUj4k� = array( "ali" => "fail", "ten" => "fail", "chinabank" => "error", "e138" => "fail", "jqr" => "fail", "wx" => "fail" );
$_obf_k5OQh4iJjoyPjJSMjpSOlZA� = array( "WAIT_BUYER_PAY", "WAIT_SELLER_SEND_GOODS", "WAIT_BUYER_CONFIRM_GOODS", "TRADE_FINISHED", "TRADE_SUCCESS", "SUCCESS", "FAIL" );
$_obf_kYyPkY_PkJKVh4qGjJGIio4� = "ali";
if ( isset( $_GET['alipayjqr'] ) )
{
    $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "jqr";
}
if ( isset( $_GET['transaction_id'] ) )
{
    $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "ten";
}
if ( isset( $_POST['v_oid'] ) )
{
    $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "chinabank";
}
if ( isset( $_GET['AttachString'] ) && $_GET['AttachString'] == "e138" )
{
    $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "e138";
}
if ( isset( $GLOBALS['HTTP_RAW_POST_DATA'] ) && substr( $GLOBALS['HTTP_RAW_POST_DATA'], 0, 5 ) == "<xml>" )
{
    $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "wx";
}
if ( !isset( $_GET['alipayjqr'] ) )
{
    include( $_obf_kYyPkY_PkJKVh4qGjJGIio4�."pay_function.php" );
}
if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
{
    $_obf_kpGPh4mNh46SkZONh4eLlJU� = "";
    $_obf_h5WSiIeGkYiNk4iJjYuHkJA� = $GLOBALS['HTTP_RAW_POST_DATA'];
    $_obf_ho6Nh5WMj4mLh5WTh4aTkok� = _obf_komQkZGUhomRk4eLipOSkJM�( $_obf_h5WSiIeGkYiNk4iJjYuHkJA� );
    if ( !array_key_exists( "return_code", $_obf_ho6Nh5WMj4mLh5WTh4aTkok� ) || !array_key_exists( "result_code", $_obf_ho6Nh5WMj4mLh5WTh4aTkok� ) )
    {
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( "未知", "GLOBALS:".$_obf_h5WSiIeGkYiNk4iJjYuHkJA�, 0 );
        exit( "<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[发送来的数据异常]]></return_msg></xml>" );
    }
    $_obf_iJWMjIiVi5OGjJOViY2Li48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( $_obf_ho6Nh5WMj4mLh5WTh4aTkok�['out_trade_no'], "val", "sql", "" );
    $_obf_lZSLkIeSlIySkY6SlIuJio0� = _obf_i4mIkpOGkomKiouRhoaMh5I�( $_obf_ho6Nh5WMj4mLh5WTh4aTkok�['transaction_id'], "val", "sql", "" );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = _obf_i4mIkpOGkomKiouRhoaMh5I�( $_obf_ho6Nh5WMj4mLh5WTh4aTkok�['total_fee'], "val", "int", "" );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� /= 100;
    $_obf_i5CMioaGiI6ShomNiIuKjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( $_obf_ho6Nh5WMj4mLh5WTh4aTkok�['result_code'], "val", "sql", "" );
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ali" )
{
    $_obf_iJWMjIiVi5OGjJOViY2Li48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "out_trade_no", "pg", "sql", "" );
    $_obf_kpGPh4mNh46SkZONh4eLlJU� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_no", "pg", "sql", "" );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "total_fee", "pg", "sql", "" );
    $_obf_i5CMioaGiI6ShomNiIuKjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_status", "pg", "sql", "" );
    $_obf_j4mLiYmUj4aJiI6IjY6TjI0� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "buyer_email", "pg", "sql", "" );
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
{
    $_obf_kpGPh4mNh46SkZONh4eLlJU� = "";
    $_obf_iJWMjIiVi5OGjJOViY2Li48� = trim( $_GET['ordernum'] );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = trim( $_GET['rmb'] );
    $_obf_iImJjYmQjYyOjIuVkIuMjIs� = trim( $_GET['sign'] );
    $_obf_i5CMioaGiI6ShomNiIuKjJE� = "TRADE_SUCCESS";
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ten" )
{
    $_obf_hpKNkIaShoaKkY6Lk4qVk5U� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_mode", "gp", "int", 0 );
    $_obf_iJWMjIiVi5OGjJOViY2Li48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "out_trade_no", "gp", "sql", "" );
    $_obf_kpGPh4mNh46SkZONh4eLlJU� = "";
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "total_fee", "gp", "sql", "" );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� /= 100;
    $_obf_i5CMioaGiI6ShomNiIuKjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_state", "gp", "sql", "" );
    if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "0" )
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "TRADE_FINISHED";
    }
    else
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "WAIT_BUYER_PAY";
    }
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "chinabank" )
{
    $_obf_kpGPh4mNh46SkZONh4eLlJU� = "";
    $_obf_k42NkY2RkoiNjJCKlZSKiIg� = trim( $_POST['v_oid'] );
    $_obf_iJWMjIiVi5OGjJOViY2Li48� = $_obf_k42NkY2RkoiNjJCKlZSKiIg�;
    $_obf_iIuQkYaUioqGlI6IjIuMiI8� = trim( $_POST['v_pstatus'] );
    $_obf_jpGJk5SSkJOIk4iQiI_OhpU� = trim( $_POST['v_amount'] );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = $_obf_jpGJk5SSkJOIk4iQiI_OhpU�;
    $_obf_hpCRlJCSjI6Ki5WSipCLkpQ� = trim( $_POST['v_moneytype'] );
    $_obf_lJSPjJCOi5CIiJSSkZWNh4Y� = trim( $_POST['remark1'] );
    $_obf_iImJjYmQjYyOjIuVkIuMjIs� = trim( $_POST['v_md5str'] );
    if ( $_obf_iIuQkYaUioqGlI6IjIuMiI8� == "20" )
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "TRADE_FINISHED";
    }
    else
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "WAIT_BUYER_PAY";
    }
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "e138" )
{
    $_obf_kpGPh4mNh46SkZONh4eLlJU� = "";
    $_obf_k42NkY2RkoiNjJCKlZSKiIg� = trim( $_GET['SerialNo'] );
    $_obf_iJWMjIiVi5OGjJOViY2Li48� = $_obf_k42NkY2RkoiNjJCKlZSKiIg�;
    $_obf_iIuQkYaUioqGlI6IjIuMiI8� = trim( $_GET['Status'] );
    $_obf_jpGJk5SSkJOIk4iQiI_OhpU� = trim( $_GET['Money'] );
    $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = $_obf_jpGJk5SSkJOIk4iQiI_OhpU�;
    $_obf_iImJjYmQjYyOjIuVkIuMjIs� = trim( $_GET['VerifyString'] );
    if ( $_obf_iIuQkYaUioqGlI6IjIuMiI8� == "2" )
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "TRADE_FINISHED";
    }
    else
    {
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "WAIT_BUYER_PAY";
    }
}
else
{
    exit( "errwg" );
}
_obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_i5CMioaGiI6ShomNiIuKjJE�, 0 );
$_obf_k42GiI_RiIqKjIaUio6IiIw� = "POSTDATA:";
foreach ( $GLOBALS['_POST'] as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
{
    $_obf_k42GiI_RiIqKjIaUio6IiIw� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".urlencode( $_obf_lYeSkY6Th5SOlYuHjZGVio8� )."&";
}
_obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_k42GiI_RiIqKjIaUio6IiIw� );
$_obf_lYuTjYmGkJWKk5WOjoeGlYw� = "GETDATA:";
foreach ( $GLOBALS['_GET'] as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
{
    $_obf_lYuTjYmGkJWKk5WOjoeGlYw� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".urlencode( $_obf_lYeSkY6Th5SOlYuHjZGVio8� )."&";
}
_obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_lYuTjYmGkJWKk5WOjoeGlYw� );
if ( !in_array( $_obf_i5CMioaGiI6ShomNiIuKjJE�, $_obf_k5OQh4iJjoyPjJSMjpSOlZA� ) )
{
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success，状态码".$_obf_i5CMioaGiI6ShomNiIuKjJE�."非法，不再通知" );
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
    {
        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[状态码未找到]]></return_msg></xml>" );
    }
    exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
}
$_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
$_obf_lZGQj4iOj4mTlZGNjZGUj5E� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select A.*,B.softname,B.mailtext from kss_tb_order as A left join kss_tb_soft as B on A.softid=B.id where A.ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'" );
if ( empty( $_obf_lZGQj4iOj4mTlZGNjZGUj5E� ) )
{
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success，订单未找到，不再通知" );
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
    {
        exit( "fail:Order_not_find" );
    }
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
    {
        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[订单未找到]]></return_msg></xml>" );
    }
    exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
}
_obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "订单找到" );
if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['orderamount'] != $_obf_lIuQk5OGjpKVjY6UiI_QjJM� )
{
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success，订单金额不符，不再通知" );
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
    {
        exit( "fail:Order_rmb" );
    }
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
    {
        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[订单金额不符]]></return_msg></xml>" );
    }
    exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
}
$_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iIeMkYyJiZKTjI2UjImPi4Y�( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['managerid'] );
$_obf_kJCGiI6Nk4_RkYuGiZWSi5M� = explode( ",", $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['alipayset'] );
$_obf_i4yRjJOUiI2QjYiHkpGUi5M� = explode( ",", $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['wxpayset'] );
if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
{
    $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = _obf_kpWLkoyMhouPipCQiImKjZA�( $_obf_h5WSiIeGkYiNk4iJjYuHkJA�, $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['wxpaykey'] );
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ali" )
{
    $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = _obf_i4iVlY2UkouLj5KGlI2Uhoc�( $_obf_kJCGiI6Nk4_RkYuGiZWSi5M�[1], $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['alikey'] );
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ten" )
{
    if ( $_obf_hpKNkIaShoaKkY6Lk4qVk5U� != 1 )
    {
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success，非即时到帐交易" );
        exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
    }
    $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = _obf_jY6OlY_RlYqPjZSQh4uPkJQ�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['tenkey'] );
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
{
    if ( strtolower( md5( "ordernum=".$_obf_iJWMjIiVi5OGjJOViY2Li48�."&rmb=".$_obf_lIuQk5OGjpKVjY6UiI_QjJM�."&key=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['alikey'] ) ) != $_obf_iImJjYmQjYyOjIuVkIuMjIs� )
    {
        exit( "fail:URL_signerror" );
    }
    $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = TRUE;
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "chinabank" )
{
    $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = TRUE;
    if ( $_obf_iImJjYmQjYyOjIuVkIuMjIs� != strtoupper( md5( $_obf_k42NkY2RkoiNjJCKlZSKiIg�.$_obf_iIuQkYaUioqGlI6IjIuMiI8�.$_obf_jpGJk5SSkJOIk4iQiI_OhpU�.$_obf_hpCRlJCSjI6Ki5WSipCLkpQ�.$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['chinabankkey'] ) ) )
    {
        $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = FALSE;
    }
}
else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "e138" )
{
    $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = TRUE;
    if ( $_obf_iImJjYmQjYyOjIuVkIuMjIs� != strtolower( md5( "SerialNo=".$_obf_k42NkY2RkoiNjJCKlZSKiIg�."&UserID=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['e138set']."&Money=".$_obf_jpGJk5SSkJOIk4iQiI_OhpU�."&Status=".$_obf_iIuQkYaUioqGlI6IjIuMiI8�."&AttachString=e138&MerchantKey=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['e138key'] ) ) )
    {
        $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = FALSE;
    }
}
if ( $_obf_k4mJh5SPkY6Vh4qHjIaJh44� !== TRUE )
{
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
    {
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "校验微信发送来的XML数据:".$_obf_k4mJh5SPkY6Vh4qHjIaJh44�.",返回给微信服务器".$_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."，签名非法" );
        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[签名没通过]]></return_msg></xml>" );
    }
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "curl:".$_obf_k4mJh5SPkY6Vh4qHjIaJh44� );
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器".$_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."，签名非法" );
    exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
}
_obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "签名效验通过" );
if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
{
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $GLOBALS['HTTP_RAW_POST_DATA'] );
}
$_obf_iIeHlZWKipOJlIyVk42UjJM� = 0;
$_obf_lYuMkpWKjIaLjIuOlIaUio8� = "";
if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['aliorderno'] != $_obf_kpGPh4mNh46SkZONh4eLlJU� )
{
    $_obf_lYuMkpWKjIaLjIuOlIaUio8� = ",`aliorderno`='".$_obf_kpGPh4mNh46SkZONh4eLlJU�."'";
}
if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "WAIT_BUYER_PAY" )
{
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success" );
    if ( $_obf_lYuMkpWKjIaLjIuOlIaUio8� != "" )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_order SET `aliorderno`='".$_obf_kpGPh4mNh46SkZONh4eLlJU�."' where ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'", "sync" );
    }
    exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
}
if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "WAIT_SELLER_SEND_GOODS" )
{
    if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['orderstatus'] < 1 )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_order SET `orderstatus`=1".$_obf_lYuMkpWKjIaLjIuOlIaUio8�."  where ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'", "sync" );
    }
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ali" )
    {
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "alipay 自动发货" );
        $_obf_jomQlJOKjYaHko_SkZGKi4w� = _obf_koyJjYuOjZOSiZOUkYmKi40�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_kpGPh4mNh46SkZONh4eLlJU�, $_obf_kJCGiI6Nk4_RkYuGiZWSi5M�[1], $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['alikey'] );
        if ( function_exists( "curl_init" ) )
        {
            $_obf_iYuIkIeRlJCQiIqQh5WGjIg� = _obf_iYqMjJCPipKLjpSRioeUlYc�( $_obf_jomQlJOKjYaHko_SkZGKi4w� );
            $_obf_iJOJjo_KkY2PkYmSkY2JjJU� = stripos( $_obf_iYuIkIeRlJCQiIqQh5WGjIg�, "<is_success>T</is_success>" );
            if ( $_obf_iJOJjo_KkY2PkYmSkY2JjJU� !== FALSE && $_obf_iJOJjo_KkY2PkYmSkY2JjJU� < 70 )
            {
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "自动发货成功！" );
            }
            else
            {
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "自动发货失败！" );
            }
        }
        else
        {
            _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "不支持curl，未能自动发货！" );
        }
    }
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success" );
    exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
}
if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "WAIT_BUYER_CONFIRM_GOODS" )
{
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success" );
    if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['orderstatus'] < 2 )
    {
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_order SET `orderstatus`=2".$_obf_lYuMkpWKjIaLjIuOlIaUio8�."  where ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'", "sync" );
    }
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ali" )
    {
        $_obf_jpSRjpKGhpOOiIuHiI_UjYo� = explode( ",", $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['alipayset'] );
        if ( $_obf_jpSRjpKGhpOOiIuHiI_UjYo�[0] == "create_partner_trade_by_buyer" && $_obf_jpSRjpKGhpOOiIuHiI_UjYo�[2] == $_obf_j4mLiYmUj4aJiI6IjY6TjI0� )
        {
            $_obf_iIeHlZWKipOJlIyVk42UjJM� = 1;
            _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "使用特殊帐号的提卡交易，发货后就给代理充值！" );
        }
        else
        {
            exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
        }
    }
    else
    {
        exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
    }
}
if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "TRADE_FINISHED" || $_obf_i5CMioaGiI6ShomNiIuKjJE� == "TRADE_SUCCESS" || $_obf_iIeHlZWKipOJlIyVk42UjJM� == 1 || $_obf_i5CMioaGiI6ShomNiIuKjJE� == "SUCCESS" )
{
    if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['orderstatus'] < 8 )
    {
        $_obf_hpGMlZWJho_Pj5CNlJWUiJI� = 0;
        $_obf_joeIhoiOh5KLlY6GiI_Hh5M� = 0;
        $_obf_jZGIi4eRiJOGjJCKk42IjI8� = "";
        $_obf_hpKUj5GNh4aPlI2JhpSGlZE� = "";
        $_obf_i4yTlYaRiIeKjY6QjImVi5E� = "";
        $_obf_j4ePi5GUjJSIj4iTiJOVh40� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_keyset where id=".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['keygroupid'] );
        if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
        {
            $_obf_kYqLhouRj5GLipOGk4iPh4c� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_agentprice where `softid`=".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid']." and `keygroupid`=".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['keygroupid']." and `managerid`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id']." and `tmpkey`='no'" );
            $_obf_h5SKjZOQh4yGkoqGkYuUj4Y� = $_obf_kYqLhouRj5GLipOGk4iPh4c�['keyprice'];
            $_obf_hoiIjJOLhoyKjZONh4eLiZU� = $_obf_h5SKjZOQh4yGkoqGkYuUj4Y� * $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['keycount'];
            if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['touzhirmb'] + $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['rmb'] < $_obf_hoiIjJOLhoyKjZONh4eLiZU� )
            {
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "代理余额不足，不能扣款！" );
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                {
                    exit( "fail:level6_rmb_Not_enough" );
                }
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                {
                    exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[代理余额不足]]></return_msg></xml>" );
                }
                exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
            }
            $_obf_lJOGjpSRkI2NiJSIjpCKj5A� = _obf_iY6RiYaNio6PiIyIiZWJkJQ�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'], $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pmid'] );
            if ( !empty( $_obf_lJOGjpSRkI2NiJSIjpCKj5A� ) )
            {
                $_obf_hoaGiZOUjIyGk4eMjJCPio0� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_agentprice where `softid`=".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid']." and `keygroupid`=".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['keygroupid']." and `managerid`=".$_obf_lJOGjpSRkI2NiJSIjpCKj5A�['id']." and `tmpkey`='no'" );
                if ( empty( $_obf_hoaGiZOUjIyGk4eMjJCPio0� ) )
                {
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "上级总代理没有该注册卡销售权！" );
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                    {
                        exit( "fail:level7_key_Not_permission" );
                    }
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                    {
                        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[上级总代理没有该注册卡销售权]]></return_msg></xml>" );
                    }
                    exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
                }
                $_obf_jo_ThoyRjpCLkoqVkYeViJA� = $_obf_hoaGiZOUjIyGk4eMjJCPio0�['keyprice'];
                $_obf_hpGMlZWJho_Pj5CNlJWUiJI� = $_obf_jo_ThoyRjpCLkoqVkYeViJA� * $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['keycount'];
                if ( $_obf_lJOGjpSRkI2NiJSIjpCKj5A�['touzhirmb'] + $_obf_lJOGjpSRkI2NiJSIjpCKj5A�['rmb'] < $_obf_hpGMlZWJho_Pj5CNlJWUiJI� )
                {
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "上级总代理帐号余额不足，不能扣款！" );
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                    {
                        exit( "fail:level7_rmb_Not_enough" );
                    }
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                    {
                        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[上级代理余额不足]]></return_msg></xml>" );
                    }
                    exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
                }
            }
            $_obf_iYiHj4aUkoqOjZOHjZKMh4c� = _obf_iY6RiYaNio6PiIyIiZWJkJQ�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'] );
            if ( empty( $_obf_iYiHj4aUkoqOjZOHjZKMh4c� ) )
            {
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "上级作者帐号未找到！" );
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                {
                    exit( "fail:Not_find_level8" );
                }
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                {
                    exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[上级作者帐号未找到]]></return_msg></xml>" );
                }
                exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
            }
            if ( $_obf_iYiHj4aUkoqOjZOHjZKMh4c�['level'] == 8 )
            {
                $_obf_kYiSlYiLiZKKk4qHiIaIlYs� = _obf_iImThpCMlYmSjIeMi5GOlIg�( $_obf_j4ePi5GUjJSIj4iTiJOVh40�['cday'], $_obf_j4ePi5GUjJSIj4iTiJOVh40�['linknum'] );
                $_obf_joeIhoiOh5KLlY6GiI_Hh5M� = $_obf_kYiSlYiLiZKKk4qHiIaIlYs� * $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['keycount'];
                if ( $_obf_iYiHj4aUkoqOjZOHjZKMh4c�['touzhirmb'] + $_obf_iYiHj4aUkoqOjZOHjZKMh4c�['rmb'] < $_obf_joeIhoiOh5KLlY6GiI_Hh5M� )
                {
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "上级作者帐号余额不足，不能扣款！" );
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                    {
                        exit( "fail:level8_rmb_Not_enough" );
                    }
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                    {
                        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[上级作者帐号余额不足]]></return_msg></xml>" );
                    }
                    exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
                }
            }
        }
        else
        {
            if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 8 )
            {
                $_obf_iYiHj4aUkoqOjZOHjZKMh4c� = $_obf_lI6OiJSPjZWVi5GQhoiPjpU�;
                $_obf_kYiSlYiLiZKKk4qHiIaIlYs� = _obf_iImThpCMlYmSjIeMi5GOlIg�( $_obf_j4ePi5GUjJSIj4iTiJOVh40�['cday'], $_obf_j4ePi5GUjJSIj4iTiJOVh40�['linknum'] );
                $_obf_joeIhoiOh5KLlY6GiI_Hh5M� = $_obf_kYiSlYiLiZKKk4qHiIaIlYs� * $_obf_hpCPjIePioeHkYiIhpSPkok�;
                if ( $_obf_iYiHj4aUkoqOjZOHjZKMh4c�['touzhirmb'] + $_obf_iYiHj4aUkoqOjZOHjZKMh4c�['rmb'] < $_obf_joeIhoiOh5KLlY6GiI_Hh5M� )
                {
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "上级作者帐号余额不足，不能扣款！" );
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                    {
                        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[上级作者帐号余额不足]]></return_msg></xml>" );
                    }
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                    {
                        exit( "fail:level8_rmb_Not_enough" );
                    }
                    exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
                }
            }
        }
        $_obf_k5KJkIyVkZWKk4_NiJSQlIk� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_ho_Ljo6NjpOOhpGHj5KHiYs�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'] );
        if ( $_obf_k5KJkIyVkZWKk4_NiJSQlIk� !== TRUE )
        {
            _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "未能成功独占操作：".$_obf_k5KJkIyVkZWKk4_NiJSQlIk� );
            if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
            {
                exit( "retry:locktable error" );
            }
            if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
            {
                exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[未能成功独占操作]]></return_msg></xml>" );
            }
            exit( $_obf_k4iNkYmOkpOVjJCHkIqUj4k�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
        }
        if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 6 )
        {
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `kss_tb_log_agentrmb` (`pid`,`softid`,`managerid`,`opmanagerid`,`addtime`,`oldrmb`,`changermb`,`optype`,`ordernum`,`intro`) VALUES (".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'].",".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'].",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'].",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'].",".time( ).",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['rmb'].",".( 0 - $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['agentamount'] ).",1,'".$_obf_iJWMjIiVi5OGjJOViY2Li48�."','零售提卡')", "sync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE `kss_tb_log_agentrmb`", "notsync" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'] );
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "操作代理金额变动日志时出错[未扣款]！".$_obf_h4aUkomQiI6JlIaSkomSkok� );
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                {
                    exit( "fail:level6_editrmb_err" );
                }
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                {
                    exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[操作代理金额变动日志时出错]]></return_msg></xml>" );
                }
                exit( $_obf_k4iNkYmOkpOVjJCHkIqUj4k�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
            }
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set `rmb`=`rmb`-".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['agentamount'].",`xfrmb`=`xfrmb`+".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['agentamount']." where `id`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'], "sync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_agentrmb set `intro`='<font color=red>扣款失败</font>' where `ordernum`='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."' order by `id` Desc limit 0,1", "sync" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE `kss_tb_manager`", "notsync" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'] );
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "代理扣款操作失败！".$_obf_h4aUkomQiI6JlIaSkomSkok� );
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                {
                    exit( "fail:level6_editrmb_err" );
                }
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                {
                    exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[代理扣款操作失败]]></return_msg></xml>" );
                }
                exit( $_obf_k4iNkYmOkpOVjJCHkIqUj4k�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
            }
            $_obf_jZGIi4eRiJOGjJCKk42IjI8� = "代理款项已扣，";
            if ( !empty( $_obf_lJOGjpSRkI2NiJSIjpCKj5A� ) )
            {
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `kss_tb_log_agentrmb` (`pid`,`softid`,`managerid`,`opmanagerid`,`addtime`,`oldrmb`,`changermb`,`optype`,`ordernum`,`intro`) VALUES\r\n(".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'].",".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'].",".$_obf_lJOGjpSRkI2NiJSIjpCKj5A�['id'].",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'].",".time( ).",".$_obf_lJOGjpSRkI2NiJSIjpCKj5A�['rmb'].",".( 0 - $_obf_hpGMlZWJho_Pj5CNlJWUiJI� ).",1,'".$_obf_iJWMjIiVi5OGjJOViY2Li48�."','零售提卡')", "sync" );
                if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
                {
                    $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE `kss_tb_log_agentrmb`", "notsync" );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'] );
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_jZGIi4eRiJOGjJCKk42IjI8�."记录上级总代扣款日志失败，操作中断[总代未扣款]！".$_obf_h4aUkomQiI6JlIaSkomSkok� );
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                    {
                        exit( "fail:level7_writelog_editrmb_err" );
                    }
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                    {
                        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[记录上级总代扣款日志失败，操作中断]]></return_msg></xml>" );
                    }
                    exit( $_obf_k4iNkYmOkpOVjJCHkIqUj4k�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
                }
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set `rmb`=`rmb`-".$_obf_hpGMlZWJho_Pj5CNlJWUiJI�.",`xfrmb`=`xfrmb`+".$_obf_hpGMlZWJho_Pj5CNlJWUiJI�." where `id`=".$_obf_lJOGjpSRkI2NiJSIjpCKj5A�['id'], "sync" );
                if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
                {
                    $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_agentrmb set `intro`='<font color=red>扣款失败</font>' where `ordernum`='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."' order by `id` Desc limit 0,1", "sync" );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE `kss_tb_manager`", "notsync" );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'] );
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_jZGIi4eRiJOGjJCKk42IjI8�."上级总代理扣款操作失败，操作中断！".$_obf_h4aUkomQiI6JlIaSkomSkok� );
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                    {
                        exit( "fail:level7_editrmb_err" );
                    }
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                    {
                        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[上级总代理扣款操作失败，操作中断]]></return_msg></xml>" );
                    }
                    exit( $_obf_k4iNkYmOkpOVjJCHkIqUj4k�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
                }
                $_obf_hpKUj5GNh4aPlI2JhpSGlZE� = "总代理款项已扣，";
            }
            if ( $_obf_iYiHj4aUkoqOjZOHjZKMh4c�['level'] == 8 )
            {
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `kss_tb_log_agentrmb` (`pid`,`softid`,`managerid`,`opmanagerid`,`addtime`,`oldrmb`,`changermb`,`optype`,`ordernum`,`intro`) VALUES (".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'].",".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'].",".$_obf_iYiHj4aUkoqOjZOHjZKMh4c�['id'].",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'].",".time( ).",".$_obf_iYiHj4aUkoqOjZOHjZKMh4c�['rmb'].",".( 0 - $_obf_joeIhoiOh5KLlY6GiI_Hh5M� ).",1,'".$_obf_iJWMjIiVi5OGjJOViY2Li48�."','零售提卡')", "sync" );
                if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
                {
                    $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE `kss_tb_log_agentrmb`", "notsync" );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'] );
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_jZGIi4eRiJOGjJCKk42IjI8�.$_obf_hpKUj5GNh4aPlI2JhpSGlZE�."记录上级作者扣款日志失败，操作中断[作者未扣款]！".$_obf_h4aUkomQiI6JlIaSkomSkok� );
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                    {
                        exit( "fail:level8_writelog_editrmb_err" );
                    }
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                    {
                        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[记录上级作者扣款日志失败，操作中断]]></return_msg></xml>" );
                    }
                    exit( $_obf_k4iNkYmOkpOVjJCHkIqUj4k�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
                }
                $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set `rmb`=`rmb`-".$_obf_joeIhoiOh5KLlY6GiI_Hh5M�.",`xfrmb`=`xfrmb`+".$_obf_joeIhoiOh5KLlY6GiI_Hh5M�." where `id`=".$_obf_iYiHj4aUkoqOjZOHjZKMh4c�['id'], "sync" );
                if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
                {
                    $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_agentrmb set `intro`='<font color=red>扣款失败</font>' where `ordernum`='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."' order by `id` Desc limit 0,1", "sync" );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE `kss_tb_manager`", "notsync" );
                    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'] );
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_jZGIi4eRiJOGjJCKk42IjI8�.$_obf_hpKUj5GNh4aPlI2JhpSGlZE�."作者扣款操作失败，操作中断！".$_obf_h4aUkomQiI6JlIaSkomSkok� );
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                    {
                        exit( "fail:level8_editrmb_err" );
                    }
                    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                    {
                        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[作者扣款操作失败，操作中断]]></return_msg></xml>" );
                    }
                    exit( $_obf_k4iNkYmOkpOVjJCHkIqUj4k�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
                }
                $_obf_i4yTlYaRiIeKjY6QjImVi5E� = "作者款项已扣，";
            }
        }
        else if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 8 )
        {
            $_obf_iYiHj4aUkoqOjZOHjZKMh4c� = $_obf_lI6OiJSPjZWVi5GQhoiPjpU�;
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "insert into `kss_tb_log_agentrmb` (`pid`,`softid`,`managerid`,`opmanagerid`,`addtime`,`oldrmb`,`changermb`,`optype`,`ordernum`,`intro`) VALUES (".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid'].",".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'].",".$_obf_iYiHj4aUkoqOjZOHjZKMh4c�['id'].",".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'].",".time( ).",".$_obf_iYiHj4aUkoqOjZOHjZKMh4c�['rmb'].",".( 0 - $_obf_joeIhoiOh5KLlY6GiI_Hh5M� ).",1,'".$_obf_iJWMjIiVi5OGjJOViY2Li48�."','零售提卡')", "sync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE `kss_tb_log_agentrmb`", "notsync" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'] );
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_jZGIi4eRiJOGjJCKk42IjI8�.$_obf_hpKUj5GNh4aPlI2JhpSGlZE�."记录作者扣款日志失败，操作中断[作者未扣款]！".$_obf_h4aUkomQiI6JlIaSkomSkok� );
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                {
                    exit( "fail:level8_writelog_editrmb_err" );
                }
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                {
                    exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[记录作者扣款日志失败，操作中断]]></return_msg></xml>" );
                }
                exit( $_obf_k4iNkYmOkpOVjJCHkIqUj4k�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
            }
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set `rmb`=`rmb`-".$_obf_joeIhoiOh5KLlY6GiI_Hh5M�.",`xfrmb`=`xfrmb`+".$_obf_joeIhoiOh5KLlY6GiI_Hh5M�." where `id`=".$_obf_iYiHj4aUkoqOjZOHjZKMh4c�['id'], "sync" );
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                $_obf_h4aUkomQiI6JlIaSkomSkok� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_agentrmb set `intro`='<font color=red>扣款失败</font>' where `ordernum`='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."' order by `id` Desc limit 0,1", "sync" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "REPAIR TABLE `kss_tb_manager`", "notsync" );
                $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'] );
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_jZGIi4eRiJOGjJCKk42IjI8�.$_obf_hpKUj5GNh4aPlI2JhpSGlZE�."作者扣款操作失败，操作中断！".$_obf_h4aUkomQiI6JlIaSkomSkok� );
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
                {
                    exit( "fail:level8_editrmb_err" );
                }
                if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
                {
                    exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[作者扣款操作失败，操作中断]]></return_msg></xml>" );
                }
                exit( $_obf_k4iNkYmOkpOVjJCHkIqUj4k�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
            }
            $_obf_i4yTlYaRiIeKjY6QjImVi5E� = "作者款项已扣，";
        }
        $_obf_jY2OjpWVjpGNi4yNiIeIjIg� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_ioeOiIuTiJGQi42VkY_Vios�( "kss_z_key_".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'] );
        $_obf_jIeNi4yViY_LjI2Ni5KQj4w� = array(
            "beginid" => $_obf_jY2OjpWVjpGNi4yNiIeIjIg�,
            "addtime" => time( ),
            "managerid" => $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'],
            "ordernum" => $_obf_iJWMjIiVi5OGjJOViY2Li48�,
            "ispay" => 1,
            "tag" => $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['tags'],
            "keyattr" => $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['keygroupid'],
            "k_num" => $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['keycount']
        );
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = _obf_jo2HlYmTj4eQhpKTkYyIj5E�( $_obf_jIeNi4yViY_LjI2Ni5KQj4w�, $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['keygroupid'] );
        $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kYyNi4eQiouGlY6Qj46HjpE�( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pid']."_".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softid'] );
        if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === TRUE )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_order SET `orderstatus`=9 where `ordernum`='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'", "sync" );
            if ( 0 < SENDMAILMODE )
            {
                include( KSSINCDIR."sendmail.php" );
                $_obf_jJSLjY_MjImIioeGkZKHipA� = "<html>";
                $_obf_jJSLjY_MjImIioeGkZKHipA� .= "<head>";
                $_obf_jJSLjY_MjImIioeGkZKHipA� .= "<title>确认</title>";
                $_obf_jJSLjY_MjImIioeGkZKHipA� .= "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />";
                $_obf_jJSLjY_MjImIioeGkZKHipA� .= "</head>";
                $_obf_jJSLjY_MjImIioeGkZKHipA� .= "<body>";
                $_obf_jJSLjY_MjImIioeGkZKHipA� .= "这是系统自动发送的邮件，请不要回复<br><br>软件名：".$_obf_lZGQj4iOj4mTlZGNjZGUj5E�['softname']."<br><br>单号：".$_obf_iJWMjIiVi5OGjJOViY2Li48�."<br>\r\n<br>卡号:<br>\r\n".join( "<br>", $_obf_iZGLlYiTk42PlJOHh4aJkok� );
                $_obf_jJSLjY_MjImIioeGkZKHipA� .= "<br><br>".base64_decode( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['mailtext'] );
                $_obf_jJSLjY_MjImIioeGkZKHipA� .= "</body>";
                $_obf_jJSLjY_MjImIioeGkZKHipA� .= "</html>";
                $_obf_lJSGjpKSio2Lj5WIio2VhpU� = kk_sendmail( "订单完成", $_obf_jJSLjY_MjImIioeGkZKHipA�, $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['payqq']."@qq.com", QQMAIL, QQMAILPASSWORD, REMOTESENDMAILAPI );
                if ( $_obf_lJSGjpKSio2Lj5WIio2VhpU� )
                {
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "邮件发送成功！" );
                }
                else
                {
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "邮件发送失败！".$_obf_lJSGjpKSio2Lj5WIio2VhpU� );
                }
            }
            _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "生成卡号成功！" );
        }
        else
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_order set `orderstatus`=7 where `ordernum`='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'", "sync" );
            _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "生成卡号失败！".$_obf_lY6RhpOJh46VkJOGkoeRiIY� );
            if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
            {
                exit( "fail:make_key_err" );
            }
            if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
            {
                exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[生成卡号失败]]></return_msg></xml>" );
            }
            exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
        }
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "完成，返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success" );
        if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
        {
            exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>" );
        }
        exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
    }
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "完成，返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success" );
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
    {
        exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>" );
    }
    exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
}
if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
{
    exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>" );
}
exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
?>
