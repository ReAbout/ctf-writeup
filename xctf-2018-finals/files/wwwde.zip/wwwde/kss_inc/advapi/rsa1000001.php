<?php

if ( !defined( "YH2" ) )
{
    exit( "Access denied to view this page!" );
}
define( "SOFTRSAMODE", 0 );
define( "SOFTRSAEKEY", "" );
define( "SOFTRSANKEY", "" );
?>
