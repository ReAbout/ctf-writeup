<?php

function _obf_iImJh5KOi5OGk5KLlJCIjYg�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

require( "inc.php" );
if ( isset( $_POST['remark1'] ) && $_POST['remark1'] == 0 )
{
    $_obf_k5OUk5WOk5KVlIaLlYmRh5I� = 1;
    include( "payapi_notify2.php" );
    exit( );
}
else
{
    function _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_hoyMkoeOj42QioaSioaKi4g�, $_obf_i5OJk5CSj4iKhpOJkJKTjpU� = 1 )
    {
        if ( defined( "SAE_MYSQL_USER" ) || DEBUGPAYWG == 0 )
        {
            return FALSE;
        }
        $_obf_jpKUipCPlZSHlYuJjYaUlZE� = KSSLOGDIR."agentczdebug1_log.php";
        if ( $_obf_i5OJk5CSj4iKhpOJkJKTjpU� == 1 )
        {
            @file_put_contents( $_obf_jpKUipCPlZSHlYuJjYaUlZE�, $_obf_hoyMkoeOj42QioaSioaKi4g�."\r\n", FILE_APPEND );
        }
        else if ( !is_file( $_obf_jpKUipCPlZSHlYuJjYaUlZE� ) && 262144 < filesize( $_obf_jpKUipCPlZSHlYuJjYaUlZE� ) )
        {
            $_obf_ipWMho2NlI2MiI_MioeTlZI� = "?";
            $_obf_ipCIiZCRiYmKhpOSi4eSjZI� = "<".$_obf_ipWMho2NlI2MiI_MioeTlZI�."php exit('Access denied to view this page!');".$_obf_ipWMho2NlI2MiI_MioeTlZI�.">\r\n";
            @file_put_contents( $_obf_jpKUipCPlZSHlYuJjYaUlZE�, $_obf_ipCIiZCRiYmKhpOSi4eSjZI�."\r\n\r\n\r\n时间:".@date( "Y-m-d H:i:s" )."\r\n订单号:".$_obf_iJWMjIiVi5OGjJOViY2Li48�."\r\n状态:".$_obf_hoyMkoeOj42QioaSioaKi4g�."\r\n" );
        }
        else
        {
            @file_put_contents( $_obf_jpKUipCPlZSHlYuJjYaUlZE�, "\r\n\r\n\r\n时间:".@date( "Y-m-d H:i:s" )."\r\n订单号:".$_obf_iJWMjIiVi5OGjJOViY2Li48�."\r\n状态:".$_obf_hoyMkoeOj42QioaSioaKi4g�."\r\n", FILE_APPEND );
        }
    }
    $_obf_jo_MipCRkYuSk4mSko2RkIg� = array( "ali" => "支付宝", "ten" => "财付通", "chinabank" => "网银在线", "e138" => "易付通", "jqr" => "支付宝机器人", "微信扫码" );
    $_obf_iZSViY2KjJSNjoePh4yOjI4� = array( "ali" => "success", "ten" => "success", "chinabank" => "ok", "e138" => "success", "jqr" => "success", "wx" => "success" );
    $_obf_k4iNkYmOkpOVjJCHkIqUj4k� = array( "ali" => "fail", "ten" => "fail", "chinabank" => "error", "e138" => "fail", "jqr" => "fail", "wx" => "fail" );
    $_obf_k5OQh4iJjoyPjJSMjpSOlZA� = array( "WAIT_BUYER_PAY", "WAIT_SELLER_SEND_GOODS", "WAIT_BUYER_CONFIRM_GOODS", "TRADE_FINISHED", "TRADE_SUCCESS", "SUCCESS", "FAIL" );
    $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "ali";
    if ( isset( $_GET['alipayjqr'] ) )
    {
        $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "jqr";
    }
    if ( isset( $_GET['transaction_id'] ) )
    {
        $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "ten";
    }
    if ( isset( $_POST['v_oid'] ) )
    {
        $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "chinabank";
    }
    if ( isset( $_GET['AttachString'] ) && $_GET['AttachString'] == "e138" )
    {
        $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "e138";
    }
    if ( isset( $GLOBALS['HTTP_RAW_POST_DATA'] ) && substr( $GLOBALS['HTTP_RAW_POST_DATA'], 0, 5 ) == "<xml>" )
    {
        $_obf_kYyPkY_PkJKVh4qGjJGIio4� = "wx";
    }
    if ( !isset( $_GET['alipayjqr'] ) )
    {
        include( $_obf_kYyPkY_PkJKVh4qGjJGIio4�."pay_function.php" );
    }
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
    {
        $_obf_kpGPh4mNh46SkZONh4eLlJU� = "";
        $_obf_h5WSiIeGkYiNk4iJjYuHkJA� = $GLOBALS['HTTP_RAW_POST_DATA'];
        $_obf_ho6Nh5WMj4mLh5WTh4aTkok� = _obf_komQkZGUhomRk4eLipOSkJM�( $_obf_h5WSiIeGkYiNk4iJjYuHkJA� );
        if ( !array_key_exists( "return_code", $_obf_ho6Nh5WMj4mLh5WTh4aTkok� ) || !array_key_exists( "result_code", $_obf_ho6Nh5WMj4mLh5WTh4aTkok� ) )
        {
            _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( "未知", "GLOBALS:".$_obf_h5WSiIeGkYiNk4iJjYuHkJA�, 0 );
            exit( "<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[发送来的数据异常]]></return_msg></xml>" );
        }
        $_obf_iJWMjIiVi5OGjJOViY2Li48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( $_obf_ho6Nh5WMj4mLh5WTh4aTkok�['out_trade_no'], "val", "sql", "" );
        $_obf_lZSLkIeSlIySkY6SlIuJio0� = _obf_i4mIkpOGkomKiouRhoaMh5I�( $_obf_ho6Nh5WMj4mLh5WTh4aTkok�['transaction_id'], "val", "sql", "" );
        $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = _obf_i4mIkpOGkomKiouRhoaMh5I�( $_obf_ho6Nh5WMj4mLh5WTh4aTkok�['total_fee'], "val", "int", "" );
        $_obf_lIuQk5OGjpKVjY6UiI_QjJM� /= 100;
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( $_obf_ho6Nh5WMj4mLh5WTh4aTkok�['result_code'], "val", "sql", "" );
    }
    else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ali" )
    {
        $_obf_iJWMjIiVi5OGjJOViY2Li48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "out_trade_no", "pg", "sql", "" );
        $_obf_kpGPh4mNh46SkZONh4eLlJU� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_no", "pg", "sql", "" );
        $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "total_fee", "pg", "sql", "" );
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_status", "pg", "sql", "" );
        $_obf_j4mLiYmUj4aJiI6IjY6TjI0� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "buyer_email", "pg", "sql", "" );
    }
    else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
    {
        $_obf_kpGPh4mNh46SkZONh4eLlJU� = "";
        $_obf_iJWMjIiVi5OGjJOViY2Li48� = trim( $_GET['ordernum'] );
        $_obf_jpGJk5SSkJOIk4iQiI_OhpU� = trim( $_GET['rmb'] );
        $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = $_obf_jpGJk5SSkJOIk4iQiI_OhpU�;
        $_obf_iImJjYmQjYyOjIuVkIuMjIs� = trim( $_GET['sign'] );
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = "TRADE_SUCCESS";
    }
    else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ten" )
    {
        $_obf_hpKNkIaShoaKkY6Lk4qVk5U� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_mode", "gp", "int", 0 );
        $_obf_iJWMjIiVi5OGjJOViY2Li48� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "out_trade_no", "gp", "sql", "" );
        $_obf_kpGPh4mNh46SkZONh4eLlJU� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "transaction_id", "gp", "sql", "" );
        $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "total_fee", "gp", "sql", "" );
        $_obf_lIuQk5OGjpKVjY6UiI_QjJM� /= 100;
        $_obf_i5CMioaGiI6ShomNiIuKjJE� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "trade_state", "gp", "sql", "" );
        if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "0" )
        {
            $_obf_i5CMioaGiI6ShomNiIuKjJE� = "TRADE_FINISHED";
        }
        else
        {
            $_obf_i5CMioaGiI6ShomNiIuKjJE� = "WAIT_BUYER_PAY";
        }
    }
    else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "chinabank" )
    {
        $_obf_kpGPh4mNh46SkZONh4eLlJU� = "";
        $_obf_k42NkY2RkoiNjJCKlZSKiIg� = trim( $_POST['v_oid'] );
        $_obf_iJWMjIiVi5OGjJOViY2Li48� = $_obf_k42NkY2RkoiNjJCKlZSKiIg�;
        $_obf_iIuQkYaUioqGlI6IjIuMiI8� = trim( $_POST['v_pstatus'] );
        $_obf_jpGJk5SSkJOIk4iQiI_OhpU� = trim( $_POST['v_amount'] );
        $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = $_obf_jpGJk5SSkJOIk4iQiI_OhpU�;
        $_obf_hpCRlJCSjI6Ki5WSipCLkpQ� = trim( $_POST['v_moneytype'] );
        $_obf_lJSPjJCOi5CIiJSSkZWNh4Y� = trim( $_POST['remark1'] );
        $_obf_iImJjYmQjYyOjIuVkIuMjIs� = trim( $_POST['v_md5str'] );
        if ( $_obf_iIuQkYaUioqGlI6IjIuMiI8� == "20" )
        {
            $_obf_i5CMioaGiI6ShomNiIuKjJE� = "TRADE_FINISHED";
        }
        else
        {
            $_obf_i5CMioaGiI6ShomNiIuKjJE� = "WAIT_BUYER_PAY";
        }
    }
    else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "e138" )
    {
        $_obf_kpGPh4mNh46SkZONh4eLlJU� = "";
        $_obf_k42NkY2RkoiNjJCKlZSKiIg� = trim( $_GET['SerialNo'] );
        $_obf_iJWMjIiVi5OGjJOViY2Li48� = $_obf_k42NkY2RkoiNjJCKlZSKiIg�;
        $_obf_iIuQkYaUioqGlI6IjIuMiI8� = trim( $_GET['Status'] );
        $_obf_jpGJk5SSkJOIk4iQiI_OhpU� = trim( $_GET['Money'] );
        $_obf_lIuQk5OGjpKVjY6UiI_QjJM� = $_obf_jpGJk5SSkJOIk4iQiI_OhpU�;
        $_obf_iImJjYmQjYyOjIuVkIuMjIs� = trim( $_GET['VerifyString'] );
        if ( $_obf_iIuQkYaUioqGlI6IjIuMiI8� == "2" )
        {
            $_obf_i5CMioaGiI6ShomNiIuKjJE� = "TRADE_FINISHED";
        }
        else
        {
            $_obf_i5CMioaGiI6ShomNiIuKjJE� = "WAIT_BUYER_PAY";
        }
    }
    else
    {
        exit( "errwg" );
    }
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_i5CMioaGiI6ShomNiIuKjJE�, 0 );
    $_obf_k42GiI_RiIqKjIaUio6IiIw� = "POSTDATA:";
    foreach ( $GLOBALS['_POST'] as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
    {
        $_obf_k42GiI_RiIqKjIaUio6IiIw� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".urlencode( $_obf_lYeSkY6Th5SOlYuHjZGVio8� )."&";
    }
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_k42GiI_RiIqKjIaUio6IiIw� );
    $_obf_lYuTjYmGkJWKk5WOjoeGlYw� = "GETDATA:";
    foreach ( $GLOBALS['_GET'] as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
    {
        $_obf_lYuTjYmGkJWKk5WOjoeGlYw� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".urlencode( $_obf_lYeSkY6Th5SOlYuHjZGVio8� )."&";
    }
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_lYuTjYmGkJWKk5WOjoeGlYw� );
    if ( !in_array( $_obf_i5CMioaGiI6ShomNiIuKjJE�, $_obf_k5OQh4iJjoyPjJSMjpSOlZA� ) )
    {
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器fail，状态码非法" );
        if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
        {
            exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[状态码未找到]]></return_msg></xml>" );
        }
        exit( $_obf_k4iNkYmOkpOVjJCHkIqUj4k�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
    }
    $_obf_jIaUiIeSjZWKlIqLkIqOioc� = new mysql_cls( );
    $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_jIuSjYuUkJGHlYuPjZOQjY4�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k� );
    $_obf_lZGQj4iOj4mTlZGNjZGUj5E� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iY6OkJCRkY2PjpCPk5CRkJA�( "select * from kss_tb_log_agentrmb where ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'" );
    if ( empty( $_obf_lZGQj4iOj4mTlZGNjZGUj5E� ) )
    {
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success，订单未找到" );
        if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
        {
            exit( "fail:Order_not_find" );
        }
        if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
        {
            exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[订单未找到]]></return_msg></xml>" );
        }
        exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
    }
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "订单找到" );
    if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['changermb'] != $_obf_lIuQk5OGjpKVjY6UiI_QjJM� )
    {
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success，订单金额不符，不再通知" );
        if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
        {
            exit( "fail:Order_rmb" );
        }
        if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
        {
            exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[订单金额不符]]></return_msg></xml>" );
        }
        exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
    }
    $_obf_lI6OiJSPjZWVi5GQhoiPjpU� = _obf_iIeMkYyJiZKTjI2UjImPi4Y�( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['managerid'] );
    $_obf_lIiPjo6LjoqUjYiUjJKOhpA� = 1;
    $_obf_lJOGjpSRkI2NiJSIjpCKj5A� = _obf_iY6RiYaNio6PiIyIiZWJkJQ�( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['pid'], $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['pmid'] );
    if ( !empty( $_obf_lJOGjpSRkI2NiJSIjpCKj5A� ) || $_obf_lJOGjpSRkI2NiJSIjpCKj5A�['islock'] == 0 )
    {
        $_obf_lIiPjo6LjoqUjYiUjJKOhpA� = 0;
    }
    $_obf_jYiHj4qPj4aUlIiUjIyJipE� = _obf_iY6RiYaNio6PiIyIiZWJkJQ�( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['pid'] );
    if ( $_obf_lIiPjo6LjoqUjYiUjJKOhpA� == 1 )
    {
        $_obf_jI2JlY_QkoeQj5OLjouLlYo� = $_obf_jYiHj4qPj4aUlIiUjIyJipE�;
    }
    else if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 7 )
    {
        $_obf_jI2JlY_QkoeQj5OLjouLlYo� = $_obf_jYiHj4qPj4aUlIiUjIyJipE�;
    }
    else
    {
        $_obf_jI2JlY_QkoeQj5OLjouLlYo� = $_obf_lJOGjpSRkI2NiJSIjpCKj5A�;
    }
    $_obf_i42MjZCUi5CJjI_NhoaRj4Y� = 0;
    if ( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['level'] == 8 && 1000 < LICTYPE )
    {
        $_obf_jI2JlY_QkoeQj5OLjouLlYo� = _obf_iIeMkYyJiZKTjI2UjImPi4Y�( 1 );
        $_obf_i42MjZCUi5CJjI_NhoaRj4Y� = 1;
    }
    $_obf_kJCGiI6Nk4_RkYuGiZWSi5M� = explode( ",", $_obf_jI2JlY_QkoeQj5OLjouLlYo�['alipayset'] );
    if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
    {
        $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = _obf_kpWLkoyMhouPipCQiImKjZA�( $_obf_h5WSiIeGkYiNk4iJjYuHkJA�, $_obf_jI2JlY_QkoeQj5OLjouLlYo�['wxpaykey'] );
    }
    else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ali" )
    {
        $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = _obf_i4iVlY2UkouLj5KGlI2Uhoc�( $_obf_kJCGiI6Nk4_RkYuGiZWSi5M�[1], $_obf_jI2JlY_QkoeQj5OLjouLlYo�['alikey'] );
    }
    else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ten" )
    {
        if ( $_obf_hpKNkIaShoaKkY6Lk4qVk5U� != 1 )
        {
            _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success，非即时到帐交易" );
            exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
        }
        $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = _obf_jY6OlY_RlYqPjZSQh4uPkJQ�( $_obf_jI2JlY_QkoeQj5OLjouLlYo�['tenkey'] );
    }
    else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "jqr" )
    {
        if ( strtolower( md5( "ordernum=".$_obf_iJWMjIiVi5OGjJOViY2Li48�."&rmb=".$_obf_lIuQk5OGjpKVjY6UiI_QjJM�."&key=".$_obf_jI2JlY_QkoeQj5OLjouLlYo�['alikey'] ) ) != $_obf_iImJjYmQjYyOjIuVkIuMjIs� )
        {
            exit( "fail:URL_signerror" );
        }
        $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = TRUE;
    }
    else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "chinabank" )
    {
        $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = TRUE;
        if ( $_obf_iImJjYmQjYyOjIuVkIuMjIs� != strtoupper( md5( $_obf_k42NkY2RkoiNjJCKlZSKiIg�.$_obf_iIuQkYaUioqGlI6IjIuMiI8�.$_obf_jpGJk5SSkJOIk4iQiI_OhpU�.$_obf_hpCRlJCSjI6Ki5WSipCLkpQ�.$_obf_jI2JlY_QkoeQj5OLjouLlYo�['chinabankkey'] ) ) )
        {
            $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = FALSE;
        }
    }
    else if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "e138" )
    {
        $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = TRUE;
        if ( $_obf_iImJjYmQjYyOjIuVkIuMjIs� != strtolower( md5( "SerialNo=".$_obf_k42NkY2RkoiNjJCKlZSKiIg�."&UserID=".$_obf_jI2JlY_QkoeQj5OLjouLlYo�['e138set']."&Money=".$_obf_jpGJk5SSkJOIk4iQiI_OhpU�."&Status=".$_obf_iIuQkYaUioqGlI6IjIuMiI8�."&AttachString=e138&MerchantKey=".$_obf_jI2JlY_QkoeQj5OLjouLlYo�['e138key'] ) ) )
        {
            $_obf_k4mJh5SPkY6Vh4qHjIaJh44� = FALSE;
        }
    }
    if ( $_obf_k4mJh5SPkY6Vh4qHjIaJh44� !== TRUE )
    {
        if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "wx" )
        {
            _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "校验微信发送来的XML数据:".$_obf_k4mJh5SPkY6Vh4qHjIaJh44�.",返回给微信服务器".$_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."，签名非法" );
            exit( "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[签名没通过]]></return_msg></xml>" );
        }
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "curl:".$_obf_k4mJh5SPkY6Vh4qHjIaJh44� );
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器".$_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."，签名非法" );
        exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
    }
    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "签名效验通过" );
    $_obf_iIeHlZWKipOJlIyVk42UjJM� = 0;
    $_obf_lYuMkpWKjIaLjIuOlIaUio8� = "";
    if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['intro'] != $_obf_kpGPh4mNh46SkZONh4eLlJU� )
    {
        $_obf_lYuMkpWKjIaLjIuOlIaUio8� = ",`intro`='".$_obf_kpGPh4mNh46SkZONh4eLlJU�."'";
    }
    if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "WAIT_BUYER_PAY" )
    {
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success" );
        if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['optype'] < 21 )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_agentrmb SET `optype`=21,`oldrmb`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['rmb'].$_obf_lYuMkpWKjIaLjIuOlIaUio8�." where ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'", "sync" );
        }
        exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
    }
    if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "WAIT_SELLER_SEND_GOODS" )
    {
        if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['optype'] < 22 )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_agentrmb SET `optype`=22,`oldrmb`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['rmb'].$_obf_lYuMkpWKjIaLjIuOlIaUio8�."  where ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'", "sync" );
        }
        if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ali" )
        {
            _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "alipay 自动发货" );
            $_obf_jomQlJOKjYaHko_SkZGKi4w� = _obf_koyJjYuOjZOSiZOUkYmKi40�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, $_obf_kpGPh4mNh46SkZONh4eLlJU�, $_obf_kJCGiI6Nk4_RkYuGiZWSi5M�[1], $_obf_jI2JlY_QkoeQj5OLjouLlYo�['alikey'] );
            if ( function_exists( "curl_init" ) )
            {
                $_obf_iYuIkIeRlJCQiIqQh5WGjIg� = _obf_iYqMjJCPipKLjpSRioeUlYc�( $_obf_jomQlJOKjYaHko_SkZGKi4w� );
                $_obf_iJOJjo_KkY2PkYmSkY2JjJU� = stripos( $_obf_iYuIkIeRlJCQiIqQh5WGjIg�, "<is_success>T</is_success>" );
                if ( $_obf_iJOJjo_KkY2PkYmSkY2JjJU� !== FALSE && $_obf_iJOJjo_KkY2PkYmSkY2JjJU� < 70 )
                {
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "自动发货成功！" );
                }
                else
                {
                    _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "自动发货失败！" );
                }
            }
            else
            {
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "不支持curl，未能自动发货！" );
            }
        }
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success" );
        exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
    }
    if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "WAIT_BUYER_CONFIRM_GOODS" )
    {
        _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "返回给".$_obf_jo_MipCRkYuSk4mSko2RkIg�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�]."服务器success" );
        if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['optype'] < 23 )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_agentrmb SET `optype`=23,`oldrmb`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['rmb'].$_obf_lYuMkpWKjIaLjIuOlIaUio8�."  where ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'", "sync" );
        }
        if ( $_obf_kYyPkY_PkJKVh4qGjJGIio4� == "ali" )
        {
            $_obf_jpSRjpKGhpOOiIuHiI_UjYo� = explode( ",", $_obf_jI2JlY_QkoeQj5OLjouLlYo�['alipayset'] );
            if ( $_obf_jpSRjpKGhpOOiIuHiI_UjYo�[0] == "create_partner_trade_by_buyer" && $_obf_jpSRjpKGhpOOiIuHiI_UjYo�[2] == $_obf_j4mLiYmUj4aJiI6IjY6TjI0� )
            {
                $_obf_iIeHlZWKipOJlIyVk42UjJM� = 1;
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "使用特殊帐号的提卡交易，发货后就给代理充值！" );
            }
            else
            {
                exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
            }
        }
        else
        {
            exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
        }
    }
    if ( $_obf_i5CMioaGiI6ShomNiIuKjJE� == "TRADE_FINISHED" || $_obf_i5CMioaGiI6ShomNiIuKjJE� == "TRADE_SUCCESS" || $_obf_i5CMioaGiI6ShomNiIuKjJE� == "SUCCESS" || $_obf_iIeHlZWKipOJlIyVk42UjJM� == 1 )
    {
        if ( $_obf_lZGQj4iOj4mTlZGNjZGUj5E�['optype'] != 24 )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_log_agentrmb SET `optype`=24,`oldrmb`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['rmb'].$_obf_lYuMkpWKjIaLjIuOlIaUio8�." where ordernum='".$_obf_iJWMjIiVi5OGjJOViY2Li48�."'", "sync" );
            $_obf_j4ePkZOGiZOLjpSLio_PjY0� = "";
            if ( $_obf_i42MjZCUi5CJjI_NhoaRj4Y� == 1 )
            {
                if ( 100 <= $_obf_lIuQk5OGjpKVjY6UiI_QjJM� )
                {
                    $_obf_j4ePkZOGiZOLjpSLio_PjY0� = ",`endtime`='".date( "Y-m-d H:i:s", strtotime( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['endtime'] ) + 2592000 )."'";
                }
                if ( $_obf_lIuQk5OGjpKVjY6UiI_QjJM� == 50 )
                {
                    $_obf_j4ePkZOGiZOLjpSLio_PjY0� = ",`endtime`='".date( "Y-m-d H:i:s", strtotime( $_obf_lI6OiJSPjZWVi5GQhoiPjpU�['endtime'] ) + 1296000 )."'";
                }
            }
            $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_tb_manager set `rmb`=`rmb`+".$_obf_lIuQk5OGjpKVjY6UiI_QjJM�." ".$_obf_j4ePkZOGiZOLjpSLio_PjY0�." where `id`=".$_obf_lI6OiJSPjZWVi5GQhoiPjpU�['id'], "sync" );
            $_obf_i42MjZCUi5CJjI_NhoaRj4Y� = 1;
            if ( $_obf_lY6RhpOJh46VkJOGkoeRiIY� === FALSE )
            {
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "代理充值加款失败！".$_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_iYmHkJSKj5OJhoiRiY2Rio4�( ) );
            }
            else
            {
                _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "代理充值加款成功！" );
            }
        }
        else
        {
            _obf_iJKHiIeSiJGQkoiPjI6Kk5I�( $_obf_iJWMjIiVi5OGjJOViY2Li48�, "二次通知已成功处理！" );
        }
    }
}
exit( $_obf_iZSViY2KjJSNjoePh4yOjI4�[$_obf_kYyPkY_PkJKVh4qGjJGIio4�] );
?>
