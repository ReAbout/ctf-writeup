<?php

function _obf_iIuGlJGNkJOSj4_JkIeJk4g�( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 1 )
{
    $_obf_iJGPjJWLj4uLkIqVjYiHh48� = unpack( "C*", "ViewZendSourceCodeIsInvalid!" );
    do
    {
        $_obf_iY2Oh5OGlIqQhpCJi5CMkog� = ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] << 4 ) + ( $_obf_lZKViImJjo6UhouJj4aVi4Y�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] >> 4 );
        $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2;
    } while ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 28 );
}

function _obf_k42GhouUh5SVj4uSlYqRlYg�( $_obf_hpGUh5GQi5KPlYaThpOMiIk� = 0 )
{
    global $_obf_jIaUiIeSjZWKlIqLkIqOioc�;
    $_obf_jI6Lho6UhomJio_IhoaQkJA� = "?";
    if ( $_obf_hpGUh5GQi5KPlYaThpOMiIk� == 0 )
    {
        $_obf_i4uVj4uLjIyVkpORlYiHlY0� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "SELECT kss_tb_manager.id as manager_id,kss_tb_manager.maxusernum as manager_maxusernum,kss_tb_manager.islock as manager_islock,kss_tb_manager.endtime as manager_endtime,kss_tb_soft . * FROM kss_tb_manager LEFT JOIN kss_tb_soft ON kss_tb_manager.pid = kss_tb_soft.pid WHERE kss_tb_manager.level >7" );
        _obf_lIiIjYmLiJCMjZSJjIeJiZI�( KSSINCDIR."cache" );
        _obf_lIiIjYmLiJCMjZSJjIeJiZI�( KSSINCDIR."advapi" );
    }
    else
    {
        $_obf_i4uVj4uLjIyVkpORlYiHlY0� = $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_lZGTiIiKhouKiZGLi5KUkI8�( "SELECT kss_tb_manager.id as manager_id,kss_tb_manager.maxusernum as manager_maxusernum,kss_tb_manager.islock AS manager_islock, kss_tb_manager.endtime AS manager_endtime, kss_tb_soft. * FROM kss_tb_manager RIGHT JOIN kss_tb_soft ON kss_tb_manager.pid = kss_tb_soft.pid WHERE kss_tb_manager.level>7 and kss_tb_soft.id =".$_obf_hpGUh5GQi5KPlYaThpOMiIk� );
        foreach ( $_obf_i4uVj4uLjIyVkpORlYiHlY0� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
        {
            $_obf_jIaUiIeSjZWKlIqLkIqOioc�->_obf_kpSOj5KVio2Hj4uKj4_KjIY�( "update kss_z_user_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid']."_".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id']." set endtime=starttime+86400*cday where endtime<2110000000", "notsync" );
        }
    }
    $_obf_jZGRipSRkIeUiIeQjoaUjJI� = "Ax0x0x0x0x0x0x0x0x0x0x0A_GT";
    $_obf_k5GHkoiPi4eQi4yQjoqPiJI� = array_search( "Ax0x0x0x0x0x0x0x0x0x0x0A_GT", get_defined_vars( ), TRUE );
    if ( !empty( $_obf_i4uVj4uLjIyVkpORlYiHlY0� ) )
    {
        if ( !is_dir( KSSINCDIR."cache" ) )
        {
            @mkdir( KSSINCDIR."cache", "0777" );
        }
        foreach ( $_obf_i4uVj4uLjIyVkpORlYiHlY0� as $_obf_kY_OlYeUlIiVjo6Hio_MkpI� )
        {
            $_obf_kouPjI2Jj46NhpSOjpCLkYY� = "<".$_obf_jI6Lho6UhomJio_IhoaQkJA�."php defined('YH2') or exit('Access denied to view this page!');\r\ndefine('SOFTRSAMODE',".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['rsaenable']."); define('SOFTRSAEKEY','".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['rsaekey']."');  define('SOFTRSANKEY','".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['rsankey']."');\r\n".$_obf_jI6Lho6UhomJio_IhoaQkJA�.">";
            file_put_contents( KSSINCDIR."advapi".DIRECTORY_SEPARATOR."rsa".$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softcode'].".php", $_obf_kouPjI2Jj46NhpSOjpCLkYY� );
            $_obf_kouUjYyRjYaSk5SThpKIj5Q� = "<".$_obf_jI6Lho6UhomJio_IhoaQkJA�."php defined('YH2') or exit('Access denied to view this page!');\r\n".base64_decode( $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['advapi'] )."\r\n".$_obf_jI6Lho6UhomJio_IhoaQkJA�.">";
            file_put_contents( KSSINCDIR."advapi".DIRECTORY_SEPARATOR.$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['pid'].$_obf_kY_OlYeUlIiVjo6Hio_MkpI�['id'].".php", $_obf_kouUjYyRjYaSk5SThpKIj5Q� );
            $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['advapi'] = 0;
            $_obf_iY6VkZSKlImOkpOUjIqVkok� = "";
            foreach ( $_obf_kY_OlYeUlIiVjo6Hio_MkpI� as $_obf_lIeHkoeKkpOSiomPi4mQk5E� => $_obf_io6UjZWThpOSjYeOj46Qkow� )
            {
                if ( _obf_i46Ti46MkZCVkYaOkYmVi4w�( $_obf_io6UjZWThpOSjYeOj46Qkow� ) )
                {
                    $_obf_iY6VkZSKlImOkpOUjIqVkok� .= "'".$_obf_lIeHkoeKkpOSiomPi4mQk5E�."' => ".$_obf_io6UjZWThpOSjYeOj46Qkow�.",\n";
                }
                else
                {
                    if ( $_obf_lIeHkoeKkpOSiomPi4mQk5E� == "mac_blacklist" )
                    {
                        $_obf_io6UjZWThpOSjYeOj46Qkow� = str_replace( "\r", "", $_obf_io6UjZWThpOSjYeOj46Qkow� );
                        $_obf_io6UjZWThpOSjYeOj46Qkow� = str_replace( "\n", ",", $_obf_io6UjZWThpOSjYeOj46Qkow� );
                        $_obf_io6UjZWThpOSjYeOj46Qkow� = str_replace( ",,", ",", $_obf_io6UjZWThpOSjYeOj46Qkow� );
                        $_obf_io6UjZWThpOSjYeOj46Qkow� = str_replace( ",,", ",", $_obf_io6UjZWThpOSjYeOj46Qkow� );
                    }
                    $_obf_iY6VkZSKlImOkpOUjIqVkok� .= "'".$_obf_lIeHkoeKkpOSiomPi4mQk5E�."' => '".mysql_real_escape_string( $_obf_io6UjZWThpOSjYeOj46Qkow� )."',\n";
                }
            }
            $_obf_iY6VkZSKlImOkpOUjIqVkok� = trim( chop( $_obf_iY6VkZSKlImOkpOUjIqVkok� ), "," );
            $_obf_kouUjYyRjYaSk5SThpKIj5Q� = "<".$_obf_jI6Lho6UhomJio_IhoaQkJA�."php\n".chr( 36 ).$_obf_k5GHkoiPi4eQi4yQjoqPiJI�."=array(\n".$_obf_iY6VkZSKlImOkpOUjIqVkok�."\n);\n".$_obf_jI6Lho6UhomJio_IhoaQkJA�.">";
            $_obf_jouMkI6Ii42Mh5WGiouIiIk� = $_obf_kY_OlYeUlIiVjo6Hio_MkpI�['softcode'];
            if ( strlen( $_obf_jouMkI6Ii42Mh5WGiouIiIk� ) == 7 )
            {
                $_obf_jouMkI6Ii42Mh5WGiouIiIk� = substr( $_obf_jouMkI6Ii42Mh5WGiouIiIk�, 0, 5 )."0".substr( $_obf_jouMkI6Ii42Mh5WGiouIiIk�, 5, 2 );
            }
            file_put_contents( KSSINCDIR."cache".DIRECTORY_SEPARATOR."soft_".$_obf_jouMkI6Ii42Mh5WGiouIiIk�.".php", $_obf_kouUjYyRjYaSk5SThpKIj5Q� );
        }
    }
}

function _obf_lIiIjYmLiJCMjZSJjIeJiZI�( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ�, $_obf_i4yQjouVlJGIkJKHiJWHiJI� = FALSE )
{
    $_obf_jZOPlIuQk5STi4yRkouSk44� = DIRECTORY_SEPARATOR;
    $_obf_ipKRjYaPkJWQj4eKiJWRjJQ� = $_obf_i4yQjouVlJGIkJKHiJWHiJI� ? realpath( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ� ) : $_obf_ipKRjYaPkJWQj4eKiJWRjJQ�;
    $_obf_ipKRjYaPkJWQj4eKiJWRjJQ� = substr( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ�, -1 ) == $_obf_jZOPlIuQk5STi4yRkouSk44� ? substr( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ�, 0, -1 ) : $_obf_ipKRjYaPkJWQj4eKiJWRjJQ�;
    if ( is_dir( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ� ) && ( $_obf_iJKKiouRh4qTh4eMiZSSlYk� = opendir( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ� ) ) )
    {
        while ( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� = readdir( $_obf_iJKKiouRh4qTh4eMiZSSlYk� ) )
        {
            if ( !( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� == "." ) )
            {
                if ( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� == ".." )
                {
                    break;
                }
            }
            else
            {
                continue;
            }
            if ( is_dir( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ�.$_obf_jZOPlIuQk5STi4yRkouSk44�.$_obf_kY_Ki4_NiIqMj5CSiIiRk48� ) )
            {
                _obf_lIiIjYmLiJCMjZSJjIeJiZI�( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ�.$_obf_jZOPlIuQk5STi4yRkouSk44�.$_obf_kY_Ki4_NiIqMj5CSiIiRk48� );
            }
            else if ( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� != "index.html" )
            {
                unlink( $_obf_ipKRjYaPkJWQj4eKiJWRjJQ�.$_obf_jZOPlIuQk5STi4yRkouSk44�.$_obf_kY_Ki4_NiIqMj5CSiIiRk48� );
            }
        }
        closedir( $_obf_iJKKiouRh4qTh4eMiZSSlYk� );
        return TRUE;
    }
    return FALSE;
}

function _obf_i4eMlI6RipSKiJGLh4uOk5E�( $_obf_h5OLiZCQipSGh46SjpOIhoo�, $_obf_kYqJhoaHlZGQjY2QkYiNjpU� )
{
    $_obf_kYqJhoaHlZGQjY2QkYiNjpU� = md5( $_obf_kYqJhoaHlZGQjY2QkYiNjpU� );
    $_obf_i4yGjYmUk4aLkIiSlYqOjIY� = 0;
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = "";
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < strlen( $_obf_h5OLiZCQipSGh46SjpOIhoo� ); ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
    {
        $_obf_i4yGjYmUk4aLkIiSlYqOjIY� = $_obf_i4yGjYmUk4aLkIiSlYqOjIY� == strlen( $_obf_kYqJhoaHlZGQjY2QkYiNjpU� ) ? 0 : $_obf_i4yGjYmUk4aLkIiSlYqOjIY�;
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� .= $_obf_h5OLiZCQipSGh46SjpOIhoo�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] ^ $_obf_kYqJhoaHlZGQjY2QkYiNjpU�[$_obf_i4yGjYmUk4aLkIiSlYqOjIY�++];
    }
    return $_obf_lY6RhpOJh46VkJOGkoeRiIY�;
}

function _obf_jZKVlY6HkYmKkIyRj4qSjIc�( $_obf_iYyTho_HlJCOh4yRj4ePj4k�, $_obf_ipCJlJOSlJSQkYqNlYqKlIs� )
{
    setcookie( $_obf_iYyTho_HlJCOh4yRj4ePj4k�, $_obf_ipCJlJOSlJSQkYqNlYqKlIs�, 0, "/", NULL, NULL, TRUE );
    if ( BINDIP == 1 )
    {
        setcookie( $_obf_iYyTho_HlJCOh4yRj4ePj4k�."_ver", md5( $_obf_ipCJlJOSlJSQkYqNlYqKlIs�.COOKKEY._obf_jZKKjpCGkZSUj4aOiIePlZI�( ) ), 0, "/", NULL, NULL, TRUE );
    }
    else
    {
        setcookie( $_obf_iYyTho_HlJCOh4yRj4ePj4k�."_ver", md5( $_obf_ipCJlJOSlJSQkYqNlYqKlIs�.COOKKEY ), 0, "/", NULL, NULL, TRUE );
    }
    return $_obf_ipCJlJOSlJSQkYqNlYqKlIs�.COOKKEY;
}

function _obf_kpONlI6UkY_HkouLk4yIk4s�( $_obf_iYyTho_HlJCOh4yRj4ePj4k�, $_obf_jI6IlJOSjIeOh5KOkYyRk48� = 0 )
{
    $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = _obf_i4mIkpOGkomKiouRhoaMh5I�( $_obf_iYyTho_HlJCOh4yRj4ePj4k�, "c", "sql", "" );
    $_obf_koiTk4aQk5OVjZGHho6Hk4o� = _obf_i4mIkpOGkomKiouRhoaMh5I�( $_obf_iYyTho_HlJCOh4yRj4ePj4k�."_ver", "c", "sql", "" );
    if ( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� == "" || $_obf_koiTk4aQk5OVjZGHho6Hk4o� == "" )
    {
        if ( $_obf_jI6IlJOSjIeOh5KOkYyRk48� == 1 )
        {
            return "";
        }
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "未登陆,<a href=index.php>请重新登陆</a>！" );
    }
    if ( BINDIP == 1 )
    {
        if ( $_obf_koiTk4aQk5OVjZGHho6Hk4o� != md5( $_obf_ipCJlJOSlJSQkYqNlYqKlIs�.COOKKEY._obf_jZKKjpCGkZSUj4aOiIePlZI�( ) ) )
        {
            if ( $_obf_jI6IlJOSjIeOh5KOkYyRk48� == 1 )
            {
                return "";
            }
            _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "非法操作(cookies),<a href='index.php' target='_top'>请重新登陆</a>" );
            return $_obf_ipCJlJOSlJSQkYqNlYqKlIs�;
        }
    }
    else if ( $_obf_koiTk4aQk5OVjZGHho6Hk4o� != md5( $_obf_ipCJlJOSlJSQkYqNlYqKlIs�.COOKKEY ) )
    {
        if ( $_obf_jI6IlJOSjIeOh5KOkYyRk48� == 1 )
        {
            return "";
        }
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "非法操作(cookies),<a href='index.php' target='_top'>请重新登陆</a>" );
    }
    return $_obf_ipCJlJOSlJSQkYqNlYqKlIs�;
}

function _obf_k5OSjY_Rh4_HkYiOko6QhpM�( $_obf_iYyTho_HlJCOh4yRj4ePj4k�, $_obf_jI6IlJOSjIeOh5KOkYyRk48� = 0 )
{
    $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = "";
    if ( isset( $_COOKIE[$_obf_iYyTho_HlJCOh4yRj4ePj4k�] ) )
    {
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_COOKIE[$_obf_iYyTho_HlJCOh4yRj4ePj4k�];
    }
    else
    {
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = "";
    }
    if ( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� != "" )
    {
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = _obf_jZORjImLjIeVj5WUiI2Lk4w�( COOKKEY2, $_obf_ipCJlJOSlJSQkYqNlYqKlIs�, "decode" );
    }
    return $_obf_ipCJlJOSlJSQkYqNlYqKlIs�;
}

function _obf_lI2NjoyHh4mLlYqJjJSQlYg�( $_obf_iYyTho_HlJCOh4yRj4ePj4k�, $_obf_ipCJlJOSlJSQkYqNlYqKlIs� )
{
    if ( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� != "" )
    {
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = _obf_jZORjImLjIeVj5WUiI2Lk4w�( COOKKEY2, $_obf_ipCJlJOSlJSQkYqNlYqKlIs�, "encode" );
    }
    setcookie( $_obf_iYyTho_HlJCOh4yRj4ePj4k�, $_obf_ipCJlJOSlJSQkYqNlYqKlIs�, time( ) + 2592000, "/", NULL, NULL, TRUE );
    return $_obf_ipCJlJOSlJSQkYqNlYqKlIs�;
}

function _obf_jZKKjpCGkZSUj4aOiIePlZI�( )
{
    $_obf_kIaUkJSThoyUi4yVkIuOkZM� = "";
    if ( filter_var( $_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE ) )
    {
        $_obf_kIaUkJSThoyUi4yVkIuOkZM� = $_SERVER['REMOTE_ADDR'];
    }
    else if ( isset( $_SERVER['HTTP_CLIENT_IP'] ) && $_SERVER['HTTP_CLIENT_IP'] != "" )
    {
        $_obf_kIaUkJSThoyUi4yVkIuOkZM� = $_SERVER['HTTP_CLIENT_IP'];
    }
    else
    {
        $_obf_kIaUkJSThoyUi4yVkIuOkZM� = $_SERVER['HTTP_X_FORWARDED_FOR'];
        if ( strpos( $_obf_kIaUkJSThoyUi4yVkIuOkZM�, "," ) !== FALSE )
        {
            $_obf_jpKKko6OkZGKjoiLjpCNlI0� = explode( ",", $_obf_kIaUkJSThoyUi4yVkIuOkZM� );
            $_obf_kIaUkJSThoyUi4yVkIuOkZM� = end( &$_obf_jpKKko6OkZGKjoiLjpCNlI0� );
        }
    }
    if ( $_obf_kIaUkJSThoyUi4yVkIuOkZM� != "" )
    {
        return $_obf_kIaUkJSThoyUi4yVkIuOkZM�;
    }
    return "0.0.0.0";
}

function _obf_k4_UjouVjoeQkpKOkIaIkZI�( $_obf_lYuNhoeVjYmSj4iOlIqMjZU�, $_obf_kYeHjY_HkpWUipWIkYeMjJU� = 32 )
{
    if ( $_obf_lYuNhoeVjYmSj4iOlIqMjZU� == "" )
    {
        return "";
    }
    $_obf_jIyLi5GOkouRjpGHkYmNiJU� = md5( COOKKEY."10000000000".$_obf_lYuNhoeVjYmSj4iOlIqMjZU� );
    $_obf_jIyLi5GOkouRjpGHkYmNiJU� = substr( $_obf_jIyLi5GOkouRjpGHkYmNiJU�, 0, $_obf_kYeHjY_HkpWUipWIkYeMjJU� );
    return $_obf_jIyLi5GOkouRjpGHkYmNiJU�;
}

function _obf_kY2KkZSVh5KLkIqRiI6KjIY�( $_obf_lYuNhoeVjYmSj4iOlIqMjZU�, $_obf_kYeHjY_HkpWUipWIkYeMjJU� = 32 )
{
    $_obf_jIyLi5GOkouRjpGHkYmNiJU� = md5( MD5KEY.chr( 102 ).chr( 104 ).chr( 117 ).chr( 111 ).chr( 121 ).chr( 117 ).chr( 110 ).$_obf_lYuNhoeVjYmSj4iOlIqMjZU� );
    $_obf_jIyLi5GOkouRjpGHkYmNiJU� = substr( $_obf_jIyLi5GOkouRjpGHkYmNiJU�, 0, $_obf_kYeHjY_HkpWUipWIkYeMjJU� );
    return $_obf_jIyLi5GOkouRjpGHkYmNiJU�;
}

function _obf_jYaRkYmQjo2KjZGOi4qOkY0�( $_obf_lYuNhoeVjYmSj4iOlIqMjZU�, $_obf_kYeHjY_HkpWUipWIkYeMjJU� = 32 )
{
    $_obf_jIyLi5GOkouRjpGHkYmNiJU� = md5( MD5KEY."signdatasoftkey".$_obf_lYuNhoeVjYmSj4iOlIqMjZU� );
    $_obf_jIyLi5GOkouRjpGHkYmNiJU� = substr( $_obf_jIyLi5GOkouRjpGHkYmNiJU�, 0, $_obf_kYeHjY_HkpWUipWIkYeMjJU� );
    return $_obf_jIyLi5GOkouRjpGHkYmNiJU�;
}

function _obf_kpOMkpCVi46VlYaSi5KPh44�( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� )
{
    if ( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� == "" )
    {
        return "";
    }
    $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = base64_encode( gzcompress( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� ) );
    $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = strtr( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, "+/=", "|_!" );
    return $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�;
}

function _obf_h4iTkpCKlYeHkZWPh5CIhpA�( $_obf_iYmKi4mIjIyJkY_Sk5CGk4c�, $_obf_kYeOjpKGlJWMjouQkomIj5E� = "GBK", $_obf_jYyLiIiLhomJko6HkIyRkoc� = "utf-8" )
{
    $_obf_lY6SjoiTkoqJiIyVlJWHkpA� = "";
    if ( $_obf_jYyLiIiLhomJko6HkIyRkoc� == "nocodeconv" || $_obf_kYeOjpKGlJWMjouQkomIj5E� == "nocodeconv" )
    {
        return $_obf_iYmKi4mIjIyJkY_Sk5CGk4c�;
    }
    if ( function_exists( "mb_convert_encoding" ) )
    {
        $_obf_k5SUjIqNi4yIi5KMjpCKjJE� = mb_convert_encoding( $_obf_iYmKi4mIjIyJkY_Sk5CGk4c�, $_obf_jYyLiIiLhomJko6HkIyRkoc�, $_obf_kYeOjpKGlJWMjouQkomIj5E� );
        return $_obf_k5SUjIqNi4yIi5KMjpCKjJE�;
    }
    if ( function_exists( "iconv" ) )
    {
        $_obf_k5SUjIqNi4yIi5KMjpCKjJE� = iconv( $_obf_kYeOjpKGlJWMjouQkomIj5E�, $_obf_jYyLiIiLhomJko6HkIyRkoc�."//IGNORE", $_obf_iYmKi4mIjIyJkY_Sk5CGk4c� );
        return $_obf_k5SUjIqNi4yIi5KMjpCKjJE�;
    }
    exit( "sorry, you have no libs support for charset change." );
}

function _obf_ko_JjomRlIiQkYiRlZKSkZI�( )
{
    $_obf_iIyGi4mRkYmVjZCHio_Lj4s� = "http://".$_SERVER['HTTP_HOST'];
    return $_obf_iIyGi4mRkYmVjZCHio_Lj4s�;
}

function _obf_h4mPjIiTlYmGiouJk42Ph4w�( )
{
    $_obf_kYqMiJOHk5WSjI_Ok5GGio8� = !function_exists( "memory_get_usage" ) ? "0" : round( memory_get_usage( ) / 1024 / 1024, 2 )."MB";
    return $_obf_kYqMiJOHk5WSjI_Ok5GGio8�;
}

function _obf_iYaQlIaRjYiMlIeGkJGGhpA�( )
{
    return intval( time( ) / 86400 - 15000 );
}

function _obf_kY6LiJGJiIiRiIuRjomOiZA�( )
{
    if ( SVRID != 1 )
    {
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "备服禁止此操作！" );
    }
}

function _obf_lYyMjpSLiZSVkpSLjJGMkYw�( $_obf_kIyQjIuPlJGQhoqMk4uTiog� )
{
    if ( _obf_ipWHiIuOiYuPjIaPkZSThok�( "usleep" ) )
    {
        usleep( $_obf_kIyQjIuPlJGQhoqMk4uTiog� * 1000 );
    }
    else
    {
        $_obf_kZGIi4yVio2Nh5CNkJOHiY8� = _obf_hpCTj4mKj5WSkpWPjouJkoc�( );
        while ( ( _obf_hpCTj4mKj5WSkpWPjouJkoc�( ) - $_obf_kZGIi4yVio2Nh5CNkJOHiY8� ) * 1000 < $_obf_kIyQjIuPlJGQhoqMk4uTiog� )
        {
            _obf_iI6QhpSTiJCJiI_KlYePlZI�( 100 );
        }
    }
}

function _obf_ipWHiIuOiYuPjIaPkZSThok�( $_obf_kpKNjomRlYuUk4qLlI2MkJU� )
{
    if ( !function_exists( $_obf_kpKNjomRlYuUk4qLlI2MkJU� ) )
    {
        return FALSE;
    }
    $_obf_jI_UiZKTi4uUkI6NlYqHiYs� = ini_get( "safe_mode" );
    $_obf_iY_LiYiQkomRjI6PjoiPjI4� = array( "set_time_limit" );
    $_obf_homViZSMjJWJkoaQkIuSlI4� = ini_get( "disable_functions" );
    $_obf_homViZSMjJWJkoaQkIuSlI4� = str_replace( " ", "", $_obf_homViZSMjJWJkoaQkIuSlI4� );
    if ( !empty( $_obf_homViZSMjJWJkoaQkIuSlI4� ) )
    {
        $_obf_k4mMjZOVkpCRipSKlI2OiYg� = explode( ",", $_obf_homViZSMjJWJkoaQkIuSlI4� );
        if ( in_array( $_obf_kpKNjomRlYuUk4qLlI2MkJU�, $_obf_k4mMjZOVkpCRipSKlI2OiYg� ) )
        {
            return FALSE;
        }
    }
    if ( !empty( $_obf_jI_UiZKTi4uUkI6NlYqHiYs� ) || in_array( $_obf_kpKNjomRlYuUk4qLlI2MkJU�, $_obf_iY_LiYiQkomRjI6PjoiPjI4� ) )
    {
        return FALSE;
    }
    return TRUE;
}

function _obf_hpCTj4mKj5WSkpWPjouJkoc�( )
{
    list( $_obf_kI6RjomJk4aRlZGMjI_Si4w�, $_obf_i4uOiIqMlYeHk4eUhoiPh4Y� ) = explode( " ", microtime( ) );
    return ( double )$_obf_kI6RjomJk4aRlZGMjI_Si4w� + ( double )$_obf_i4uOiIqMlYeHk4eUhoiPh4Y�;
}

function _obf_i4mGjpKMk5WRipSVi4mLi40�( $_obf_lJKOiJSHjo_Sj4yKk4aIh5I� )
{
    $_obf_jpGTk4aTlZCKjpOSkpCNj44� = count( $_obf_lJKOiJSHjo_Sj4yKk4aIh5I� );
    $_obf_iJGIlZOLhoaSh4mPjIqOj44� = 0;
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_jpGTk4aTlZCKjpOSkpCNj44�; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� += 2, )
    {
        $_obf_iJGIlZOLhoaSh4mPjIqOj44� = $_obf_iJGIlZOLhoaSh4mPjIqOj44� + $_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� + 1] - $_obf_lJKOiJSHjo_Sj4yKk4aIh5I�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�];
    }
    return round( $_obf_iJGIlZOLhoaSh4mPjIqOj44� * 1000, 3 );
}

function _obf_kIuUko_Mh42UkZSHjZSQiZI�( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� )
{
    if ( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� == "" )
    {
        return "";
    }
    $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = strtr( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�, "|_!", "+/=" );
    $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = gzuncompress( base64_decode( $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� ) );
    return $_obf_hoeUj5OSh5CMlI2Qh42Ijoc�;
}

function _obf_iJCRko_Hj4_Oh4eIjIaKk5I�( $_obf_j4uTjpCNho6Kh4qGh4eLi40�, $_obf_ipOUiI2LiYiKlJKKjomQh4o� )
{
    if ( ini_get( "safe_mode" ) )
    {
        $_obf_jZCHlIqNkJSSiYaQk4eVko0� = dir( $_obf_j4uTjpCNho6Kh4qGh4eLi40� );
        $_obf_k5SPi4eOiYyTk5SSlJCSk4c� = array( );
        while ( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� = $_obf_jZCHlIqNkJSSiYaQk4eVko0�->read( ) )
        {
            if ( !is_file( $_obf_j4uTjpCNho6Kh4qGh4eLi40�.$_obf_kY_Ki4_NiIqMj5CSiIiRk48� ) && !( pathinfo( $_obf_kY_Ki4_NiIqMj5CSiIiRk48�, PATHINFO_EXTENSION ) == $_obf_ipOUiI2LiYiKlJKKjomQh4o� ) )
            {
                $_obf_k5SPi4eOiYyTk5SSlJCSk4c�[] = $_obf_j4uTjpCNho6Kh4qGh4eLi40�.$_obf_kY_Ki4_NiIqMj5CSiIiRk48�;
            }
        }
        $_obf_jZCHlIqNkJSSiYaQk4eVko0�->close( );
        return $_obf_k5SPi4eOiYyTk5SSlJCSk4c�;
    }
    return glob( $_obf_j4uTjpCNho6Kh4qGh4eLi40�."*.".$_obf_ipOUiI2LiYiKlJKKjomQh4o� );
}

function _obf_hpGJi4yHlIqLhpSIh4iJlYw�( )
{
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = ADMINFOLDER;
    if ( !is_file( KSSROOTDIR.$_obf_j4eSkIiSiZCRh4_NiYaQkYk�.DIRECTORY_SEPARATOR."z_datawin.php" ) )
    {
        $_obf_lYiOi5KHk4uIiIaMk5CMkIg� = substr( KSSROOTDIR, 0, strlen( KSSROOTDIR ) - 1 );
        $_obf_iJKKiouRh4qTh4eMiZSSlYk� = @opendir( $_obf_lYiOi5KHk4uIiIaMk5CMkIg� );
        if ( $_obf_iJKKiouRh4qTh4eMiZSSlYk� !== FALSE )
        {
            do
            {
                while ( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� = readdir( $_obf_iJKKiouRh4qTh4eMiZSSlYk� ) )
                {
                    if ( !( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� == "." ) )
                    {
                        if ( $_obf_kY_Ki4_NiIqMj5CSiIiRk48� == ".." )
                        {
                            break;
                        }
                    }
                    else
                    {
                    }
                }
            } while ( !is_dir( $_obf_lYiOi5KHk4uIiIaMk5CMkIg�.DIRECTORY_SEPARATOR.$_obf_kY_Ki4_NiIqMj5CSiIiRk48� ) && !is_file( $_obf_lYiOi5KHk4uIiIaMk5CMkIg�.DIRECTORY_SEPARATOR.$_obf_kY_Ki4_NiIqMj5CSiIiRk48�.DIRECTORY_SEPARATOR."z_datawin.php" ) );
            $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = $_obf_kY_Ki4_NiIqMj5CSiIiRk48�;
            $_obf_ioyNhoyGk5GGlY6UjomGhoo� = @file_get_contents( KSSINCDIR."_config.php" );
            $_obf_ioyNhoyGk5GGlY6UjomGhoo� = preg_replace( "/define\\('ADMINFOLDER','[^']*'\\)/i", "define('ADMINFOLDER','".$_obf_j4eSkIiSiZCRh4_NiYaQkYk�."')", $_obf_ioyNhoyGk5GGlY6UjomGhoo� );
            @file_put_contents( KSSINCDIR."_config.php", $_obf_ioyNhoyGk5GGlY6UjomGhoo� );
            closedir( $_obf_iJKKiouRh4qTh4eMiZSSlYk� );
        }
    }
    return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
}

function _obf_jY_QjpOPk46MkoqNlZCQiJU�( $_obf_jY6MlYuNjIiIj4uKkJKOjZQ� = "K" )
{
    list( $_obf_lZKQjYaMioqRkY2GjIyIiYg�, $_obf_kZKGjYeUiY6VhoaGi5CUkZE� ) = explode( " ", microtime( ) );
    return $_obf_jY6MlYuNjIiIj4uKkJKOjZQ�.substr( date( "ymdHis" ), 1 ).substr( $_obf_lZKQjYaMioqRkY2GjIyIiYg�, 2, 6 )._obf_iI6QhpSTiJCJiI_KlYePlZI�( 6 );
}

function _obf_hoaMjI_TjpOThpKLi5WVjYo�( $_obf_kY2VkYmHjYaLhpKTiJKHioo�, $_obf_lYeSkIeGiYmPiZKGlIyVlIo� = 1 )
{
    $_obf_komNlJORioqPkZWTlJSVk4w� = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    $_obf_lZCGkY_HkY_SiI2NkIqKjYk� = "";
    do
    {
        $_obf_lZCGkY_HkY_SiI2NkIqKjYk� = $_obf_komNlJORioqPkZWTlJSVk4w�[$_obf_kY2VkYmHjYaLhpKTiJKHioo� % 52].$_obf_lZCGkY_HkY_SiI2NkIqKjYk�;
        $_obf_kY2VkYmHjYaLhpKTiJKHioo� = intval( $_obf_kY2VkYmHjYaLhpKTiJKHioo� / 52 );
    } while ( $_obf_kY2VkYmHjYaLhpKTiJKHioo� != 0 );
    $_obf_lZCGkY_HkY_SiI2NkIqKjYk� = _obf_iI6QhpSTiJCJiI_KlYePlZI�( 5 - strlen( $_obf_lZCGkY_HkY_SiI2NkIqKjYk� ), 1 ).$_obf_lZCGkY_HkY_SiI2NkIqKjYk�;
    if ( $_obf_lYeSkIeGiYmPiZKGlIyVlIo� == 1 )
    {
        $_obf_k4uRh4uLkIaSjIySkZOUkY8� = chr( mt_rand( 65, 90 ) );
    }
    else
    {
        $_obf_k4uRh4uLkIaSjIySkZOUkY8� = chr( mt_rand( 97, 122 ) );
    }
    $_obf_homRh5WGiYaRkpOKhpKVjoY� = array( );
    $_obf_homRh5WGiYaRkpOKhpKVjoY�[] = $_obf_k4uRh4uLkIaSjIySkZOUkY8�.$_obf_lZCGkY_HkY_SiI2NkIqKjYk�;
    $_obf_homRh5WGiYaRkpOKhpKVjoY�[] = _obf_iI6QhpSTiJCJiI_KlYePlZI�( 22 );
    return $_obf_homRh5WGiYaRkpOKhpKVjoY�;
}

function _obf_iI6QhpSTiJCJiI_KlYePlZI�( $_obf_kYeHjY_HkpWUipWIkYeMjJU�, $_obf_lIyOioeNkY6Vj4qPkJGMiJQ� = 0 )
{
    $_obf_k5SUjIqNi4yIi5KMjpCKjJE� = "";
    $_obf_h4mOjJSIkpCRh4yRho_VkIg� = 0;
    for ( ; $_obf_h4mOjJSIkpCRh4yRho_VkIg� < $_obf_kYeHjY_HkpWUipWIkYeMjJU�; ++$_obf_h4mOjJSIkpCRh4yRho_VkIg�, )
    {
        if ( defined( "KEYAZ" ) )
        {
            $_obf_jpKNkoqNiZKGlZWLipKNiJI� = mt_rand( 0, 1 );
            if ( $_obf_jpKNkoqNiZKGlZWLipKNiJI� == 1 )
            {
                $_obf_k5SUjIqNi4yIi5KMjpCKjJE� .= chr( mt_rand( 65, 90 ) );
            }
            else
            {
                $_obf_k5SUjIqNi4yIi5KMjpCKjJE� .= chr( mt_rand( 97, 122 ) );
            }
        }
        else if ( $_obf_lIyOioeNkY6Vj4qPkJGMiJQ� == 1 )
        {
            $_obf_k5SUjIqNi4yIi5KMjpCKjJE� .= mt_rand( 0, 9 );
        }
        else
        {
            $_obf_jpKNkoqNiZKGlZWLipKNiJI� = mt_rand( 0, 2 );
            if ( $_obf_jpKNkoqNiZKGlZWLipKNiJI� == 0 )
            {
                $_obf_k5SUjIqNi4yIi5KMjpCKjJE� .= mt_rand( 0, 9 );
            }
            else if ( $_obf_jpKNkoqNiZKGlZWLipKNiJI� == 1 )
            {
                $_obf_k5SUjIqNi4yIi5KMjpCKjJE� .= chr( mt_rand( 65, 90 ) );
            }
            else
            {
                $_obf_k5SUjIqNi4yIi5KMjpCKjJE� .= chr( mt_rand( 97, 122 ) );
            }
        }
    }
    $_obf_k5SUjIqNi4yIi5KMjpCKjJE� = strtr( $_obf_k5SUjIqNi4yIi5KMjpCKjJE�, "eEoO0", "iIpP8" );
    $_obf_k5SUjIqNi4yIi5KMjpCKjJE� = str_ireplace( "char", "Dhar", $_obf_k5SUjIqNi4yIi5KMjpCKjJE� );
    return $_obf_k5SUjIqNi4yIi5KMjpCKjJE�;
}

function _obf_h4uGi5CNhpOUiZCKiYyOhpA�( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� )
{
    if ( preg_match( "/^(\\d{4,4})-(\\d{2,2})-(\\d{2,2}) (\\d{2,2}):(\\d{2,2}):(\\d{2,2})\$/", $_obf_ipCJlJOSlJSQkYqNlYqKlIs� ) && strlen( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� ) == 19 )
    {
        return TRUE;
    }
    return FALSE;
}

function _obf_jZGJkpOSkY_HiY2HjY2JlIg�( $_obf_hpCTj4mKj5WSkpWPjouJkoc� = 0, $_obf_h4ySh4aGiY6QlZKUh42Jh4g� = "Y-m-d H:i:s" )
{
    if ( $_obf_hpCTj4mKj5WSkpWPjouJkoc� == 0 )
    {
        return date( $_obf_h4ySh4aGiY6QlZKUh42Jh4g� );
    }
    return date( $_obf_h4ySh4aGiY6QlZKUh42Jh4g�, $_obf_hpCTj4mKj5WSkpWPjouJkoc� );
}

function _obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� )
{
    $_obf_hpSPhpKRjpGTio2UjYaMlY0� = unpack( "C*", $_obf_ipCJlJOSlJSQkYqNlYqKlIs� );
    foreach ( $_obf_hpSPhpKRjpGTio2UjYaMlY0� as $_obf_lZGKh5OTlI6OkomMkIeRj4g� )
    {
        if ( !( $_obf_lZGKh5OTlI6OkomMkIeRj4g� < 48 ) || !( 57 < $_obf_lZGKh5OTlI6OkomMkIeRj4g� ) && !( $_obf_lZGKh5OTlI6OkomMkIeRj4g� != 45 ) )
        {
            continue;
        }
        return FALSE;
    }
    return TRUE;
}

function _obf_j5CKkY_GkomSkoaUlIuLlYk�( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� )
{
    $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = htmlspecialchars_decode( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� );
    $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = str_replace( "<", "&lt;", $_obf_ipCJlJOSlJSQkYqNlYqKlIs� );
    $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = str_replace( ">", "&gt;", $_obf_ipCJlJOSlJSQkYqNlYqKlIs� );
    $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = str_replace( YH2, "&#34;", $_obf_ipCJlJOSlJSQkYqNlYqKlIs� );
    $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = str_replace( "'", "&#39;", $_obf_ipCJlJOSlJSQkYqNlYqKlIs� );
    return $_obf_ipCJlJOSlJSQkYqNlYqKlIs�;
}

function _obf_i4mIkpOGkomKiouRhoaMh5I�( $_obf_iYyTho_HlJCOh4yRj4ePj4k�, $_obf_lIyOioeNkY6Vj4qPkJGMiJQ�, $_obf_i5CJkYuGjYuKiI2LjYuUlYg� = "sql", $_obf_koiTi5CIio6Qho_Qh5GOi4s� = "0" )
{
    $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = "";
    switch ( strtoupper( $_obf_lIyOioeNkY6Vj4qPkJGMiJQ� ) )
    {
    case "GP" :
        if ( isset( $_GET[$_obf_iYyTho_HlJCOh4yRj4ePj4k�] ) )
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_GET[$_obf_iYyTho_HlJCOh4yRj4ePj4k�];
        }
        else if ( isset( $_POST[$_obf_iYyTho_HlJCOh4yRj4ePj4k�] ) )
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_POST[$_obf_iYyTho_HlJCOh4yRj4ePj4k�];
        }
        else
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_obf_koiTi5CIio6Qho_Qh5GOi4s�;
        }
        break;
    case "PG" :
        if ( isset( $_POST[$_obf_iYyTho_HlJCOh4yRj4ePj4k�] ) )
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_POST[$_obf_iYyTho_HlJCOh4yRj4ePj4k�];
        }
        else if ( isset( $_GET[$_obf_iYyTho_HlJCOh4yRj4ePj4k�] ) )
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_GET[$_obf_iYyTho_HlJCOh4yRj4ePj4k�];
        }
        else
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_obf_koiTi5CIio6Qho_Qh5GOi4s�;
        }
        break;
    case "G" :
        if ( isset( $_GET[$_obf_iYyTho_HlJCOh4yRj4ePj4k�] ) )
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_GET[$_obf_iYyTho_HlJCOh4yRj4ePj4k�];
        }
        else
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_obf_koiTi5CIio6Qho_Qh5GOi4s�;
        }
        break;
    case "P" :
        if ( isset( $_POST[$_obf_iYyTho_HlJCOh4yRj4ePj4k�] ) )
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_POST[$_obf_iYyTho_HlJCOh4yRj4ePj4k�];
        }
        else
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_obf_koiTi5CIio6Qho_Qh5GOi4s�;
        }
        break;
    case "C" :
        if ( isset( $_COOKIE[$_obf_iYyTho_HlJCOh4yRj4ePj4k�] ) )
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_COOKIE[$_obf_iYyTho_HlJCOh4yRj4ePj4k�];
        }
        else
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_obf_koiTi5CIio6Qho_Qh5GOi4s�;
            break;
        }
    default :
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_obf_iYyTho_HlJCOh4yRj4ePj4k�;
    }
    if ( is_array( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� ) )
    {
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = implode( ",", $_obf_ipCJlJOSlJSQkYqNlYqKlIs� );
    }
    if ( get_magic_quotes_gpc( ) )
    {
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = stripslashes( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� );
    }
    switch ( strtolower( $_obf_i5CJkYuGjYuKiI2LjYuUlYg� ) )
    {
    case "sqljs" :
        if ( !preg_match( "/s\\s*c\\s*r\\s*i\\s*p\\s*t|<.*?>|select|insert|update|delete |union|into|load_file|outfile|char|0x[0-9a-f]{6}|\\.\\/|\\/\\*|'/i", $_obf_ipCJlJOSlJSQkYqNlYqKlIs� ) )
        {
            break;
        }
        ob_clean( );
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = preg_replace( "/(s\\s*c\\s*r\\s*i\\s*p\\s*t|<.*?>|select|insert|update|delete |union|into|load_file|outfile|char|0x[0-9a-f]{6}|\\.\\/|\\*|')/i", "<font color=red>\$1</font>", $_obf_ipCJlJOSlJSQkYqNlYqKlIs� );
        _obf_kYyOhouLjo2Gh4eNj4iQlIg�( "信息部份有禁止使用的字符串".$_obf_iYyTho_HlJCOh4yRj4ePj4k�.",".$_obf_ipCJlJOSlJSQkYqNlYqKlIs� );
        break;
    case "sql" :
        if ( !preg_match( "/select|insert|update|delete |union|into|load_file|outfile|char|0x[0-9a-f]{6}|\\.\\/|\\/\\*|'/i", $_obf_ipCJlJOSlJSQkYqNlYqKlIs� ) )
        {
            break;
        }
        ob_clean( );
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = preg_replace( "/(select|insert|update|delete |union|into|load_file|outfile|char|0x[0-9a-f]{6}|\\.\\/|\\*|')/i", "<font color=red>\$1</font>", $_obf_ipCJlJOSlJSQkYqNlYqKlIs� );
        exit( "<p>MySQL injection:".$_obf_lIyOioeNkY6Vj4qPkJGMiJQ�.",".$_obf_iYyTho_HlJCOh4yRj4ePj4k�.",".$_obf_ipCJlJOSlJSQkYqNlYqKlIs�."</p>" );
    case "int" :
        if ( _obf_kZKMiI2OlY6Ih42OkI6Sjo0�( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� ) )
        {
            break;
        }
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_obf_koiTi5CIio6Qho_Qh5GOi4s�;
        break;
    case "num" :
        if ( _obf_i46Ti46MkZCVkYaOkYmVi4w�( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� ) )
        {
            break;
        }
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_obf_koiTi5CIio6Qho_Qh5GOi4s�;
        break;
    case "time" :
        if ( !_obf_h4uGi5CNhpOUiZCKiYyOhpA�( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� ) )
        {
            $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = $_obf_koiTi5CIio6Qho_Qh5GOi4s�;
        }
        if ( !( $_obf_ipCJlJOSlJSQkYqNlYqKlIs� == "0" ) )
        {
            break;
        }
        $_obf_ipCJlJOSlJSQkYqNlYqKlIs� = "2000-01-01 00:00:00";
    }
    return $_obf_ipCJlJOSlJSQkYqNlYqKlIs�;
}

function _obf_i46Ti46MkZCVkYaOkYmVi4w�( $_obf_lImSkomRk4uRjJGSkZWJh4k� )
{
    if ( $_obf_lImSkomRk4uRjJGSkZWJh4k� == "" )
    {
        return FALSE;
    }
    if ( preg_match( "/^-{0,1}[0-9]*[\\.]{0,1}[0-9]*\$/i", $_obf_lImSkomRk4uRjJGSkZWJh4k�, $_obf_i4_Kj5CPh4qKkYyHj42Qkoc� ) )
    {
        return TRUE;
    }
    return FALSE;
}

function _obf_iIuRj5CUkIuHi4mPkY2Vio0�( $_obf_i4uIiouJjZGHlJWTlJSLipA� = 0 )
{
    if ( !empty( $_obf_jY_KhpWMlYuJkpGIi4uRjpI� ) )
    {
        if ( if ( !empty( $_obf_jY_KhpWMlYuJkpGIi4uRjpI� ) )
 )
        {
            return $_obf_jY_KhpWMlYuJkpGIi4uRjpI�;
        }
        return $_obf_koeHlJCLj4mLiYmRhpWUj5I�;
    }
    $_obf_jY_KhpWMlYuJkpGIi4uRjpI� = user_ext_getip( );
    if ( 7 < strlen( $_obf_jY_KhpWMlYuJkpGIi4uRjpI� ) )
    {
        if ( $_obf_i4uIiouJjZGHlJWTlJSLipA� == 1 )
        {
            $_obf_koeHlJCLj4mLiYmRhpWUj5I� = bindec( decbin( ip2long( $_obf_jY_KhpWMlYuJkpGIi4uRjpI� ) ) );
            return $_obf_koeHlJCLj4mLiYmRhpWUj5I�;
        }
        return $_obf_jY_KhpWMlYuJkpGIi4uRjpI�;
    }
    $_obf_lZKSjIqVh4iKjYiTiJCVlJU� = isset( $_SERVER['HTTP_CLIENT_IP'] ) && $_SERVER['HTTP_CLIENT_IP'] != "" ? $_SERVER['HTTP_CLIENT_IP'] : FALSE;
    $_obf_komJlIiMioyGkZWNkpCVh44� = isset( $_SERVER['REMOTE_ADDR'] ) && $_SERVER['REMOTE_ADDR'] != "" ? $_SERVER['REMOTE_ADDR'] : FALSE;
    $_obf_k5CMh46Ri4iTlY_Vj4uJk40� = isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) && $_SERVER['HTTP_X_FORWARDED_FOR'] != "" ? $_SERVER['HTTP_X_FORWARDED_FOR'] : FALSE;
    $_obf_kIaUkJSThoyUi4yVkIuOkZM� = FALSE;
    if ( $_obf_lZKSjIqVh4iKjYiTiJCVlJU� )
    {
        $_obf_kIaUkJSThoyUi4yVkIuOkZM� = $_obf_lZKSjIqVh4iKjYiTiJCVlJU�;
    }
    if ( $_obf_k5CMh46Ri4iTlY_Vj4uJk40� )
    {
        $_obf_kIaUkJSThoyUi4yVkIuOkZM� = $_obf_k5CMh46Ri4iTlY_Vj4uJk40�;
    }
    if ( strpos( $_obf_kIaUkJSThoyUi4yVkIuOkZM�, "," ) !== FALSE )
    {
        $_obf_jpKKko6OkZGKjoiLjpCNlI0� = explode( ",", $_obf_kIaUkJSThoyUi4yVkIuOkZM� );
        $_obf_kIaUkJSThoyUi4yVkIuOkZM� = end( &$_obf_jpKKko6OkZGKjoiLjpCNlI0� );
    }
    $_obf_jY_KhpWMlYuJkpGIi4uRjpI� = $_obf_kIaUkJSThoyUi4yVkIuOkZM� ? $_obf_kIaUkJSThoyUi4yVkIuOkZM� : $_SERVER['REMOTE_ADDR'];
    if ( !preg_match( "/^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\$/", $_obf_jY_KhpWMlYuJkpGIi4uRjpI� ) )
    {
        $_obf_jY_KhpWMlYuJkpGIi4uRjpI� = "0.0.0.0";
    }
    if ( $_obf_i4uIiouJjZGHlJWTlJSLipA� == 1 )
    {
        $_obf_koeHlJCLj4mLiYmRhpWUj5I� = bindec( decbin( ip2long( $_obf_jY_KhpWMlYuJkpGIi4uRjpI� ) ) );
        return $_obf_koeHlJCLj4mLiYmRhpWUj5I�;
    }
    return $_obf_jY_KhpWMlYuJkpGIi4uRjpI�;
}

function _obf_kpCOhomRj5CHh5SLjZKIi4Y�( $_obf_jJWMiJWJjoyIkYmLjY6VipM�, $_obf_jpKPlJSUiZOHkYaPlIeOiY4� )
{
    preg_match_all( "/./us", $_obf_jJWMiJWJjoyIkYmLjY6VipM�, $_obf_i4eRk5OHhpONhpWMjpCRlZI� );
    $_obf_j4eSkIiSiZCRh4_NiYaQkYk� = "";
    foreach ( $_obf_i4eRk5OHhpONhpWMjpCRlZI�[0] as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
    {
        if ( !( $_obf_koiIh4mRlJKGlIiGiJCUkI4� < $_obf_jpKPlJSUiZOHkYaPlIeOiY4� ) )
        {
            break;
        }
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= $_obf_lYeSkY6Th5SOlYuHjZGVio8�;
    }
    if ( $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < count( $_obf_i4eRk5OHhpONhpWMjpCRlZI�[0] ) )
    {
        $_obf_j4eSkIiSiZCRh4_NiYaQkYk� .= "…";
    }
    return $_obf_j4eSkIiSiZCRh4_NiYaQkYk�;
}

function _obf_ioeJkYuOkIeLk4eLjJKSlYs�( &$_obf_jIiQlIiOi5OIkJOLipSVhoc�, $_obf_lIiOkpGGhpSVlYmRjIeUiZE� )
{
    $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_jIiQlIiOi5OIkJOLipSVhoc�;
    $_obf_jIiQlIiOi5OIkJOLipSVhoc� = chr( 123 ).chr( 158 ).mt_rand( );
    $_obf_iZCGk4uKkImIjoaQipGLioc� = array_search( $_obf_jIiQlIiOi5OIkJOLipSVhoc�, get_defined_vars( ), TRUE );
    if ( $_obf_iZCGk4uKkImIjoaQipGLioc� != $_obf_lIiOkpGGhpSVlYmRjIeUiZE� )
    {
        file_put_contents( "/kss_api/db.log", "DBCONFIGNAME  --  ".$_obf_iZCGk4uKkImIjoaQipGLioc�."\r\n\r\n\r\n", FILE_APPEND );
    }
    if ( $_obf_iZCGk4uKkImIjoaQipGLioc� != $_obf_lIiOkpGGhpSVlYmRjIeUiZE� && mt_rand( 1, 3 ) != 2 )
    {
        $_obf_jIiQlIiOi5OIkJOLipSVhoc� = $_obf_lY6RhpOJh46VkJOGkoeRiIY�;
    }
}

function _obf_ioqHi5WHiJKIkoeIhouHjYw�( $_obf_jJWMiJWJjoyIkYmLjY6VipM� = NULL )
{
    preg_match_all( "/./us", $_obf_jJWMiJWJjoyIkYmLjY6VipM�, $_obf_i4eRk5OHhpONhpWMjpCRlZI� );
    return count( $_obf_i4eRk5OHhpONhpWMjpCRlZI�[0] );
}

function _obf_hpSOjImTiIuPiJKUjoaKjpA�( $_obf_iYmKi4mIjIyJkY_Sk5CGk4c�, $_obf_kYeOjpKGlJWMjouQkomIj5E� = "GBK", $_obf_jYyLiIiLhomJko6HkIyRkoc� = "utf-8" )
{
    $_obf_lY6SjoiTkoqJiIyVlJWHkpA� = "";
    if ( function_exists( "mb_convert_encoding" ) )
    {
        $_obf_k5SUjIqNi4yIi5KMjpCKjJE� = mb_convert_encoding( $_obf_iYmKi4mIjIyJkY_Sk5CGk4c�, $_obf_jYyLiIiLhomJko6HkIyRkoc�, $_obf_kYeOjpKGlJWMjouQkomIj5E� );
        return $_obf_k5SUjIqNi4yIi5KMjpCKjJE�;
    }
    if ( function_exists( "iconv" ) )
    {
        $_obf_k5SUjIqNi4yIi5KMjpCKjJE� = iconv( $_obf_kYeOjpKGlJWMjouQkomIj5E�, $_obf_jYyLiIiLhomJko6HkIyRkoc�, $_obf_iYmKi4mIjIyJkY_Sk5CGk4c� );
        return $_obf_k5SUjIqNi4yIi5KMjpCKjJE�;
    }
    exit( "sorry, you have no libs support for charset change." );
}

function _obf_kYyOhouLjo2Gh4eNj4iQlIg�( $_obf_kZGJho2VkZWGkZWJkYyHjoY�, $_obf_jI6Sko6Si5GPiIqJjpWMkoo� = 0, $_obf_kpOOiZSJkYqHh4uThpOKjos� = "" )
{
    global $_obf_iY6Gi4qJipOUiImLlY2Rj48�;
    if ( empty( $_obf_iY6Gi4qJipOUiImLlY2Rj48� ) )
    {
        ob_clean( );
    }
    $_obf_lIiKi4mHiYaPj5OGkJKJkIo� = _obf_i4mIkpOGkomKiouRhoaMh5I�( "isajax", "pg", "int", 0 );
    if ( $_obf_lIiKi4mHiYaPj5OGkJKJkIo� == 0 )
    {
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n<html>\r\n<head>\r\n<title>MsgBox</title>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo INSTALLPATH;
        echo "kss_inc/style/admin_style.css\">\r\n</head>\r\n<body>\r\n<div id=\"errbox\">&nbsp;";
        echo $_obf_kZGJho2VkZWGkZWJkYyHjoY�."<br><br>";
        if ( $_obf_jI6Sko6Si5GPiIqJjpWMkoo� == 1 )
        {
            echo "<p align=center><input type='button' class='submitbtn' value='返回' onclick='history.go(-1)'></p>";
        }
        echo "</div>\r\n</body>\r\n</html>";
        exit( );
    }
    exit( $_obf_kZGJho2VkZWGkZWJkYyHjoY� );
}

function _obf_j5SMi5KSiouIj4iIipWIkIs�( $_obf_kpKOiYmNj4eMjYmOkImMjoc�, $_obf_iouGh4aRkYmSioiOlImUio4�, $_obf_iY_Nj4_Gko6Mh42Ki4aIj4k� = 25 )
{
    if ( _obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_init" ) )
    {
    }
    if ( !_obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_exec" ) )
    {
        return "curlerr:php not curl";
    }
    if ( !_obf_ipWHiIuOiYuPjIaPkZSThok�( "curl_exec" ) )
    {
        return "curlerr:curl_exec disable";
    }
    $_obf_joiNh4aIhouViZGQho_JiI4� = curl_init( );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_URL, $_obf_kpKOiYmNj4eMjYmOkImMjoc� );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_RETURNTRANSFER, 1 );
    if ( !empty( $_obf_iouGh4aRkYmSioiOlImUio4� ) )
    {
        $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� = "";
        foreach ( $_obf_iouGh4aRkYmSioiOlImUio4� as $_obf_koiIh4mRlJKGlIiGiJCUkI4� => $_obf_lYeSkY6Th5SOlYuHjZGVio8� )
        {
            $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� .= $_obf_koiIh4mRlJKGlIiGiJCUkI4�."=".$_obf_lYeSkY6Th5SOlYuHjZGVio8�."&";
        }
        $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� .= "nowtime=".time( );
        curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_POST, 1 );
        curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_POSTFIELDS, $_obf_hoeUj5OSh5CMlI2Qh42Ijoc� );
    }
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_TIMEOUT, $_obf_iY_Nj4_Gko6Mh42Ki4aIj4k� );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)" );
    curl_setopt( $_obf_joiNh4aIhouViZGQho_JiI4�, CURLOPT_HTTPHEADER, array( "Accept-Language: zh-cn", "Connection: Keep-Alive", "Cache-Control: no-cache" ) );
    $_obf_lJCJh4yIiZSPi5WUko2Nh4g� = curl_exec( $_obf_joiNh4aIhouViZGQho_JiI4� );
    if ( curl_errno( $_obf_joiNh4aIhouViZGQho_JiI4� ) )
    {
        $_obf_jJWVlI2Kh4uIkouNkI6QkoY� = curl_error( $_obf_joiNh4aIhouViZGQho_JiI4� );
        curl_close( $_obf_joiNh4aIhouViZGQho_JiI4� );
        if ( $_obf_iY_Nj4_Gko6Mh42Ki4aIj4k� == 1 && stripos( $_obf_jJWVlI2Kh4uIkouNkI6QkoY�, "peration timed out after" ) )
        {
            return "sendok";
        }
        $_obf_lJCJh4yIiZSPi5WUko2Nh4g� = "curlerr:".$_obf_jJWVlI2Kh4uIkouNkI6QkoY�;
        return $_obf_lJCJh4yIiZSPi5WUko2Nh4g�;
    }
    curl_close( $_obf_joiNh4aIhouViZGQho_JiI4� );
    return $_obf_lJCJh4yIiZSPi5WUko2Nh4g�;
}

function _obf_h4aIlI6QlYmUkY6MlI6Qhos�( $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�, $_obf_jpCKlY6RkYuPkoyHlJKMios�, $_obf_kouViYyOlJWMkpSKkpGSlJE�, $_obf_lY_TjZOSjouUj5SUj42Hjow� )
{
    $_obf_jpKUipCPlZSHlYuJjYaUlZE� = KSSLOGDIR."query_errlog.php";
    if ( !is_file( $_obf_jpKUipCPlZSHlYuJjYaUlZE� ) && 262144 < filesize( $_obf_jpKUipCPlZSHlYuJjYaUlZE� ) )
    {
        $_obf_ipWMho2NlI2MiI_MioeTlZI� = "?";
        $_obf_ipCIiZCRiYmKhpOSi4eSjZI� = "<".$_obf_ipWMho2NlI2MiI_MioeTlZI�."php exit('Access denied to view this page!');".$_obf_ipWMho2NlI2MiI_MioeTlZI�.">\r\n";
        @file_put_contents( $_obf_jpKUipCPlZSHlYuJjYaUlZE�, $_obf_ipCIiZCRiYmKhpOSi4eSjZI�.$_obf_i4qPjo_Oj5GJiIyIi4qKh5U�."\r\n file:".@basename( $_obf_kouViYyOlJWMkpSKkpGSlJE� )."\tline:".$_obf_lY_TjZOSjouUj5SUj42Hjow�."\terr:".$_obf_jpCKlY6RkYuPkoyHlJKMios�."\r\n\r\n" );
    }
    else
    {
        @file_put_contents( $_obf_jpKUipCPlZSHlYuJjYaUlZE�, $_obf_i4qPjo_Oj5GJiIyIi4qKh5U�."\r\n file:".@basename( $_obf_kouViYyOlJWMkpSKkpGSlJE� )."\tline:".$_obf_lY_TjZOSjouUj5SUj42Hjow�."\terr:".$_obf_jpCKlY6RkYuPkoyHlJKMios�."\r\n\r\n", FILE_APPEND );
    }
}

function _obf_jZORjImLjIeVj5WUiI2Lk4w�( $_obf_k4uOiIuPjpWSlYmOk5CMhoo�, $_obf_lIyUkIaVk46LiZCNipOIkJA�, $_obf_h4ySh4aGiY6QlZKUh42Jh4g� )
{
    if ( $_obf_h4ySh4aGiY6QlZKUh42Jh4g� == "decode" )
    {
        $_obf_lIyUkIaVk46LiZCNipOIkJA� = base64_decode( $_obf_lIyUkIaVk46LiZCNipOIkJA� );
    }
    $_obf_koiIh4mRlJKGlIiGiJCUkI4�[] = "";
    $_obf_iI_MjYmLiomOiZGTkJOPk5A�[] = "";
    $_obf_lI6GkY6IjYyRk5OPiIeUj5A� = strlen( $_obf_k4uOiIuPjpWSlYmOk5CMhoo� );
    $_obf_k42VlIuTipSPkI6HlYaRi4g� = strlen( $_obf_lIyUkIaVk46LiZCNipOIkJA� );
    $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 256; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
    {
        $_obf_koiIh4mRlJKGlIiGiJCUkI4�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] = ord( $_obf_k4uOiIuPjpWSlYmOk5CMhoo�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4� % $_obf_lI6GkY6IjYyRk5OPiIeUj5A�] );
        $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] = $_obf_jpKPlJSUiZOHkYaPlIeOiY4�;
    }
    $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < 256; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
    {
        $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = ( $_obf_jIiLiYiQj5CSk5KRjJSGjYw� + $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] + $_obf_koiIh4mRlJKGlIiGiJCUkI4�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] ) % 256;
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�];
        $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] = $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw�];
        $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw�] = $_obf_lY6RhpOJh46VkJOGkoeRiIY�;
    }
    $_obf_iI6MiZSQhpGSjYyIlJCIi48� = "";
    $_obf_iJSNjIuPjoqSjYyUiIyIi5A� = $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = $_obf_jpKPlJSUiZOHkYaPlIeOiY4� = 0;
    for ( ; $_obf_jpKPlJSUiZOHkYaPlIeOiY4� < $_obf_k42VlIuTipSPkI6HlYaRi4g�; ++$_obf_jpKPlJSUiZOHkYaPlIeOiY4�, )
    {
        $_obf_iJSNjIuPjoqSjYyUiIyIi5A� = ( $_obf_iJSNjIuPjoqSjYyUiIyIi5A� + 1 ) % 256;
        $_obf_jIiLiYiQj5CSk5KRjJSGjYw� = ( $_obf_jIiLiYiQj5CSk5KRjJSGjYw� + $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_iJSNjIuPjoqSjYyUiIyIi5A�] ) % 256;
        $_obf_lY6RhpOJh46VkJOGkoeRiIY� = $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_iJSNjIuPjoqSjYyUiIyIi5A�];
        $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_iJSNjIuPjoqSjYyUiIyIi5A�] = $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw�];
        $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw�] = $_obf_lY6RhpOJh46VkJOGkoeRiIY�;
        $_obf_lIeHkoeKkpOSiomPi4mQk5E� = $_obf_iI_MjYmLiomOiZGTkJOPk5A�[( $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_iJSNjIuPjoqSjYyUiIyIi5A�] + $_obf_iI_MjYmLiomOiZGTkJOPk5A�[$_obf_jIiLiYiQj5CSk5KRjJSGjYw�] ) % 256];
        $_obf_iI6MiZSQhpGSjYyIlJCIi48� .= chr( ord( $_obf_lIyUkIaVk46LiZCNipOIkJA�[$_obf_jpKPlJSUiZOHkYaPlIeOiY4�] ) ^ $_obf_lIeHkoeKkpOSiomPi4mQk5E� );
    }
    if ( $_obf_h4ySh4aGiY6QlZKUh42Jh4g� == "encode" )
    {
        $_obf_iI6MiZSQhpGSjYyIlJCIi48� = base64_encode( $_obf_iI6MiZSQhpGSjYyIlJCIi48� );
    }
    return $_obf_iI6MiZSQhpGSjYyIlJCIi48�;
}

require( KSSINCDIR."ext_ip.php" );
$_obf_i4yQhoyIkoiSkJONjImJjZM� = "dbconfig";
_obf_ioeJkYuOkIeLk4eLjJKSlYs�( $_obf_mGKRY4dMuU6bZZJfh1_TX5k�, $_obf_i4yQhoyIkoiSkJONjImJjZM� );
?>
