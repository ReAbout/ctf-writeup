<?php

$_obf_joeVho6Tj4mQlJKKiI_LkJM� = 0;
define( "SALESTART", 1 );
require( "./kss_inc/inc.php" );
require( "./kss_inc/sale.php" );
?>
