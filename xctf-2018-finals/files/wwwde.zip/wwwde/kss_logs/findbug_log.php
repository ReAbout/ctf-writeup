<?php

echo "﻿";
exit( "Access denied to view this page!" );
?>
