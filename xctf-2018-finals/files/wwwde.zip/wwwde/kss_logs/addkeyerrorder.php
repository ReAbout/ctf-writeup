<?php

exit( "Access denied to view this page!" );
?>
