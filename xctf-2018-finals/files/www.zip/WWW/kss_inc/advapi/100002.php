<?php defined('YH2') or exit('Access denied to view this page!');
//$data源数据，对输出到客户端的数据进行自定义加密,以下是例子里相对应的加密方法
function __myEncrypt($data){
	if(isset($_GET['r'])){		//为不支持RSA的客户端语言写的例子 set命令有设置rsa单元的话就会有$_GET['r']变量
		$rc4密钥2 = _rs(2);
		$rc4密钥3 = _rs(3);		
		$rc4加密 = rc4byte($rc4密钥2,$data);	
		$rc4加密 = rc4byte($rc4密钥3,$rc4加密);
		$base64编码数据 = base64_encode($rc4加密);   //必须base64_encode
		return $base64编码数据;
	}else{
		$rc4密钥 = _rs(2);     //make_key();	//生成随机字符串
		$rsa加密的rc4密钥 = encode_rsa2(_rs(1),$rc4密钥);
		$加密后的数据 = base64_encode(rc4byte($rc4密钥,$data));   //加密后最好base64_encode一下	
		$返回数据 = $rsa加密的rc4密钥 . ',' . $加密后的数据;
		return $返回数据;		
	}
}

//如果软件基本设置里的返回信息为A为空，并且本函数存在，客户端取得的返回信息A将是此函数返回的值
function ab_a(){
	return '返回信息为A';
}

//如果软件基本设置里的返回信息为B为空，并且本函数存在，客户端取得的返回信息B将是此函数返回的值
function ab_b(){
	return '返回信息为B';
}

//扣点接口advapi("v_points,要扣的点数")
function v_points($points,$sysguid){	 //第一个参数是要扣的点数，第二个参数是系统自动附加的参数  	
	$errinfo = '';
	$rt = api_points($errinfo,$points,$sysguid);
	if($rt !== false){
		//扣点成功
		return $rt;
	}else{
		//扣点失败，返回失败信息
		return $errinfo;
	}
}
//以上都是系统的关键接口，不可以删除

//下边你可以自由添加自己的接口定义
//例子1：这个是最简单的advapi接口，只有接口名无参数 【advapi("v_geta")】
function v_geta(){
	return 'v_geta的返回数据';
}

//例子2：这个是带参数的接口， 接口名后有2个参数 【advapi("v_getb,100,200") 第一个是函数名，后边的两个才是参数】
function v_getb($val1,$val2){
	return $val1 + $val2;   //对传递过来的参数进行简单的加法运算
}
?>