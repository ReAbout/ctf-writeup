<?php defined('YH2') or exit('Access denied to view this page!');
define('SOFTRSAMODE',0); define('SOFTRSAEKEY','');  define('SOFTRSANKEY','');
?>