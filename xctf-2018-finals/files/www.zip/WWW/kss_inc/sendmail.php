<?php

function kk_sendmail($title,$body,$to,$frommail,$frommailpassword,$remoteapi='',$Attachment=''){
	if(SENDMAILMODE==1 || $Attachment!=''){
		return bak_sendmail($title,$body,$to,$frommail,$frommailpassword,$remoteapi='',$Attachment='');		
	}else{
		return '�ʼ����͹��ܹر�';
	}
}

function bak_sendmail($title,$body,$to,$frommail,$frommailpassword,$remoteapi='',$Attachment=''){
	if(preg_match('/^(.*)@(.*)$/i', $frommail,$matches)){
		if(strtolower($matches[2])=='qq.com'){
			$frommail=$matches[1].'@SSL465.qq.com';
		}
	}
			
	if(preg_match('/^(.*)@(SSL)(\d*)\.(.*)$/i', $frommail,$matches)){
		$v_smtpsvr='smtp.'.$matches[4];
		$v_for=$matches[1].'@'.$matches[4];
		$v_port=$matches[3];
		$v_ssl=true;
	}else{
		$matches=explode('@',$frommail);
		$v_smtpsvr='smtp.'.$matches[1];
		$v_for=$frommail;
		$v_port=25;
		$v_ssl=false; 		
	}	
	if(function_exists('fsockopen')){	
        include_once KSSINCDIR.'class.smtp.php';	
		include_once KSSINCDIR.'class.phpmailer.php';
        
		$mail  = new PHPMailer();
		$mail->PluginDir  = KSSINCDIR;
		$mail->IsSMTP();
		$mail->SMTPAuth   = true;                  //# enable SMTP authentication
		$mail->Host 	= $v_smtpsvr;      //# sets GMAIL as the SMTP server
		if($v_ssl==true)
		$mail->SMTPSecure = "ssl"; // sets the prefix to the servier
		$mail->Port       = $v_port;                   //# set the SMTP port for the GMAIL server
		$mail->Username   = $v_for;  //# GMAIL username
		$mail->Password   = $frommailpassword;            //# GMAIL password	 
		$mail->From       = $v_for;
		$mail->FromName   = $v_for;
		$mail->Subject    = $title;
		$mail->MsgHTML($body);
		$mail->AddAddress($to,$to);
		if($Attachment!='')
			$mail->AddAttachment($Attachment); //# ���Ӹ���
		$mail->IsHTML(true); 
		$result=$mail->Send();
		if($result!==true)
			$result=$mail->ErrorInfo;
		return $result;		
	}elseif(extension_loaded('sockets')){
		include_once KSSINCDIR.'class.mail.php';
	
		$mail  = new MySendMail();		
		$mail->setServer($v_smtpsvr, $v_for, $frommailpassword,$v_port,$v_ssl); 		//����smtp���������ӷ�ʽ
		$mail->setFrom($v_for); //���÷�����
		$mail->setReceiver($to); //�����ռ���
		if($Attachment!='')
			$mail->addAttachment($Attachment); //# ���Ӹ���
		$mail->setMail($title, $body); 			//�����ʼ����⡢����
		$result=$mail->sendMail(); 				//����
		if($result!==true)
			$result=$mail->error();
		return $result;
	}
}


?>
