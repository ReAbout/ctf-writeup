<?php
//用户自定义的取IP函数，失败或出错请一定返回 0.0.0.0 
function user_ext_getip(){
	return '0.0.0.0';
}
?>