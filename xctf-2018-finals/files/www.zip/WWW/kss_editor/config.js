﻿CKEDITOR.editorConfig = function( config )
{
	config.language = 'zh-cn';
	config.skin='kama';
	config.width='745'

};
